package com.tjmedia.tdmk.cameramovietest;



import java.util.ArrayList;


import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.Toast;



public class CameraMovieTestActivity extends Activity implements OnClickListener {
    /** Called when the activity is first created. */
	private static final String TAG_LOG = "CameraMovieTestActivity";
	SurfaceView mCameraview;
	SurfaceHolder previewHolder;	
	Camera mCamera = null;	
	Button btnTopMovie; 
	Button btnTopCamera;
    Button btnVideoRec;
    Button btnSnapShot;
    Button btnViewChange;
    Button btnViewAutoChange;
    Button btnExit;
	int mFrameWidth;
	int mFrameHeight;
	
	Toast mToast;
	DrawLoopHandler mDrawhandler = null;
	PowerManager mPowerManager = null;
	WakeLock mWakeLock = null;
	Window ct;
	MovView mMediaPlayer;
	LinearLayout mMediaLayout;
	LinearLayout mCameraLayout;
	LinearLayout mButtonLayout;
	int mViewChangeCount = 0;
	int mViewPos = 0;
	TJCameraView mPreview;
	FrameLayout frame;
	private String DEFAULT_URI_1;
	private String DEFAULT_URI_2; 
	
	boolean Camerafull = false; 
	boolean Mediafull = false;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	Log.d(TAG_LOG, "============= TMFP.onCreate =============");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);        

        DEFAULT_URI_1 = "android.resource://" + this.getPackageName()+"/"+R.raw.test1;    	
        			
		mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = mPowerManager.newWakeLock(
				PowerManager.SCREEN_BRIGHT_WAKE_LOCK, getClass().getName());	
		
		if (null != mWakeLock)
		{
			mWakeLock.acquire();
		}
       CameraView(this.getApplicationContext());

    }
    @Override
    protected void onResume() {
    	// TODO Auto-generated method stub
    	Log.d(TAG_LOG, "============= TMFP.onResume =============");
    	super.onResume();
    }
    
    @Override
    protected void onStart() {
    	// TODO Auto-generated method stub
    	Log.d(TAG_LOG, "============= TMFP.onStart =============");
    	super.onStart();
    }
    
    @Override
    protected void onStop() {
    	// TODO Auto-generated method stub
    	Log.d(TAG_LOG, "============= TMFP.onStop =============");
    	super.onStop();
    }
    
    @Override
    protected void onPause() {
    	// TODO Auto-generated method stub
    	Log.d(TAG_LOG, "============= TMFP.onPause =============");
//    	if (null != mDrawhandler)
//    	{
//    		mDrawhandler.stop();
//    		mDrawhandler = null;
//    	}
    	super.onPause();
    }
    
    @Override
    protected void onDestroy() 
    {
    	Log.d(TAG_LOG, "============= TMFP.onDestroy =============");
    	if (null != mWakeLock)
    	{
	    	mCamera.release();
	    	mCamera = null;
    	}
    	if (null != mWakeLock)
    	{
    		mWakeLock.release();
    	}
    	super.onDestroy();
    };    

	public void CameraView(Context ctx)
	{
        frame = new FrameLayout(this);
		mFrameWidth = getWindowManager().getDefaultDisplay().getWidth();
		mFrameHeight = getWindowManager().getDefaultDisplay().getHeight() - 50;
                                       
        mButtonLayout = new LinearLayout(frame.getContext());
        LinearLayout.LayoutParams linearParam = 
        		new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);
        mButtonLayout.setLayoutParams(linearParam);
        

        mMediaLayout = new LinearLayout(frame.getContext());
        LinearLayout.LayoutParams linearParam2 = 
        		new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);
        mMediaLayout.setLayoutParams(linearParam2);
    
        mCameraLayout = new LinearLayout(frame.getContext());
        LinearLayout.LayoutParams linearParam3 = 
        		new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);
        mCameraLayout.setLayoutParams(linearParam3);        
        
        if (true)
        {
        	btnViewChange = new Button(mButtonLayout.getContext());
        	btnViewChange.setText("Test");
        	mButtonLayout.addView(btnViewChange,150,100);   
        	
        	btnExit = new Button(mButtonLayout.getContext());
        	btnExit.setText("Exit");
        	mButtonLayout.addView(btnExit,150,100);   
        	
//        	btnViewAutoChange = new Button(mButtonLayout.getContext());
//        	btnViewAutoChange.setText("AutoMove");
//        	mButtonLayout.addView(btnViewAutoChange,150,100);            	

        	
        	
	        mMediaPlayer = new MovView(mMediaLayout.getContext());
	        
	        playvideo(0);
	        
			mMediaPlayer.setVisibility(View.VISIBLE);
			mMediaPlayer.setOnPreparedListener(mOnPreparedListener);
			mMediaPlayer.setOnCompletionListener(mOnCompleteListener);			
			mMediaLayout.addView(mMediaPlayer.getLayout(), 640,360);
					    
			
			mCamera = TJCameraView.getCameraInstance();
			mPreview = new TJCameraView(mCameraLayout.getContext(), mCamera);
			mCameraLayout.addView(mPreview, 640,480);
			
			
			//Frame ( Button -> Media -> Camera )						
			frame.addView(mButtonLayout,0);
			frame.addView(mMediaLayout, 1);			
			frame.addView(mCameraLayout,2);		
			//Frame ( Button -> Camera -> Media )
//			frame.addView(mButtonLayout,0);
//			frame.addView(mCameraLayout,1);			
//			frame.addView(mMediaLayout, 2);			
					

			setContentView(frame);	        
	        
			View view = mMediaPlayer.getLayout();
			LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
			Log.d("","media w:" + params.width + "h:" + params.height );        				        		
			params.leftMargin = 640;
			view.setLayoutParams(params);
			
			frame.bringChildToFront(mButtonLayout);
					    			        	        
	        btnViewChange.setOnClickListener(new OnClickListener() {
	        	@Override
				public void onClick(View v) {	        		
	        		Draw();
	        	}
	        });
	        
	        btnExit.setOnClickListener(new OnClickListener() {
	        	@Override
				public void onClick(View v) {	        		
	        		finish();
	        	}
	        });
	        
//	        btnViewAutoChange.setOnClickListener(new OnClickListener() {
//	        	@Override
//				public void onClick(View v) {	
//	        		mDrawhandler.stop();
//	        		mDrawhandler.sleep(5000);
//	        		mDrawhandler.start();				
//
//	        	}
//	        });
	        
        }          

	}    
	
	int sel = 0;
	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		
		final int action = ev.getAction();
        int x = (int)ev.getX();
        int y = (int)ev.getY();
		Log.d(TAG_LOG, "onTouchEvent()========" + ev.getX() + "," + ev.getY());
		
        switch (action & MotionEvent.ACTION_MASK) {
        
        	case MotionEvent.ACTION_UP:
        	
					if (sel == 0)
					{
//						frame.removeView(mCameraLayout);
//						frame.removeView(mButtonLayout);
//						frame.addView(mCameraLayout);
//						frame.addView(mButtonLayout);						

						View view = mMediaPlayer.getLayout();									
						LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();							
						params.leftMargin = x - params.width/2;
						params.topMargin = y - params.height/2;
						view.setLayoutParams(params);
						
						Log.d(TAG_LOG,"Media x:" + params.leftMargin + " y:" + params.topMargin);
						sel = 1;		
					}
					else
					{						
//						frame.removeView(mMediaLayout);
//						frame.removeView(mButtonLayout);
//						frame.addView(mMediaLayout);
//						frame.addView(mButtonLayout);
						
						View pview = mPreview;
							
						LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
						
						pparams.leftMargin = x - pparams.width/2;
						pparams.topMargin = y - pparams.height/2;
						pview.setLayoutParams(pparams);
						
						Log.d(TAG_LOG,"Camera x:" + pparams.leftMargin + " y:" + pparams.topMargin);			
						sel = 0;
					}
			//		pparams.leftMargin = params.leftMargin + params.width/2;
			//		pparams.topMargin = params.topMargin + params.height/2;
			//		Log.d("","Move x:" + pparams.leftMargin + " y:" + pparams.topMargin);
					
			//		pview.setLayoutParams(pparams);	  
        }	
        try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.onTouchEvent(ev);
	}
	
	void Draw()
	{
		switch(mViewChangeCount)
		{
			case 0:
			{			
				View pview = mPreview;
				LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
				Log.d("","camera w:" + pparams.width + "h:" + pparams.height );;
				pparams.width = 640;
				pparams.height = 480;	        				        		
				pparams.leftMargin = 640;
				pparams.rightMargin = 0;
				pparams.topMargin = 360;
				pparams.bottomMargin = 0;
				pview.setLayoutParams(pparams);	     
				
				View view = mMediaPlayer.getLayout();
				LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
				Log.d("","media w:" + params.width + "h:" + params.height );
				params.width = 640;
				params.height = 360;	        				        		
				params.leftMargin = 0;
				params.topMargin = 0;
				view.setLayoutParams(params);	
				mViewChangeCount++;
			}
			break;
			
			case 1:
			{			
				View pview = mPreview;
				LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
				Log.d("","camera w:" + pparams.width + "h:" + pparams.height );;
				pparams.width = 320;
				pparams.height = 240;	        				        		
				pparams.leftMargin = 0;
				pparams.topMargin = 0;
				pview.setLayoutParams(pparams);	     
				
				View view = mMediaPlayer.getLayout();
				LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
				Log.d("","media w:" + params.width + "h:" + params.height );
				params.width = 320;
				params.height = 240;	        				        		
				params.leftMargin = 320;
				params.topMargin = 0;
				view.setLayoutParams(params);	  
				mViewChangeCount++;
			}
			break;		        		
			case 2:
			{
//				frame.removeView(mCameraLayout);
//				frame.removeView(mButtonLayout);
//				frame.addView(mCameraLayout);
//				frame.addView(mButtonLayout);
//				
				View pview = mPreview;
				LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
				Log.d("","camera w:" + pparams.width + "h:" + pparams.height );;
				pparams.width = 640;
				pparams.height = 480;	        				        		
				pparams.leftMargin = 320;		        			
				pparams.topMargin = 120;		        			
				pview.setLayoutParams(pparams);	   
				
				View view = mMediaPlayer.getLayout();
				LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
				Log.d("","media w:" + params.width + "h:" + params.height );
				params.width = 640;
				params.height = 360;	        				        		
				params.leftMargin = 480;			        		
				params.topMargin = 240;
				view.setLayoutParams(params);	 				
				mViewChangeCount++;
			}
			break;
			
			case 3:
			{
//				frame.removeView(mMediaLayout);
//				frame.removeView(mButtonLayout);
//				frame.addView(mMediaLayout);
//				frame.addView(mButtonLayout);
//				
				View pview = mPreview;
				LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
				Log.d("","camera w:" + pparams.width + "h:" + pparams.height );;
				pparams.width = 640;
				pparams.height = 480;	        				        		
				pparams.leftMargin = 480;		        			
				pparams.topMargin = 240;		        			
				pview.setLayoutParams(pparams);	   
				
				View view = mMediaPlayer.getLayout();
				LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
				Log.d("","media w:" + params.width + "h:" + params.height );
				params.width = 640;
				params.height = 360;	        				        		
				params.leftMargin = 320;			        		
				params.topMargin = 120;
				view.setLayoutParams(params);
				mViewChangeCount++;
				
			}
			break;		  
			
			case 4:
			{
//				frame.removeView(mCameraLayout);
//				frame.removeView(mButtonLayout);
//				frame.addView(mCameraLayout);
//				frame.addView(mButtonLayout);			
//				
				View pview = mPreview;
				LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
				Log.d("","camera w:" + pparams.width + "h:" + pparams.height );;
				pparams.width = mFrameWidth-320;
				pparams.height = mFrameHeight-240;	        				        		
				pparams.leftMargin = 0;		        			
				pparams.topMargin = 0;		        			
				pview.setLayoutParams(pparams);	   
				
				View view = mMediaPlayer.getLayout();
				LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
				Log.d("","media w:" + params.width + "h:" + params.height );
				params.width = 320;
				params.height = 240;	        				        		
				params.leftMargin = mFrameWidth-320;			        		
				params.topMargin = mFrameHeight-240;
				view.setLayoutParams(params);	 
				
				Camerafull = true;
				Mediafull = false;

				mViewChangeCount++;
				
			}
			break;	
			
			case 5:
			{														
//				
//				frame.removeView(mMediaLayout);
//				frame.removeView(mButtonLayout);
//				frame.addView(mMediaLayout);
//				frame.addView(mButtonLayout);
//				
				View pview = mPreview;
				LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
				Log.d("","camera w:" + pparams.width + "h:" + pparams.height );;
				pparams.width = 640;
				pparams.height = 480;	        				        		
				pparams.leftMargin = mFrameWidth-640;		        			
				pparams.topMargin = mFrameHeight-480;		        			
				pview.setLayoutParams(pparams);
								
				
				
				View view = mMediaPlayer.getLayout();
				LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
				Log.d("","media w:" + params.width + "h:" + params.height );
				params.width = mFrameWidth-640;
				params.height = mFrameHeight-480;	        				        		
				params.leftMargin = mFrameWidth-640;			        		
				params.topMargin = 0;
				view.setLayoutParams(params);
				Camerafull = false;
				Mediafull = true;
				
				mViewChangeCount++;
			}
			break;				
			
			case 6:
			{
				View pview = mPreview;
				LinearLayout.LayoutParams pparams = (LayoutParams) pview.getLayoutParams();
				Log.d("","camera w:" + pparams.width + "h:" + pparams.height );;
				pparams.width = 640;
				pparams.height = 480;	        				        		
				pparams.leftMargin = 0;
				pparams.rightMargin = 0;
				pparams.topMargin = 0;
				pparams.bottomMargin = 0;
				pview.setLayoutParams(pparams);	   
				
				View view = mMediaPlayer.getLayout();
				LinearLayout.LayoutParams params = (LayoutParams) view.getLayoutParams();
				Log.d("","media w:" + params.width + "h:" + params.height );
				params.width = 640;
				params.height = 360;	        				        		
				params.leftMargin = 640;
				params.topMargin = 0;
				view.setLayoutParams(params);	 
				mViewChangeCount = 0;
				
				mViewChangeCount = 0;
			}
			break;	
		}
		SystemClock.sleep(100);
	}

	
	public class DrawLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG_LOG, "handleMessage");
			if (bStop == false) {								
				Draw();
    			sendMessageDelayed(obtainMessage(0), 5000);
    			
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}
		
		public boolean isStoped() {
			return bStop;
		}
		
		public void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;							
		}
	};
    
	String DEFAULT_URI = null;
	String INIT_URI = null;
	String DEFAULT_DIR = null;
	ArrayList<String>	mList = new ArrayList<String>();
	int					mListCount = 0;
	
	private boolean mIsVideoSizeKnown = false;
    private boolean mIsVideoReadyToBePlayed = false;
    

	MediaPlayer.OnPreparedListener mOnPreparedListener = new OnPreparedListener() {

		@Override
		public void onPrepared(MediaPlayer arg0) {
			// TODO Auto-generated method stub
			Log.d("TJ","mOnPreparedListener++++++");
			mMediaPlayer.start();
			Log.d("TJ","mOnPreparedListener------");
		}
		
	};
			
	MediaPlayer.OnCompletionListener mOnCompleteListener = new MediaPlayer.OnCompletionListener() {
		@Override
		public void onCompletion(MediaPlayer mp) {
			// TODO Auto-generated method stub		
			Log.d("TJ","mOnCompleteListener++++++");
			stopvideo();			
			playvideo(0);
			Log.d("TJ","mOnCompleteListener------");
		}
	};
	
	
	int nextfile = 0;
	private void playvideo(int time) {
		 //try {				
				if (null != DEFAULT_DIR)
				{
					DEFAULT_URI = mList.get(mListCount);
					Log.d("test","play:" + DEFAULT_URI);	
					mMediaPlayer.setVideoPath( DEFAULT_URI ); // 動画ファイル指定
					mListCount++;
					if (mList.size() > 0 && mListCount >= mList.size())
						mListCount = 0;
					
				}
				else
				{
					mMediaPlayer.setVideoPath(DEFAULT_URI_1);
				}					 				
	}
	
	private void stopvideo() {		
	 	if (null != mMediaPlayer)
	 	{
	 		//mMediaPlayer.stopPlayback();
	 	}
	}
	
    private void releaseMediaPlayer(){
        if (mMediaPlayer != null) {
        }
    }	
    


	public void onClick(View v) {
        // TODO Auto-generated method stub
    }    
		
	public void printToast(String messageToast) {
		if (null != mToast)
			mToast.cancel();
		mToast = Toast.makeText(this, messageToast, Toast.LENGTH_LONG);
		mToast.setGravity(Gravity.CENTER,0, 0);
		mToast.show();		
	}	
	
	public boolean onKeyDown(int KeyCode, KeyEvent event) {
		Log.d(TAG_LOG, "onKeyDown()");
		Log.d(TAG_LOG, "KeyCode = " + KeyCode);
		if (KeyCode == 4) finish();
		return false;
	}
	
	
}