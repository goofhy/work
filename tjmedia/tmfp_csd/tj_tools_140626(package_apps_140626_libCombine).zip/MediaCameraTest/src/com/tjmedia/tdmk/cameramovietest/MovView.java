package com.tjmedia.tdmk.cameramovietest;

import java.io.IOException;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public class MovView implements SurfaceHolder.Callback, OnPreparedListener, OnVideoSizeChangedListener, OnCompletionListener,
		OnErrorListener, OnBufferingUpdateListener {
//	private Handler mHandler = new Handler();
	private RelativeLayout mLayout;
	private SurfaceView mSurfaceView;
	private MediaPlayer mMediaPlayer;
	private SurfaceHolder mSurfaceHolder;
	private Context mCtxt;
	private OnCompletionListener mCplLstnr;
	private OnErrorListener mErrLstnr;
	private OnPreparedListener mPrpLstnr;

	// all possible internal states
	private static final int STATE_ERROR = -1;
	private static final int STATE_IDLE = 0;
	private static final int STATE_PREPARING = 1;
	private static final int STATE_PREPARED = 2;
	private static final int STATE_PLAYING = 3;
	private static final int STATE_PAUSED = 4;
	private static final int STATE_PLAYBACK_COMPLETED = 5;
	private static final int STATE_SUSPEND = 6;
	private static final int STATE_RESUME = 7;
	private static final int STATE_SUSPEND_UNSUPPORTED = 8;

	private int mCurrentState = STATE_IDLE;
	private int mTargetState = STATE_IDLE;

	private int mVideoWidth;
	private int mVideoHeight;

	private Uri mUri;
	private int mDuration;
	private int mSeekWhenPrepared; // recording the seek position while preparing
	private boolean mCanPause;
	private boolean mCanSeekBack;
	private boolean mCanSeekForward;
//	private int mStateWhenSuspended; //state before calling suspend()
	private int mCurrentBufferPercentage;
	private int mSurfaceWidth;
	private int mSurfaceHeight;

	/**
	 * 
	 * @author HI Corp.
	 * 
	 */
	private class MySurfaceView extends SurfaceView {

		public MySurfaceView( Context context ) {
			super( context );
		}

		@Override
		protected void onMeasure( int widthMeasureSpec, int heightMeasureSpec ) {
			//Log.i("@@@@", "onMeasure");
			int width = getDefaultSize( mVideoWidth, widthMeasureSpec );
			int height = getDefaultSize( mVideoHeight, heightMeasureSpec );
			if ( mVideoWidth > 0 && mVideoHeight > 0 ) {
				if ( mVideoWidth * height > width * mVideoHeight ) {
					//Log.i("@@@", "image too tall, correcting");
					height = width * mVideoHeight / mVideoWidth;
				} else if ( mVideoWidth * height < width * mVideoHeight ) {
					//Log.i("@@@", "image too wide, correcting");
					width = height * mVideoWidth / mVideoHeight;
				} else {
					//Log.i("@@@", "aspect ratio is correct: " +
					//width+"/"+height+"="+
					//mVideoWidth+"/"+mVideoHeight);
				}
			}
			//Log.i("@@@@@@@@@@", "setting size: " + width + 'x' + height);
			setMeasuredDimension( width, height );
		}

	}

	/**
	 * 
	 * @param context
	 */
	public MovView( Context context ) {
		Log.d("TJ", "*** Constructor" );
		mVideoWidth = 0;
		mVideoHeight = 0;
		mLayout = new RelativeLayout( context );
		//mLayout.setBackgroundColor( 0x00000000 );
		mLayout.setVisibility( View.VISIBLE );
		mSurfaceView = new MySurfaceView( context );
		mSurfaceView.getHolder().setType( SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS );
		mSurfaceView.getHolder().addCallback( this );
		mSurfaceView.setVisibility( View.VISIBLE );
		mSurfaceView.setFocusable( false );
		mSurfaceView.setFocusableInTouchMode( false );
		mLayout.addView( mSurfaceView );
		mCtxt = context;
		mMediaPlayer = new MediaPlayer();
		mCurrentState = STATE_IDLE;
		mTargetState = STATE_IDLE;
	}

	/**
	 * 
	 */
	@Override
	public void surfaceChanged( SurfaceHolder holder, int format, int width, int height ) {
		Log.d("TJ", "*** surfaceChanged" );
		mSurfaceWidth = width;
		mSurfaceHeight = height;
		boolean isValidState = (mTargetState == STATE_PLAYING);
		boolean hasValidSize = (mVideoWidth == width && mVideoHeight == height);
		if ( mMediaPlayer != null && isValidState && hasValidSize ) {
			if ( mSeekWhenPrepared != 0 ) {
//				seekTo( mSeekWhenPrepared );
			}
			start();
		}
	}

	/**
	 * 
	 */
	@Override
	public void surfaceCreated( SurfaceHolder holder ) {
		Log.d("TJ", "*** surfaceCreated" );
		
		if (mSurfaceHolder != null)
		{			
			while(true)
			{
				Log.e("TJ","****************surfaceCreated========NG!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!***************");
			}
			//return;
		}
		mSurfaceHolder = holder;
		if ( mMediaPlayer != null && mCurrentState == STATE_SUSPEND && mTargetState == STATE_RESUME ) {
			mMediaPlayer.setDisplay( mSurfaceHolder );
			resume();
		} else {
			Log.d("TJ","surfaceCreated========start");
			Log.d("TJ","surfaceCreated openVideo Call!!!!!!!!");			
			openVideo();
			Log.d("TJ","surfaceCreated========end");
		}
	}

	/**
	 * 
	 */
	@Override
	public void surfaceDestroyed( SurfaceHolder holder ) {
		Log.d("TJ", "*** surfaceDestroyed" );
		
		mSurfaceHolder = null;		
		if ( mCurrentState != STATE_SUSPEND ) {
			release( true );
		}
	}

	/**
	 * 
	 * @param cleartargetstate
	 */
	private void release( boolean cleartargetstate ) {
		Log.d("TJ", "*** release(" + cleartargetstate + ")" );
		if ( mMediaPlayer == null ) return;
		purgeMediaPlayer();
		mCurrentState = STATE_IDLE;
		if ( cleartargetstate ) {
			mTargetState = STATE_IDLE;
		}
	}

	/**
	 * 
	 */
	public void stopPlayback() {
		Log.d("TJ", "*** stopPlayback" );
		if ( mMediaPlayer == null ) return;
		purgeMediaPlayer();
		mCurrentState = STATE_IDLE;
		mTargetState = STATE_IDLE;
	}

	/**
	 * 
	 */
	private void purgeMediaPlayer() {
		Log.d("TJ","purgeMediaPlayer========start");
		mMediaPlayer.setOnErrorListener( null );
		mMediaPlayer.setOnPreparedListener( null );
		mMediaPlayer.setOnVideoSizeChangedListener( null );
		mMediaPlayer.stop();
		mMediaPlayer.reset();
		mMediaPlayer.release();
		mMediaPlayer = null;
	}

	/**
	 * 
	 */
	private void openVideo() {
		Log.d("TJ", "*** openVideo / uri=" + mUri );
		if ( mUri == null || mSurfaceHolder == null ) {
			// not ready for playback just yet, will try again later
			return;
		}

		// we shouldn't clear the target state, because somebody might have
		// called start() previously
		release( false );
		try {
			Log.d("TJ","openVideo========start");
			mMediaPlayer = new MediaPlayer();
			mMediaPlayer.setOnPreparedListener( this );
			mMediaPlayer.setOnVideoSizeChangedListener( this );
			mDuration = -1;
			mMediaPlayer.setOnCompletionListener( this );
			mMediaPlayer.setOnErrorListener( this );
			mMediaPlayer.setOnBufferingUpdateListener( this );
			mCurrentBufferPercentage = 0;
			mMediaPlayer.setDataSource( mCtxt, mUri );
			mMediaPlayer.setDisplay( mSurfaceHolder );
			mMediaPlayer.setAudioStreamType( AudioManager.STREAM_MUSIC );
			mMediaPlayer.prepare();
			//Log.d("TJ","openVideo=====================================mMediaPlayer.Start!!!!!");
			//mMediaPlayer.start();
			// we don't set the target state here either, but preserve the
			// target state that was there before.
			mCurrentState = STATE_PREPARING;
			//Log.d("TJ","openVideo========end");
		} catch ( IOException ex ) {
			Log.d("TJ","Unable to open content: " + mUri, ex );
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;
			mErrLstnr.onError( mMediaPlayer, MediaPlayer.MEDIA_ERROR_UNKNOWN, 0 );
			return;
		} catch ( IllegalArgumentException ex ) {
			Log.d("TJ","Unable to open content: " + mUri, ex );
			mCurrentState = STATE_ERROR;
			mTargetState = STATE_ERROR;
			mErrLstnr.onError( mMediaPlayer, MediaPlayer.MEDIA_ERROR_UNKNOWN, 0 );
			return;
		}
	}

	/**
	 * 
	 */
	@Override
	public void onVideoSizeChanged( MediaPlayer mp, int width, int height ) {
		Log.d("TJ", "*** onVideoSizeChanged" );
		mVideoWidth = mp.getVideoWidth();
		mVideoHeight = mp.getVideoHeight();
		if ( mVideoWidth != 0 && mVideoHeight != 0 ) {			
			mSurfaceView.getHolder().setFixedSize( mVideoWidth, mVideoHeight );			
		}
	}

	/**
	 * 
	 */
	@Override
	public void onPrepared( MediaPlayer mp ) {
		Log.d("TJ", "*** onPrepared" );
		mCurrentState = STATE_PREPARED;

		mCanPause = mCanSeekBack = mCanSeekForward = true;

		mVideoWidth = mp.getVideoWidth();
		mVideoHeight = mp.getVideoHeight();

		Log.d("TJ","onPrepared========seek!!!!" + mSeekWhenPrepared);
		int seekToPosition = mSeekWhenPrepared; // mSeekWhenPrepared may be changed after seekTo() call
		if ( seekToPosition != 0 ) {
			seekTo( seekToPosition );
		}
		if ( mVideoWidth != 0 && mVideoHeight != 0 ) {
			//Log.i("@@@@", "video size: " + mVideoWidth +"/"+ mVideoHeight);
			mSurfaceView.getHolder().setFixedSize( mVideoWidth, mVideoHeight );
			if ( mSurfaceWidth == mVideoWidth && mSurfaceHeight == mVideoHeight ) {
				// We didn't actually change the size (it was already at the size
				// we need), so we won't get a "surface changed" callback, so
				// start the video here instead of in the callback.
				if ( mTargetState == STATE_PLAYING ) {
					Log.d("TJ","onPrepared========start call!!!");
					start();
					Log.d("TJ","onPrepared========end");
				} else if ( !isPlaying() && (seekToPosition != 0 || getCurrentPosition() > 0) ) {
				}
			}
		} else {
			// We don't know the video size yet, but should start anyway.
			// The video size might be reported to us later.
			if ( mTargetState == STATE_PLAYING ) {
				start();
			}
		}
		if ( mPrpLstnr != null ) {
			mPrpLstnr.onPrepared( mp );
		}
	}

	/**
	 * 
	 */
	@Override
	public void onCompletion( MediaPlayer mp ) {
		Log.d("TJ", "*** onCompletion" );
		if ( mCplLstnr != null ) {
			mCurrentState = STATE_PLAYBACK_COMPLETED;
			mTargetState = STATE_PLAYBACK_COMPLETED;
			mCplLstnr.onCompletion( mp );
		}
	}

	/**
	 * 
	 */
	@Override
	public boolean onError( MediaPlayer mp, int what, int extra ) {
		Log.d("TJ","Error: " + what + "," + extra );
		mCurrentState = STATE_ERROR;
		mTargetState = STATE_ERROR;
		if ( mErrLstnr != null ) {
			if ( mErrLstnr.onError( mp, what, extra ) ) {
				return true;
			}
		}
		return true;
	}

	/**
	 * 
	 */
	@Override
	public void onBufferingUpdate( MediaPlayer mp, int percent ) {
		mCurrentBufferPercentage = percent;
	}

	/**
	 * 
	 */
	public void onPause() {
		Log.d("TJ", "*** onPause" );
		if ( mMediaPlayer == null ) return;
		if ( mMediaPlayer.isPlaying() ) {
			mMediaPlayer.stop();
		}
	}

	/**
	 * 
	 */
	public void start() {
		if ( isInPlaybackState() ) {
			Log.d("TJ", "*** start - ok" );
			if ( mMediaPlayer == null ) return;
			
			Log.d("TJ","===========================================================mMediaPlayer.start()!!!!" );			
			mMediaPlayer.start();
			Log.d("TJ","====================================================================" );
			mCurrentState = STATE_PLAYING;
		} else {
			Log.d("TJ", "*** start - preparing" );
		}
		mTargetState = STATE_PLAYING;
	}

	/**
	 * 
	 */
	public void pause() {
		Log.d("TJ", "*** pause" );
		if ( isInPlaybackState() ) {
			if ( mMediaPlayer == null ) return;
			if ( mMediaPlayer.isPlaying() ) {
				mMediaPlayer.pause();
				mCurrentState = STATE_PAUSED;
			}
		}
		mTargetState = STATE_PAUSED;
	}

	/**
	 * 
	 */
	public void suspend() {
		Log.d("TJ", "*** suspend" );
		if ( isInPlaybackState() ) {
			release( false );
			mCurrentState = STATE_SUSPEND_UNSUPPORTED;
		}
	}

	/**
	 * 
	 */
	public void resume() {
		Log.d("TJ", "*** resume" );
		if ( mSurfaceHolder == null && mCurrentState == STATE_SUSPEND ) {
			mTargetState = STATE_RESUME;
			return;
		}
		if ( mMediaPlayer != null && mCurrentState == STATE_SUSPEND ) {
			Log.d("TJ","Unable to resume video" );
			return;
		}
		if ( mCurrentState == STATE_SUSPEND_UNSUPPORTED ) {
			openVideo();
		}
	}

	/**
	 * 
	 * @return
	 */
	public int getDuration() {
		if ( isInPlaybackState() ) {
			if ( mDuration > 0 ) {
				return mDuration;
			}
			mDuration = mMediaPlayer.getDuration();
			return mDuration;
		}
		mDuration = -1;
		return mDuration;
	}

	/**
	 * 
	 * @return
	 */
	public int getCurrentPosition() {
		if ( isInPlaybackState() ) {
			return mMediaPlayer.getCurrentPosition();
		}
		return 0;
	}

	/**
	 * 
	 * @param msec
	 */
	public void seekTo( int msec ) {
		if ( isInPlaybackState() ) {
			mMediaPlayer.seekTo( msec );
			mSeekWhenPrepared = 0;
		} else {
			mSeekWhenPrepared = msec;
		}
	}

	/**
	 * 
	 * @return
	 */
	public boolean isPlaying() {
		return isInPlaybackState() && mMediaPlayer.isPlaying();
	}

	/**
	 * 
	 * @return
	 */
	public int getBufferPercentage() {
		if ( mMediaPlayer != null ) {
			return mCurrentBufferPercentage;
		}
		return 0;
	}

	/**
	 * 
	 * @return
	 */
	private boolean isInPlaybackState() {
		if ( mSurfaceView == null ) return false;
		return (mMediaPlayer != null && mCurrentState != STATE_ERROR && mCurrentState != STATE_IDLE && mCurrentState != STATE_PREPARING);
	}

	/**
	 * 
	 * @return
	 */
	public boolean canPause() {
		return mCanPause;
	}

	/**
	 * 
	 * @return
	 */
	public boolean canSeekBackward() {
		return mCanSeekBack;
	}

	/**
	 * 
	 * @return
	 */
	public boolean canSeekForward() {
		return mCanSeekForward;
	}

	/**
	 * 
	 * @param cpl_lstnr
	 */
	public void setOnCompletionListener( OnCompletionListener cpl_lstnr ) {
		mCplLstnr = cpl_lstnr;
	}

	/**
	 * 
	 * @param err_lstnr
	 */
	public void setOnErrorListener( OnErrorListener err_lstnr ) {
		mErrLstnr = err_lstnr;
	}

	/**
	 * 
	 * @param prp_lstnr
	 */
	public void setOnPreparedListener( OnPreparedListener prp_lstnr ) {
		mPrpLstnr = prp_lstnr;
	}

	/**
	 * 
	 * @param b
	 */
	public void setZOrderOnTop( boolean b ) {
		if ( mSurfaceView == null ) return;
		mSurfaceView.setZOrderOnTop( b );
	}

	/**
	 * 
	 * @param path
	 */
	public void setVideoPath( String path ) {
		setVideoURI( Uri.parse( path ) );
	}

	/**
	 * 
	 * @param uri
	 */
	public void setVideoURI( Uri uri ) {
		Log.d("TJ","setVideoURI========start");
		if ( mSurfaceView == null ) 
		{
			Log.d("TJ","setVideoURI========end mSurfaceView is null*************");
			return;
		}
		Log.d("TJ","setVideoURI openVideo Call!!!!!!!!");
		mUri = uri;
		mSeekWhenPrepared = 0;
		openVideo();
		mSurfaceView.requestLayout();
		mSurfaceView.invalidate();
		Log.d("TJ","setVideoURI========end");
	}

	/**
	 * 
	 * @param vv
	 * @param filepath
	 */
	public void setVideoPath( final MovView vv, final String filepath ) {
//		mHandler.post( new Runnable() {
//			public void run() {
//				try {
					vv.setVideoPath( filepath );
////				} catch ( Exception e ) {
////					Log.d("TJ","setDataSource(path)", e );
////				}
////			}
//		} );
	}

	/**
	 * 
	 * @param vv
	 * @param uri
	 */
	public void setVideoURI( final MovView vv, final String uri ) {
//		mHandler.post( new Runnable() {
//			public void run() {
//				try {
					vv.setVideoURI( Uri.parse( uri ) );
//				} catch ( Exception e ) {
//					Log.d("TJ","setDataSource(ctxt,uri)", e );
//				}
//			}
//		} );
	}

	/**
	 * 
	 * @param vv
	 */
	public void start( final MovView vv ) {
//		mHandler.post( new Runnable() {
//			public void run() {
				vv.start();
//			}
//		} );
	}

	/**
	 * 
	 * @param vv
	 */
	public void stopPlayback( final MovView vv ) {
//		mHandler.post( new Runnable() {
//			public void run() {
				vv.stopPlayback();
//			}
//		} );
	}

	/**
	 * 
	 * @param vv
	 * @param params
	 */
	public void setLayoutParams( final MovView vv, final ViewGroup.LayoutParams params ) {
//		mHandler.post( new Runnable() {
//			public void run() {
				vv.setLayoutParams( params );
//			}
//		} );
	}

	/**
	 * 
	 * @param vv
	 * @param params
	 */
	public void setLayoutParams( final MovView vv, final RelativeLayout.LayoutParams params ) {
//		mHandler.post( new Runnable() {
//			public void run() {
				vv.setLayoutParams( params );
//			}
//		} );
	}

	/**
	 * 
	 * @param vv
	 * @param visibility
	 */
	public void setVisibility( final MovView vv, final int visibility ) {
		Log.d("TJ", "*** setVisibility( vv, " + visibility + " )" );
//		mHandler.post( new Runnable() {
//			public void run() {
				if ( mLayout != null ) {
					mLayout.setVisibility( visibility );
				}
				if ( mSurfaceView != null ) {
					mSurfaceView.setVisibility( visibility );
				}
//			}
//		} );
	}

	/**
	 * 
	 * @param vv
	 * @param color
	 */
	public void setBackgroundColor( final MovView vv, final int color ) {
//		mHandler.post( new Runnable() {
//			public void run() {
				vv.setBackgroundColor( color );
//			}
//		} );
	}

	/**
	 * 
	 * @param params
	 */
	public void setLayoutParams( ViewGroup.LayoutParams params ) {
		Log.d("TJ", "*** setLayoutParams( ViewGroup.LayoutParams )" );
		if ( mLayout == null || mSurfaceView == null ) return;
		mLayout.setLayoutParams( params );
		mSurfaceView.setLayoutParams( params );
	}

	/**
	 * 
	 * @param params
	 */
	public void setLayoutParams( RelativeLayout.LayoutParams params ) {
		Log.d("TJ", "*** setLayoutParams( RelativeLayout.LayoutParams )" );
		//	MovViewのLayoutParamsは勝手に変更されるらしく、同じインスタンスだとmParentViewも影響を受けるので、別に生成する
		if ( mLayout == null || mSurfaceView == null ) return;
		RelativeLayout.LayoutParams params2 = new RelativeLayout.LayoutParams( params );
		mLayout.setLayoutParams( params );
		params2.setMargins( 0, 0, 0, 0 );
		params2.addRule( RelativeLayout.CENTER_IN_PARENT );
		mSurfaceView.setLayoutParams( params2 );
	}

	/**
	 * 
	 * @param visibility
	 */
	public void setVisibility( int visibility ) {
		Log.d("TJ", "*** setVisibility( " + visibility + " )" );
		mLayout.setVisibility( visibility );
	}

	/**
	 * 
	 * @param color
	 */
	public void setBackgroundColor( int color ) {
		if ( mLayout != null ) {
			mLayout.setBackgroundColor( color );
		}
	}

	/**
	 * 
	 * @return
	 */
	public View getLayout() {
		return mLayout;
	}

	public SurfaceView getSurefaceview() {
		return mSurfaceView;
	}
		

	/**
	 * 
	 */
	public void dispose() {
		Log.d("TJ", "*** dispose" );
		mLayout.setVisibility( View.GONE );
		mSurfaceView.setVisibility( View.GONE );
		if ( mMediaPlayer != null ) {
			purgeMediaPlayer();
		}
		mCplLstnr = null;
		mErrLstnr = null;
		mPrpLstnr = null;
		mSurfaceHolder = null;
		mSurfaceView = null;
		mCtxt = null;
//		mHandler = null;
		mLayout = null;
	}

	/**
	 * 音量設定
	 * 
	 * @param vol_l
	 * @param vol_r
	 */
	public void setVolume( float vol_l, float vol_r ) {
		Log.d("TJ", "*** setVolume( " + vol_l + ", " + vol_r + " )" );
		if ( mMediaPlayer == null ) return;
		mMediaPlayer.setVolume( vol_l, vol_r );
	}

	/**
	 * URIのクリア
	 */
	public void resetUri() {
		mUri = null;
	}
}
