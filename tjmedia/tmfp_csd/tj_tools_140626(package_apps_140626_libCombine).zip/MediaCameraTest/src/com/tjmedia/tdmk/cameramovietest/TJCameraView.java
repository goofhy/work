package com.tjmedia.tdmk.cameramovietest;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.hardware.Camera;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.ShutterCallback;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Toast;

import android.util.Log;

public class TJCameraView extends SurfaceView implements SurfaceHolder.Callback {
	private final String TAG = "TJCameraView";

	public SurfaceHolder mHolder = null;

	SurfaceView mSurfaceView;
	Camera mCamera;
	
	public static final int MEDIA_TYPE_IMAGE = 1;
	public static final int MEDIA_TYPE_VIDEO = 2;
//	SoundPoolManager mPoolManger;
	private Context mContext;
	
	/** A safe way to get an instance of the Camera object. */
	public static Camera getCameraInstance(){
	    Camera c = null;
	    try {
	        c = Camera.open(); // attempt to get a Camera instance
	    }
	    catch (Exception e){
	        // Camera is not available (in use or does not exist)
	    }
	    return c; // returns null if camera is unavailable
	}

	public TJCameraView(Context context, Camera camera) {
		super(context);
		Log.d(TAG, "TJCameraView.Constructor");
		try {
			mContext = context;
			mCamera = camera;
			mHolder = getHolder();
			mHolder.addCallback(this);								
			mHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);			
			
//			if(mPoolManger == null) {
//				mPoolManger = new SoundPoolManager(getApplicationContext());
//				mPoolManger = new SoundPoolManager(context);
//			}			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	public void surfaceCreated(SurfaceHolder holder) {
		Log.d(TAG, "surfaceCreated");
		try {
			if (mCamera == null || holder == null)
			{
				Log.e(TAG, "mCamera is null");
				mCamera = Camera.open();
			}
			
			mCamera.setPreviewDisplay(holder);
//			mCamera.startPreview();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void surfaceDestroyed(SurfaceHolder holder) {
		Log.d(TAG, "surfaceDestroyed");
//		if (mCamera != null){
//        	mCamera.release();        // release the camera for other applications
//        	mCamera = null;
//        	Log.d(TAG, "mCamera ==================release");
//        }
	}

	public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
		Log.d(TAG, "surfaceChanged");
		
		if (mCamera == null)
		{
			Log.e(TAG, "mCamera is null");
			mCamera = Camera.open();
		}		
		
		if(mHolder.getSurface() == null) {
	          // preview surface does not exist
	          return;
		}

        // stop preview before making changes
        try {
            mCamera.stopPreview();
        } catch (Exception e){
          // ignore: tried to stop a non-existent preview
        }
        
        // set preview size and make any resize, rotate or
        // reformatting changes here
        if (mCamera != null) {
	        Camera.Parameters p = mCamera.getParameters();
	        p.setPreviewSize(640, 480);
	        mCamera.setParameters(p);
        }
	        
        // start preview with new settings
        try {
			mCamera.setPreviewDisplay(holder);
			mCamera.startPreview();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	
	
	public void takeASnapShot() {
		if(mCamera!=null) {
			if (null != mshutterCallback)
				try {
					mCamera.takePicture(mshutterCallback, null, mPicture);
				} catch (Exception e) {
					// take picture failed
					e.toString();
				}
		}
	}
	
	private ShutterCallback mshutterCallback = new ShutterCallback()
	{
		public void onShutter() {
			//if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TINKERBELL);
		}
	};	
	
	private PictureCallback mPicture = new PictureCallback() {
	    @Override
	    public void onPictureTaken(byte[] data, Camera camera) {
	        boolean result = createExternalStoragePublicPicture(MEDIA_TYPE_IMAGE, data);
	        
	        if(result != true) {
	        	result = createInternalStoragePublicPicture(data);
	        }
//	        if (result == true) {	            
//				ToastManager.showToast(getContext(), "Success : Snapshot", Toast.LENGTH_SHORT);
//	        } else {
//	            Log.d(TAG, "File not found: ");
//	        }
	       mCamera.startPreview();
	    }
	};
	
	boolean createExternalStoragePublicPicture(int type, byte[] data) {
		boolean result = false;
        File path = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File filedir = new File(path, "TJ_PICTURE");

        try {
        	if(!filedir.exists()) {
        		 if (!filedir.mkdirs()){
     	            Log.d(TAG, "failed to create directory");
     	            return result;
     	        }
        	}
        	
        	// Create a media file name
        	File filename = new File(filedir.getPath() + File.separator + "tj_snapshot.jpg");
//    	    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
//    	    File filename = new File(filedir.getPath() + File.separator + "Date_"+ timeStamp + ".jpg");

            FileOutputStream  fos = new FileOutputStream(filename);
            BufferedOutputStream bos = new BufferedOutputStream(fos);
            bos.write(data);
            fos.close();
            bos.close();

            // Tell the media scanner about the new file so that it is
            // immediately available to the user.
            MediaScannerConnection.scanFile(mContext, new String[] { filename.toString() }, null, mMscListener);
            
        } catch (Exception e) {
            // Unable to create file, likely because external storage is
            // not currently mounted.
            Log.e(TAG, "Error writing " + filedir, e);
            return result;
        }
        return result = true;
    }
	
	
	private boolean createInternalStoragePublicPicture(byte[] data) {
		boolean result = false;
		// Create a media file name
		File filename = new File("/data/data/" + getContext().getPackageName() + "/files/"
				+ File.separator + "tj_snapshot.jpg");
		String str = "tj_snapshot.jpg";
//		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
//		File filename = new File("/data/data/" + getContext().getPackageName() + "/files/"
//				+ File.separator + "Date_"+ timeStamp + ".jpg");
//		String str = "Date_"+ timeStamp + ".jpg";
		Log.d(TAG, "filename=" + filename);
			
		try {
			FileOutputStream  fos = getContext().openFileOutput(str, Context.MODE_WORLD_WRITEABLE);
			BufferedOutputStream bos = new BufferedOutputStream(fos);
			bos.write(data);
			fos.close();
			bos.close();
			
			MediaScannerConnection.scanFile(mContext, new String[] { filename.toString() }, null, mMscListener);
		} catch (Exception e) {
			// Unable to create file, likely because external storage is
			// not currently mounted.
			Log.e(TAG, "Error writing " + str, e);
			return result;
		}
		return result = true;
	}
	
	MediaScannerConnection.OnScanCompletedListener mMscListener = 
			new MediaScannerConnection.OnScanCompletedListener() {
		@Override
		public void onScanCompleted(String arg0, Uri arg1) {
			Log.i("ExternalStorage", "Scanned " + arg0 + ":");
			Log.i("ExternalStorage", "-> uri=" + arg1);
			
		}
	};
	
	public Uri getOutputMediaFileUri(int type) {
		return Uri.fromFile(getOutputMediaFile(type));
	}
	
	public File getOutputMediaFile(int type) {
        File path = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File filedir = new File(path, "TJ_VID");

    		if(!filedir.exists()) {
    			if (!filedir.mkdirs()){
    				Log.d(TAG, "failed to create directory");
    			}
    		}
	    	// Create a media file name
		    File filename = new File(filedir.getPath() + File.separator + "TJ_VID.mp4");
//		    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
//		    File filename = new File(filedir.getPath() + File.separator + "VID_"+ timeStamp + ".mp4");
    	return filename;
	}
	
	public void setExposureCompensation(int index) {
		Camera.Parameters p;
		if(mCamera == null) {
			return;
		}
		switch (index) {
			case 0:
				p = mCamera.getParameters();
				p.setExposureCompensation(2);
		        mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 1:
				p = mCamera.getParameters();
				p.setExposureCompensation(1);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 2:
				p = mCamera.getParameters();
				p.setExposureCompensation(0);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 3:
				p = mCamera.getParameters();
				p.setExposureCompensation(-1);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 4:
				p = mCamera.getParameters();
				p.setExposureCompensation(-2);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			default:
				p = mCamera.getParameters();
				p.setExposureCompensation(0);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
		}
	}
	
	public void setFLASH(int index) {
		Camera.Parameters p;
		if(mCamera == null) {
			return;
		}
		switch (index) {
			case 0:
				p = mCamera.getParameters();
				List<String> list = p.getSupportedFlashModes();
//				Iterator<String> iter = list.iterator();
//				int i=0;
//				while(iter.hasNext()) {
//					Log.d(TAG, "list:[" + i + "]=" + iter.next());
//					i++;
//				}
				p.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
		        mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 1:
				p = mCamera.getParameters();
				p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			default:
				p = mCamera.getParameters();
				p.setFlashMode(Camera.Parameters.FLASH_MODE_ON);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
		}
	}
	
	public void setBalance(int index) {
		Camera.Parameters p;
		if(mCamera == null) {
			return;
		}
		switch (index) {
			case 0:
				p = mCamera.getParameters();
				List<String> list = p.getSupportedWhiteBalance();
				Iterator<String> iter = list.iterator();
//				int i=0;
//				while(iter.hasNext()) {
//					Log.d(TAG, "list:[" + i + "]=" + iter.next());
//					i++;
//				}
				p.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_INCANDESCENT);
		        mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 1:
				p = mCamera.getParameters();
				p.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_FLUORESCENT);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 2:
				p = mCamera.getParameters();
				p.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_DAYLIGHT);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 3:
				p = mCamera.getParameters();
				p.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_SHADE);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			case 4:
				p = mCamera.getParameters();
				p.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_AUTO);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
			default:
				p = mCamera.getParameters();
				p.setWhiteBalance(Camera.Parameters.WHITE_BALANCE_AUTO);
				mCamera.setParameters(p);
				mCamera.startPreview();
				break;
		}
	}
	
	
	/*
	 ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *   
	 * DEMO modules 
	 * 
	 ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *   
	 */
	/** Create a File for saving an image or video */
	public static File demogetOutputMediaFile(int type){
	    // To be safe, you should check that the SDCard is mounted
	    // using Environment.getExternalStorageState() before doing this.

	    File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
	              Environment.DIRECTORY_PICTURES), "MyCameraApp");
	    // This location works best if you want the created images to be shared
	    // between applications and persist after your app has been uninstalled.

	    // Create the storage directory if it does not exist
	    if (! mediaStorageDir.exists()){
	        if (! mediaStorageDir.mkdirs()){
	            Log.d("MyCameraApp", "failed to create directory");
	            return null;
	        }
	    }

	    // Create a media file name
	    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
	    File mediaFile;
	    if (type == MEDIA_TYPE_IMAGE){
	        mediaFile = new File(mediaStorageDir.getPath() + File.separator +
	        "Date_"+ timeStamp + ".jpg");
	    } else if(type == MEDIA_TYPE_VIDEO) {
	        mediaFile = new File(mediaStorageDir.getPath() + File.separator +
	        "VID_"+ timeStamp + ".mp4");
	    } else {
	        return null;
	    }

	    return mediaFile;
	}

}
