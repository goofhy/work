package com.tjmedia.tdmk.cameramovietest;



public class RegexManager {
	public static final String TAG = "RegexManager";
	
	private static final String REGULAREXPRESSION_AUDIO = ".*(?i)(mp3|mp4|ogg|wav)$";
	private static final String REGULAREXPRESSION_VIDEO = ".*(?i)(mp4|3pg)$";
	private static final String REGULAREXPRESSION_TSPFW = ".*(?i)(bin|BIN)$";
	private static final String REGULAREXPRESSION_APK = ".*(?i)(apk|APK)$";
	
	public static boolean isAudioFormatInfo(String s) {
		return s.matches(REGULAREXPRESSION_AUDIO);
	}
	
	public static boolean isVideoFormatInfo(String s) {
		return s.matches(REGULAREXPRESSION_VIDEO);
	}

	public static boolean isTspFWFormatInfo(String s) {
		return s.matches(REGULAREXPRESSION_TSPFW);
	}

	public static boolean isPackageFormatInfo(String s) {
		return s.matches(REGULAREXPRESSION_APK);
	}

	/*
	 * convert like pattern singleQuote ' -> ' '
	 * ex)
	 * 		SELECT * FROM audio WHERE (_data like '%/sdcard/music/nori fly - Don''t You Know.mp3');
	 */
	final static String regex = "'";
	final static String replacement = "''";
	public static String getConvertEscapeSingleQuote(String s) {
		s = s.replace(regex, replacement);
		return s;
	}
	
}
