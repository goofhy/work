#!/bin/sh
javah -o SerialPort.h -jni -classpath ../src android_serialport_api.SerialPort

