/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.SystemRun;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.RemoteException;
import android.provider.Settings;
import android.app.Service;
import android.os.IBinder;
import android.content.Intent;
import android.util.Log;
import com.android.SystemRun.*;
/**
 * Application that sets the provisioned bit, like SetupWizard does.
 */
public class DefaultService extends Service {
	
	static String TAG = "DefaultService";
	final int AID_APP =         10000;  /* first app user */
	static Context mContext;

		@Override
    public IBinder onBind(Intent intent) {
    	Log.d(TAG, "========================DEFAULT JAVA Service onBind========================");
    	return mbinder;
    }
    
    @Override
    public void onCreate() {
    	// TODO Auto-generated method stub
    	super.onCreate();
    }
    
    @Override
    public void onStart(Intent intent, int startId) {
    	Log.d(TAG, "========================DEFAULT JAVA Service onStart========================");
    	mContext = getApplicationContext();
    }
    
    @Override
    public void onDestroy() {  
    	Log.d(TAG, "========================DEFAULT JAVA Service onStart========================");
    	super.onDestroy();
    }    
    
	public static String getData() {
		String data = "";
		Log.d(TAG, "getData++");
		try {
			InputStream in = mContext.openFileInput("ret.txt");
			if (in != null)
			{
				InputStreamReader input = new InputStreamReader(in);
				BufferedReader reader = new BufferedReader(input);
				
				String str = "";
				try {
					while((str = reader.readLine()) != null)						
					{
						data += str + "\n";
						//Log.d(TAG,"[" + str + "]");
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					input.close();
					reader.close();
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.d(TAG, "getData--");
		return data;
	}
	
    
	IDefaultServiceInterface.Stub mbinder = new IDefaultServiceInterface.Stub() {	
		@Override
		public String SystemCall(String cmd) throws RemoteException
		{
			synchronized (this) {				
				Log.d(TAG, "SystemCall++");
				String data = "";
				StringBuffer strbuf = new StringBuffer ( );
				BufferedReader br = null;
				File f = null;
				String szCmd = "stj -c " + cmd;
				String szPackageinfoDir = null;
				String uid = null;
				PackageInfo packageInfo = null;
				
				try {
					packageInfo = getPackageManager().getPackageInfo(getPackageName(),0);
				} catch (NameNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				if (packageInfo != null)
				{
					szPackageinfoDir = packageInfo.applicationInfo.dataDir;
					if (packageInfo.applicationInfo.uid >= AID_APP)
					{
						uid = "u0_a" + (packageInfo.applicationInfo.uid - AID_APP);
						Log.d(TAG, packageInfo.applicationInfo.dataDir + " UID[" + uid + "]");
					}
					else
					{
						Log.w(TAG, packageInfo.applicationInfo.dataDir + " UID[null]");
					}
				}
				
				try
				{ 
					f = new File("/system/xbin/su");
					
					if(!f.canExecute() || uid == null)
					{
						szCmd = cmd;
					}
					else
					{
						szCmd = "su " + cmd + " > /data/data/com.android.SystemRun/files/ret.txt";
					}
					
					Log.d(TAG, szCmd );
					
					Process proc = Runtime.getRuntime( ).exec( szCmd );
					
					try {
						proc.waitFor();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}					
					
					DataOutputStream os = new DataOutputStream(proc.getOutputStream());
					os.flush();
					br = new BufferedReader ( new InputStreamReader ( proc.getInputStream ( ) ) );
					if (br == null)
					{
						Log.d(TAG, "SystemCall--retrun is null");
						return null;
					}
					String line;
					while ( ( line = br.readLine ( ) ) != null )
						strbuf.append ( line + "\n" );
					br.close ( );					
					
				}
				catch ( Exception e ) { 				
				}
				
				if(!f.canExecute())
				{
					data = strbuf.toString ();
				}
				else
				{
					Process proc1 = null;
					Process proc2 = null;					
					try {
						proc1 = Runtime.getRuntime( ).exec( "stj -c chmod 777 /data/data/com.android.SystemRun/files/ret.txt" );
						try {
							proc1.waitFor();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						proc2 = Runtime.getRuntime( ).exec( "stj -c chown " + uid + "." + uid + " /data/data/com.android.SystemRun/files/ret.txt" );
						try {
							proc2.waitFor();
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}					

					data = getData();
				}
//				Log.d(TAG, szCmd + " : " + data);
				Log.d(TAG, "SystemCall--");
				return data;
				
			}
//			String szCommand = cmd + " > /data/data/com.tjmedia.service/files/ret.txt";
//			int ret = SYSTEM_Run(szCommand);
//			Log.d(TAG,szCommand + " : " + ret);
//			String result = getData();
//			Log.d(TAG,"[" + result + "]");			
//            return result;
						
		}		
	};
}

