package com.android.SystemRun;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import android.os.RemoteException;

public class DefaultServiceManager extends BroadcastReceiver{

	private static final String TAG = "DefaultServiceManager";
	private PowerManager mPowerManager;	
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub				
		if(intent.getAction().equals("android.intent.action.BOOT_COMPLETED")){
			Log.d(TAG, "============= android.intent.action.BOOT_COMPLETED =============");
			ComponentName cn = new ComponentName(context.getPackageName(), DefaultService.class.getName());
		    ComponentName svcName = context.startService(new Intent().setComponent(cn));
		    
		    if (svcName == null) 
		      Log.e("BOOTSVC", "Could not start service " + cn.toString());
		}		
		else if (intent.getAction().equals("DEFALUT.SYSTEM"))
		{
			Log.d(TAG, "============= DEFALUT.SYSTEM =============");			
			String str = intent.getStringExtra("cmd");			
			Log.d(TAG, "Start=============["+ str +"]=============");			
			
			BufferedReader reader = null;
			try
			{
				 Process process = Runtime.getRuntime().exec("su");
				 DataOutputStream os = new DataOutputStream(process.getOutputStream());
				 reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				 os.writeBytes(str);
				 os.flush();
			 		
				 try {
					if(process.waitFor() != 0)
					 {
					  //
					 }
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 String strUsbUrbnum =reader.readLine();
				 Log.d(TAG, "=============["+ strUsbUrbnum +"]=============");		
				 reader.close();
			 		//return reader;
			}
			catch (IOException e)
			{
			}
			Log.d(TAG, "End=============["+ str +"]=============");			
		}
	}	
	
	
}
