/** Automatically generated file. DO NOT MODIFY */
package com.example.com.tjmedia.key_led_vol_ir;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}