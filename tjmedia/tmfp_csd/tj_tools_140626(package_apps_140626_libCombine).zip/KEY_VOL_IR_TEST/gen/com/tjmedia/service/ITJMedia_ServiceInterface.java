/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: Q:\\work\\fptm\\android\\vendor\\tjmedia\\tj_tools\\KEY_VOL_IR_TEST\\src\\com\\tjmedia\\service\\ITJMedia_ServiceInterface.aidl
 */
package com.tjmedia.service;
public interface ITJMedia_ServiceInterface extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.tjmedia.service.ITJMedia_ServiceInterface
{
private static final java.lang.String DESCRIPTOR = "com.tjmedia.service.ITJMedia_ServiceInterface";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.tjmedia.service.ITJMedia_ServiceInterface interface,
 * generating a proxy if needed.
 */
public static com.tjmedia.service.ITJMedia_ServiceInterface asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.tjmedia.service.ITJMedia_ServiceInterface))) {
return ((com.tjmedia.service.ITJMedia_ServiceInterface)iin);
}
return new com.tjmedia.service.ITJMedia_ServiceInterface.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_GetVersionInfo:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
java.lang.String _result = this.GetVersionInfo(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_IR_Send:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
byte _arg1;
_arg1 = data.readByte();
int _result = this.IR_Send(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_MITSUBISHI_IR_Send:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
byte _arg1;
_arg1 = data.readByte();
int _result = this.MITSUBISHI_IR_Send(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PRIVATEINFO_GetTotalSize:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.PRIVATEINFO_GetTotalSize();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PRIVATEINFO_GetBlockSize:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.PRIVATEINFO_GetBlockSize();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PRIVATEINFO_GetBlock:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
byte[] _arg2;
int _arg2_length = data.readInt();
if ((_arg2_length<0)) {
_arg2 = null;
}
else {
_arg2 = new byte[_arg2_length];
}
int _result = this.PRIVATEINFO_GetBlock(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg2);
return true;
}
case TRANSACTION_PRIVATEINFO_SetBlock:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _arg1;
_arg1 = data.readInt();
byte[] _arg2;
_arg2 = data.createByteArray();
int _result = this.PRIVATEINFO_SetBlock(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PROXY_Stop:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.PROXY_Stop();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PROXY_Start:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.PROXY_Start();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PROXY_SetServerInfo:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _arg2;
_arg2 = data.readInt();
int _result = this.PROXY_SetServerInfo(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PROXY_HTTP_AddRedirectionPort:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.PROXY_HTTP_AddRedirectionPort(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PROXY_HTTPS_AddRedirectionPort:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
int _result = this.PROXY_HTTPS_AddRedirectionPort(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_SYSTEM_GetSerialNumber:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.SYSTEM_GetSerialNumber();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_SYSTEM_SetSerialNumber:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.SYSTEM_SetSerialNumber(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_GetUsbWifiStatus:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.GetUsbWifiStatus();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_GetUsbNfcStatus:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.GetUsbNfcStatus();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_GetBusUsbNfc:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _result = this.GetBusUsbNfc();
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_SetVolumeScanTime:
{
data.enforceInterface(DESCRIPTOR);
byte _arg0;
_arg0 = data.readByte();
int _result = this.SetVolumeScanTime(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_SystemCall:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _result = this.SystemCall(_arg0);
reply.writeNoException();
reply.writeString(_result);
return true;
}
case TRANSACTION_PACKAGE_Install:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _result = this.PACKAGE_Install(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_PACKAGE_UnInstall:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _arg1;
_arg1 = data.readInt();
int _result = this.PACKAGE_UnInstall(_arg0, _arg1);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_SYSTEM_Run:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
int _result = this.SYSTEM_Run(_arg0);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_TEST:
{
data.enforceInterface(DESCRIPTOR);
int _result = this.TEST();
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.tjmedia.service.ITJMedia_ServiceInterface
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
//DK 제공//////////////////////////////////////////////////////////////////////////////////////////////////////
//설명 : 각 Version 취득 
//values : int ( 0 : boot Ver, 1: Kernel Ver, 2 : Android Ver, 3 : TJService ver ,4 : Touch Ver, 5 : wifi ver )
//return : String ( null : 실패 , 그외 성공)

@Override public java.lang.String GetVersionInfo(int section) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(section);
mRemote.transact(Stub.TRANSACTION_GetVersionInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : IR 전송 ( CSD )
//values : byte[] pBuffer(ir data), byte leng(ir data의 byte 갯수)
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int IR_Send(byte[] pBuffer, byte leng) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(pBuffer);
_data.writeByte(leng);
mRemote.transact(Stub.TRANSACTION_IR_Send, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : MITSUBISHI TV IR 전송 ( CSD )
//values : byte[] pBuffer(ir data), byte leng(ir data의 byte 갯수)
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int MITSUBISHI_IR_Send(byte[] pBuffer, byte leng) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(pBuffer);
_data.writeByte(leng);
mRemote.transact(Stub.TRANSACTION_MITSUBISHI_IR_Send, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 기존 NANDINFO에 해당하는 전체 데이터의 크기를 가져옴.  기본 256KB(1KB * 256개 블록)으로 구성됨.
//values : none
//return : int ( 양수 : 성공 및 크기(byte) , 음수 : 실패 )

@Override public int PRIVATEINFO_GetTotalSize() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_PRIVATEINFO_GetTotalSize, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 1개 블럭의 크기를 가져옴.  기본 1KB
//values : none
//return : int ( 양수 : 성공 및 크기(byte) , 음수 : 실패 )

@Override public int PRIVATEINFO_GetBlockSize() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_PRIVATEINFO_GetBlockSize, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 시작블럭(nStartBlock)부터 블럭갯수(nBlockCount)만큼 데이터를 가져옴.
//values : int nStartBlock(시작블럭), int nBlockCount(블록갯수), 
//         byte[] pData_out(데이터)
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int PRIVATEINFO_GetBlock(int nStartBlock, int nBlockCount, byte[] pData_out) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(nStartBlock);
_data.writeInt(nBlockCount);
if ((pData_out==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(pData_out.length);
}
mRemote.transact(Stub.TRANSACTION_PRIVATEINFO_GetBlock, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(pData_out);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 시작블럭(nStartBlock)부터 블럭갯수(nBlockCount)만큼 데이터를 기입함.
//values : int nStartBlock(시작블럭), int nBlockCount(블록갯수), 
//       byte[] pData (데이터)
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int PRIVATEINFO_SetBlock(int nStartBlock, int nBlockCount, byte[] pData) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(nStartBlock);
_data.writeInt(nBlockCount);
_data.writeByteArray(pData);
mRemote.transact(Stub.TRANSACTION_PRIVATEINFO_SetBlock, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 프록시 관련 동작 중지.
//values : none
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int PROXY_Stop() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_PROXY_Stop, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 설정된 프록시 정보로 RedSocks 기동
//values : none
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int PROXY_Start() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_PROXY_Start, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 프록시 정보 설정(설정된 정보로 redsocks.conf 작성과 iptables 기본값 실행함.)
//values :  
//String szServerIP (프록시 서버 주소)
//int nPortHTTP ( 프록시 서버의 HTTP 포트 번호 )
//int nPortHTTPS ( 프록시 서버의 HTTPS 포트 번호 )
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int PROXY_SetServerInfo(java.lang.String szServerAddress, int nPortHTTP, int nPortHTTPS) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(szServerAddress);
_data.writeInt(nPortHTTP);
_data.writeInt(nPortHTTPS);
mRemote.transact(Stub.TRANSACTION_PROXY_SetServerInfo, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 프록시 서버의 HTTP 포트 번호 추가.
//       HTTP(80)  제외한 추가로 설정할 HTTP 포트 설정하고, iptables를 수행
//values : int nPort (프록시 서버의 HTTP 포트 번호 )
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int PROXY_HTTP_AddRedirectionPort(int nPort) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(nPort);
mRemote.transact(Stub.TRANSACTION_PROXY_HTTP_AddRedirectionPort, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 프록시 서버의 HTTPS 포트 번호 추가.
//      HTTPS(443) 제외한 추가로 설정할 HTTP 포트 설정하고, iptables를 수행
//values : int nPort (프록시 서버의 HTTPS 포트 번호 )
//return : int ( 0 : 성공 , 음수 : 실패 )

@Override public int PROXY_HTTPS_AddRedirectionPort(int nPort) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(nPort);
mRemote.transact(Stub.TRANSACTION_PROXY_HTTPS_AddRedirectionPort, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 단말의 시리얼번호를 취득.
//values : none
//return : Stirng ( !null  : 성공,  null : 실패 )

@Override public java.lang.String SYSTEM_GetSerialNumber() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_SYSTEM_GetSerialNumber, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : 단말의 시리얼번호 기입.
//values : none
//return : in ( 0 : 성공, 음수 : 실패 )

@Override public int SYSTEM_SetSerialNumber(java.lang.String szSerialNumber) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(szSerialNumber);
mRemote.transact(Stub.TRANSACTION_SYSTEM_SetSerialNumber, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : wifi usb 연결상태
//values : none
//return : in ( 0 : 성공, 음수 : 실패 )

@Override public int GetUsbWifiStatus() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_GetUsbWifiStatus, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : nfc usb 연결상태
//values : none
//return : in ( 0 : 성공, 음수 : 실패 )

@Override public int GetUsbNfcStatus() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_GetUsbNfcStatus, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : nfc usb bus 취득
//values : none
//return : in ( !null : 성공, null : 실패 )

@Override public java.lang.String GetBusUsbNfc() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_GetBusUsbNfc, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//설명 : volume scan time 설정
//values : byte m10_time(0~255)
//return :  in ( 0 : 성공, 음수 : 실패 )

@Override public int SetVolumeScanTime(byte m10_time) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByte(m10_time);
mRemote.transact(Stub.TRANSACTION_SetVolumeScanTime, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public java.lang.String SystemCall(java.lang.String cmd) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.lang.String _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(cmd);
mRemote.transact(Stub.TRANSACTION_SystemCall, _data, _reply, 0);
_reply.readException();
_result = _reply.readString();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
//TJ//////////////////////////////////////////////////////////////////////////////////////////////////////

@Override public int PACKAGE_Install(java.lang.String szAPK, int nOption) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(szAPK);
_data.writeInt(nOption);
mRemote.transact(Stub.TRANSACTION_PACKAGE_Install, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int PACKAGE_UnInstall(java.lang.String szPackageName, int nOption) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(szPackageName);
_data.writeInt(nOption);
mRemote.transact(Stub.TRANSACTION_PACKAGE_UnInstall, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int SYSTEM_Run(java.lang.String szCommandLine) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(szCommandLine);
mRemote.transact(Stub.TRANSACTION_SYSTEM_Run, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
@Override public int TEST() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_TEST, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_GetVersionInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_IR_Send = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_MITSUBISHI_IR_Send = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_PRIVATEINFO_GetTotalSize = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_PRIVATEINFO_GetBlockSize = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_PRIVATEINFO_GetBlock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_PRIVATEINFO_SetBlock = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
static final int TRANSACTION_PROXY_Stop = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
static final int TRANSACTION_PROXY_Start = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
static final int TRANSACTION_PROXY_SetServerInfo = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
static final int TRANSACTION_PROXY_HTTP_AddRedirectionPort = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
static final int TRANSACTION_PROXY_HTTPS_AddRedirectionPort = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
static final int TRANSACTION_SYSTEM_GetSerialNumber = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
static final int TRANSACTION_SYSTEM_SetSerialNumber = (android.os.IBinder.FIRST_CALL_TRANSACTION + 13);
static final int TRANSACTION_GetUsbWifiStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 14);
static final int TRANSACTION_GetUsbNfcStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 15);
static final int TRANSACTION_GetBusUsbNfc = (android.os.IBinder.FIRST_CALL_TRANSACTION + 16);
static final int TRANSACTION_SetVolumeScanTime = (android.os.IBinder.FIRST_CALL_TRANSACTION + 17);
static final int TRANSACTION_SystemCall = (android.os.IBinder.FIRST_CALL_TRANSACTION + 18);
static final int TRANSACTION_PACKAGE_Install = (android.os.IBinder.FIRST_CALL_TRANSACTION + 19);
static final int TRANSACTION_PACKAGE_UnInstall = (android.os.IBinder.FIRST_CALL_TRANSACTION + 20);
static final int TRANSACTION_SYSTEM_Run = (android.os.IBinder.FIRST_CALL_TRANSACTION + 21);
static final int TRANSACTION_TEST = (android.os.IBinder.FIRST_CALL_TRANSACTION + 22);
}
//DK 제공//////////////////////////////////////////////////////////////////////////////////////////////////////
//설명 : 각 Version 취득 
//values : int ( 0 : boot Ver, 1: Kernel Ver, 2 : Android Ver, 3 : TJService ver ,4 : Touch Ver, 5 : wifi ver )
//return : String ( null : 실패 , 그외 성공)

public java.lang.String GetVersionInfo(int section) throws android.os.RemoteException;
//설명 : IR 전송 ( CSD )
//values : byte[] pBuffer(ir data), byte leng(ir data의 byte 갯수)
//return : int ( 0 : 성공 , 음수 : 실패 )

public int IR_Send(byte[] pBuffer, byte leng) throws android.os.RemoteException;
//설명 : MITSUBISHI TV IR 전송 ( CSD )
//values : byte[] pBuffer(ir data), byte leng(ir data의 byte 갯수)
//return : int ( 0 : 성공 , 음수 : 실패 )

public int MITSUBISHI_IR_Send(byte[] pBuffer, byte leng) throws android.os.RemoteException;
//설명 : 기존 NANDINFO에 해당하는 전체 데이터의 크기를 가져옴.  기본 256KB(1KB * 256개 블록)으로 구성됨.
//values : none
//return : int ( 양수 : 성공 및 크기(byte) , 음수 : 실패 )

public int PRIVATEINFO_GetTotalSize() throws android.os.RemoteException;
//설명 : 1개 블럭의 크기를 가져옴.  기본 1KB
//values : none
//return : int ( 양수 : 성공 및 크기(byte) , 음수 : 실패 )

public int PRIVATEINFO_GetBlockSize() throws android.os.RemoteException;
//설명 : 시작블럭(nStartBlock)부터 블럭갯수(nBlockCount)만큼 데이터를 가져옴.
//values : int nStartBlock(시작블럭), int nBlockCount(블록갯수), 
//         byte[] pData_out(데이터)
//return : int ( 0 : 성공 , 음수 : 실패 )

public int PRIVATEINFO_GetBlock(int nStartBlock, int nBlockCount, byte[] pData_out) throws android.os.RemoteException;
//설명 : 시작블럭(nStartBlock)부터 블럭갯수(nBlockCount)만큼 데이터를 기입함.
//values : int nStartBlock(시작블럭), int nBlockCount(블록갯수), 
//       byte[] pData (데이터)
//return : int ( 0 : 성공 , 음수 : 실패 )

public int PRIVATEINFO_SetBlock(int nStartBlock, int nBlockCount, byte[] pData) throws android.os.RemoteException;
//설명 : 프록시 관련 동작 중지.
//values : none
//return : int ( 0 : 성공 , 음수 : 실패 )

public int PROXY_Stop() throws android.os.RemoteException;
//설명 : 설정된 프록시 정보로 RedSocks 기동
//values : none
//return : int ( 0 : 성공 , 음수 : 실패 )

public int PROXY_Start() throws android.os.RemoteException;
//설명 : 프록시 정보 설정(설정된 정보로 redsocks.conf 작성과 iptables 기본값 실행함.)
//values :  
//String szServerIP (프록시 서버 주소)
//int nPortHTTP ( 프록시 서버의 HTTP 포트 번호 )
//int nPortHTTPS ( 프록시 서버의 HTTPS 포트 번호 )
//return : int ( 0 : 성공 , 음수 : 실패 )

public int PROXY_SetServerInfo(java.lang.String szServerAddress, int nPortHTTP, int nPortHTTPS) throws android.os.RemoteException;
//설명 : 프록시 서버의 HTTP 포트 번호 추가.
//       HTTP(80)  제외한 추가로 설정할 HTTP 포트 설정하고, iptables를 수행
//values : int nPort (프록시 서버의 HTTP 포트 번호 )
//return : int ( 0 : 성공 , 음수 : 실패 )

public int PROXY_HTTP_AddRedirectionPort(int nPort) throws android.os.RemoteException;
//설명 : 프록시 서버의 HTTPS 포트 번호 추가.
//      HTTPS(443) 제외한 추가로 설정할 HTTP 포트 설정하고, iptables를 수행
//values : int nPort (프록시 서버의 HTTPS 포트 번호 )
//return : int ( 0 : 성공 , 음수 : 실패 )

public int PROXY_HTTPS_AddRedirectionPort(int nPort) throws android.os.RemoteException;
//설명 : 단말의 시리얼번호를 취득.
//values : none
//return : Stirng ( !null  : 성공,  null : 실패 )

public java.lang.String SYSTEM_GetSerialNumber() throws android.os.RemoteException;
//설명 : 단말의 시리얼번호 기입.
//values : none
//return : in ( 0 : 성공, 음수 : 실패 )

public int SYSTEM_SetSerialNumber(java.lang.String szSerialNumber) throws android.os.RemoteException;
//설명 : wifi usb 연결상태
//values : none
//return : in ( 0 : 성공, 음수 : 실패 )

public int GetUsbWifiStatus() throws android.os.RemoteException;
//설명 : nfc usb 연결상태
//values : none
//return : in ( 0 : 성공, 음수 : 실패 )

public int GetUsbNfcStatus() throws android.os.RemoteException;
//설명 : nfc usb bus 취득
//values : none
//return : in ( !null : 성공, null : 실패 )

public java.lang.String GetBusUsbNfc() throws android.os.RemoteException;
//설명 : volume scan time 설정
//values : byte m10_time(0~255)
//return :  in ( 0 : 성공, 음수 : 실패 )

public int SetVolumeScanTime(byte m10_time) throws android.os.RemoteException;
public java.lang.String SystemCall(java.lang.String cmd) throws android.os.RemoteException;
//TJ//////////////////////////////////////////////////////////////////////////////////////////////////////

public int PACKAGE_Install(java.lang.String szAPK, int nOption) throws android.os.RemoteException;
public int PACKAGE_UnInstall(java.lang.String szPackageName, int nOption) throws android.os.RemoteException;
public int SYSTEM_Run(java.lang.String szCommandLine) throws android.os.RemoteException;
public int TEST() throws android.os.RemoteException;
}
