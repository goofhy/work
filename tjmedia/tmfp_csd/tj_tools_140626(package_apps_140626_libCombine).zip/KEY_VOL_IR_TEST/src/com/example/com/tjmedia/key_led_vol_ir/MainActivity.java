package com.example.com.tjmedia.key_led_vol_ir;


import java.util.ArrayList;

import com.example.com.tjmedia.key_led_vol_ir.R.layout;


import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.SystemClock;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;


public class MainActivity extends Activity {

	protected static final String TAG = "KEY_VOL_IR";
//	com.tjmedia.serviceapi.ITJMedia_ServiceInterface TJService;
	com.tjmedia.service.ITJMedia_ServiceInterface TJService;
	
    /** Key code constant: TMFP MUSIC Vol UP */
    public static final int KEYCODE_TMFP_MUSIC_VOL_UP            = 220;
    /** Key code constant: TMFP MUSIC Vol DOWN */
    public static final int KEYCODE_TMFP_MUSIC_VOL_DOWN          = 221;    
    /** Key code constant: TMFP BGM Vol UP */
    public static final int KEYCODE_TMFP_BGM_VOL_UP              = 222;
    /** Key code constant: TMFP BGM Vol DOWN */
    public static final int KEYCODE_TMFP_BGM_VOL_DOWN            = 223;    
    /** Key code constant: TMFP ECO Vol UP */
    public static final int KEYCODE_TMFP_ECO_VOL_UP              = 224;
    /** Key code constant: TMFP ECO Vol DOWN */
    public static final int KEYCODE_TMFP_ECO_VOL_DOWN            = 225;
        /** Key code constant: TMFP MIC Vol UP */
    public static final int KEYCODE_TMFP_MIC_VOL_UP              = 226;
    /** Key code constant: TMFP MIC Vol DOWN */
    public static final int KEYCODE_TMFP_MIC_VOL_DOWN            = 227;
    
    /** Key code constant: TMFP LIVESOUND Key */
    public static final int KEYCODE_TMFP_LIVESOUND            = 228;
    /** Key code constant: TMFP STANDBY Key */
    public static final int KEYCODE_TMFP_STANDBY              = 229;
    /** Key code constant: TMFP RESERVED Key */
    public static final int KEYCODE_TMFP_REV              	  = 230;
    
    /** Key code constant: CSD MB Key 1*/
    public static final int KEYCODE_CSD_MBKEY1                = 231;
    /** Key code constant: CSD MB Key 2*/
    public static final int KEYCODE_CSD_MBKEY2                = 232;
    /** Key code constant: CSD MB Key 3*/
    public static final int KEYCODE_CSD_MBKEY3                = 233;
    /** Key code constant: CSD MB Key 4*/
    public static final int KEYCODE_CSD_MBKEY4                = 234;
    /** Key code constant: CSD MB Key 5*/
    public static final int KEYCODE_CSD_MBKEY5                = 235;
    /** Key code constant: CSD MB Key 6*/
    public static final int KEYCODE_CSD_MBKEY6                = 236;
    /** Key code constant: CSD MB Key 7*/
    public static final int KEYCODE_CSD_MBKEY7                = 237;
    /** Key code constant: CSD MB Key 8*/
    public static final int KEYCODE_CSD_MBKEY8                = 238;
    /** Key code constant: CSD MB Key 9*/
    public static final int KEYCODE_CSD_MBKEY9                = 239;
    /** Key code constant: CSD MB Key 10*/
    public static final int KEYCODE_CSD_MBKEY10               = 240;
    /** Key code constant: CSD MB Key 11*/
    public static final int KEYCODE_CSD_MBKEY11               = 241;
    /** Key code constant: CSD MB Key 12*/
    public static final int KEYCODE_CSD_MBKEY12               = 242;
    /** Key code constant: CSD MB Key 13*/
    public static final int KEYCODE_CSD_MBKEY13               = 243;
    /** Key code constant: CSD MB Key 14*/
    public static final int KEYCODE_CSD_MBKEY14               = 244;
    /** Key code constant: CSD MB Key 15*/
    public static final int KEYCODE_CSD_MBKEY15               = 245;
    /** Key code constant: CSD MB Key 16*/
    public static final int KEYCODE_CSD_MBKEY16               = 246;
    /** Key code constant: CSD MB Key 17*/
    public static final int KEYCODE_CSD_MBKEY17               = 247;
    /** Key code constant: CSD MB Key 18*/
    public static final int KEYCODE_CSD_MBKEY18               = 248;
    /** Key code constant: CSD MB Key 19*/
    public static final int KEYCODE_CSD_MBKEY19               = 249;    
    /** Key code constant: CSD MB Key 20*/
    public static final int KEYCODE_CSD_MBKEY20               = 250; 
    /** Key code constant: TSP Key 1*/
    public static final int KEYCODE_TMFP_TSPKEY1                = 251;
    /** Key code constant: TSP Key 2*/
    public static final int KEYCODE_TMFP_TSPKEY2                = 252;
    /** Key code constant: TSP Key 3*/
    public static final int KEYCODE_TMFP_TSPKEY3                = 253;
    /** Key code constant: TSP Key 4*/
    public static final int KEYCODE_TMFP_TSPKEY4                = 254;
    /** Key code constant: TSP Key 5*/
    public static final int KEYCODE_TMFP_TSPKEY5                = 255;
    /** Key code constant: TSP Key 6*/
    public static final int KEYCODE_TMFP_TSPKEY6                = 256;
    /** Key code constant: TSP Key 7*/
    public static final int KEYCODE_TMFP_TSPKEY7                = 257;
    /** Key code constant: TSP Key 8*/
    public static final int KEYCODE_TMFP_TSPKEY8                = 258;
    /** Key code constant: TSP Key 9*/
    public static final int KEYCODE_TMFP_TSPKEY9                = 259;
    /** Key code constant: TSP Key 10*/
    public static final int KEYCODE_TMFP_TSPKEY10               = 260;
    /** Key code constant: TSP Key 11*/
    public static final int KEYCODE_TMFP_TSPKEY11               = 261;
    /** Key code constant: TSP Key 12*/
    public static final int KEYCODE_TMFP_TSPKEY12               = 262;
    /** Key code constant: TSP Key 13*/
    public static final int KEYCODE_TMFP_TSPKEY13               = 263;
    /** Key code constant: TSP Key 14*/
    public static final int KEYCODE_TMFP_TSPKEY14               = 264;
    /** Key code constant: TSP Key 15*/
    public static final int KEYCODE_TMFP_TSPKEY15               = 265;
    /** Key code constant: TSP Key 16*/
    public static final int KEYCODE_TMFP_TSPKEY16               = 266;    
    
    //TRANS (LED)
    private static final byte	BOTTOM_PCB_LED_ALL_CMD				= (byte) 0x10;	//select
  
    //Left Front LED
    private static final byte	LEFT_FRONT_PCB_LED_ALL_CMD			= (byte) 0x20;	//select
    private static final byte	LEFT_FRONT_PCB_LED_TEMPO_CTRL_CMD	= (byte) 0x21;	//select
    private static final byte	LEFT_FRONT_PCB_LED_TEMPO_UP_CMD		= (byte) 0x22;	//select
    private static final byte	LEFT_FRONT_PCB_LED_TEMPO_CTRL_STAND_CMD	= (byte) 0x23;	//select
    private static final byte	LEFT_FRONT_PCB_LED_TEMPO_CTRL_DOWN_CMD	= (byte) 0x24;	//select
    private static final byte	LEFT_FRONT_PCB_LED_RESERVED_CMD		= (byte) 0x25;	//select    
    private static final byte	LEFT_FRONT_PCB_LED_SCORE_CMD		= (byte) 0x26;	//select
    private static final byte	LEFT_FRONT_PCB_LED_DAM_CMD			= (byte) 0x27;	//select
    
    //Right Front LED
    private static final byte	RIGHT_FRONT_PCB_LED_ALL_CMD			= (byte) 0x30;	//select
    private static final byte	RIGHT_FRONT_PCB_LED_KEY_CTRL_CMD	= (byte) 0x31;	//select
    private static final byte	RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD	= (byte) 0x32;	//select
    private static final byte	RIGHT_FRONT_PCB_LED_KEY_BASE_CMD	= (byte) 0x33;	//select
    private static final byte	RIGHT_FRONT_PCB_LED_KEY_B_CMD		= (byte) 0x34;	//select
    private static final byte	RIGHT_FRONT_PCB_LED_START_CMD		= (byte) 0x35;	//select
    private static final byte	RIGHT_FRONT_PCB_LED_STOP_CMD		= (byte) 0x36;	//select    
    private static final byte	RIGHT_FRONT_PCB_LED_MENU_CMD		= (byte) 0x37;	//select
    
    //Left & Right Front LED 
    private static final byte	LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD	= (byte) 0x40;	//select
    
    //Left Back LED
    private static final byte	LEFT_BACK_PCB_LED_ALL_CMD			= (byte) 0x28;	//select
    
    //Right Back LED
    private static final byte	RIGHT_BACK_PCB_LED_ALL_CMD			= (byte) 0x38;	//select
    
    //Left & Right Back LED
    private static final byte	LEFT_RIGHT_BACK_PCB_LED_ALL_CMD		= (byte) 0x48;	//select
    
    public static final byte	VOL_TRANSTIME						= (byte) 0x90;        	//0 : ?�시�?, 10*(time) = msec
    
    public static byte R_LED		= 0x04;
    public static byte G_LED		= 0x02;
    public static byte B_LED		= 0x01;
    public static byte RG_LED		= 0x06;
    public static byte RB_LED		= 0x05;
    public static byte GB_LED		= 0x03;
    public static byte RGB_LED		= 0x07;
    
    public static byte OFF_LED		= 0x00;
    public static byte ON_LED		= 0x01;
    

    SeekBar music = null;
    SeekBar bgm = null;
    SeekBar eco = null;
    SeekBar mic = null;
    SeekBar voltime = null;
    Button exit = null;
    ListView list = null;
    public ArrayAdapter<String> mAdapter;
    ArrayList<String> mItem;    
    LoopHandler a; 
    LoopHandler2 b;     
			
	private ServiceConnection con = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
//			TJService = com.tjmedia.serviceapi.ITJMedia_ServiceInterface.Stub.asInterface(service);
			TJService = com.tjmedia.service.ITJMedia_ServiceInterface.Stub.asInterface(service);
			if (TJService == null)
			{
				Log.d(TAG, "onServiceConnected>------------ TJService is NULL ------------");
			}
			else
			{
				Log.d(TAG, "onServiceConnected>------------ TJService = " + TJService);
			}
			if (getTMFP())
			Senddata_TMFPVOL(VOL_TRANSTIME,(byte)0);
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			Log.d(TAG, "onServiceDisconnected> TJService = " + TJService);		
			TJService = null;
		}		
	};
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);		
		
		//startService(new Intent("com.tjmedia.service")); 
				
		list = (ListView) findViewById(R.id.listView1);
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);
		list.setAdapter(mAdapter);
		
		music = (SeekBar) findViewById(R.id.seekBar1);
		bgm = (SeekBar) findViewById(R.id.seekBar2);
		eco = (SeekBar) findViewById(R.id.seekBar3);		
		mic = (SeekBar) findViewById(R.id.seekBar4);
		voltime = (SeekBar) findViewById(R.id.seekBar5);
		exit = (Button) findViewById(R.id.button1);
		
		music.setMax(100);
		bgm.setMax(100);
		eco.setMax(100);
		mic.setMax(100);
		voltime.setMax(255);	//2.5sec
		voltime.setOnSeekBarChangeListener(new SeekBarChangeListener());
		exit.setOnClickListener(mClickListener);
		
        IntentFilter filter = new IntentFilter();
        filter.addAction("TMFP.RMC");
        filter.addAction("TMFP.VOL");
        registerReceiver(IRReceiver, filter);
        a = new LoopHandler();
		a.sleep(1000);
		a.start();				
	}
	
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {
		public void onClick(View v) {
			if (v.getId() == R.id.button1)
				finish();
		}
	};
	
	class SeekBarChangeListener implements OnSeekBarChangeListener{
		 
	    public void onProgressChanged(SeekBar seekbar, int progress, boolean fromUser) {
	    	Log.d(TAG, "=======================progress: " + progress);
			Senddata_TMFPVOL(VOL_TRANSTIME,progress);
	    }
	 
	    public void onStartTrackingTouch(SeekBar arg0) {
	         
	    }
	 
	    public void onStopTrackingTouch(SeekBar arg0) {
	         
	    }
	     
	}
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		Log.d(TAG,"onResume++");
		super.onResume();
//		Intent intent = new Intent("com.tjmedia.serviceapi.TJMedia_ServiceInterface");
		Intent intent = new Intent("com.tjmedia.service.TJMedia_ServiceInterface");
		bindService(intent, con, Context.BIND_AUTO_CREATE);
		Log.d(TAG,"onResume--");
	
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		Log.d(TAG,"onPause++");
		unregisterReceiver(IRReceiver);
		a.stop();
		unbindService(con);
		Log.d(TAG,"onPause--");
		super.onPause();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
//		b.stop();
		super.onDestroy();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	int gCount = 0;
	
	//TMFP//////////////////////////////////////////////////////////////
	public void Senddata_TMFPLED(byte cmd, byte led, byte bright) {

		byte[] buffer = new byte[100];		
		buffer[0] = led;	//MODE
		buffer[1] = bright;
		
		Intent intent = new Intent();
		intent.setAction("TMFP.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", buffer);		
		intent.putExtra("leng",(byte)2);
		
		String str = "CMD[" + String.format("0x%02X", cmd) + "]";
		str += "LEN[2]DATA";
		int i = 0;
		for (i = 0; i < 2; i++)
		{					
			str += "[" + String.format("0x%02X", buffer[i]) + "]";	
		}
		
//		mItem.add(0, str + "\n");
//		mAdapter.notifyDataSetChanged();
//		list.invalidate();
		
		sendBroadcast(intent);
				
	}
	
	public void Senddata_TMFPVOL(byte cmd, int time) {

		byte[] buffer = new byte[100];				
		byte mTime = (byte)time;
		buffer[0] = mTime;	
//		if (mTime > 0) mTime += 129;
    	String str2 = "Set Volume Time:" + time*10 + "[msec]";
		Log.d(TAG, "=======================TJService VolTime: " + str2);

//		Intent intent = new Intent();
//		intent.setAction("TMFP.DATA");
//		intent.putExtra("cmd", cmd);
//		intent.putExtra("data", buffer);		
//		intent.putExtra("leng",(byte)1);
//		
//		sendBroadcast(intent);
		if (TJService == null)
		{
			Intent intent = new Intent();
			intent.setAction("TMFP.DATA");
			intent.putExtra("cmd", cmd);
			intent.putExtra("data", buffer);		
			intent.putExtra("leng",(byte)1);			
			sendBroadcast(intent);			
		}
		else
		{			
			try {
				int ret = TJService.SetVolumeScanTime(mTime);
				Log.d(TAG,"TJService.SetVolumeScanTime return : " + ret);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		mItem.add(0, str2 + "\n");
		mAdapter.notifyDataSetChanged();
		list.invalidate();
				
	}
	
	BroadcastReceiver IRReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {	
				if (intent.getAction().equals("TMFP.RMC"))
				{					
					byte nSize = 1;
					byte i = 0;
					//byte data = intent.getByteExtra("data", (byte)0);
					nSize = intent.getByteExtra("leng", (byte)0);
					byte [] data = new byte [100];
					data = intent.getByteArrayExtra("data");										
					
					String str;					
					 str = "TMFP.RMC :";					 
//					 str += String.format("[0x%02X]", data);
					for (i = 0; i < nSize; i++)
					{					
						str += "[" + String.format("0x%02X", data[i]) + "]";	
					}					 
					 str += "\n";					
					 Log.d(TAG, str);		
					mItem.add(0, str);
					mAdapter.notifyDataSetChanged();

				}
				if (intent.getAction().equals("TMFP.VOL"))
				{
					String str;					
					str = "TMFP.VOL :";
					int nSize = intent.getIntExtra("leng", 0);
					int key = intent.getIntExtra("key", 0);
					KeyEvent event = new KeyEvent(-1,nSize);
					int i = 0;
					str += "VOL:[" + key + "]" + " Counter[" + nSize + "]";
					 str += "\n";					
					 Log.d(TAG, str);		
//					mItem.add(0, str);
//					mAdapter.notifyDataSetChanged();
					
					onKeyDown(key,event);
				}
		}	
	};
		
	//CSD//////////////////////////////////////////////////////////////		
	public int Senddata_DAMRMC(byte cmd ,byte[] buffer,byte len) {

		Intent intent = new Intent();
		intent.setAction("CSD.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", buffer);		
		intent.putExtra("leng",len);
		sendBroadcast(intent);
		return 1;
				
	}

	public int Senddata_DAMRMC(byte cmd ,byte buffer,byte len) {

		byte data[] = new byte[1];
		data[0] = buffer;
		Intent intent = new Intent();
		intent.setAction("CSD.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", data);		
		intent.putExtra("leng",len);
		sendBroadcast(intent);
		return 1;			
	}	
	
	//TMFP&CSD//////////////////////////////////////////////////////////////
	public static boolean getTMFP()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")|| strManufacturer.equals("TJMEDIA")) && (strProduct.equals("fptm") || strProduct.equals("tmfp")))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	public static boolean getCSD()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia") || strManufacturer.equals("TJMEDIA")) && (strProduct.equals("csd")))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	public static boolean getTM10()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if (strManufacturer.equals("tjmedia") || strManufacturer.equals("tdmk"))
		{			
			return true;
		}
		else
		{		
			return false;
		}	
	}		
	public static boolean getTJ()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if (strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	
	byte mVolTimeCount = 0;
	
	public int TJApiTest()
	{
		Log.d(TAG, "TJApiTest++");
		if (null != TJService)
		{
			try 
			{
				if (getTMFP())
				{
//					String str = "GetVersionInfo(test):";
//					str += TJService.GetVersionInfo(3);
//					Log.d(TAG, "TJService Version: " + str);
//					
//					mItem.add(0, str + "\n");
//					mAdapter.notifyDataSetChanged();
//					list.invalidate();
					
					String str2 = mVolTimeCount*10 + "[msec]";
					Log.d(TAG, "=======================TJService VolTime: " + str2);
					Senddata_TMFPVOL(VOL_TRANSTIME,mVolTimeCount++);

					mItem.add(0, str2 + "\n");
					mAdapter.notifyDataSetChanged();
					list.invalidate();

				}
				else if (getCSD() || getTM10())
				{
					//DAM IR TEST//////////////////////////////////////////////
					String str = "RMC(test):";
					byte[] pBufferIR=new byte[9];					
					byte leng = 9;
					pBufferIR[0]=(byte)0x08;
					pBufferIR[1]=(byte)0x31;
					pBufferIR[2]=(byte)0x32;
					pBufferIR[3]=(byte)0x33;
					pBufferIR[4]=(byte)0x34;
					pBufferIR[5]=(byte)'<';			// '<'
					pBufferIR[6]=(byte)0x35;
					pBufferIR[7]=(byte)0x36;
					pBufferIR[8]=(byte)0x09;
								
//					int result = Senddata_DAMRMC((byte)1,pBufferIR,leng);
					
					int result = TJService.IR_Send(pBufferIR, leng);
					if (result == 0)
					{
						str = "IR Send[OK]:1234-56";						
					}
					else
					{
						str = "IR Send[NG]:1234-56";						
					}										
					Log.d(TAG, str);
					mItem.add(0, str + "\n");
					mAdapter.notifyDataSetChanged();
					list.invalidate();	
					//MTV IR TEST//////////////////////////////////////////////
					str = "RMC(test):";	
					byte[] pBufferTvIR=new byte[1];
					pBufferTvIR[0] = (byte)0x02;
					byte tvleng = 1;
//					int result = Senddata_DAMRMC((byte)2,pBufferTvIR,tvleng);					
					result = TJService.MITSUBISHI_IR_Send(pBufferTvIR, tvleng);
					if (result == 0)
					{
						str = "MTV IR Send[OK]:POWER On/Off";						
					}
					else
					{
						str = "MTV IR Send[NG]:POWER On/Off";					
					}										
					Log.d(TAG, str);
					mItem.add(0, str + "\n");
					mAdapter.notifyDataSetChanged();
					list.invalidate();	
					
				}
				
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Log.d(TAG, "TJApiTest--");
		return -1;
	}
	
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		Log.d(TAG, "onKeyDown()");
		
		String str = "";
		int i = 0;
		int multicount = event.getAction() == -1? event.getKeyCode() : 1;
					
		Log.d(TAG, "KeyCode:[" + keyCode + "] count:[" + multicount + "]");	
//		TJApiTest();
		if (getCSD())
			TJApiTest();
		
		switch(keyCode)
		{
			case 4:
			case 28:
				finish();
			break;
			case KEYCODE_TMFP_LIVESOUND:
				str = "LIVESOUND : DOWN";
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();
				Senddata_TMFPLED(BOTTOM_PCB_LED_ALL_CMD, ON_LED, (byte)0x5);
				Senddata_TMFPLED(LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, ON_LED, (byte)0x5);
				Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, RGB_LED, (byte)0x5);
				break;
							
			case KEYCODE_TMFP_STANDBY:
				str = "STANDBY : DOWN";			
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();
				Senddata_TMFPLED(BOTTOM_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
				Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, OFF_LED, (byte)0);				
				Senddata_TMFPLED(LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
				break;
				
			case KEYCODE_TMFP_MUSIC_VOL_DOWN:
				str = "MUSIC VOLUME : DOWN" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				for (i = 0; i < multicount; i++)
				{
					if (music.getProgress() > 0)
						music.setProgress(music.getProgress() - 1);
				}										
				if (voltime.getProgress() > 0)	break;
				
				gCount--;
				if (gCount < 0) gCount = 0;
				Senddata_TMFPLED(BOTTOM_PCB_LED_ALL_CMD, ON_LED, (byte)gCount);
				Senddata_TMFPLED(LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, ON_LED, (byte)gCount);
				Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, RGB_LED, (byte)gCount);
				
				break;
				
			case KEYCODE_TMFP_MUSIC_VOL_UP:
				str = "MUSIC VOLUME : UP" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				
				for (i = 0; i < multicount; i++)
				{
					if (music.getProgress() < 100)
						music.setProgress(music.getProgress() + 1);
					else
						music.setProgress(0);
				}
				if (voltime.getProgress() > 0)	break;
				
				gCount++;
				if (gCount > 32) gCount = 32;
				Senddata_TMFPLED(BOTTOM_PCB_LED_ALL_CMD, ON_LED, (byte)gCount);
				Senddata_TMFPLED(LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, ON_LED, (byte)gCount);
				Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, RGB_LED, (byte)gCount);
				
				break;		
		
			case KEYCODE_TMFP_BGM_VOL_DOWN:
				str = "BGM VOLUME : DOWN" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				
				for (i = 0; i < multicount; i++)
				{
					if (bgm.getProgress() > 0)
						bgm.setProgress(bgm.getProgress() - 1);			//
				}
				if (voltime.getProgress() > 0)	break;
				Senddata_TMFPLED(RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD, OFF_LED, (byte)0);
				break;
			case KEYCODE_TMFP_BGM_VOL_UP:
				str = "BGM VOLUME : UP" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				
				for (i = 0; i < multicount; i++)
				{
					if (bgm.getProgress() < 100)
						bgm.setProgress(bgm.getProgress() + 1);
					else
						bgm.setProgress(0);
				}
				if (voltime.getProgress() > 0)	break;
				Senddata_TMFPLED(RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD, ON_LED, (byte)10);
				break;
				
			case KEYCODE_TMFP_ECO_VOL_DOWN:
				str = "ECO VOLUME : DOWN" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				
				for (i = 0; i < multicount; i++)
				{
					if (eco.getProgress() > 0)
						eco.setProgress(eco.getProgress() - 1);
				}
				if (voltime.getProgress() > 0)	break;
				Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
				break;
			case KEYCODE_TMFP_ECO_VOL_UP:
				str = "ECO VOLUME : UP" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				
				for (i = 0; i < multicount; i++)
				{
					if (eco.getProgress() < 100)
						eco.setProgress(eco.getProgress() + 1);
					else
						eco.setProgress(0);
				}
				if (voltime.getProgress() > 0)	break;
				gCount++;
				i = gCount%7;
				switch(i)
				{
					case 0:
						Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, R_LED, (byte)10);
					break;

					case 1:
						Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, G_LED, (byte)10);
					break;
					
					case 2:
						Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, B_LED, (byte)10);
					break;

					case 3:
						Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, RG_LED, (byte)10);
					break;

					case 4:
						Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, RB_LED, (byte)10);
					break;

					case 5:
						Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, GB_LED, (byte)10);
					break;

					case 6:
						Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, RGB_LED, (byte)10);
					break;
					
				}
				break;
				
			case KEYCODE_TMFP_MIC_VOL_DOWN:
				str = "MIC VOLUME : DOWN" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				
				for (i = 0; i < multicount; i++)
				{
					if (mic.getProgress() > 0)
						mic.setProgress(mic.getProgress() - 1);
				}				
				if (voltime.getProgress() > 0)	break;
				Senddata_TMFPLED(LEFT_BACK_PCB_LED_ALL_CMD, RGB_LED, (byte)0);
				Senddata_TMFPLED(RIGHT_BACK_PCB_LED_ALL_CMD, RGB_LED, (byte)0);
				break;
			case KEYCODE_TMFP_MIC_VOL_UP:
				str = "MIC VOLUME : UP" + "("  + multicount + ")";		
				
				mItem.add(0, str + "\n");
				mAdapter.notifyDataSetChanged();
				list.invalidate();

				
				for (i = 0; i < multicount; i++)
				{
					if (mic.getProgress() < 100)
						mic.setProgress(mic.getProgress() + 1);
					else
						mic.setProgress(0);
				}
								
				break;
				default: return false;
		}			
			
		return true;		
	};
	
	public class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				synchronized (this) {
					list.invalidate();
					music.invalidate();
					mic.invalidate();
					eco.invalidate();
					bgm.invalidate();
					sleep(1);
				}
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		public void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;							
		}
	};
	
	
	public class LoopHandler2 extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				synchronized (this) {
					byte []cmd = new byte[100];
					byte []led = new byte[100];
					int i = 0;
					
					  
				  cmd[0]=BOTTOM_PCB_LED_ALL_CMD;                  	  led[0]=OFF_LED;
				  
				  cmd[15]=LEFT_BACK_PCB_LED_ALL_CMD;                  led[15]=RGB_LED;
				  cmd[16]=RIGHT_BACK_PCB_LED_ALL_CMD;                 led[16]=RGB_LED;
				  cmd[17]=LEFT_RIGHT_BACK_PCB_LED_ALL_CMD;            led[17]=RGB_LED;					                                                      
				  
				  cmd[18]=LEFT_FRONT_PCB_LED_ALL_CMD;                 led[18]=OFF_LED;
				  cmd[19]=LEFT_FRONT_PCB_LED_TEMPO_CTRL_CMD;          led[19]=ON_LED;
				  cmd[20]=LEFT_FRONT_PCB_LED_TEMPO_UP_CMD;            led[20]=ON_LED;
				  cmd[21]=LEFT_FRONT_PCB_LED_TEMPO_CTRL_STAND_CMD;          led[21]=ON_LED;
				  cmd[22]=LEFT_FRONT_PCB_LED_TEMPO_CTRL_DOWN_CMD;          led[22]=ON_LED;
				  cmd[23]=LEFT_FRONT_PCB_LED_RESERVED_CMD;            led[23]=ON_LED;
				  cmd[24]=LEFT_FRONT_PCB_LED_SCORE_CMD;               led[24]=ON_LED;
				  cmd[25]=LEFT_FRONT_PCB_LED_DAM_CMD;                 led[25]=ON_LED;
				  
				  cmd[26]=RIGHT_FRONT_PCB_LED_ALL_CMD;                led[26]=OFF_LED;
				  cmd[27]=RIGHT_FRONT_PCB_LED_KEY_CTRL_CMD;           led[27]=ON_LED;
				  cmd[28]=RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD;           led[28]=ON_LED;
				  cmd[29]=RIGHT_FRONT_PCB_LED_KEY_BASE_CMD;           led[29]=ON_LED;
				  cmd[30]=RIGHT_FRONT_PCB_LED_KEY_B_CMD;              led[30]=ON_LED;
				  cmd[31]=RIGHT_FRONT_PCB_LED_START_CMD;              led[31]=ON_LED;
				  cmd[32]=RIGHT_FRONT_PCB_LED_STOP_CMD;               led[32]=ON_LED;
				  cmd[33]=RIGHT_FRONT_PCB_LED_MENU_CMD;               led[33]=ON_LED;
				  
					for(i = 15; i < 17; i++)
					{
						if (led[i] == OFF_LED) continue;
						Senddata_TMFPLED(cmd[i], led[i], (byte)0xFF);
						String str = "LED : [" + String.format("0x%02X", cmd[i]) + "]";
						Log.d(TAG,str);						
						SystemClock.sleep(1000);
					}
					sleep(1000);
				}
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		public void stop() {
			bStop = true;
			Senddata_TMFPLED(BOTTOM_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
			Senddata_TMFPLED(LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
			Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
		}

		private void start() {
			bStop = false;		
			Senddata_TMFPLED(BOTTOM_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
			Senddata_TMFPLED(LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
			Senddata_TMFPLED(LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, OFF_LED, (byte)0);
		}
	};			

}
