/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <android/log.h>
//#include <cutils/log.h>
#include "jni.h"
#include <stdio.h>
#include <string.h>
#include <sys/system_properties.h>

#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <jni.h>
#include <cstdlib> 
#include "android/log.h"
#define LOGI(fmt, args...) __android_log_print(ANDROID_LOG_INFO,  TAG, fmt, ##args)
#define LOGD(fmt, args...) __android_log_print(ANDROID_LOG_DEBUG, TAG, fmt, ##args)
#define LOGE(fmt, args...) __android_log_print(ANDROID_LOG_ERROR, TAG, fmt, ##args)

static const char *TAG="TJMedia_ServiceLIB";

static JavaVM *g_pVM;
/*
static jint tes(JNIEnv *env, jobject thiz,jint nKBsize, jdoubleArray arr, int nStorage) {	            
		jdouble *parr;
		double buff[4];
    parr = env->GetDoubleArrayElements(arr, NULL);
    BenchmarkThread(nKBsize,buff,nStorage);
    for ( int i = 0; i < 4; i++)
    {
    	parr[i] = buff[i];
    }
    env->ReleaseDoubleArrayElements(arr, parr, 0);
    return 0;
}
*/



static speed_t getBaudrate(jint baudrate)
{
	switch(baudrate) {
	case 0: return B0;
	case 50: return B50;
	case 75: return B75;
	case 110: return B110;
	case 134: return B134;
	case 150: return B150;
	case 200: return B200;
	case 300: return B300;
	case 600: return B600;
	case 1200: return B1200;
	case 1800: return B1800;
	case 2400: return B2400;
	case 4800: return B4800;
	case 9600: return B9600;
	case 19200: return B19200;
	case 38400: return B38400;
	case 57600: return B57600;
	case 115200: return B115200;
	case 230400: return B230400;
	case 460800: return B460800;
	case 500000: return B500000;
	case 576000: return B576000;
	case 921600: return B921600;
	case 1000000: return B1000000;
	case 1152000: return B1152000;
	case 1500000: return B1500000;
	case 2000000: return B2000000;
	case 2500000: return B2500000;
	case 3000000: return B3000000;
	case 3500000: return B3500000;
	case 4000000: return B4000000;
	default: return -1;
	}
}
//Remocon +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#define TDMK_IOCTL_NUMBER			'z'
#define TDMK_IOCTL__RMC_SEND\
	_IOW(TDMK_IOCTL_NUMBER, 1, TDMK_RMC_Send_t*)
	
#define TDMK_IOCTL__MITSUBISHI_RMC_SEND\
	_IOW(TDMK_IOCTL_NUMBER, 11, TDMK_RMC_Send_t*)

#define __PACKED__                  __attribute__((packed))

typedef struct
{
	int	nCmd;
	void	*pParam;
} __PACKED__
TDMK_CMD_t;

typedef struct 
{
	int             nLen;
	unsigned char   pData[32];
} __PACKED__
TDMK_RMC_Send_t;

int TJ_MITSUBISHI_IR_Send(int nSize, uint8_t *pBuffer)
{
	int ret = 0;
	int err;
	
     TDMK_CMD_t stCmd;
        TDMK_RMC_Send_t stSend;

        stSend.nLen = nSize;
        memcpy(stSend.pData, pBuffer, nSize);

        stCmd.nCmd = 11;
        stCmd.pParam = (void*)&stSend;


        int fd = open("/dev/tdmk_misc", O_RDWR);
        if (fd < 0)
        {
                return -1;
        }
        write (fd, (unsigned char*)&stCmd, sizeof(TDMK_CMD_t));
	close(fd);
	return ret;
}

int TJ_IR_Send(int nSize, uint8_t *pBuffer)
{

	int ret = 0;
	int err;

	TDMK_CMD_t stCmd;
	TDMK_RMC_Send_t stSend;

	stSend.nLen = nSize;
	memcpy(stSend.pData, pBuffer, nSize);

	stCmd.nCmd = 1;
	stCmd.pParam = (void*)&stSend;


	int fd = open("/dev/tdmk_misc", O_RDWR);	
	if (fd < 0)
	{
		return -1;
	}
	write (fd, (unsigned char*)&stCmd, sizeof(TDMK_CMD_t));
 
	close(fd);
	return ret;
}

//JNI Function++++++++++++++++++++++++++++++++

/*
 * Class:     com/tjmedia/service/TJMedia_ServiceAPI
 * Method:    Rmcsend
 * Signature: (B[BI)I;
 */
static int Rmcsend(JNIEnv *env, jclass pThis, jbyte rmcid, jbyteArray pData, jint nSize)
{
	jint ret = 0;	
	jbyte		*pBuffer;
	pBuffer = env->GetByteArrayElements(pData,NULL);
	
	if (pBuffer == NULL)
	{		
		return -1;
	}

	switch(rmcid)
	{
		case 1:				
		if (TJ_IR_Send(nSize, (uint8_t*)pBuffer)!=0)
		{
			ret = -1;
	  }
	  break;
	  
		case 2:				
		if (TJ_MITSUBISHI_IR_Send(nSize, (uint8_t*)pBuffer)!=0)
		{
			ret = -2;
	  }
	  break;
	  
	  default :
	  	ret = -3;
	}
	
	env->ReleaseByteArrayElements(pData,pBuffer,0);

  return ret;
}
/*
 * Class:     com/tjmedia/service/TJMedia_ServiceAPI
 * Method:    Serialopen
 * Signature: (Ljava/lang/String;II)Ljava/io/FileDescriptor;
 */
static jobject Serialopen(JNIEnv *env, jobject thiz, jstring path, jint baudrate, jint flags)
{
	int fd;
	speed_t speed;
	jobject mFileDescriptor;

	/* Check arguments */
	{
		speed = getBaudrate(baudrate);
		if (speed == -1) {
			/* TODO: throw an exception */
			LOGE("Invalid baudrate");
			return NULL;
		}
	}

	/* Opening device */
	{
		jboolean iscopy;
		const char *path_utf = env->GetStringUTFChars(path, &iscopy);
		
		LOGD("Opening serial port %s with flags 0x%x", path_utf, O_RDWR | flags);
		fd = open(path_utf, O_RDWR | flags);
		LOGD("open() fd = %d", fd);
		env->ReleaseStringUTFChars(path, path_utf);
		if (fd == -1)
		{
			/* Throw an exception */
			LOGE("Cannot open port");
			/* TODO: throw an exception */
			return NULL;
		}
	}

	/* Configure device */
	{
		struct termios cfg;
		int status = 0;
		LOGD("Configuring serial port");
		if (tcgetattr(fd, &cfg))
		{
			LOGE("tcgetattr() failed");
			close(fd);
			/* TODO: throw an exception */
			return NULL;
		}
		LOGD("Configuring serial port:OK ");

		cfmakeraw(&cfg);
		cfsetispeed(&cfg, speed);
		cfsetospeed(&cfg, speed);

		if (tcsetattr(fd, TCSANOW, &cfg))
		{
			LOGE("tcsetattr() failed");
			close(fd);
			/* TODO: throw an exception */
			return NULL;
		}
		/*
		status |= TIOCM_RTS;
		ioctl(fd, TIOCMSET, &status);
		status |= TIOCM_DTR;
		ioctl(fd, TIOCMSET, &status);
		sleep(1);
		status &= ~TIOCM_DTR;
                ioctl(fd, TIOCMSET, &status);
		*/
	}

	/* Create a corresponding file descriptor */
	{
		jclass cFileDescriptor = env->FindClass("java/io/FileDescriptor");
		jmethodID iFileDescriptor = env->GetMethodID(cFileDescriptor, "<init>", "()V");
		jfieldID descriptorID = env->GetFieldID(cFileDescriptor, "descriptor", "I");
		mFileDescriptor = env->NewObject(cFileDescriptor, iFileDescriptor);
		env->SetIntField(mFileDescriptor, descriptorID, (jint)fd);
	}

	return mFileDescriptor;
}

/*
 * Class:     com/tjmedia/service/TJMedia_ServiceAPI
 * Method:    Serialclose
 * Signature: ()V
 */
static void Serialclose(JNIEnv *env, jobject thiz)
{
	jclass SerialPortClass = env->GetObjectClass(thiz);
	jclass FileDescriptorClass = env->FindClass("java/io/FileDescriptor");

	jfieldID mFdID = env->GetFieldID(SerialPortClass, "mFd", "Ljava/io/FileDescriptor;");
	jfieldID descriptorID = env->GetFieldID(FileDescriptorClass, "descriptor", "I");

	jobject mFd = env->GetObjectField(thiz, mFdID);
	jint descriptor = env->GetIntField(mFd, descriptorID);

	LOGD("close(fd = %d)", descriptor);
	close(descriptor);
}

/*
 * Class:     com/tjmedia/service/TJMedia_ServiceAPI
 * Method:    SystemRun
 * Signature: (Ljava/lang/String;)I
 */
static int SystemRun(JNIEnv *env, jobject thiz,jstring cmd)
{
	int ret = 0;
	jboolean iscopy;
	const char *cmd_utf = env->GetStringUTFChars(cmd, &iscopy);
	ret = system(cmd_utf);
	LOGD("%s => ret:%d",cmd_utf, ret);
	env->ReleaseStringUTFChars(cmd, cmd_utf);
	return ret;
}

/*
 * Class:     com/tjmedia/service/TJMedia_ServiceAPI
 * Method:    Get_Property
 * Signature: (Ljava/lang/String;)Ljava/lang/String;
 */
static jstring GetProperty(JNIEnv *env, jobject thiz,jstring strCmd) {
	char szCmd[256] = {0};  
	char curr_target[128] = {0};      
	int result  = 0;
	const char *pszCmd = env->GetStringUTFChars(strCmd, 0);
	strcpy(szCmd,pszCmd);	
	__system_property_get(szCmd, curr_target);	
	env->ReleaseStringUTFChars(strCmd, pszCmd);
	
	return env->NewStringUTF(curr_target);
}

/*
 * Class:     com/tjmedia/service/TJMedia_ServiceAPI
 * Method:    GetSerialNumber
 * Signature: ()Ljava/lang/String;
 */
static jstring GetSerialNumber(JNIEnv *env, jobject thiz)
{
	char str[128] = {0}; 
	sprintf(str,"AK0111222");
	return env->NewStringUTF(str);
}
//JNI Function--------------------------------

static const char *classPathName = "com/tjmedia/service/TJMedia_ServiceAPI";

static JNINativeMethod methods[] = {  
  {"JNIGetProperty","(Ljava/lang/String;)Ljava/lang/String;",(void*)GetProperty },
  {"JNIGetSerialNumber","()Ljava/lang/String;",(void*)GetSerialNumber },  
  {"JNIRmcsend","(B[BI)I",(void*)Rmcsend },
  {"JNISerialopen","(Ljava/lang/String;II)Ljava/io/FileDescriptor;",(void*)Serialopen },
  {"JNISerialclose","()V",(void*)Serialclose },
  {"JNISystemRun","(Ljava/lang/String;)I",(void*)SystemRun },
};

/*
 * Register several native methods for one class.
 */
static int registerNativeMethods(JNIEnv* env, const char* className,
    JNINativeMethod* gMethods, int numMethods)
{
    jclass clazz;

    clazz = env->FindClass(className);
    if (clazz == NULL) {
        LOGE("Native registration unable to find class '%s'", className);
        return JNI_FALSE;
    }
    if (env->RegisterNatives(clazz, gMethods, numMethods) < 0) {
        LOGE("RegisterNatives failed for '%s'", className);
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

/*
 * Register native methods for all classes we know about.
 *
 * returns JNI_TRUE on success.
 */
static int registerNatives(JNIEnv* env)
{
  if (!registerNativeMethods(env, classPathName,
                 methods, sizeof(methods) / sizeof(methods[0]))) {
                 	LOGE("ERROR: registerNativeMethods failed");
    return JNI_FALSE;
  }

  return JNI_TRUE;
}


// ----------------------------------------------------------------------------

/*
 * This is called by the VM when the shared library is first loaded.
 */
 
typedef union {
    JNIEnv* env;
    void* venv;
} UnionJNIEnvToVoid;

jint JNI_OnLoad(JavaVM* vm, void* reserved)
{
    UnionJNIEnvToVoid uenv;
    uenv.venv = NULL;
    jint result = -1;
    JNIEnv* env = NULL;
    
    LOGI("JNI_OnLoad");

    if (vm->GetEnv(&uenv.venv, JNI_VERSION_1_4) != JNI_OK) {
        LOGE("ERROR: GetEnv failed");
        goto bail;
    }
    env = uenv.env;

    if (registerNatives(env) != JNI_TRUE) {
        LOGE("ERROR: registerNatives failed");
        goto bail;
    }
    g_pVM = vm;
    result = JNI_VERSION_1_4;
    
bail:
    return result;
}
