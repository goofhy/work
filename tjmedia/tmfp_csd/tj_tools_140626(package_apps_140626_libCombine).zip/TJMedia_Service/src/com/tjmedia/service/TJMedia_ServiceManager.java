package com.tjmedia.service;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.util.Log;

public class TJMedia_ServiceManager extends BroadcastReceiver{

	private static final String TAG = "TJMedia_ServiceManager";
	private PowerManager mPowerManager;
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub				
		if(intent.getAction().equals("android.intent.action.BOOT_COMPLETED")){
			Log.d(TAG, "============= android.intent.action.BOOT_COMPLETED =============");
			ComponentName cn = new ComponentName(context.getPackageName(), TJMedia_Service.class.getName());
		    ComponentName svcName = context.startService(new Intent().setComponent(cn));
		    
		    if (svcName == null) 
		      Log.e("BOOTSVC", "Could not start service " + cn.toString());
		}		
		else if (intent.getAction().equals("TMFP.DATA") || intent.getAction().equals("CSD.DATA"))
		{
			Log.d(TAG, "============= TMFP.DATA =============");
			byte bSize = intent.getByteExtra("leng",(byte)0x1);
			byte bCmd =  intent.getByteExtra("cmd", (byte)0x0);			
			byte[] buffer = new byte[bSize];
			buffer = intent.getByteArrayExtra("data");
			
//			String str;
//			int i = 0;
//			str = "TMFP.DATA :cmd[" + bCmd + "] len[" + bSize + "] data";
//			for(i=0; i<bSize ;i++)
//			str += String.format("[0x%02X]", buffer[i]);						 						
//			str += "\n";					
//			Log.d(TAG, str);		
			TJMedia_Service.Send(bCmd, buffer,bSize);			 
		}		
		else if (intent.getAction().equals("TMFP.ALARM"))
		{
			Log.d(TAG, "============= TMFP.ALARM =============");
			
			boolean bOnOff = intent.getBooleanExtra("onoff", false);
			int time = intent.getIntExtra("time", 0);
			TJMedia_Service.SetAlarm(bOnOff,time);
		}
	}
	

}
