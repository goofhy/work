package com.tjmedia.service;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.security.InvalidParameterException;
import java.util.Date;


import android.R.string;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.os.SystemClock;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.hardware.usb.UsbManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.widget.Toast;
import android.view.KeyEvent;
import com.tjmedia.*;


public class TJMedia_Service extends Service{
	
	static String TAG = "TJMedia_Service";
	
	//VERSION
	static String TJSERVICE_VER = "v";	
	
	final int AID_APP =         10000;  /* first app user */
	
//	private SerialPort mSerialPort = null;
//	private static SerialPort mTestSerialPort = null;
	protected static OutputStream mOutputStream;
	private static InputStream mInputStream;
	private ReadThread mReadThread;
	private int mRecvCount = 0;
	static AlarmManager am;
	static PendingIntent sender;
	private TJMedia_Common TJCommon; 
	private static TJMedia_Common sTJCommon;
	private int g_nCount = TJCommon.KEYCODE_TMFP_MUSIC_VOL_UP;	
	static TJMedia_ServiceAPI tjApi = null;
	
	static final String SN_FILENAME = "sn.txt";
	static final String SN_ORG_FILENAME = "/system/vendor/tjmedia/sn.txt";
	static final String SN_TMP_FILENAME = "/data/data/com.tjmedia.service/files/sn.txt";
	
	int g_08cmd = 0;
	int g_09cmd = 0;
	int g_rmcpos = 0;
	int g_recvpos = 0;
	byte [] g_rmcsend = new byte[20];
	byte [] g_recv = new byte[100];
	int mRecvStx = 0;
	int mRecvEtx = 0;	
	boolean mOnStartflag = false;
	boolean mSystemCallRetrun = false;
	boolean mSystemCallError = false;
	static Context mContext;
  

    @Override
    public IBinder onBind(Intent intent) {
    	TJSERVICE_VER =  "v"+ TJLog.updateVersionInfo(this);
    	Log.d(TAG, "========================TJMEDIA JAVA Service [" + TJSERVICE_VER + "] OnBind========================" + mbinder);
    	
    	g_08cmd = 0;
    	g_09cmd = 0;
    	g_rmcpos = 0;
    	
    	if (!mOnStartflag) init();
    	
        return mbinder;
//    	return null;
    }
        
    @Override
    public void onCreate() {
    	// TODO Auto-generated method stub
    	super.onCreate();
    }
    
    public void init()
    {        
    	Log.d(TAG, "========================TJMEDIA JAVA Service [" + TJSERVICE_VER + "] Init========================");
        if (null == tjApi)
        	tjApi = new TJMedia_ServiceAPI();

        mContext = getApplicationContext();
        if (TJLog.getCSD())
        {
			try {
				if (null != tjApi)
					tjApi.SerialPort(new File("/dev/ttySAC1"), 0, 0);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			   
        	Log.d(TAG, "onStart() => B/D CSD");
        	Log.d(TAG, "onStart()--");        	
        }
        else if (TJLog.getTMFP())
        {
	        Log.d(TAG, "onStart() => B/D TMFP");
	    	try {
	    		Log.d(TAG, "SerialOpen++");
	    		if (null != tjApi)
	    			tjApi.SerialPort(new File("/dev/ttySAC1"), 115200, 0);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	Log.d(TAG, "SerialOpen--");
	    	    	
	    	
			try {
				if (null != tjApi)
				{
					mOutputStream = tjApi.getSerialPortOutputStream();
					mInputStream = tjApi.getSerialPortInputStream();				
					/* Create a receiving thread */
					mReadThread = new ReadThread();
					mReadThread.start();
					InitMicom();	    			    		
				}	

			} catch (SecurityException e) {
				
			} catch (InvalidParameterException e) {
				
			}    	
			Log.d(TAG, "onStart()--");
        }	
        else if(TJLog.getTM10())
        {
        	Log.d(TAG, "onStart() => B/D TM10");
			try {
				if (null != tjApi)
					tjApi.SerialPort(new File("/dev/ttySAC1"), 0, 0);
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			       	        
        	Log.d(TAG, "onStart()--"); 
        }
        
        try {
			Log.d(TAG, "========================SN :" + mbinder.SYSTEM_GetSerialNumber());
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        Intent intent1 = new Intent(this, TJMedia_ServiceAlramManager.class);
		sender = PendingIntent.getBroadcast(this, 0, intent1, 0);
    }
    
    @Override
    public void onStart(Intent intent, int startId) {
    	TJSERVICE_VER =  "v"+ TJLog.updateVersionInfo(this);
    	Log.d(TAG, "========================TJMEDIA JAVA Service [" + TJSERVICE_VER + "] onStart========================");
    	
    	g_08cmd = 0;
    	g_09cmd = 0;
    	g_rmcpos = 0;
    	mOnStartflag = true;
        Log.d(TAG, "onStart()++");     
        init();
        super.onStart(intent, startId);
    }
     
    @Override
    public void onDestroy() {         
    	
        Log.d(TAG, "========================TJMEDIA JAVA Service [" + TJSERVICE_VER + "] onDestroy========================");        
        if (TJLog.getCSD())
        {
        	Log.d(TAG, "onDestroy() => B/D CSD");
        	return;
        }
        if (TJLog.getTM10())
        {
        	Log.d(TAG, "onDestroy() => B/D CSD");
        	return;
        }     
        
        Log.d(TAG, "onDestroy() => B/D TMFP");
        Log.d(TAG, "mReadThread.stop");
        mReadThread.stop();
        Log.d(TAG, "mSerialPort.close");
        if (null != tjApi)
        	tjApi.JNISerialclose();
        mOnStartflag = false;
        Log.d(TAG, "onDestroy()--");
        super.onDestroy();
    }
        
    private void TMFP_System(String str)
    {
    	//Log.d(TAG, "TMFP_System = " + str);
    	if (null != tjApi)
    		tjApi.JNISystemRun(str);
    }
    
    static void TestTMFP_System(String str)
    {
    	//Log.d(TAG, "TMFP_System = " + str);
    	if (null != tjApi)
    		tjApi.JNISystemRun(str);
    }    
     
    private static int CSD_RmcSend(byte id, byte [] data, int len)
    {
    	//Log.d(TAG, "TMFP_System = " + str);		
    	//mSerialPort.system(str);
    	if (null != tjApi)
    		return tjApi.JNIRmcsend(id, data, len);
    	return -1;
    }    
    
 
    private void InitMicom()
    {
    	byte []data = new byte[100];
    	byte []data2 = new byte[1];
    	TJLog.d(TAG,"InitMicom++");
    	try {
    		
			data2[0] = 0;
			//VolScanTime : 0 msec => onkeydown/up
			TJLog.d(TAG,"Micom Volume ScanTime : 0msec++");
			Send(sTJCommon.VOL_TRANSTIME,data2,(byte)1);
    		
    		data[0] = TJCommon.STX;
    		data[1] = TJCommon.MICOM_GET_VER_CMD;
    		data[2] = 2;
    		data[3] = 0;
    		data[4] = 0;
    		data[5] = 0x53;
    		data[6] = TJCommon.ETX;
    		TJLog.d(TAG,"Micom Volume GetVersion++");
			mOutputStream.write(data,0,7);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
    	TJLog.d(TAG,"InitMicom--");
    }
    
	private class ReadThread extends Thread {
				
		LoopHandler mLoop = new LoopHandler();
		public class LoopHandler extends Handler {
			private int count = 0;
			private boolean bStop;
			private boolean mFLAG = false;

			@Override
			synchronized public void handleMessage(Message msg) {
//				Log.d(TAG, "handleMessage");
				if (bStop == false) {					
						bStop = true;
						Log.d(TAG, "Timeout> rmc---------------");	
						rmcsend((byte)0,1);					
				}
				super.handleMessage(msg);
			}

			private void sleep(long delayMillis) {
				this.removeMessages(0);
				sendMessageDelayed(obtainMessage(0), delayMillis);
			}

			public void stop() {
				bStop = true;
			}

			private void start() {
				bStop = false;							
			}
		};

		synchronized public int rmcsend(byte data, int force)
		{
			Log.d(TAG, "==rmc status : f=> " + force + " 08cmd =>" + g_08cmd + " 09cmd =>" + g_09cmd + " g_rmcpos =>" + g_rmcpos + "==");		
			if (1 == force)
			{
				if (0 == g_rmcpos)
				{					
					return 0;
				}
				Intent intent = new Intent();
				intent.setAction("TMFP.RMC");
				intent.putExtra("data", g_rmcsend);																	
				intent.putExtra("leng", (byte)g_rmcpos);
				sendBroadcast(intent);
				g_rmcpos = 0;
				g_08cmd = 0;
				g_09cmd = 0;
				return 1;
			}
			
			//08 Start
			if (data == (byte)0x08 && 0 == g_08cmd)
			{
				g_08cmd = 1;
				g_rmcsend[g_rmcpos++] = data;							
				return 0;
			}
			//09 Stop
			else if (data == (byte)0x09 && 1 == g_08cmd && 0 == g_09cmd)
			{
				g_09cmd = 1;
				g_rmcsend[g_rmcpos++] = data;
				
				Intent intent = new Intent();
				intent.setAction("TMFP.RMC");
				intent.putExtra("data", g_rmcsend);																	
				intent.putExtra("leng", (byte)g_rmcpos);
				sendBroadcast(intent);											

				g_rmcpos = 0;
				g_08cmd = 0;
				g_09cmd = 0;

				return 1;
			}
			//�??�약 buffer 처리
			else if (1 == g_08cmd && 0 == g_09cmd)
			{				 
				 if (g_rmcpos >= 18)
				 {
					g_rmcsend[g_rmcpos++] = data;
					Intent intent = new Intent();
					intent.setAction("TMFP.RMC");
					intent.putExtra("data", g_rmcsend);																	
					intent.putExtra("leng", (byte)g_rmcpos);
					sendBroadcast(intent);

					g_rmcpos = 0;
					g_08cmd = 0;
					g_09cmd = 0;

					return 1; 
				 }
				 else
				 {
					 g_rmcsend[g_rmcpos++] = data;
				 }
			     return 0;	
			}
			else			
			{
				byte [] send = new byte[1];
				send[0] = data;
				Intent intent = new Intent();
				intent.setAction("TMFP.RMC");
				intent.putExtra("data", send);																	
				intent.putExtra("leng", (byte)1);
				sendBroadcast(intent);
				return 1;
			}
		}
		
		synchronized public int keysend(int data, int leng)
		{					
				Intent intent = new Intent();
				intent.setAction("TMFP.VOL");
				intent.putExtra("key", data);																	
				intent.putExtra("leng",leng);
				sendBroadcast(intent);	
				Log.d(TAG, "BroadCase KEY:" + data + " LENG:" + leng);	
				return 0;
		}

		synchronized public int paser_to_send(byte[] buffer,int size)
		{
			int stx_pos = 0;			
			int cmd_pos = 1;
			int cmd = -1;
			int len_pos = 2;
			int data_pos = 3;
			int ret = -1;	
			String strcmd;	
						
			//stx,cmd,len,data,crc,etx
			if (size < 6)
			{				
				int i = 0;
				String str = "";
				for (i = 0; i < size; i++)
				{
					str += "[" + String.format("0x%02X", buffer[i]) + "]";					
				}
				Log.e(TAG, "Error, Recv data:" + str);				
				return -1;
			}
			
			int len = buffer[len_pos];			
			int crc_pos = data_pos + len;
			int etx_pos = crc_pos + 1;
			
//			String strcmd;			
//			Log.d(TAG, "Recv data:" + len + ":" + crc_pos +":" + etx_pos);
			
			//stx
			if (buffer[stx_pos] == TJCommon.STX &&
				etx_pos+1 == size 		&&
				buffer[etx_pos] == TJCommon.ETX		)
			{
				cmd = buffer[cmd_pos];				
				switch(cmd)
				{
					case TJMedia_Common.RMC_ID:
					{
//						byte[] send = new byte[len];
//						System.arraycopy(buffer,data_pos,send,0,len);
//						byte send = buffer[data_pos];
//						Intent intent = new Intent();
//						intent.setAction("TMFP.RMC");
//						intent.putExtra("data", send);																	
//						sendBroadcast(intent);			
						if (0 == rmcsend(buffer[data_pos],0))
						{
							mLoop.stop();
							mLoop.removeMessages(0);							
							mLoop.start();
							mLoop.sleep(300);
						}
						else
						{
							mLoop.stop();
							mLoop.removeMessages(0);										
						}
						return 1;
					}					
					
					case TJMedia_Common.VOL1_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL1_UP:TJCommon.VOL1_DOWN;
					}
					break;													

					case TJMedia_Common.VOL2_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL2_UP:TJCommon.VOL2_DOWN;						
					}
					break;						

					case TJMedia_Common.VOL3_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL3_UP:TJCommon.VOL3_DOWN;						
					}
					break;						

					case TJMedia_Common.VOL4_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL4_UP:TJCommon.VOL4_DOWN;						
					}
					break;	
					
					case TJMedia_Common.EXT_VOL1_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL1_UP:TJCommon.VOL1_DOWN;
						int leng = buffer[data_pos+1];
						keysend(ret,leng);						
					}
					return 2;											

					case TJMedia_Common.EXT_VOL2_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL2_UP:TJCommon.VOL2_DOWN;
						int leng = buffer[data_pos+1];
						keysend(ret,leng);						
					}
					return 2;										

					case TJMedia_Common.EXT_VOL3_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL3_UP:TJCommon.VOL3_DOWN;
						int leng = buffer[data_pos+1];
						keysend(ret,leng);						
					}
					return 2;					

					case TJMedia_Common.EXT_VOL4_ID:
					{
						ret = (buffer[data_pos] > 0)?TJCommon.VOL4_UP:TJCommon.VOL4_DOWN;
						int leng = buffer[data_pos+1];
						keysend(ret,leng);						
					}
					return 2;					
					
					case TJMedia_Common.MICOM_GET_VER_CMD:
					{						
						byte[] send = new byte[len];
						System.arraycopy(buffer,data_pos,send,0,len);						
						Log.d(TAG,"=========Version===========" + send[0] + "," + send[1]);						
					}
					return 0;
					
					default: break;
					
				}
			}
			else
			{
				int i = 0;
				String str = "";
				for (i = 0; i < size; i++)
				{
					str += "[" + String.format("0x%02X", buffer[i]) + "]";					
				}
				Log.e(TAG, "Unknow, Recv data:" + str);		
				return -1;
			}
			if (ret != -1)
			{
				//strcmd = "echo " + ret + " > /sys/devices/platform/s3c2440-i2c.6/i2c-6/6-0048/vkeytest";
				strcmd = "echo " + ret + " > /sys/devices/platform/gpio-keys.0/vkeytest";				
				TMFP_System(strcmd);
			}
			return ret;
		}				
		
		public void parser()
		{
			
			byte[] buffer = new byte[1];			
			int size = 0;
			try {
				size = mInputStream.read(buffer,0,1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (size > 0)
			{
//				String tmpstr = "["  + g_recvpos + "]" + "[" + String.format("0x%02X", buffer[0]) + "]";
//				Log.d(TAG, tmpstr);
				
				if (mRecvStx == 0 && buffer[0] == TJCommon.STX)
				{
					mRecvStx = 1;
					g_recvpos = 0;
				}
				else if (mRecvStx == 1 && mRecvEtx == 0 &&  buffer[0] == TJCommon.ETX && g_recvpos > 4)
				{
					mRecvEtx = 1;					
				}				
				else if (g_recvpos > 10)
				{
					int i = 0;
					String str = "";
					for (i = 0; i < g_recvpos; i++)
					{
						str += "[" + String.format("0x%02X", g_recv[i]) + "]";					
					}
					Log.e(TAG, "Error, Paser Recv data:" + str);
					
					g_recvpos = 0;
					mRecvStx = mRecvEtx = 0;					
				}
				
				if (1 == mRecvStx)
				{
					g_recv[g_recvpos++] = buffer[0];
				}				
				if (1 == mRecvEtx)
				{
//					Log.d(TAG, "Paser Recv data: OK[" + g_recvpos + "]++");
					paser_to_send(g_recv,g_recvpos);
//					Log.d(TAG, "Paser Recv data: --");
					g_recvpos = 0;
					mRecvStx = mRecvEtx = 0;
				}				
			}
						
		}
		
		@Override
		public void run() {
			super.run();
			while(!isInterrupted()) {
				int size;
				int nCount = 0;
				//					byte[] buffer = new byte[100];
									if (mInputStream == null) return;
									parser();
				//					size = mInputStream.read(buffer);
				//					
				//					if (size > 0) {
				//						paser_to_send(buffer,size);
				//							int i = 0;
				//							String str = "";
				//							for (i = 0; i < size; i++)
				//							{
				//								str += "[" + String.format("0x%02X", buffer[i]) + "]";					
				//							}
				//							Log.d(TAG, "Recv data:" + str);				
				//					}															
			}
			
		}
	}
	
	public static void SetAlarm(boolean onoff,int time)
	{
		if (onoff)
		{
			Log.d(TAG, "============= TMFP.ALARM :ON [" + time + "]msec");
			am.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime(), time, sender);
		}
		else
		{
			Log.d(TAG, "============= TMFP.ALARM :OFF");
			am.cancel(sender);
		}
	}

	synchronized public static int Send(byte cmd, byte[] buffer, byte size) {
		// TODO Auto-generated method stub
		int ret = -1;
		if (size <= 0)
		{
	    	Log.e(TAG, "Unknow LEN[" + String.format("0x%02X", size) + "]");
	    	return -1;			
		}
		if (TJLog.getTMFP())
		{			
		    if (sTJCommon.BOTTOM_PCB_LED_ALL_CMD <= cmd && sTJCommon.MICOM_GET_VER_CMD >= cmd || (sTJCommon.VOL_TRANSTIME == cmd))
		    {
		    	byte[] transbuffer = new byte[100];
		    	int i = 0;
		    	int translen = 5 + size;
		    	transbuffer[0] = sTJCommon.STX;
		    	transbuffer[1] = cmd;
		    	transbuffer[2] = size;	    	
		    	System.arraycopy(buffer,0,transbuffer,3,size);
		    	
		    	transbuffer[3+size] += cmd;
		    	transbuffer[3+size] += size;
		    	for (i = 0; i < size; i++)
		    	{
		    		transbuffer[3+size] += buffer[i];
		    	}
		    	transbuffer[3+size+1] = sTJCommon.ETX;
		    	
				try {			
					mOutputStream.write(transbuffer,0,translen);
					String str = "";
					for (i = 0; i < translen; i++)
					{					
						str += "[" + String.format("0x%02X", transbuffer[i]) + "]";	
					}
					Log.d(TAG, "Trans data:" + str);		
					ret = 0;
				} catch (IOException e) {
					ret = -1;
					e.printStackTrace();
				}   
		    }
		    else
		    {
		    	Log.e(TAG, "Unknow CMD[" + String.format("0x%02X", cmd) + "]");
		    	return -1;
		    }
		}
		else
		{
			int i = 0;
			if (sTJCommon.API_IRSEND == cmd || sTJCommon.API_MTVIRSEND == cmd)
			{
				String str = "RMC_SEND" + " cmd[" + String.format("0x%02X", cmd) + "]";
				if (cmd == 2) str += "tv:"; 
				for (i = 0; i < size; i++)
				{					
					str += "[" + String.format("0x%02X", buffer[i]) + "]";	
				}			
				if (0 != CSD_RmcSend(cmd,buffer,size))
				{
					str += ":NG";		
					ret = -1;
				}
				else
				{
					str += ":OK";
					ret = 0;
				}
				Log.d(TAG, "Trans data:" + str);
			}
			return ret;
		}
		return ret;
		
	}
	

	public static String getData(String szFilename) {
		String data = "";
		Log.d(TAG, "getData++");
		try {
			InputStream in = mContext.openFileInput(szFilename);
			if (in != null)
			{
				InputStreamReader input = new InputStreamReader(in);
				BufferedReader reader = new BufferedReader(input);
				
				String str = "";
				try {
					while((str = reader.readLine()) != null)						
					{
						data += str + "\n";
						//Log.d(TAG,"[" + str + "]");
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					input.close();
					reader.close();
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Log.d(TAG, "getData--");
		return data;
	}
	
	ITJMedia_ServiceInterface.Stub mbinder = new ITJMedia_ServiceInterface.Stub() {		

		public int IR_Send(byte[] pBuffer, byte leng) throws RemoteException
		{
			if (TJLog.getTMFP())	return -1;
			return Send(sTJCommon.API_IRSEND,pBuffer,leng);
		}

		public int MITSUBISHI_IR_Send (byte[] pBuffer, byte leng) throws RemoteException
		{
			if (TJLog.getTMFP())	return -1;
			return Send(sTJCommon.API_MTVIRSEND,pBuffer,leng);
		}
		
		@Override
		public int PROXY_SetServerInfo(String szServerAddress, int nPortHTTP, int nPortHTTPS) throws RemoteException
		{
			if (null == tjApi) return -1;			
			return tjApi.PROXY_SetServerInfo(szServerAddress, nPortHTTP, nPortHTTPS);
		}
		@Override
		public int PROXY_HTTP_AddRedirectionPort(int nPort) throws RemoteException
		{
			if (null == tjApi) return -1;
			return tjApi.PROXY_HTTP_AddRedirectionPort(nPort);
		}
		@Override
		public int PROXY_HTTPS_AddRedirectionPort(int nPort) throws RemoteException
		{
			if (null == tjApi) return -1;			
			return tjApi.PROXY_HTTPS_AddRedirectionPort(nPort);						
		}
		@Override
		public int PROXY_Start() throws RemoteException
		{
			if (null == tjApi) return -1;
			return tjApi.PROXY_Start();
		}
		@Override
		public int PROXY_Stop() throws RemoteException
		{
			if (null == tjApi) return -1;			
			return tjApi.PROXY_Stop();
		}
		
		@Override
		public String GetVersionInfo(int section) throws RemoteException
		{
			switch(section)
			{
			case 3: return TJSERVICE_VER;
			}
			
//			if (null == tjApi) return -1;		
//			return tjApi.GetVersionInfo();		
			return null;
		}	

		@Override
		public int PRIVATEINFO_GetTotalSize() throws RemoteException
		{
			if (null == tjApi) return -1;		
			return tjApi.PRIVATEINFO_GetTotalSize();		
		}
		
		@Override
		public int PRIVATEINFO_GetBlockSize() throws RemoteException
		{
			if (null == tjApi) return -1;	
			return tjApi.PRIVATEINFO_GetBlockSize();	
		}
		
		@Override
		public int PRIVATEINFO_GetBlock(int nStartBlock, int nBlockCount, byte[] pData_out) throws RemoteException
		{
			if (null == tjApi) return -1;	
			return tjApi.PRIVATEINFO_GetBlock(nStartBlock, nBlockCount, pData_out);			
		}
		
		@Override
		public int PRIVATEINFO_SetBlock(int nStartBlock, int nBlockCount, byte[] pData) throws RemoteException
		{
			if (null == tjApi) return -1;		
			return tjApi.PRIVATEINFO_SetBlock(nStartBlock, nBlockCount, pData);	
		}
						
		@Override
		public int PACKAGE_Install(String szAPK, int nOption) throws RemoteException
		{
			if (null == tjApi) return -1;		
			return tjApi.PACKAGE_Install(szAPK,nOption);	
		}
		
		@Override
		public int PACKAGE_UnInstall(String szPackageName, int nOption) throws RemoteException
		{
			if (null == tjApi) return -1;		
			return tjApi.PACKAGE_UnInstall(szPackageName,nOption);	
		}
		

		@Override
		public int SYSTEM_Run(String szCommandLine) throws RemoteException
		{
			if (null == tjApi) return -1;
			return tjApi.SYSTEM_Run(szCommandLine);
		}
		

		@Override
		public int SYSTEM_SetSerialNumber(String szSerialNumber) throws RemoteException
		{
//			if (null == tjApi) return -1;
//			return tjApi.SYSTEM_SetSerialNumber(szSerialNumber);
			mContext.deleteFile(SN_FILENAME);
			FileOutputStream fos;
			try {
				fos = mContext.openFileOutput(SN_FILENAME,Context.MODE_WORLD_WRITEABLE);
				try {
					fos.write(szSerialNumber.getBytes());
					fos.close();
					SystemCall("cp " + SN_TMP_FILENAME + " " + SN_ORG_FILENAME , true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}				
			return 0;
		}

		@Override
		public String SYSTEM_GetSerialNumber() throws RemoteException
		{
//			if (null == tjApi) return null;
//			return tjApi.SYSTEM_GetSerialNumber();
			mContext.deleteFile(SN_FILENAME);			
			SystemCall("cp " + SN_ORG_FILENAME + " " + SN_TMP_FILENAME , true);
			SystemCall("chown system.system " + SN_TMP_FILENAME,false);
			SystemCall("chmod 777 " + SN_TMP_FILENAME,false);
			return getData(SN_FILENAME);			
		}
		
		@Override
		public int TEST() throws RemoteException
		{
			Log.d(TAG , "test");
			return 0;
		}	
		@Override
		public int GetUsbWifiStatus() throws RemoteException
		{
			if (null == tjApi) return -1;
			UsbManager usbmanager = (UsbManager) getSystemService(Context.USB_SERVICE);
			if (null == usbmanager) return -3;
			int wifi = tjApi.GetUsbWifiStatus(usbmanager);
			return wifi;
		}		
		@Override
		public int GetUsbNfcStatus() throws RemoteException
		{
			if (null == tjApi) return -1;			
			UsbManager usbmanager = (UsbManager) getSystemService(Context.USB_SERVICE);
			if (null == usbmanager) return -3;
			int nfc = tjApi.GetUsbNfcStatus(usbmanager);
			return nfc;
		}	
		@Override
		public String GetBusUsbNfc() throws RemoteException
		{
			if (null == tjApi) return null;			
			UsbManager usbmanager = (UsbManager) getSystemService(Context.USB_SERVICE);
			if (null == usbmanager) return null;
			String nfc = tjApi.GetBusUsbNfc(usbmanager);
			return nfc;
		}	
		@Override
		public int SetVolumeScanTime(byte m10_time) throws RemoteException
		{
			if (TJLog.getCSD())	return -1;
			byte data[] = new byte[1];
			data[0] = m10_time;
			return Send(sTJCommon.VOL_TRANSTIME,data,(byte)1);
		}
		
		@Override
		public String SystemCall(String cmd, boolean historydelete) throws RemoteException
		{
			synchronized (this) {				
				Log.d(TAG, "SystemCall++");
				String data = "";
				String error = "";
				String szCmd = "su 0 " + cmd;		
				
				Date date = new Date();
				int M = date.getMonth();
				int D = date.getDate(); 
				int h = date.getHours();
        		int m = date.getMinutes();
        		int s = date.getSeconds();        		
				
        		
				String szhistroCmdS = "Success [" + M +"/"+D +" "+ h +":" + m + ":" + s + "] cmd [" + cmd + "]\n";
				String szhistroCmdE = "Error [" + M +"/"+D +" "+ h +":" + m + ":" + s + "] cmd [" + cmd + "]\n";
				mSystemCallRetrun = false;
				mSystemCallError = false;
				try
				{
					if (historydelete)
					{
						mContext.deleteFile("ret.txt");
						mContext.deleteFile("error.txt");
					}
					FileOutputStream fos = mContext.openFileOutput("ret.txt",Context.MODE_APPEND);							
					FileOutputStream ferros = mContext.openFileOutput("error.txt",Context.MODE_APPEND);					
					fos.write(szhistroCmdS.getBytes());
					ferros.write(szhistroCmdE.getBytes());
					Log.d(TAG, szCmd );										
					Process proc = Runtime.getRuntime().exec( szCmd );					
					ReadStream s1 = new ReadStream(fos, proc.getInputStream());
					ErrorStream s2 = new ErrorStream(ferros, proc.getErrorStream());
					s1.start();
					s2.start();
				
					while(true)
					{ 
						if (!s1.isAlive() && !s2.isAlive())
						{
							proc.waitFor();
							break;
						}
					}
				}
				catch ( Exception e ) { 				
				}
				
				if (mSystemCallRetrun)
					data = getData("ret.txt");
					else
					data = getData("error.txt");
//				Log.d(TAG, szCmd + " : " + data);
				Log.d(TAG, "SystemCall--");				
				return data;				
			}
					}
	};    	
					
					
	public class ReadStream extends Thread {
		
		FileOutputStream name;
	    InputStream is;	    
					
	    public ReadStream(FileOutputStream sname, InputStream sis) {
	        name = sname;
	        is = sis;
	    }       
	    	    
	    public void run () {
					try {
	            InputStreamReader isr = new InputStreamReader (is);
	            BufferedReader br = new BufferedReader (isr);   
	            int i = 0;
	            while (true) {
	                String s = br.readLine ();	                
	                if (s == null && i++ > 10)
	                {	                	
	                	break;
					}					
					
	                if (s == null)
					{
	                	//Log.d(TAG,".");
	                	continue;
	                }
//	                System.out.println ("[" + name + "] " + s);
	                String source = s + "\n";
	                if (!s.equals(""))
	                	mSystemCallRetrun = true;
	                name.write(source.getBytes());	               
					}
					br.close ( );					
	            is.close ();
	            name.close();
	        } catch (Exception ex) {
	            System.out.println ("Problem reading stream " + name + "... :" + ex);
	            ex.printStackTrace ();
	        }
				}
				}
				
	public class ErrorStream extends Thread {
		
		FileOutputStream name;
	    InputStream is;	    
	    
	    public ErrorStream(FileOutputStream sname, InputStream sis) {
	        name = sname;
	        is = sis;
				}
	    	    
	    public void run () {
						try {
	            InputStreamReader isr = new InputStreamReader (is);
	            BufferedReader br = new BufferedReader (isr);   
	            int i = 0;
	            while (true) {
	                String s = br.readLine ();	                
	                if (s == null && i++ > 10)
	                {	                	
	                	break;
					}
	                
	                if (s == null)
	                {
	                	//Log.d(TAG,".");
	                	continue;
					}						
//	                System.out.println ("[" + name + "] " + s);
	                String source = s + "\n";
	                mSystemCallError = true;
	                Log.d(TAG,"Error==========\n" + s + "===============\n");
	                name.write(source.getBytes());	               
					}					
	            br.close();
	            is.close ();
	            name.close();
	        } catch (Exception ex) {
	            System.out.println ("Problem reading stream " + name + "... :" + ex);
	            ex.printStackTrace ();
				}
			}
		}
}
