package com.tjmedia.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.KeyEvent;


public class TJMedia_ServiceAlramManager extends BroadcastReceiver {
    private static final String TAG_LOG = "AlarmReceiver";	
	private PowerManager mPowerManager;
	private WakeLock mWakeLock;
	public static final int KEYCODE_TMFP_MIC_VOL_UP              = 226;
	public static final int KEYCODE_CSD_MBKEY1              = 231;
	static String TAG = "TJMedia_ServiceAlramManager";    
    @Override
    public void onReceive(Context context, Intent intent) {
    	Log.d(TAG,"=========TJMedia_ServiceAlramManager===========");
    	
		mPowerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
		
		if (!mPowerManager.isScreenOn())
		{			
			if (TJLog.getTMFP())
			{
				Log.d(TAG, "============= TMFP.ALARM : Enable Wakeup=============");
				String strcmd = "echo " + KEYCODE_TMFP_MIC_VOL_UP + " > /sys/devices/platform/gpio-keys.0/vkeytest";
				TJMedia_Service.TestTMFP_System(strcmd);
			}
			else if (TJLog.getCSD())
			{
				Log.d(TAG, "============= CSD.ALARM : Enable Wakeup=============");
				String strcmd = "echo " + KEYCODE_CSD_MBKEY1 + " > /sys/devices/platform/matrix-keypad/vkeytest";
				TJMedia_Service.TestTMFP_System(strcmd);
			}
	    			
		}
		else
		{
			if (TJLog.getTMFP())
				Log.d(TAG, "============= TMFP.ALARM : Current is WakeupMode=============");
			else if (TJLog.getCSD())
				Log.d(TAG, "============= CSD.ALARM : Current is WakeupMode=============");
		}
    	
    }

}