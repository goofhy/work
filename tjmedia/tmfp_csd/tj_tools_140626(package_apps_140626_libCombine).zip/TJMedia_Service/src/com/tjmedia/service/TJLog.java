package com.tjmedia.service;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;

public class TJLog {
	public static final String TAG = "TJDebugger";
	public static final boolean DEBUG = true;

	public static final void v(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.v(TAG, tag + "." + msg);
		}
	}

	public static final void e(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.e(TAG, tag + "." + msg);
		}
	}

	public static final void e(String tag, String msg, Exception ex) {
		if (DEBUG) {
			android.util.Log.e(TAG, tag + "." + msg, ex);
		}
	}
	
	public static final void w(String tag, String msg, Exception ex) {
		if (DEBUG) {
			android.util.Log.e(TAG, tag + "." + msg, ex);
		}
	}

	public static final void d(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.d(TAG, tag + "." + msg);
		}
	}

	public static final void i(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.i(TAG, tag + "." + msg);
		}
	}
	
	public static boolean getTMFP()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")|| strManufacturer.equals("TJMEDIA")) && (strProduct.equals("fptm") || strProduct.equals("tmfp")))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	public static boolean getCSD()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia") || strManufacturer.equals("TJMEDIA")) && (strProduct.equals("csd")))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	public static boolean getTJ()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if (strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	
	public static boolean getTM10()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if (strManufacturer.equals("tjmedia") || strManufacturer.equals("tdmk"))
		{
			d("","---TM10---");
			return true;
		}
		else
		{
			d("","!!!!!!TM10");
			return false;
		}	
	}
	
	private static String getAppVersionName(Context context) {
		String version;
		try {
		   PackageInfo i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
		   version = i.versionName;
		} catch(NameNotFoundException e) { 
			version = null;
		}
		return version;
	}
	
	private static int getAppVersionCode(Context context) {
		int version;
		try {
			PackageInfo i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
			version = i.versionCode;
		} catch(NameNotFoundException e) { 
			version = -1;
		}
		return version;
	}	
	
	public static String updateVersionInfo(Context context) {
		String vName = getAppVersionName(context);		
		return vName;
	}
}