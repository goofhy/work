package com.tjmedia.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import android.content.Context;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.RemoteException;
import android.util.Log;

public class TJMedia_ServiceAPI {
	private String TAG = "TJMedia_ServiceAPI";
	public static final int TJUSBWIFI_VID = 5263;
	public static final int TJUSBNFC_VID = 1356;
	
	private FileDescriptor mFd;
	private FileInputStream mFileInputStream;
	private FileOutputStream mFileOutputStream;
	
    static 
    {
    	System.loadLibrary("TJService");
    } 	    
    
	private native static FileDescriptor JNISerialopen(String path, int baudrate, int flags);
	
	public native static int JNISystemRun(String cmd);

	public native static int JNIRmcsend(byte rmcid,byte[] pBuffer, int len);
	
	public native static void JNISerialclose();
    
	public native static String JNIGetProperty(String str);
	
    public native static String JNIGetSerialNumber();
    
	public void SerialPort(File device, int baudrate, int flags) throws SecurityException, IOException {

		/* Check access permission */
//		if (!device.canRead() || !device.canWrite()) {
//			try {
//				/* Missing read/write permission, trying to chmod the file */
//				Process su;
//				su = Runtime.getRuntime().exec("/system/xbin/su");
//				String cmd = "chmod 666 " + device.getAbsolutePath() + "\n"
//						+ "exit\n";
//				su.getOutputStream().write(cmd.getBytes());
//				if ((su.waitFor() != 0) || !device.canRead()
//						|| !device.canWrite()) {
//					throw new SecurityException();
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//				throw new SecurityException();
//			}
//		}
		
		if (0 == baudrate)
		{
			
		}
		else
		{
			mFd = JNISerialopen(device.getAbsolutePath(), baudrate, flags);
			if (mFd == null) {
				Log.e(TAG, "native open returns null");
				throw new IOException();
			}
			mFileInputStream = new FileInputStream(mFd);
			mFileOutputStream = new FileOutputStream(mFd);
		}
	}

	// Getters and setters
	public InputStream getSerialPortInputStream() {
		return mFileInputStream;
	}

	public OutputStream getSerialPortOutputStream() {
		return mFileOutputStream;
	}

	//사용
	public int PROXY_SetServerInfo(String szServerAddress, int nPortHTTP, int nPortHTTPS)
	{
		Log.d(TAG , "PROXY_SetServerInfo");
		return 0;
	}
	
	public int PROXY_HTTP_AddRedirectionPort(int nPort)
	{
		Log.d(TAG , "PROXY_HTTP_AddRedirectionPort");
		return 0;
	}
	
	public int PROXY_HTTPS_AddRedirectionPort(int nPort)
	{
		Log.d(TAG , "PROXY_HTTPS_AddRedirectionPort");
		return 0;
	}
	
	public int PROXY_Start()
	{
		Log.d(TAG , "PROXY_Start");
		return 0;
	}
	
	public int PROXY_Stop()
	{
		Log.d(TAG , "PROXY_Stop");
		return 0;
	}
	
	//사용
	public int GetVersionInfo()
	{
		Log.d(TAG , "GetVersionInfo");
		return 0;
	}	

	//사용
	public int PRIVATEINFO_GetTotalSize()
	{
		Log.d(TAG , "PRIVATEINFO_GetTotalSize");
		return 0;
	}

	public int PRIVATEINFO_GetBlockSize()
	{
		Log.d(TAG , "PRIVATEINFO_GetBlockSize");
		return 0;
	}
	
	public int PRIVATEINFO_GetBlock(int nStartBlock, int nBlockCount, byte[] pData_out)
	{
		Log.d(TAG , "PRIVATEINFO_GetBlock");
		return 0;
	}
	
	public int PRIVATEINFO_SetBlock(int nStartBlock, int nBlockCount, byte[] pData)
	{
		Log.d(TAG , "PRIVATEINFO_SetBlock");
		return 0;
	}
	
	//사용?
	public int BATT_GetStatus()
	{
		Log.d(TAG , "BATT_GetStatus");
		return 0;
	}
	
	//사용
	public int LED_SetOnOff(int nType, int nOnOff)
	{
		Log.d(TAG , "LED_SetOnOff");
		return 0;
	}
	
	//사용?
	public int WIFI_Enable()
	{
		Log.d(TAG , "WIFI_Enable");
		return 0;
	}
	
	public int WIFI_Disable()
	{
		Log.d(TAG , "WIFI_Disable");
		return 0;
	}
	
	public int WIFI_GetState()
	{
		Log.d(TAG , "WIFI_GetState");
		return 0;
	}

	//사용
	public int POWER_Reboot(int nIsNormalReboot)
	{
		Log.d(TAG , "POWER_Reboot");
		return 0;
	}
	
	public int POWER_Shutdown(int nIsNormalShutdown)
	{
		Log.d(TAG , "POWER_Shutdown");
		return 0;
	}
	

	//사용
	public int PACKAGE_Install(String szAPK, int nOption)
	{
		Log.d(TAG , "PACKAGE_Install");
		return 0;
	}
	
	public int PACKAGE_UnInstall(String szPackageName, int nOption)
	{
		Log.d(TAG , "PACKAGE_UnInstall");
		return 0;
	}
	

	//사용?
	public int SYSTEM_Run(String szCommandLine)
	{
		Log.d(TAG , "SYSTEM_Run:" + szCommandLine);
		return JNISystemRun(szCommandLine);		
	}
	

	//사용?
	public String SYSTEM_CreatePrivateStorage()
	{
		Log.d(TAG , "SYSTEM_CreatePrivateStorage");
		return "";
	}
	
	public int SYSTEM_DestroyPrivateStorage()
	{
		Log.d(TAG , "SYSTEM_DestroyPrivateStorage");
		return 0;
	}
	
//	//사용
//	public int SYSTEM_SetSerialNumber(String szSerialNumber)
//	{
//		Log.d(TAG , "SYSTEM_SetSerialNumber");
//		return 0;
//	}
	
	//사용
//	public String SYSTEM_GetSerialNumber()
//	{
//		Log.d(TAG , "SYSTEM_GetSerialNumber");		
//		return JNIGetSerialNumber();
//	}
	
	//사용
	public int BLUETOOTH_ChangeDeviceName(String szDeviceName)
	{
		Log.d(TAG , "BLUETOOTH_ChangeDeviceName");
		return 0;
	}
	
	//사용
	public int USB_CheckDevice()
	{
		Log.d(TAG , "USB_CheckDevice");
		return 0;
	}	

	//사용(sis touch전용)
	public int TouchScreenCalibration()
	{
		Log.d(TAG , "TouchScreenCalibration");
		return 0;
	}
	    	
	//사용
	public String GetProperty(String str)
	{
		Log.d(TAG , "GetProperty");
		return JNIGetProperty(str);
	}		
	
	public int GetUsbWifiStatus(UsbManager usbmanager)
	{
		String wifi = GetUsbBus(usbmanager,TJUSBWIFI_VID);	
		if (wifi == null)
			return -2;
		return 0;
	}		
	
	public int GetUsbNfcStatus(UsbManager usbmanager)
	{
		String nfc = GetUsbBus(usbmanager,TJUSBNFC_VID);	
		if (nfc == null)
			return -2;
		return 0;
	}	

	public String GetBusUsbNfc(UsbManager usbmanager)
	{
		String nfc = GetUsbBus(usbmanager,TJUSBNFC_VID);
		return nfc;
	}	
		
	public String GetUsbBus(UsbManager usbmanager, int vid) {

		int i = 0;		
    	HashMap<String, UsbDevice> deviceList = usbmanager.getDeviceList();
    	Collection<UsbDevice> deviceCollection = deviceList.values();
    	Iterator<UsbDevice> deviceIterator = deviceCollection.iterator();
    	Log.i(TAG, "Number of connected USB Devices = " + deviceCollection.size());
    	while(deviceIterator.hasNext()){	    		
    	    UsbDevice device = deviceIterator.next();
    	    Log.i(TAG, "devicename : " + device.getDeviceName() + " productid : " + device.getProductId() + " vendorid :" + device.getVendorId());
    	    if (device.getVendorId() == vid)
    	    {
    	    	Log.i(TAG, "Find : " + deviceCollection.size());
    	    	return device.getDeviceName();
    	    }
    	    if (i++>10) break;
    	};
		return null;
	}	
}
