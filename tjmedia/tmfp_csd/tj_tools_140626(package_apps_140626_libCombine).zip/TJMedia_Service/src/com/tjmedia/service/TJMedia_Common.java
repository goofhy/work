package com.tjmedia.service;

public class TJMedia_Common {
	/** Key code constant: TMFP MUSIC Vol UP */
    public static final int KEYCODE_TMFP_MUSIC_VOL_UP            = 220;
    /** Key code constant: TMFP MUSIC Vol DOWN */
    public static final int KEYCODE_TMFP_MUSIC_VOL_DOWN          = 221;    
    /** Key code constant: TMFP BGM Vol UP */
    public static final int KEYCODE_TMFP_BGM_VOL_UP              = 222;
    /** Key code constant: TMFP BGM Vol DOWN */
    public static final int KEYCODE_TMFP_BGM_VOL_DOWN            = 223;    
    /** Key code constant: TMFP ECO Vol UP */
    public static final int KEYCODE_TMFP_ECO_VOL_UP              = 224;
    /** Key code constant: TMFP ECO Vol DOWN */
    public static final int KEYCODE_TMFP_ECO_VOL_DOWN            = 225;
        /** Key code constant: TMFP MIC Vol UP */
    public static final int KEYCODE_TMFP_MIC_VOL_UP              = 226;
    /** Key code constant: TMFP MIC Vol DOWN */
    public static final int KEYCODE_TMFP_MIC_VOL_DOWN            = 227;
    
    /** Key code constant: TMFP LIVESOUND Key */
    public static final int KEYCODE_TMFP_LIVESOUND            = 228;
    /** Key code constant: TMFP STANDBY Key */
    public static final int KEYCODE_TMFP_STANDBY              = 229;
    /** Key code constant: TMFP RESERVED Key */
    public static final int KEYCODE_TMFP_REV              	  = 230;
    
    /** Key code constant: CSD MB Key 1*/
    public static final int KEYCODE_CSD_MBKEY1                = 231;
    /** Key code constant: CSD MB Key 2*/
    public static final int KEYCODE_CSD_MBKEY2                = 232;
    /** Key code constant: CSD MB Key 3*/
    public static final int KEYCODE_CSD_MBKEY3                = 233;
    /** Key code constant: CSD MB Key 4*/
    public static final int KEYCODE_CSD_MBKEY4                = 234;
    /** Key code constant: CSD MB Key 5*/
    public static final int KEYCODE_CSD_MBKEY5                = 235;
    /** Key code constant: CSD MB Key 6*/
    public static final int KEYCODE_CSD_MBKEY6                = 236;
    /** Key code constant: CSD MB Key 7*/
    public static final int KEYCODE_CSD_MBKEY7                = 237;
    /** Key code constant: CSD MB Key 8*/
    public static final int KEYCODE_CSD_MBKEY8                = 238;
    /** Key code constant: CSD MB Key 9*/
    public static final int KEYCODE_CSD_MBKEY9                = 239;
    /** Key code constant: CSD MB Key 10*/
    public static final int KEYCODE_CSD_MBKEY10               = 240;
    /** Key code constant: CSD MB Key 11*/
    public static final int KEYCODE_CSD_MBKEY11               = 241;
    /** Key code constant: CSD MB Key 12*/
    public static final int KEYCODE_CSD_MBKEY12               = 242;
    /** Key code constant: CSD MB Key 13*/
    public static final int KEYCODE_CSD_MBKEY13               = 243;
    /** Key code constant: CSD MB Key 14*/
    public static final int KEYCODE_CSD_MBKEY14               = 244;
    /** Key code constant: CSD MB Key 15*/
    public static final int KEYCODE_CSD_MBKEY15               = 245;
    /** Key code constant: CSD MB Key 16*/
    public static final int KEYCODE_CSD_MBKEY16               = 246;
    /** Key code constant: CSD MB Key 17*/
    public static final int KEYCODE_CSD_MBKEY17               = 247;
    /** Key code constant: CSD MB Key 18*/
    public static final int KEYCODE_CSD_MBKEY18               = 248;
    /** Key code constant: CSD MB Key 19*/
    public static final int KEYCODE_CSD_MBKEY19               = 249;    
    /** Key code constant: CSD MB Key 20*/
    public static final int KEYCODE_CSD_MBKEY20               = 250; 
    /** Key code constant: TSP Key 1*/
    public static final int KEYCODE_TMFP_TSPKEY1                = 251;
    /** Key code constant: TSP Key 2*/
    public static final int KEYCODE_TMFP_TSPKEY2                = 252;
    /** Key code constant: TSP Key 3*/
    public static final int KEYCODE_TMFP_TSPKEY3                = 253;
    /** Key code constant: TSP Key 4*/
    public static final int KEYCODE_TMFP_TSPKEY4                = 254;
    /** Key code constant: TSP Key 5*/
    public static final int KEYCODE_TMFP_TSPKEY5                = 255;
    /** Key code constant: TSP Key 6*/
    public static final int KEYCODE_TMFP_TSPKEY6                = 256;
    /** Key code constant: TSP Key 7*/
    public static final int KEYCODE_TMFP_TSPKEY7                = 257;
    /** Key code constant: TSP Key 8*/
    public static final int KEYCODE_TMFP_TSPKEY8                = 258;
    /** Key code constant: TSP Key 9*/
    public static final int KEYCODE_TMFP_TSPKEY9                = 259;
    /** Key code constant: TSP Key 10*/
    public static final int KEYCODE_TMFP_TSPKEY10               = 260;
    /** Key code constant: TSP Key 11*/
    public static final int KEYCODE_TMFP_TSPKEY11               = 261;
    /** Key code constant: TSP Key 12*/
    public static final int KEYCODE_TMFP_TSPKEY12               = 262;
    /** Key code constant: TSP Key 13*/
    public static final int KEYCODE_TMFP_TSPKEY13               = 263;
    /** Key code constant: TSP Key 14*/
    public static final int KEYCODE_TMFP_TSPKEY14               = 264;
    /** Key code constant: TSP Key 15*/
    public static final int KEYCODE_TMFP_TSPKEY15               = 265;
    /** Key code constant: TSP Key 16*/
    public static final int KEYCODE_TMFP_TSPKEY16               = 266;    
    

    
    //TRANS (LED)
    public static final byte	BOTTOM_PCB_LED_ALL_CMD				= (byte) 0x10;	//select
    public static final byte	BOTTOM_PCB_LED_MUSIC_HI_CMD			= (byte) 0x11;
    public static final byte	BOTTOM_PCB_LED_MUSIC_LOW_CMD		= (byte) 0x12;
    public static final byte	BOTTOM_PCB_LED_MUSIC_CMD			= (byte) 0x13;
    public static final byte	BOTTOM_PCB_LED_LIVE_1_CMD			= (byte) 0x14;
    public static final byte	BOTTOM_PCB_LED_LIVE_2_CMD			= (byte) 0x15;
    public static final byte	BOTTOM_PCB_LED_ECO_HI_CMD			= (byte) 0x16;
    public static final byte	BOTTOM_PCB_LED_ECO_LOW_CMD			= (byte) 0x17;
    public static final byte	BOTTOM_PCB_LED_ECO_CMD				= (byte) 0x18;
    public static final byte	BOTTOM_PCB_LED_BGM_HI_CMD			= (byte) 0x19;
    public static final byte	BOTTOM_PCB_LED_BGM_LOW_CMD			= (byte) 0x1A;
    public static final byte	BOTTOM_PCB_LED_BGM_CMD				= (byte) 0x1B;
    public static final byte	BOTTOM_PCB_LED_MIC_HI_CMD			= (byte) 0x1C;
    public static final byte	BOTTOM_PCB_LED_MIC_LOW_CMD			= (byte) 0x1D;
    public static final byte	BOTTOM_PCB_LED_MIC_CMD				= (byte) 0x1E;
    
    //Left Front LED
    public static final byte	LEFT_FRONT_PCB_LED_ALL_CMD			= (byte) 0x20;	//select
    public static final byte	LEFT_FRONT_PCB_LED_TEMPO_CTRL_CMD	= (byte) 0x21;	//select
    public static final byte	LEFT_FRONT_PCB_LED_TEMPO_UP_CMD		= (byte) 0x22;	//select
    public static final byte	LEFT_FRONT_PCB_LED_TEMPO_CTRL_STAND_CMD	= (byte) 0x23;	//select
    public static final byte	LEFT_FRONT_PCB_LED_TEMPO_CTRL_DOWN_CMD	= (byte) 0x24;	//select
    public static final byte	LEFT_FRONT_PCB_LED_RESERVED_CMD		= (byte) 0x25;	//select    
    public static final byte	LEFT_FRONT_PCB_LED_SCORE_CMD		= (byte) 0x26;	//select
    public static final byte	LEFT_FRONT_PCB_LED_DAM_CMD			= (byte) 0x27;	//select
    
    //Right Front LED
    public static final byte	RIGHT_FRONT_PCB_LED_ALL_CMD			= (byte) 0x30;	//select
    public static final byte	RIGHT_FRONT_PCB_LED_KEY_CTRL_CMD	= (byte) 0x31;	//select
    public static final byte	RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD	= (byte) 0x32;	//select
    public static final byte	RIGHT_FRONT_PCB_LED_KEY_BASE_CMD	= (byte) 0x33;	//select
    public static final byte	RIGHT_FRONT_PCB_LED_KEY_B_CMD		= (byte) 0x34;	//select
    public static final byte	RIGHT_FRONT_PCB_LED_START_CMD		= (byte) 0x35;	//select
    public static final byte	RIGHT_FRONT_PCB_LED_STOP_CMD		= (byte) 0x36;	//select    
    public static final byte	RIGHT_FRONT_PCB_LED_MENU_CMD		= (byte) 0x37;	//select
    
    //Left & Right Front LED 
    public static final byte	LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD	= (byte) 0x40;	//select
    
    //Left Back LED
    public static final byte	LEFT_BACK_PCB_LED_ALL_CMD			= (byte) 0x28;	//select
    
    //Right Back LED
    public static final byte	RIGHT_BACK_PCB_LED_ALL_CMD			= (byte) 0x38;	//select
    
    //Left & Right Back LED
    public static final byte	LEFT_RIGHT_BACK_PCB_LED_ALL_CMD		= (byte) 0x48;	//select
    
    public static final byte   LIGHT_RIGHT_BACK_PCB_LED_TJ_CMD		= (byte) 0x50;
    
    public static final byte   MICOM_GET_VER_CMD					= (byte) 0x60;	
    
    public static final byte	VOL_TRANSTIME						= (byte) 0x90;        	//0 : 실시간 , 10*(time) = msec  
    
    
    public static byte R_LED		= 0x04;
    public static byte G_LED		= 0x02;
    public static byte B_LED		= 0x01;
    public static byte RG_LED		= 0x06;
    public static byte RB_LED		= 0x05;
    public static byte GB_LED		= 0x03;
    public static byte RGB_LED		= 0x07;
    
    public static byte OFF_LED		= 0x00;
    public static byte ON_LED		= 0x01;
    
    
    public static final int	RMC_DATA	= 0;
    public static final int	VOL1_UP		= KEYCODE_TMFP_MUSIC_VOL_UP;
    public static final int	VOL1_DOWN	= KEYCODE_TMFP_MUSIC_VOL_DOWN;
    public static final int	VOL2_UP		= KEYCODE_TMFP_BGM_VOL_UP;
    public static final int	VOL2_DOWN	= KEYCODE_TMFP_BGM_VOL_DOWN;
    public static final int	VOL3_UP		= KEYCODE_TMFP_ECO_VOL_UP;
    public static final int	VOL3_DOWN	= KEYCODE_TMFP_ECO_VOL_DOWN;
    public static final int	VOL4_UP		= KEYCODE_TMFP_MIC_VOL_UP;
    public static final int	VOL4_DOWN	= KEYCODE_TMFP_MIC_VOL_DOWN;    
    
    public static final byte	STX			= (byte) 0xE0;
    public static final byte	ETX			= (byte) 0xFD;
    
    //RECV (IR+VOL)
    public static final byte	RMC_ID		= (byte) 0x80;
    public static final byte	VOL1_ID		= (byte) 0x81;
    public static final byte	VOL2_ID		= (byte) 0x82;
    public static final byte	VOL3_ID		= (byte) 0x83;
    public static final byte	VOL4_ID		= (byte) 0x84;    
    
    public static final byte	EXT_VOL1_ID		= (byte) 0x85;
    public static final byte	EXT_VOL2_ID		= (byte) 0x86;
    public static final byte	EXT_VOL3_ID		= (byte) 0x87;
    public static final byte	EXT_VOL4_ID		= (byte) 0x88;
        
    
    public static final byte	API_IRSEND			= (byte) 0x1;
    public static final byte	API_MTVIRSEND		= (byte) 0x2;
    
}
