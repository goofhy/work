package com.example.usbtest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.util.Log;

public class UsbTest extends Activity {

	private static final String TAG = "<<<<<<<<<<<USB>>>>>>>>>>>>";
	private static final String ACTION_USB_PERMISSION = "com.example.usbtest.USB_PERMISSION";
	UsbManager manager;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);				
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Intent intent = getIntent();
		String action = intent.getAction();
		Log.d(TAG,"action : " + action);
		manager = (UsbManager) getSystemService(Context.USB_SERVICE);
		if(manager==null) {
		    	Log.i(TAG, "USB Manager is NULL");
		}
		else {
			Log.i(TAG, "USB Manager = " + manager);
		}		

		IntentFilter filter = new IntentFilter();
		filter.addAction(ACTION_USB_PERMISSION);
		filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
		filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
		registerReceiver(mUsbReceiver, filter);				
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		unregisterReceiver(mUsbReceiver);
	}
	
	public void enumerateUSBDevices() {
    	HashMap<String, UsbDevice> deviceList = manager.getDeviceList();
    	Collection<UsbDevice> deviceCollection = deviceList.values();
    	Iterator<UsbDevice> deviceIterator = deviceCollection.iterator();
    	Log.i(TAG, "Number of connected USB Devices = " + deviceCollection.size());
    	while(deviceIterator.hasNext()){
    	    UsbDevice device = deviceIterator.next();
    	    Log.i(TAG, "devicename : " + device.getDeviceName() + " productid : " + device.getProductId() + " vendorid :" + device.getVendorId());
    	}
    }
	
	private final BroadcastReceiver mUsbReceiver = new BroadcastReceiver() {

	    public void onReceive(Context context, Intent intent) {
	        String action = intent.getAction();
	        
	        Log.d(TAG, "mUsbReceiver action:" + action);
	        
	        if (ACTION_USB_PERMISSION.equals(action)) {
	            synchronized (this) {
	                UsbDevice device = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
	               
	                if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
	                    if(device != null){
	                      //call method to set up device communication
	                    	Log.d(TAG, "permission for device " + device);
	                    	enumerateUSBDevices();
	                   }
	                } 
	                else {
	                    Log.d(TAG, "permission denied for device " + device);
	                    enumerateUSBDevices();
	                }
	            }
	        }
	        else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
	            UsbDevice device = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
	            if (device != null) {
	                // call your method that cleans up and closes communication with the device
	            	Log.d(TAG, "ACTION_USB_DEVICE_DETACHED device " + device);
	            	enumerateUSBDevices();
	            }
	        }
	        else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
	            UsbDevice device = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
	            if (device != null) {
	                // call your method that cleans up and closes communication with the device
	            	Log.d(TAG, "ACTION_USB_DEVICE_ATTACHED device " + device);
	            	enumerateUSBDevices();
	            	
//	            	write();
//	            	read();	            	
	            }	            
	        }	        

	    }
	};	
	
	void write()
	{
		String uriString = "/storage/usb";
		String mount_path = "";
		File file = new File(uriString);
		if (file.canRead()) {
			mount_path = uriString;
			File filedir = new File(mount_path, "TJ_STORAGE");
			if (!filedir.exists()) {
				if (!filedir.mkdirs()) {
					Log.e(TAG, "failed to create directory");
					return;
				}
			}
			
			try {
				File filename = new File(filedir.getPath() + File.separator + "usbfile.txt");
				FileWriter fw = new FileWriter(filename);
				BufferedWriter bw = new BufferedWriter(fw);
//						FileOutputStream  fos = new FileOutputStream(filename);
//			            BufferedOutputStream bos = new BufferedOutputStream(fos);
//			            byte[] result = filename.toString().getBytes();
//			            byte[] result = "Hello World".getBytes();
				String result = null;

	            bw.write(result);
	            bw.close();
	            fw.close();
	            mount_path = filename.toString();
			} catch (FileNotFoundException fe) {
				fe.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
	}
	
	void read()
	{
		String uriString = "/storage/usb";					
		File file = new File(uriString, "TJ_STORAGE");
		if (file.canRead()) {			
			try {
				File filename = new File(file.getPath() + File.separator + "usbfile.txt");
				FileReader fr = new FileReader(filename);
				BufferedReader br = new BufferedReader(fr);
				StringBuffer sb = new StringBuffer();
				String temp = null;
	            while ((temp=br.readLine()) != null) {
	            	sb.append(temp);
	            	Log.d(TAG,"read:" + sb.toString());
	            }
	            br.close();
	            fr.close();
			} catch (FileNotFoundException fe) {
				fe.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

//package com.jamierf.maestro.binding;
//
//import android.app.PendingIntent;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.hardware.usb.UsbDevice;
//import android.hardware.usb.UsbDeviceConnection;
//import android.hardware.usb.UsbManager;
//import com.jamierf.maestro.api.Product;
//
//import java.io.IOException;
//import java.nio.ByteBuffer;
//import java.util.Map;
//
//public class AndroidDriverBinding implements DriverBinding {
//
//    private static final String ACTION_USB_PERMISSION = AndroidDriverBinding.class.getPackage() + ".USB_PERMISSION";
//
//    public static void bindToDevice(Context context, Product product, AsyncBindingListener listener) {
//        try {
//            final UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
//
//            final Map<String, UsbDevice> devices = manager.getDeviceList();
//            for (final UsbDevice device : devices.values()) {
//                if (device.getVendorId() == product.getVendorId() && device.getProductId() == product.getProductId()) {
//                    AndroidDriverBinding.bindToDevice(context, device, listener);
//                    return;
//                }
//            }
//
//            throw new IOException("Unable to find USB device.");
//        } catch (Exception e) {
//            listener.onException(e);
//        }
//    }
//
//    private static void bindToDevice(Context context, final UsbDevice device, final AsyncBindingListener listener) {
//        final UsbManager manager = (UsbManager) context.getSystemService(Context.USB_SERVICE);
//
//        context.registerReceiver(new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//                if (!ACTION_USB_PERMISSION.equals(intent.getAction())) {
//                    listener.onException(new IOException("No permission to access USB device."));
//                    return;
//                }
//
//                listener.onBind(device.getVendorId(), device.getProductId(), new AndroidDriverBinding(manager, device));
//            }
//        }, new IntentFilter(ACTION_USB_PERMISSION));
//
//        manager.requestPermission(device, PendingIntent.getBroadcast(context, 0, new Intent(ACTION_USB_PERMISSION), 0));
//    }
//
//    private final UsbManager manager;
//    private final UsbDevice device;
//
//    private transient UsbDeviceConnection conn;
//
//    public AndroidDriverBinding(UsbManager manager, UsbDevice device) {
//        this.manager = manager;
//        this.device = device;
//    }
//
//    @Override
//    public ByteBuffer allocateBuffer(int length) {
//        return ByteBuffer.wrap(new byte[length]);
//    }
//
//    private synchronized UsbDeviceConnection getConnection() {
//        if (conn == null)
//            conn = manager.openDevice(device);
//
//        return conn;
//    }
//
//    @Override
//    public int getVendorId() {
//        return device.getVendorId();
//    }
//
//    @Override
//    public int getProductId() {
//        return device.getProductId();
//    }
//
//    @Override
//    public String getSerial() {
//        final UsbDeviceConnection conn = this.getConnection();
//        return conn.getSerial();
//    }
//
//    @Override
//    public int controlTransfer(int requestType, int request, int value, int index, ByteBuffer buffer, int timeout) {
//        if (buffer == null)
//            buffer = this.allocateBuffer(0);
//
//        if (!buffer.hasArray())
//            throw new IllegalArgumentException("Buffer must be array based (should be allocated using allocateBuffer(int)).");
//
//        final byte[] bytes = buffer.array();
//
//        final UsbDeviceConnection conn = this.getConnection();
//        final int read = conn.controlTransfer(requestType, request, value, index, bytes, bytes.length, timeout);
//
//        return read;
//    }
//
//    @Override
//    public void close() {
//        if (conn == null)
//            return;
//
//        conn.close();
//        conn = null;
//    }
//}
