package com.tjmedia.tdmk.java_client;

import java.io.Serializable;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

public class TDMKMisc_Service 
{
	/*
	** automatically fill in version information from Initalize() method
	*/
	public static class VERSION_Info_t
	{
		public static String		szBootloader;
		public static String		szKernel;
		public static String		szAndroid;
		public static String		szWifi;
		public static String		szBluetooth;
		public static String		szTouchScreen;
		public static String		szMiscDriver;
		public static String		szMiscHelper;
	}
	
	public class GSENSOR_INFO_t
	{
		public int		x;
		public int		y;
		public int		z;
	}
	
	public static class USBDEVICE_INFO_t
	{
		public static String	szVendor;
		public static String	szProduct;
		public static String	szSerialNumber;
	}
	
	static 
	{
		try
		{
			System.loadLibrary("tdmkmisc");
		}
		catch (UnsatisfiedLinkError e)
		{
			System.err.println("libtdmkmisc.so : library load failed.");
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// Proxy
	//
	
	/*
	**
	*/
	public static native int PROXY_SetServerInfo(String szServerAddress, int nPortHTTP, int nPortHTTPS);
	/*
	**
	*/
	public static native int PROXY_HTTP_AddRedirectionPort(int nPort);
	/*
	**
	*/
	public static native int PROXY_HTTPS_AddRedirectionPort(int nPort);
	/*
	**
	*/
	public static native int PROXY_Start();
	/*
	**
	*/
	public static native int PROXY_Stop();
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// TDMK Service
	//
	
	/*
	** tdmk_misc_jni initialize
	*/
	public static native int Initalize();
	/*
	** tdmk_misc_jni finalize
	*/
	public static native void Finalize();
	/*
	** reload version info : VERSION_Info_t
	*/
	public static native int GetVersionInfo();

	/////////////////////////////////////////////////////////////////////////////
	//
	// Remote Controller
	//
	
	/*
	** IR Command Code 
	*/
	public static final int		RMC__DAM=0x1D;
	public static final int		RMC__START=0x01;
	public static final int		RMC__STOP=0x00;
	public static final int		RMC__RESERVE_OK=0x0A;
	public static final int		RMC__RESERVE_CANCLE=0x07;
	public static final int		RMC__REW=0x1A;
	public static final int		RMC__FF=0x1C;
	public static final int		RMC__PAUSE=0x1B;
	public static final int		RMC__ORIGINAL_SONG=0x60;
	public static final int		RMC__TEMP_UP=0x20;
	public static final int		RMC__TEMP_DOWN=0x21;
	public static final int		RMC__KEY_UP=0x04;
	public static final int		RMC__KEY_DOWN=0x05;
	public static final int		RMC__KEY_RESET=0x60;
	public static final int		RMC__SCORE=0x1F;
	public static final int		RMC__BACK=0x2F;
	public static final int		RMC__GUIDE_VOCAL=0x26;
	public static final int		RMC__MUSIC_UP=0xAA;
	public static final int		RMC__MUSIC_DOWN=0xA9;
	public static final int		RMC__MIC_UP=0xAC;
	public static final int		RMC__MIC_DOWN=0xAB;
	public static final int		RMC__PRIORITY_RESERVE=0x03;
	public static final int		RMC__NUMBER_INPUT_IN=0x08;
	public static final int		RMC__NUMBER_INPUT_OUT=0x09;
	public static final int		RMC__KEY_INPUT_IN=0x58;
	public static final int		RMC__KEY_INPUT_OUT=0x59;
	public static final int		RMC__KARAOKE_VOLUME_UP=0xAF;
	public static final int		RMC__KARAOKE_VOLUME_DOWN=0xAD;
	public static final int		RMC__OPEN_CLOSE=0xA8;
	public static final int		RMC__BACK_CHROUS=0xD0;
	public static final int		RMC__WIFE=0x0C;
	public static final int		RMC__RUBE=0x06;
	public static final int		RMC__WIFE_RUBE=0x27;
	public static final int		RMC__QUESTION_X3=0x25;
	public static final int		RMC__DIRECT_SE_O=0x3E;
	public static final int		RMC__DIRECT_SE_A=0x3F;
	public static final int		RMC__DIRECT_SE_X=0xA0;
	public static final int		RMC__EFFECT_LEVEL_UP=0xCD;
	public static final int		RMC__EFFECT_LEVEL_DOWN=0xCF;
	public static final int		RMC__HARMONY=0x50;
	public static final int		RMC__VOICE_CHANGE=0x52;
	public static final int		RMC__VOICE_DOUBLE_RING=0x53;
	public static final int		RMC__ONE_DUET=0x51;
	public static final int		RMC__VOCAL_EFFECT_ON_OFF=0xCC;
	public static final int		RMC__VOCAL_EFFECT_GUIDE=0x0D;
	public static final int		RMC__MEMORY_SET=0x0B;
	public static final int		RMC__DAM_IP_INPUT_IN=0x61;
	public static final int		RMC__DAM_IP_INPUT_OUT=0x62;

	/*
	** send remote control data
	*/
	public static native int IR_Send(byte[] pBuffer);
	/*
	** send remote control data
	*/
	public static native int IR_Send(int nData);
	
	/*
	** send mitsubishi tv remote control data : added by ajkajk
	*/
	public static native int MITSUBISHI_IR_Send(byte[] pBuffer);
	/////////////////////////////////////////////////////////////////////////////
	//
	// Private Machine Info
	//
	
	/*
	** PRIVINFO default total size : 256KB
	*/
	public static native int PRIVATEINFO_GetTotalSize();
	/*
	** PRIVINFO default block size : 1KB
	*/
	public static native int PRIVATEINFO_GetBlockSize();
	/*
	**
	*/
	public static native int PRIVATEINFO_GetBlock(int nStartBlock, int nBlockCount, byte[] pData_out);
	/*
	**
	*/
	public static native int PRIVATEINFO_SetBlock(int nStartBlock, int nBlockCount, byte[] pData);

	/////////////////////////////////////////////////////////////////////////////
	//
	// G-Sensor 
	// 		This function is deprecated, use Android-Framework-SensorManager instead.
	//
	
	/*
	**
	*/
	public static native GSENSOR_INFO_t GSENSOR_GetData();
	/*
	**
	*/
	public static native int GSENSOR_SetAxisAdjust();
	/*
	**
	*/
	public static native int GSENSOR_SetCalibarationData(int x, int y, int z);

	/////////////////////////////////////////////////////////////////////////////
	//
	// Battery
	//
	
	/*
	** Battery Status Code 
	*/
	public static final int		BATT__CHARGE_FULL=0;
	public static final int		BATT__CHARGING=1;
	public static final int		BATT__CHARGE_ERROR=2;
	public static final int		BATT__NO_CHARGE=3;

	/*
	** return :
	**     0 = BATT__CHARGE_FULL
	**     1 = BATT__CHARGING
	**     2 = BATT__CHARGE_ERROR
	**     3 = BATT__NO_CHARGE
	*/
	public static native int BATT_GetStatus();
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// LED
	//
	
	/*
	** LED Direction Code 
	*/
	public static final int		LED__NFC=0;
	public static final int		LED__WLAN=1;
	public static final int		LED__IR=2;
	public static final int		LED__REMOTE_KEY=3;
	public static final int		LED__BACK_KEY=4;
	public static final int		LED__HOME_KEY=5;
	public static final int		LED__STOP_KEY=6;
	public static final int		LED__FLASH=7;
	//public static final int		METHOD__PRESS_ON=0x100;
	//public static final int		METHOD__PRESS_OFF=0x200;
	//public static final int		METHOD__DISABLE_KEY=0x400
	//public static final int		METHOD__ENABLE_KEY=0x800

	/*
	** nType :
	**     0 = LED__NFC
	**     1 = LED__WLAN
	**     2 = LED__IR
	**     3 = LED__REMOTE_KEY
	**     4 = LED__BACK_KEY
	**     5 = LED__HOME_KEY
	**     6 = LED__STOP_KEY
	**     7 = LED__FLASH
	**
	*/
	public static native int LED_SetOnOff(int nType, int nOnOff);
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// WIFI : needed to declare permission in manifest.xml
	//
	//     <uses-permission android:name="android.permission.UPDATE_DEVICE_STATS"/>
	//     <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
	//     <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
	//     <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
	//     <uses-permission android:name="android.permission.CHANGE_NETWORK_STATE" />
	//
	
	/*
	** WIFI Status Code
	*/
	public static final int		WIFI__STATE_DISABLING=0;
	public static final int		WIFI__STATE_DISABLED=1;
	public static final int		WIFI__STATE_ENABLING=2;
	public static final int		WIFI__STATE_ENABLED=3;
	public static final int		WIFI__STATE_UNKNOWN=4;

	/*
	**
	*/
	public static native int WIFI_Enable();	
	/*
	**
	*/
	public static native int WIFI_Disable();	
	/*
	** return :
	**    0 = WIFI__STATE_DISABLING
	**    1 = WIFI__STATE_DISABLED
	**    2 = WIFI__STATE_ENABLING
	**    3 = WIFI__STATE_ENABLED
	**    4 = WIFI__STATE_UNKNOWN
	*/
	public static native int WIFI_GetState();	
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// SecureCore
	//
	
	/*
	**
	*/
	public static native int SECURECORE_GetTotalSize();	
	/*
	** nOffset : skip bytes
	** nBuffer : read bytes (==pData_out size)
	*/
	public static native int SECURECORE_WriteData(int nOffset, int nBuffer, byte[] pData);
	/*
	** nOffset : skip bytes
	** nBuffer : read bytes (==pData size)
	*/
	public static native int SECURECORE_ReadData(int nOffset, int nBuffer, byte[] pData_out);
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// POWER
	//
	
	public static final int		POWER__REBOOT_NORMAL=1;
	public static final int		POWER__REBOOT_WITHOUT_VIEW=0;
	public static final int		POWER__SHUTDOWN_NORMAL=1;
	public static final int		POWER__SHUTDOWN_WITHOUT_VIEW=0;
	
	/*
	**
	*/
	public static native int POWER_Reboot(int nIsNormalReboot);
	/*
	**
	*/
	public static native int POWER_Shutdown(int nIsNormalShutdown);
	
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// PACKAGE
	//
	
	/*
	** ref. : pm command
	**
	** PACKAGE__INSTALL_NORMAL=0      : [-l] install the package with FORWARD_LOCK.
	** PACKAGE__INSTALL_REINSTALL=1   : [-r] reinstall an exisiting app, keeping its data.
	** PACKAGE__INSTALL_ALLOW_TEST=2  : [-t] allow test .apks to be installed.
	** PACKAGE__INSTALL_ON_SDCARD=3   : [-s] install package on sdcard.
	** PACKAGE__INSTALL_ON_FLASH=4    : [-f] install package on internal flash.
	** 
	** PACKAGE__UNINSTALL_NORMAL=0    : 
	** PACKAGE__UNINSTALL_KEEP_DATA=1 : [-k] keep the data and cache directories around.
	** 
	*/

	public static final int		PACKAGE__INSTALL_NORMAL=0;
	public static final int		PACKAGE__INSTALL_REINSTALL=1;
	public static final int		PACKAGE__INSTALL_ALLOW_TEST=2;
	public static final int		PACKAGE__INSTALL_ON_SDCARD=3;
	public static final int		PACKAGE__INSTALL_ON_FLASH=4;
	
	public static final int		PACKAGE__UNINSTALL_NORMAL=0;
	public static final int		PACKAGE__UNINSTALL_KEEP_DATA=1;

	/*
	** ex) PACKAGE_Install("TDMKMisc_MiscJavaClient.apk", PACKAGE__INSTALL_NORMAL);
	*/
	public static native int PACKAGE_Install(String szAPK, int nOption);
	/*
	** ex) PACKAGE_UnInstall("com.tjmedia.tdmk.java_client", PACKAGE__UNINSTALL_NORMAL);
	*/
	public static native int PACKAGE_UnInstall(String szPackageName, int nOption);

	/////////////////////////////////////////////////////////////////////////////
	//
	// SYSTEM
	//
	
	/*
	** run system level shell command
	*/
	public static native int SYSTEM_Run(String szCommandLine);
    
	/*
	** mount private storage directory using tmpfs
	*/
	public static native String SYSTEM_CreatePrivateStorage();
	/*
	** unmount private storage directory using tmpfs
	*/
	public static native int SYSTEM_DestroyPrivateStorage();
	/*
	** 
	*/
	public static native int SYSTEM_SetSerialNumber(String szSerialNumber);
	/*
	** 
	*/
	public static native String SYSTEM_GetSerialNumber();
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// Bluetooth
	//
	
	/*
	**
	*/
	public static native int BLUETOOTH_ChangeDeviceName(String szDeviceName);

	/////////////////////////////////////////////////////////////////////////////
	//
	// USB
	//

	public static final int			USB__NONE=0;		// no change
	public static final int			USB__ATTACH=1;		// insert usb storage
	public static final int			USB__DETACH=2;		// remove usb storage
	
	/*
	** return :
	**    0 = USB__NONE
	**    1 = USB__ATTACH
	**    2 = USB__DETACH
	*/
	public static native int USB_CheckDevice();
	
	/////////////////////////////////////////////////////////////////////////////
	//
	// TouchScreen
	//

	public static native int TouchScreenCalibration();
	
	
	public static native int HDMI_EnableViewPosition(int x, int y, int w, int h);
	public static native int HDMI_DisableViewPosition();
}
