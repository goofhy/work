/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.tjmedia.android.tjdebugger.touch;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.ToastManager;

public class TouchExampleView extends View {
	
	private static final String TAG = "TouchExampleView";
	
	private final int H_WIDTH = 300;
    private final int H_HEIGHT = 2;
    private final int V_WIDTH = 2;
    private final int V_HEIGHT = 300;
    private static final int INVALID_POINTER_ID = -1;
    
//    private ScaleGestureDetector mScaleDetector;
    private float mScaleFactor = 1.f;
    
    InnerTouch mFirst;
    InnerTouch mSecond;
    Paint mPaint;
    ArrayList<Vertex> arVertex1;
    ArrayList<Vertex> arVertex2;
    
    public static boolean FLAG_DRAWING1 = false;
    private static boolean FLAG_DRAWING2 = false;
    Context gcontex;
    public TouchExampleView(Context context) {
        this(context, null, 0);
        gcontex = context;
        mPaint = new Paint();       
        mPaint.setStrokeWidth(3); //두께 설정
        mPaint.setAntiAlias(true); //부드러운 표현
        mPaint.setColor(Color.RED);
        arVertex1 = new ArrayList<Vertex>();
        arVertex2 = new ArrayList<Vertex>();
    }
    
    public TouchExampleView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }
    
    public TouchExampleView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        
          mFirst = new InnerTouch(getContext());
          mSecond = new InnerTouch(getContext());
    }
    
    long testRate = 0;    
    int change = 0;
    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        final int action = ev.getAction();
        
        switch (action & MotionEvent.ACTION_MASK) {
	        case MotionEvent.ACTION_DOWN:
	        	FLAG_DRAWING1= true;
	            mFirst.mActivePointerId = ev.getPointerId(0);
	            Log.e(TAG, "ACTION_DOWN=" + mFirst.mActivePointerId);
	            mFirst.mLastTouchX = ev.getX();
	            mFirst.mLastTouchY = ev.getY();
	            TouchAct.mTspCal = false;
	            invalidate();
	            arVertex1.add(new Vertex(mFirst.mLastTouchX, mFirst.mLastTouchY, false, Color.RED));

	            break;
	        case MotionEvent.ACTION_UP:
	        	Log.d(TAG, "ACTION_UP=" + mFirst.mActivePointerId);
	        	FLAG_DRAWING1 = false;
	        	FLAG_DRAWING2 = false;
	    	    invalidate();
	    	    arVertex1.clear();
	    	    arVertex2.clear();
		        super.onTouchEvent(ev);   
		        return false;

	            
	        case MotionEvent.ACTION_MOVE:
	        	if(testRate%200 == 1) {
	        		Log.e(TAG, "ACTION_MOVE");
	        	}
	        	testRate++;
	        	
	        	if (FLAG_DRAWING1 && FLAG_DRAWING2) {
	        		mFirst.mLastTouchX = ev.getX(0);
	        		mFirst.mLastTouchY = ev.getY(0);
	        		mSecond.mLastTouchX = ev.getX(1);
	        		mSecond.mLastTouchY = ev.getY(1);
	        		
	        		if (arVertex1.size() > 300)
	        		{
	        			ToastManager.showToast(gcontex, "First Line Clear!!!", Toast.LENGTH_SHORT);
	        			arVertex1.clear();
	        			arVertex1.add(new Vertex(mFirst.mLastTouchX, mFirst.mLastTouchY, false, Color.RED));
	        		}
	        		else
	        		{
	        			arVertex1.add(new Vertex(mFirst.mLastTouchX, mFirst.mLastTouchY, true, Color.RED));
	        		}
	        		if (arVertex2.size() > 300)
	        		{
	        			ToastManager.showToast(gcontex, "Second Line Clear!!!", Toast.LENGTH_SHORT);
	        			arVertex2.clear();
	        			arVertex2.add(new Vertex(mSecond.mLastTouchX, mSecond.mLastTouchY, false, Color.RED));
	        		}
	        		else
	        		{
	        			arVertex2.add(new Vertex(mSecond.mLastTouchX, mSecond.mLastTouchY, true, Color.RED));
	        		}

	        	} else if(FLAG_DRAWING1) {
	        		mFirst.mLastTouchX = ev.getX(0);
	        		mFirst.mLastTouchY = ev.getY(0);
	        		if (arVertex1.size() > 300)
	        		{
	        			ToastManager.showToast(gcontex, "Frist Line Clear!!!", Toast.LENGTH_SHORT);
	        			arVertex1.clear();
	        			arVertex1.add(new Vertex(mFirst.mLastTouchX, mFirst.mLastTouchY, false, Color.RED));
	        		}
	        		else
	        		{
	        			arVertex1.add(new Vertex(mFirst.mLastTouchX, mFirst.mLastTouchY, true, Color.RED));
	        		}

	        	} else {
	        		mSecond.mLastTouchX = ev.getX(1);
	        		mSecond.mLastTouchY = ev.getY(1);
	        		if (arVertex2.size() > 300)
	        		{
	        			ToastManager.showToast(gcontex, "Second Line Clear!!!", Toast.LENGTH_SHORT);
	        			arVertex2.clear();
	        			arVertex2.add(new Vertex(mSecond.mLastTouchX, mSecond.mLastTouchY, false, Color.RED));
	        		}
	        		else
	        		{
	        			arVertex2.add(new Vertex(mSecond.mLastTouchX, mSecond.mLastTouchY, true, Color.RED));
	        		}
	        	}
	        	invalidate();
	        	break;
	        case MotionEvent.ACTION_POINTER_DOWN: {
		  		final int pointerIndex = (ev.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) 
		  				>> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
	  				final int pointerId = ev.getPointerId(pointerIndex);
	  				Log.e(TAG, "ACTION_POINTER_DOWN.pointerId=" + pointerId);
	  				if (pointerId == 0) {
	  					FLAG_DRAWING1 = true;
	  					mFirst.mLastTouchX = ev.getX(0);
	  					mFirst.mLastTouchY = ev.getY(0);
	  					mFirst.mActivePointerId = ev.getPointerId(0);
	  					arVertex1.add(new Vertex(mFirst.mLastTouchX, mFirst.mLastTouchY, false, Color.RED));
	  				} else {
	  					FLAG_DRAWING2 = true;
	  					mSecond.mLastTouchX = ev.getX(1);
	  					mSecond.mLastTouchY = ev.getY(1);
	  					mSecond.mActivePointerId = ev.getPointerId(1);
	  					arVertex2.add(new Vertex(mSecond.mLastTouchX, mSecond.mLastTouchY, false, Color.RED));
	  				}
	  				break;
	        }
	        case MotionEvent.ACTION_POINTER_UP:
	        	final int pointerIndex = (ev.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) 
    			>> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
		    	final int pointerId = ev.getPointerId(pointerIndex);
		    	Log.d(TAG, "ACTION_POINTER_UP=" + pointerIndex + ", " + pointerId
		    			+ String.format(", APid_f-%d", mFirst.mActivePointerId)
		    			+ String.format(", APid_se-%d", mSecond.mActivePointerId)
		    			);
		    	if(pointerId == 0) {
		    		FLAG_DRAWING2 = false;
		    		
		    		float x1 = arVertex1.get(arVertex1.size()-1).x;
		    		float y1 = arVertex1.get(arVertex1.size()-1).y;
		    		float x1b = Math.abs(ev.getX(0) - x1);
		    		float y1b = Math.abs(ev.getY(0) - y1);
		    		
		    		float x2 = -1;
		    		float y2 = -1;
		    		float x2b = -1;
		    		float y2b = -1;
		    		if (arVertex2.size() > 0 && arVertex2.size() < 300)
		    		{
		    			x2 = arVertex2.get(arVertex2.size()-1).x;
		    			y2 = arVertex2.get(arVertex2.size()-1).y;
			    		x2b = Math.abs(ev.getX(0) - x2);
			    		y2b = Math.abs(ev.getY(0) - y2);
		    			
		    		}
		    		

		    		
		    		//1 up
		    		if (x2 > -1 && x1b+y1b < x2b+y2b)
		    		{
		    			change = 1;
			    		arVertex1.clear();		    	
			    		int index = 0;
			    		for (index = 0; index < arVertex2.size(); index++)
			    		{
			    			if (index == 0)
			    				arVertex1.add(new Vertex(arVertex2.get(index).x, arVertex2.get(index).y, false, Color.RED));
			    			else
			    				arVertex1.add(new Vertex(arVertex2.get(index).x, arVertex2.get(index).y, true, Color.RED));
			    		}
			    		arVertex2.clear();	
		    		}
		    		//2 up
		    		else
		    		{
			    		arVertex2.clear();		    			
		    		}
		    	} else {
		    		final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
		    		Log.d(TAG, "ELSE newPointerIndex=" + newPointerIndex);
		    		if(newPointerIndex == 0) {
		    			FLAG_DRAWING2 = false;
		    			arVertex2.clear();
		    		} else {
		    			FLAG_DRAWING1 = false;
		    			arVertex1.clear();
		    		}
		    	}
		        super.onTouchEvent(ev);   
		        return false;

        }
        super.onTouchEvent(ev);   
        return true;
    }
    
    final int TEXT_X_AXIS = 50;
    final int TEXT_Y_AXIS = 30;
    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();        
        Paint bPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bPaint.setColor(0xffA0FFA0);
        Paint rPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        rPaint.setTextSize(20);
        rPaint.setColor(0xffFA8800);
        if (FLAG_DRAWING1) {
        	mFirst.mHRect.left = mFirst.mLastTouchX - (H_WIDTH/2);
        	mFirst.mHRect.top = mFirst.mLastTouchY - (H_HEIGHT/2);
        	mFirst.mHRect.right =  mFirst.mHRect.left + H_WIDTH;
        	mFirst.mHRect.bottom = mFirst.mHRect.top + H_HEIGHT;
	        canvas.drawRect(mFirst.mHRect, bPaint);
	        mFirst.mVRect.left = mFirst.mLastTouchX - (V_WIDTH/2);
	        mFirst.mVRect.top = mFirst.mLastTouchY - (V_HEIGHT/2);
	        mFirst.mVRect.right =  mFirst.mVRect.left + V_WIDTH;
	        mFirst.mVRect.bottom = mFirst.mVRect.top + V_HEIGHT;
	        canvas.drawRect(mFirst.mVRect, bPaint);
	        canvas.drawLine(mFirst.mLastTouchX-1,mFirst.mLastTouchY-1,mFirst.mLastTouchX,mFirst.mLastTouchY,mPaint);
	        mFirst.mCoordinates.left = mFirst.mLastTouchX;
	        mFirst.mCoordinates.top = mFirst.mLastTouchY;
	        canvas.drawText("x, y=(" + mFirst.mCoordinates.left + ", "+ mFirst.mCoordinates.top + ")",
	        		mFirst.mCoordinates.left >= 1000 ?
	        				mFirst.mCoordinates.left-(TEXT_X_AXIS*4) : mFirst.mCoordinates.left+TEXT_X_AXIS, 
    				mFirst.mCoordinates.top >= 500 ?
    						mFirst.mCoordinates.top-(TEXT_Y_AXIS) : mFirst.mCoordinates.top+TEXT_Y_AXIS,
	        		rPaint);
	        
	        for (int i=0;i<arVertex1.size();i++) {
	            if (arVertex1.get(i).Draw) {
	             mPaint.setColor(arVertex1.get(i).color);
	             //
	             canvas.drawLine(arVertex1.get(i-1).x, arVertex1.get(i-1).y, 
	               arVertex1.get(i).x, arVertex1.get(i).y, mPaint);
	            }
	           }
	        
        }
        if (FLAG_DRAWING2) {
        	mSecond.mHRect.left = mSecond.mLastTouchX - (H_WIDTH/2);
        	mSecond.mHRect.top = mSecond.mLastTouchY - (H_HEIGHT/2);
        	mSecond.mHRect.right =  mSecond.mHRect.left + H_WIDTH;
        	mSecond.mHRect.bottom = mSecond.mHRect.top + H_HEIGHT;
        	canvas.drawRect(mSecond.mHRect, bPaint);
        	mSecond.mVRect.left = mSecond.mLastTouchX - (V_WIDTH/2);
        	mSecond.mVRect.top = mSecond.mLastTouchY - (V_HEIGHT/2);
        	mSecond.mVRect.right =  mSecond.mVRect.left + V_WIDTH;
        	mSecond.mVRect.bottom = mSecond.mVRect.top + V_HEIGHT;
        	canvas.drawRect(mSecond.mVRect, bPaint);
        	canvas.drawLine(mFirst.mLastTouchX-1,mFirst.mLastTouchY-1,mFirst.mLastTouchX,mFirst.mLastTouchY,mPaint);
        	mSecond.mCoordinates.left = mSecond.mLastTouchX;
        	mSecond.mCoordinates.top = mSecond.mLastTouchY;
        	canvas.drawText("x, y=(" + mSecond.mCoordinates.left + ", "+ mSecond.mCoordinates.top + ")",
	        		mSecond.mCoordinates.left >= 1000 ?
	        				mSecond.mCoordinates.left-(TEXT_X_AXIS*4) : mSecond.mCoordinates.left+TEXT_X_AXIS, 
    				mSecond.mCoordinates.top >= 500 ?
    						mSecond.mCoordinates.top-(TEXT_Y_AXIS) : mSecond.mCoordinates.top+TEXT_Y_AXIS,
	        		rPaint);
        	
	        for (int i=0;i<arVertex2.size();i++) {
	            if (arVertex2.get(i).Draw) {
	             mPaint.setColor(arVertex2.get(i).color);
	             //
	             canvas.drawLine(arVertex2.get(i-1).x, arVertex2.get(i-1).y, 
	               arVertex2.get(i).x, arVertex2.get(i).y, mPaint);
	            }
	           }        	
        }

        canvas.restore();
    }

//    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
//        @Override
//        public boolean onScale(ScaleGestureDetector detector) {
//            invalidate();
//            return true;
//        }
//    }
    
    class InnerTouch {
    	Context mContext;
    	/////////////////////////////////////////////////////////////////////////////////////////////
    	// 		horizontal, vertical 
    	private RectF mHRect;
    	private RectF mVRect;
    	private RectF mCoordinates;
    	
    	public InnerTouch(Context context) {
    		this.mContext = context;
    		mHRect = new RectF(0, 0, H_WIDTH, H_HEIGHT);
        	mVRect = new RectF(0, 0, V_WIDTH, V_HEIGHT);
        	mCoordinates = new RectF(0, 0, 100, 30);
    	}
        private float mLastTouchX = 0.f;
        private float mLastTouchY = 0.f;
        
        private int mActivePointerId = INVALID_POINTER_ID;
    }
    
    public class Vertex {
    	   float x;
    	   float y;
    	   boolean Draw;
    	   int color;
    	   
    	   Vertex(float ax, float ay, boolean ad, int color) {
    	    x = ax;
    	    y = ay;
    	    Draw = ad;
    	    this.color=color;
    	   }
    }
    /*
     * ***************************************************************************
     * SAMPLE
     * ***************************************************************************
     */
//  @Override
//  public boolean onTouchEvent(MotionEvent ev) {
//  	// Let the ScaleGestureDetector inspect all events.
//  	mScaleDetector.onTouchEvent(ev);
//  	
//  	final int action = ev.getAction();
//  	switch (action & MotionEvent.ACTION_MASK) {
//  	case MotionEvent.ACTION_DOWN: {
//  		final float x = ev.getX();
//  		final float y = ev.getY();
//  		
//  		mLastTouchX = x;
//  		mLastTouchY = y;
//  		mActivePointerId = ev.getPointerId(0);
//  		break;
//  	}
//  	
//  	case MotionEvent.ACTION_MOVE: {
//  		final int pointerIndex = ev.findPointerIndex(mActivePointerId);
//  		final float x = ev.getX(pointerIndex);
//  		final float y = ev.getY(pointerIndex);
//  		
//  		// Only move if the ScaleGestureDetector isn't processing a gesture.
//  		if (!mScaleDetector.isInProgress()) {
//  			final float dx = x - mLastTouchX;
//  			final float dy = y - mLastTouchY;
//  			
//  			mPosX += dx;
//  			mPosY += dy;
//  			
//  			invalidate();
//  		}
//  		
//  		mLastTouchX = x;
//  		mLastTouchY = y;
//  		
//  		break;
//  	}
//  	
//  	case MotionEvent.ACTION_UP: {
//  		mActivePointerId = INVALID_POINTER_ID;
//  		break;
//  	}
//  	
//  	case MotionEvent.ACTION_CANCEL: {
//  		mActivePointerId = INVALID_POINTER_ID;
//  		break;
//  	}
//  	
//  	case MotionEvent.ACTION_POINTER_UP: {
//  		final int pointerIndex = (ev.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) 
//  				>> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
//  				final int pointerId = ev.getPointerId(pointerIndex);
//  				if (pointerId == mActivePointerId) {
//  					// This was our active pointer going up. Choose a new
//  					// active pointer and adjust accordingly.
//  					final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
//  					mLastTouchX = ev.getX(newPointerIndex);
//  					mLastTouchY = ev.getY(newPointerIndex);
//  					mActivePointerId = ev.getPointerId(newPointerIndex);
//  				}
//  				break;
//  	}
//  	}
//  	
//  	return true;
//  }
    
//    private class ScaleListener extends ScaleGestureDetector.SimpleOnScaleGestureListener {
//    	@Override
//    	public boolean onScale(ScaleGestureDetector detector) {
//    		mScaleFactor *= detector.getScaleFactor();
//    		
//    		// Don't let the object get too small or too large.
//    		mScaleFactor = Math.max(0.1f, Math.min(mScaleFactor, 5.0f));
//    		
//    		invalidate();
//    		return true;
//    	}
//    }
}
