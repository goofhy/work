package com.tjmedia.android.tjdebugger.activity;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.backlight.BacklightAct;
import com.tjmedia.android.tjdebugger.camera.CameraAct;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.TJArrayAdapter;
import com.tjmedia.android.tjdebugger.common.TJListItem;
import com.tjmedia.android.tjdebugger.common.ToastManager;
import com.tjmedia.android.tjdebugger.led.LedAct;
import com.tjmedia.android.tjdebugger.remocon.RemoconAct;
import com.tjmedia.android.tjdebugger.sensor.GSensorAct;
import com.tjmedia.android.tjdebugger.video.VideoAct;
import com.tjmedia.android.tjdebugger.wifi.WifiAct;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : jimmy
 * @Date    : 2012. 2. 27. 
 * @History : TJMedia Menu Tree
 * 
 * com.tjmedia.android.tjdebugger.package
 *  1)		AM : 센서관리 G-Sencer,
 *  2)		BM : 온도센서
 *  3)		CM : 리모콘                	     
 *  4)		BM : 카메라(flash test)
 * 	 5)		CM : Wifi(AP 접속 / 리스트 검색), Storage 성능측정
 *  6)		DM : NFC, 터치 기능테스트
 *  7)		EM : LCD Backlight, Recording/Player
 *  8)		FM : MV Player / Recording
 *  9)		GM : Reboots, Version Info.
 *  10)	HM : Reboots, Version Info, Battery Info.
 *  11)	IM : Bluetooth.
 *  ** 추가 작업항목
 *  12)	JM : , SecureCore, LED test
 *
 */
//import android.os.AsyncTask;
//import android.os.AsyncTask;
//import android.os.SystemProperties;

public class TJDebuggerActivity extends Activity {
	private final String TAG = "TJDebuggerActivity";
    /** Called when the activity is first created. */
	ListView mTJMainListView;
	ArrayAdapter<String> mAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate()!!!");
        setContentView(R.layout.tj_main);
        initObjInfo();
        initListListener();
        initListViewInfo();
        
    }
    
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	private void initObjInfo() {
	}
	
	private void initListListener() {
		mTJMainListView = (ListView) findViewById(R.id.TJ_Main_List);
		mTJMainListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		mTJMainListView.setOnItemClickListener(new OnItemClickListener() {		
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Log.i(TAG, "mTJMainListView.onItemClick()");
				TJListItem temp = (TJListItem)parent.getItemAtPosition(position);
				int index = Integer.valueOf(temp.getColumns(0));
				Log.i(TAG, "index = " + index);
				callActivity(index);
			}
		});
	}
	
	private void initListViewInfo() {
		ArrayAdapter<TJListItem> mTJAdapter;
		ArrayList<TJListItem> list = new ArrayList<TJListItem>();
		TJListItem obj = null;
		
		for(int i=0; i<Const.TITLES.length; i++) {
			obj = new TJListItem(String.valueOf(i), Const.TITLES[i], Const.DETAILS[i]);
			list.add(obj);
		}
		mTJAdapter = new TJArrayAdapter(getApplicationContext(), R.layout.tj_main_list_row, list);
		mTJMainListView.setAdapter(mTJAdapter);
		mTJAdapter.notifyDataSetChanged();
	}
	
	private void callActivity(int index) {
		Intent i;
		switch (index) {
		case 0:
//			startActivity(new Intent(getApplicationContext(), AMMainAct.class));
			startActivity(new Intent(Const.TITLES[index]));
			break;
		case 1:
//			startActivity(new Intent(getApplicationContext(), BMMainAct.class));
			startActivity(new Intent(Const.TITLES[index]));
			break;
		case 2:
//			startActivity(new Intent(getApplicationContext(), CMMainAct.class));
			startActivity(new Intent(Const.TITLES[index]));
			break;
		case 3:
//			startActivity(new Intent(getApplicationContext(), DMMainAct.class));
			startActivity(new Intent(Const.TITLES[index]));
			break;
		case 4:
//			startActivity(new Intent(getApplicationContext(), EMMainAct.class));
			startActivity(new Intent(Const.TITLES[index]));
			break;
		case 5:
//			startActivity(new Intent(getApplicationContext(), FMMainAct.class));
			startActivity(new Intent(Const.TITLES[index]));
			break;
		case 6:
//			startActivity(new Intent(getApplicationContext(), GMMainAct.class));
			startActivity(new Intent(Const.TITLES[index]));
			break;
		default:
			ToastManager.showToast(this, getResources().getString(R.string.tj_main_index04), Toast.LENGTH_SHORT);
			break;
		}
		
	}
	
}