package com.tjmedia.android.tjdebugger.backlight;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.activity.TJDebugger;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SharedManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class BacklightAct extends Activity {   
   
	private static final String TAG = "BacklightAct";
	
	Button mTitleExit;
	SoundPoolManager mPoolManger;

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.backlight_main);    
        initObjInfo();
        initViewID();
        
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
		mLoopHandler.stop();
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
	}
    
	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		Backlight.mComponetListView = (ListView) findViewById(R.id.Backlight_main_ListView);
		Backlight.mComponet01 = (TextView) findViewById(R.id.Backlight_main_index01);
		for(int i=0; i<Backlight.mComponets.length; i++) {
			Backlight.mComponets[i] = (Button)  findViewById(Const.I_BACKLIGHT_NUMS[i]);
			Backlight.mComponets[i].setOnClickListener(mClickListener);
		}
		Backlight.mComponet21 = (Button)  findViewById(R.id.Backlight_main_index21);
		Backlight.mComponet21.setOnClickListener(mClickListener);
		
		Backlight.mComponet90 = (RadioButton) findViewById(R.id.Backlight_main_dialog_Index_RG01);
		Backlight.mComponet91 = (RadioButton) findViewById(R.id.Backlight_main_dialog_Index_RG02);
		Backlight.mComponet98 = (Button)  findViewById(R.id.Backlight_main_index98);
		Backlight.mComponet99 = (Button)  findViewById(R.id.Backlight_main_index99);
		Backlight.mAndroidSettings = (Button)  findViewById(R.id.BacklightAndroidSettings);
		Backlight.mComponet98.setOnClickListener(mClickListener);
		Backlight.mComponet99.setOnClickListener(mClickListener);
		Backlight.mAndroidSettings.setOnClickListener(mClickListener);
		
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		Backlight.mComponetListView.setAdapter(mAdapter);
		readBackLightInfoThroughSystemSetting();
		setBackLightEvent(SharedManager.getSettingBrightnessLevel(getApplicationContext()));
		
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}		
//		mBrightnessVales = 255;
//		saveBackLightInfoThroughSystemSetting();
	}
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			case R.id.Backlight_main_index02:
				setBackLightEvent(0);
				break;
			case R.id.Backlight_main_index03:
				setBackLightEvent(1);
				break;
			case R.id.Backlight_main_index04:
				setBackLightEvent(2);
				break;
			case R.id.Backlight_main_index05:
				setBackLightEvent(3);
				break;
			case R.id.Backlight_main_index06:
				setBackLightEvent(4);
				break;
			case R.id.Backlight_main_index07:
				setBackLightEvent(5);
				break;
			case R.id.Backlight_main_index08:
				setBackLightEvent(6);
				break;
			case R.id.Backlight_main_index09:
				setBackLightEvent(7);
				break;
			case R.id.Backlight_main_index10:
				setBackLightEvent(8);
				break;
			case R.id.Backlight_main_index11:
				setBackLightEvent(9);
				break;
			case R.id.Backlight_main_index12:
				setBackLightEvent(10);
				break;
			case R.id.Backlight_main_index21:	// 100%
				saveBackLightInfoThroughSystemSetting();
				ToastManager.showToast(getApplicationContext(), "Brightness Value Saved", Toast.LENGTH_SHORT);
				break;
			case R.id.Backlight_main_index98:	// Aging Start
				if(Backlight.mComponet90.isChecked()) {
					Frequency = 500;
				} else {
					Frequency = 1000;
				}
				ToastManager.showToast(getApplicationContext(), "Aging Start", Toast.LENGTH_SHORT);
				mLoopHandler.start();
				break;
			case R.id.Backlight_main_index99:	// Aging Stop
				ToastManager.showToast(getApplicationContext(), "Aging Stop", Toast.LENGTH_SHORT);
				mLoopHandler.stop();
				break;
			case R.id.BacklightAndroidSettings:	//Android Display settings
				startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS));				
				break;
			default:
				break;
			}
		}
	};
	
	Handler mHandler = new Handler();
	public int Frequency = 500;
	private LoopHandler mLoopHandler = new LoopHandler();
	public void loop() {
		setBackLightEvent(mLoopHandler.count % 11);
		mLoopHandler.count++;
		mLoopHandler.sleep(Frequency);
	}
	
	class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			loop();
		}
	};
	
	private long mListIndex = 0;
	private int mBrightnessIndex = 10;
	private void updateList(int index) {
		mItem.add(0, "INDEX[" + mListIndex + "] : "
				+ "Brightness : " + Const.I_BACKLIGHT_PERCENT[index]  + "\n");
		mAdapter.notifyDataSetChanged();
		mListIndex++;
		mBrightnessIndex = index;
	}
	
	float mBrightnessVales = 0;
	private void setBackLightEvent(int key) {
		switch (key) {
		case 0:
			setBackLightScreenBrightness(0);
			updateList(0);
			break;
		case 1:
			setBackLightScreenBrightness(10);
			updateList(1);
			break;
		case 2:
			setBackLightScreenBrightness(20);
			updateList(2);
			break;
		case 3:
			setBackLightScreenBrightness(30);
			updateList(3);
			break;
		case 4:
			setBackLightScreenBrightness(40);
			updateList(4);
			break;
		case 5:
			setBackLightScreenBrightness(50);
			updateList(5);
			break;
		case 6:
			setBackLightScreenBrightness(60);
			updateList(6);
			break;
		case 7:
			setBackLightScreenBrightness(70);
			updateList(7);
			break;
		case 8:
			setBackLightScreenBrightness(80);
			updateList(8);
			break;
		case 9:
			setBackLightScreenBrightness(90);
			updateList(9);
			break;
		case 10:
			setBackLightScreenBrightness(100);
			updateList(10);
			break;
		default:
			setBackLightScreenBrightness(100);
			updateList(10);
			break;
		}
	}
	private void setBackLightScreenBrightness(int brightnessPercent) {
		// brightnessPercent 0 ~ 100;
		int divide = brightnessPercent;
		if(divide < 10) {
			divide = 5;
		}
		float value = ((255*divide)/100);
		float result = value / 255; 
		WindowManager.LayoutParams lp = getWindow().getAttributes();
		lp.screenBrightness = result;
		mBrightnessVales = result;
//		Log.d(TAG, "result=" + result);
		getWindow().setAttributes(lp);
	}
	
	private static final int MAXIMUM_BACKLIGHT = 255;
	private int readBackLightInfoThroughSystemSetting() {
		int result = 0;
		try {
			mBrightnessVales = Settings.System.getInt(getBaseContext().getContentResolver(), 
                Settings.System.SCREEN_BRIGHTNESS);
        } catch (SettingNotFoundException snfe) {
        	mBrightnessVales = MAXIMUM_BACKLIGHT;
        }
		result = (int)mBrightnessVales*100/255;
		Log.d(TAG, "mBrightnessVales=" + mBrightnessVales + ", result=" + result);
		return result; 
	}
	
	private void saveBackLightInfoThroughSystemSetting() {
		int SysBackLightValue = (int)(mBrightnessVales * 255);
    	android.provider.Settings.System.putInt(getContentResolver(),
    			android.provider.Settings.System.SCREEN_BRIGHTNESS, SysBackLightValue);
    	SharedManager.setSettingBrightnessLevel(getApplicationContext(), mBrightnessIndex);
	}
	
	static class Backlight {
		private static ListView 		mComponetListView;
		private static TextView		mComponet01;		// Button display Viewer
		private static Button[] 		mComponets = new Button[11];		// start 0 btn
		
		private static Button 			mComponet21;		// Save
		
		private static RadioButton 	mComponet90;
		private static RadioButton 	mComponet91;
		private static Button 			mComponet98;		// Aging Start
		private static Button 			mComponet99;		// Aging Stop
		private static Button 			mAndroidSettings;	//Android Settings
		
	}
	
	/*
	 * ************************************************************
	 * Interface below methods
	 */
	public void setBackLight(Object obj, int brightnessPercent) {
			// brightnessPercent 0 ~ 100;
			int divide = brightnessPercent;
			if(divide < 10) {
				divide = 5;
			}
			float value = ((255*divide)/100);
			float result = value / 255;
			
			if (obj instanceof TJDebugger) {
				TJDebugger tjobj = (TJDebugger)obj;
				WindowManager.LayoutParams lp = tjobj.getWindow().getAttributes();
				lp.screenBrightness = result;
				tjobj.getWindow().setAttributes(lp);
			}
	}
	
}
	
	

