package com.tjmedia.android.tjdebugger.remocon;

import java.util.ArrayList;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */



public class RemoconAct extends Activity {   
   
	private static final String TAG = "RemoconAct"; 	

	String strManufacturer = android.os.Build.MANUFACTURER;	
	String strProduct = android.os.Build.PRODUCT;
	
	  // Field descriptor #6 I
	  public static final byte RMC__DAM = 29;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__START = 1;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__STOP = 0;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__RESERVE_OK = 10;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__RESERVE_CANCLE = 7;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__REW = 26;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__FF = 28;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__PAUSE = 27;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__ORIGINAL_SONG = 96;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__TEMP_UP = 32;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__TEMP_DOWN = 33;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__KEY_UP = 4;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__KEY_DOWN = 5;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__KEY_RESET = 96;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__SCORE = 31;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__BACK = 47;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__GUIDE_VOCAL = 38;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__MUSIC_UP = (byte) 170;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__MUSIC_DOWN = (byte) 169;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__MIC_UP = (byte) 172;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__MIC_DOWN = (byte) 171;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__PRIORITY_RESERVE = 3;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__NUMBER_INPUT_IN = 8;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__NUMBER_INPUT_OUT = 9;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__KEY_INPUT_IN = 88;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__KEY_INPUT_OUT = 89;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__KARAOKE_VOLUME_UP = (byte) 175;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__KARAOKE_VOLUME_DOWN = (byte) 173;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__OPEN_CLOSE = (byte) 168;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__BACK_CHROUS = (byte) 208;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__WIFE = 12;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__RUBE = 6;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__WIFE_RUBE = 39;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__QUESTION_X3 = 37;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__DIRECT_SE_O = 62;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__DIRECT_SE_A = 63;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__DIRECT_SE_X = (byte) 160;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__EFFECT_LEVEL_UP = (byte) 205;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__EFFECT_LEVEL_DOWN = (byte) 207;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__HARMONY = 80;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__VOICE_CHANGE = 82;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__VOICE_DOUBLE_RING = 83;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__ONE_DUET = 81;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__VOCAL_EFFECT_ON_OFF = (byte) 204;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__VOCAL_EFFECT_GUIDE = 13;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__MEMORY_SET = 11;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__DAM_IP_INPUT_IN = 97;
	  
	  // Field descriptor #6 I
	  public static final byte RMC__DAM_IP_INPUT_OUT = 98;
	
	Button mTitleExit;
	
	
	public RemoconAct() {
	}
	
	public RemoconAct(Context context) {
		this.Frequency = 2000;
	}
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.remocon_main);    
 
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
		unregisterReceiver(IRReceiver);
		mLoopHandler.stop();
		mPoolManger.release();
//		TDMKMisc_Service.Finalize();
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("TMFP.RMC");
        registerReceiver(IRReceiver, filter);
	}
	
	
	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		Remocon.mComponetListView = (ListView) findViewById(R.id.Remocon_main_ListView);
		Remocon.mComponet01 = (TextView) findViewById(R.id.Remocon_main_index01);
		for(int i=0; i<Remocon.mComponets.length; i++) {
			Remocon.mComponets[i] = (Button)  findViewById(Const.I_REMOCON_NUMS[i]);
			Remocon.mComponets[i].setOnClickListener(mClickListener);
		}
		Remocon.mComponet21 = (Button)  findViewById(R.id.Remocon_main_index21);
		Remocon.mComponet22 = (Button)  findViewById(R.id.Remocon_main_index22);
		Remocon.mComponet23 = (Button)  findViewById(R.id.Remocon_main_index23);
		Remocon.mComponet24 = (Button)  findViewById(R.id.Remocon_main_index24);
		Remocon.mComponet25 = (Button)  findViewById(R.id.Remocon_main_index25);
		Remocon.mComponet26 = (Button)  findViewById(R.id.Remocon_main_index26);
		Remocon.mComponet27 = (Button)  findViewById(R.id.Remocon_main_index27);
		
		Remocon.mComponet21.setOnClickListener(mClickListener);
		Remocon.mComponet22.setOnClickListener(mClickListener);
		Remocon.mComponet23.setOnClickListener(mClickListener);
		Remocon.mComponet24.setOnClickListener(mClickListener);
		Remocon.mComponet25.setOnClickListener(mClickListener);
		Remocon.mComponet26.setOnClickListener(mClickListener);
		Remocon.mComponet27.setOnClickListener(mClickListener);
		
		Remocon.mComponet90 = (RadioButton) findViewById(R.id.Remocon_main_dialog_Index_RG01);
		Remocon.mComponet91 = (RadioButton) findViewById(R.id.Remocon_main_dialog_Index_RG02);

		Remocon.mComponet92 = (RadioButton) findViewById(R.id.Remocon_main_dialog_Index_RG11);
		Remocon.mComponet93 = (RadioButton) findViewById(R.id.Remocon_main_dialog_Index_RG12);
		
		Remocon.mComponet98 = (Button)  findViewById(R.id.Remocon_main_index98);
		Remocon.mComponet99 = (Button)  findViewById(R.id.Remocon_main_index99);
		Remocon.mComponet98.setOnClickListener(mClickListener);
		Remocon.mComponet99.setOnClickListener(mClickListener);
		
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		Remocon.mComponetListView.setAdapter(mAdapter);
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
	}
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.top_exit:
				mPoolManger.playTouchSe();
				finish();
				break;
			case R.id.Remocon_main_index02:	// 0
				mPoolManger.playTouchSe();
				setDigitEvent(0);
				break;
			case R.id.Remocon_main_index03:	// 1
				mPoolManger.playTouchSe();
				setDigitEvent(1);
				break;
			case R.id.Remocon_main_index04:	// 2
				mPoolManger.playTouchSe();
				setDigitEvent(2);
				break;
			case R.id.Remocon_main_index05:	// 3
				mPoolManger.playTouchSe();
				setDigitEvent(3);
				break;
			case R.id.Remocon_main_index06:	// 4
				mPoolManger.playTouchSe();
				setDigitEvent(4);
				break;
			case R.id.Remocon_main_index07:	// 5
				mPoolManger.playTouchSe();
				setDigitEvent(5);
				break;
			case R.id.Remocon_main_index08:	// 6
				mPoolManger.playTouchSe();
				setDigitEvent(6);
				break;
			case R.id.Remocon_main_index09:	// 7
				mPoolManger.playTouchSe();
				setDigitEvent(7);
				break;
			case R.id.Remocon_main_index10:	// 8
				mPoolManger.playTouchSe();
				setDigitEvent(8);
				break;
			case R.id.Remocon_main_index11:	// 9
				mPoolManger.playTouchSe();
				setDigitEvent(9);
				break;
				
			case R.id.Remocon_main_index21:	// send
				sendSongIdRMC();
				break;
			case R.id.Remocon_main_index22:	// memory read
				mPoolManger.playTouchSe();
				readSongIDInfo();
				break;
			case R.id.Remocon_main_index23:	// start
				sendPlayStartRMC();
				break;
			case R.id.Remocon_main_index24:	// stop
				sendPlayStopRMC();
				break;
			case R.id.Remocon_main_index25:	// Mitsubishi_TV_pwr On/Off
				sendMitsubishiPWEROnOffRMC();
				break;				
				
			case R.id.Remocon_main_index26:	// Mitsubishi_TV vol+
				sendMitsubishiVolUP();
				break;		
				
			case R.id.Remocon_main_index27:	// Mitsubishi_TV  vol-
				sendMitsubishiVolDown();
				break;		
				
			case R.id.Remocon_main_index98:	// Aging Start
				if(Remocon.mComponet90.isChecked()) {
					Frequency = 1000;
				} else {
					Frequency = 2000;
				}
				ToastManager.showToast(getApplicationContext(), "Aging Start", Toast.LENGTH_SHORT);
				mLoopHandler.start();
				break;
			case R.id.Remocon_main_index99:	// Aging Stop
				ToastManager.showToast(getApplicationContext(), "Aging Stop", Toast.LENGTH_SHORT);
				mLoopHandler.stop();
				break;
				
				
			default:
				break;
			}
		}
	};
	
	Handler mHandler = new Handler();
	public int Frequency = 1000;
	private LoopHandler mLoopHandler = new LoopHandler();
	//private String[] mArrTestSongIDs = {"1111-11", "2222-22", "3333-33"}; 
	private String[] mArrTestSongIDs = {"1111-11", "1111-12", "1111-13"}; 
	public void loop() {
//		setDigitEvent(mLoopHandler.count % 7);
//		mLoopHandler.count++;
		mSBDigit.setLength(0);
		int index = mLoopHandler.count%3;
		if(index == 0) {
			mSBDigit.append(mArrTestSongIDs[mLoopHandler.songCount%3]);			
			sendSongIdRMC();			
		} else if(index ==1) {
			sendPlayStartRMC();
		} else {
			sendPlayStopRMC();
			mLoopHandler.songCount++;
		}
		mLoopHandler.count++;
		mLoopHandler.sleep(Frequency);
	}
	
	class LoopHandler extends Handler {
		private int count = 0;
		private int songCount = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
			//Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			loop();
		}
	};
	
	private long mListIndex = 0;
	private void updateList(int key, boolean result) {
		switch (key) {
		case 0:
			mItem.add(0, "INDEX[" + mListIndex + "] : "
					+ mSBDigit.toString() + (result == true ? " Reserved, OK"  : " Reserved, NG")  + "\n");
			mAdapter.notifyDataSetChanged();
			mListIndex++;
			break;
		case 1:
			mItem.add(0, "INDEX[" + mListIndex + "] : "
					+ (result == true ? "START, OK"  : "START, NG")  + "\n");
			mAdapter.notifyDataSetChanged();
			mListIndex++;
			break;
		case 2:
			mItem.add(0, "INDEX[" + mListIndex + "] : "
					+ (result == true ? "STOP, OK"  : "STOP, NG")  + "\n");
			mAdapter.notifyDataSetChanged();
			mListIndex++;
			break;
			
		case 3:
			mItem.add(0, "INDEX[" + mListIndex + "] : "
					+ (result == true ? "MTV POWER ON/OFF, OK"  : "MTV POWER ON/OFF, NG")  + "\n");
			mAdapter.notifyDataSetChanged();
			mListIndex++;
			break;

		case 4:
			mItem.add(0, "INDEX[" + mListIndex + "] : "
					+ (result == true ? "MTV Vol+, OK"  : "MTV Vol+, NG")  + "\n");
			mAdapter.notifyDataSetChanged();
			mListIndex++;
			break;
		case 5:
			mItem.add(0, "INDEX[" + mListIndex + "] : "
					+ (result == true ? "MTV Vol-, OK"  : "MTV Vol-, NG")  + "\n");
			mAdapter.notifyDataSetChanged();
			mListIndex++;
			break;
			
		default:
			break;
		}
	}
	
	StringBuilder mSBDigit = new StringBuilder();
	StringBuilder mSBDigitBackUp = new StringBuilder();
	private void setDigitEvent(int flag) {
		if(mSBDigit.length() == 7) {
			mSBDigit.setLength(0);
		}
		if(mSBDigit.length() == 4) {
			mSBDigit.append("-");
		}
		mSBDigit.append(flag);
		Remocon.mComponet01.setText(mSBDigit.toString());
	}
	
	
	public int Senddata_DAMRMC(byte cmd ,byte[] buffer,byte len) {

		Intent intent = new Intent();
		intent.setAction("CSD.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", buffer);		
		intent.putExtra("leng",len);
		sendBroadcast(intent);
		return 0;
				
	}
	
	public int Senddata_DAMRMC(byte cmd ,byte buffer,byte len) {

		byte data[] = new byte[1];
		data[0] = buffer;
		Intent intent = new Intent();
		intent.setAction("CSD.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", data);		
		intent.putExtra("leng",len);
		sendBroadcast(intent);
		return 0;
				
	}	

	SoundPoolManager mPoolManger;
	private void sendSongIdRMC() {
		
		Log.d(TAG, "sendSongIdRMC++");
		if(mSBDigit.length() < 4) {
			ToastManager.showToast(getApplicationContext(), "Try to select a song number", Toast.LENGTH_SHORT);
			return;
		}
		
		String[] arr = mSBDigit.toString().split("-");
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<arr.length; i++) {
			sb.append(arr[i]);
		}
		String str = sb.toString();
		//Byte[] numByte = ConvertManager.convertFromStringToHexByte(str, 6);
		Byte[] numByte = new Byte[6];
		for(int i=0; i<str.length(); i++) {
			numByte[i] = (byte)str.charAt(i);
		}
		
//		mPoolManger.playTouchSe();
//		Log.e(TAG, "SoundRepeat.len:" + SoundRepeat);
//		mSoundHandler.start();
		
		byte[] pBufferIR=new byte[9];
		
		pBufferIR[0]=(byte)0x08;
		pBufferIR[1] = (numByte[0] != null) ? (byte)numByte[0] : 0;
		pBufferIR[2] = (numByte[1] != null) ? (byte)numByte[1] : 0;
		pBufferIR[3] = (numByte[2] != null) ? (byte)numByte[2] : 0;
		pBufferIR[4] = (numByte[3] != null) ? (byte)numByte[3] : 0;
		pBufferIR[5] = (byte)'<';
		pBufferIR[6] = (numByte[4] != null) ? (byte)numByte[4] : 0;
		pBufferIR[7] = (numByte[5] != null) ? (byte)numByte[5] : 0;
		pBufferIR[8] = (byte)0x09;
		
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{				
			int result = Senddata_DAMRMC((byte)1,pBufferIR,(byte)9);
						
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			if (Remocon.mComponet92.isChecked())
			{
				SoundRepeat = str.length();
				new Thread(new Sound()).start();		
			}
			updateList(0, bool);
			clearData();
			Log.d(TAG, "sendSongIdRMC--");
		}
	}
	
	class Sound extends Thread {
		int count = 0;
		@Override
		public void run() {
//			SoundPoolManager.play(SoundPoolManager.ID_TOUCH, 1);
//			SoundPoolManager.play(SoundPoolManager.ID_TOUCH, 5);
			synchronized(this)
			{
				try {
					sleep(SoundRepeat*50);
				} catch (InterruptedException ie) {
					ie.printStackTrace();
				}
				
				while(count < SoundRepeat) {
					mPoolManger.playTouchSe();
					try {
						sleep(50);
					} catch (InterruptedException ie) {
						ie.printStackTrace();
					}
					count++;
					
				}
			}
		}
	};
	
	SoundHandler mSoundHandler = new SoundHandler();
	int SoundFrequency = 1000;
	int SoundRepeat = 0;
	class SoundHandler extends Handler {
		private int count = 0;
		
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				soundLoop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
			count = 0;
		}

		private void start() {
			bStop = false;
			soundLoop();
		}
	};
	
	private void soundLoop() {
		if(mSoundHandler.count > SoundRepeat) {
			mSoundHandler.stop();
			return;
		}
//		SoundPoolManager.play(SoundPoolManager.ID_TOUCH, 1);
		mSoundHandler.count++;
		mSoundHandler.sleep(SoundFrequency);
	}
	
	private void readSongIDInfo() {
		mSBDigit.append(mSBDigitBackUp.toString());
		Remocon.mComponet01.setText(mSBDigit.toString());
	}
	
	private void sendPlayStartRMC() {
		Log.d(TAG, "sendPlayStartRMC++");
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{			
			int result = Senddata_DAMRMC((byte)1,RMC__RESERVE_OK,(byte)1);
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			if (Remocon.mComponet92.isChecked())
			{
				mPoolManger.playTouchSe();
			}
			updateList(1, bool);
			clearData();
			Log.d(TAG, "sendPlayStartRMC--");
		}
	}
	
	private void sendPlayStopRMC() {
		Log.d(TAG, "sendPlayStopRMC++");
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{			
			int result = Senddata_DAMRMC((byte)1,RMC__RESERVE_CANCLE,(byte)1);
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			if (Remocon.mComponet92.isChecked())
			{
				mPoolManger.playTouchSe();
			}
			updateList(2, bool);
			clearData();
			Log.d(TAG, "sendPlayStopRMC--");
		}
	}
	
	private void sendMitsubishiPWEROnOffRMC() {
		Log.d(TAG, "sendMitsubishiPWEROnOffRMC++");
		//int result = TDMKMisc_Service.IR_Send(TDMKMisc_Service.RMC__RESERVE_CANCLE);
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{
			byte[] pBufferIR=new byte[1];
			pBufferIR[0]=(byte)0x02;			
			int result = Senddata_DAMRMC((byte)2,pBufferIR,(byte)1);
			
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			if (Remocon.mComponet92.isChecked())
			{
				mPoolManger.playTouchSe();
			}
			updateList(3, bool);
			clearData();
			Log.d(TAG, "sendMitsubishiPWEROnOffRMC--");
		}
	}	
	
	private void sendMitsubishiVolUP() {
		Log.d(TAG, "sendMitsubishiVolUP++");
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{	
			byte[] pBufferIR=new byte[1];
			pBufferIR[0]=(byte)0x22;			
			int result = Senddata_DAMRMC((byte)2,pBufferIR,(byte)1);
			
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			if (Remocon.mComponet92.isChecked())
			{
				mPoolManger.playTouchSe();
			}
			updateList(4, bool);
			clearData();
			Log.d(TAG, "sendMitsubishiVolUP--");
		}
	}		
	
	private void sendMitsubishiVolDown() {
		Log.d(TAG, "sendMitsubishiVolDown++");
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{
			
			byte[] pBufferIR=new byte[1];
			pBufferIR[0]=(byte)0x2A;			
			int result = Senddata_DAMRMC((byte)2,pBufferIR,(byte)1);
			
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			if (Remocon.mComponet92.isChecked())
			{
				mPoolManger.playTouchSe();
			}
			updateList(5, bool);
			clearData();
			Log.d(TAG, "sendMitsubishiVolDown--");
		}
	}
		
	
	private void clearData() {
		mSBDigitBackUp.setLength(0);
		mSBDigitBackUp.append(mSBDigit.toString());
		mSBDigit.setLength(0);
		Remocon.mComponet01.setText("");
	}
	
	static class Remocon {
		private static ListView 			mComponetListView;
		private static TextView			mComponet01;		// Button display Viewer
		private static Button[] 			mComponets = new Button[10];		// start 0 btn
		
		private static Button 				mComponet21;		// Send
		private static Button 				mComponet22;		// Memory read
		private static Button 				mComponet23;		// open RMC 
		private static Button 				mComponet24;		// close RMC
		private static Button 				mComponet25;		// MITSUBISHI Power On/Off
		private static Button 				mComponet26;		// MITSUBISHI vol+
		private static Button 				mComponet27;		// MITSUBISHI vol-
		
		private static RadioButton 		mComponet90;
		private static RadioButton 		mComponet91;
		private static RadioButton 		mComponet92;
		private static RadioButton 		mComponet93;		
		private static Button 				mComponet98;		// Aging Start
		private static Button 				mComponet99;		// Aging Stop
		
		
	}
	
	/*
	 * ************************************************************
	 * Interface below methods
	 */
	public String reserveASongNumberThroughRMC() {
		Log.d(TAG, "reserveASongNumberThroughRMC()");
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{
			mSBDigit.setLength(0);
			mSBDigit.append(mArrTestSongIDs[mLoopHandler.songCount%3]);
			
			String[] arr = mSBDigit.toString().split("-");
			StringBuilder sb = new StringBuilder();
			for(int i=0; i<arr.length; i++) {
				sb.append(arr[i]);
			}
			String str = sb.toString();
			Byte[] numByte = new Byte[6];
			for(int i=0; i<str.length(); i++) {
				numByte[i] = (byte)str.charAt(i);
			}
			
			byte[] pBufferIR=new byte[9];
			
			pBufferIR[0]=(byte)0x08;
			pBufferIR[1]=(byte)numByte[0];
			pBufferIR[2]=(byte)numByte[1];
			pBufferIR[3]=(byte)numByte[2];
			pBufferIR[4]=(byte)numByte[3];
			pBufferIR[5]=(byte)'<';			// '<'
			pBufferIR[6]=(byte)numByte[4];
			pBufferIR[7]=(byte)numByte[5];
			pBufferIR[8]=(byte)0x09;
						
			int result = Senddata_DAMRMC((byte)1,pBufferIR,(byte)9);
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			String str2 = getUpdateList(0, bool);
			mLoopHandler.songCount++;
			return str2;
		}		
		else
		{
			return "unsupported function";
		}
	}
	
	public String sendPlaySignalToRMC() {
		Log.d(TAG, "sendPlayStartRMCForFactoryMode()");		
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{			
			int result = Senddata_DAMRMC((byte)1,RMC__START,(byte)1);
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			String str = getUpdateList(1, bool);
			return str;
		}
		else
		{
			return "unsupported function";
		}
	}
		
	
	public String sendStopSignalToRMC() {
		Log.d(TAG, "sendPlayStopRMCForFactoryMode()");
//		if (strManufacturer.equals("tjmedia") && strProduct.equals("csd"))
		if (Log.getCSD())
		{			
			int result = Senddata_DAMRMC((byte)1,RMC__STOP,(byte)1);
			boolean bool = false;
			if(result == 0) {
				bool = true;
			}
			String str = getUpdateList(2, bool);
			return str;
		}
		else
		{
			return "unsupported function";
		}		
	}
	
	public String getUpdateList(int key, boolean result) {
		String str = "";
		switch (key) {
		case 0:
			str = mSBDigit.toString() + (result == true ? " Reserved, OK"  : " Reserved, NG")  + "\n";
//			str = "INDEX[" + mListIndex + "] : "
//					+ mSBDigit.toString() + (result == true ? " Reserved, OK"  : " Reserved, NG")  + "\n";
//			mListIndex++;
			return str;
		case 1:
			str = "INDEX[" + mListIndex + "] : "
					+ (result == true ? "START, OK"  : "START, NG")  + "\n";
			mListIndex++;
			return str;
		case 2:
			str = "INDEX[" + mListIndex + "] : "
					+ (result == true ? "STOP, OK"  : "STOP, NG")  + "\n";
			mListIndex++;
			return str;
		default:
			return str;
		}
	}
	
//	BroadcastReceiver IRReceiver = new BroadcastReceiver() {
//		@Override
//		public void onReceive(Context context, Intent intent) {	
//				if (intent.getAction().equals("TMFP.RMC"))
//				{
//					byte data = intent.getByteExtra("data", (byte)0);					
//					String str;					
//					str = "recv:[";
//						str += String.format("[0x%02X]", data);						 						
//					str += "\n";					
//					Log.d(TAG, str);
//					
//					if (0 == mListIndex%50)
//					{
//						mItem.clear();
//					}
//					 
//					mItem.add(0, "INDEX[" + mListIndex + "] : "
//							+ str + "\n");
//					mAdapter.notifyDataSetChanged();
//					mListIndex++;
//					
//				}
//		}	
//	};
	
	BroadcastReceiver IRReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {	
				if (intent.getAction().equals("TMFP.RMC"))
				{
					byte [] data = new byte [100];
					byte nSize = 1;
					byte i = 0;
					//byte data = intent.getByteExtra("data", (byte)0);					
					data = intent.getByteArrayExtra("data");					
					nSize = intent.getByteExtra("leng", (byte)0);
					
					String str;					
					 str = "수신:";					 
//					 str += String.format("[0x%02X]", data);
					for (i = 0; i < nSize; i++)
					{					
						str += "[" + String.format("0x%02X", data[i]) + "]";	
					}					 
					str += "\n";					
					Log.d(TAG, str);		
					if (0 == mListIndex%50)
					{
						mItem.clear();
					}
						 
					mItem.add(0, "INDEX[" + mListIndex + "] : "
							+ str + "\n");
					mAdapter.notifyDataSetChanged();
					mListIndex++;

				}
		}	
	};	
    
}
	
	

