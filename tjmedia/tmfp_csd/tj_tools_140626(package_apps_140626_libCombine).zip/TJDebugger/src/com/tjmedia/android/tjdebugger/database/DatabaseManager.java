package com.tjmedia.android.tjdebugger.database;

import java.util.ArrayList;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.provider.MediaStore;

import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.RegexManager;
import com.tjmedia.android.tjdebugger.common.TJListItem;

public class DatabaseManager {
	private String TAG = "DatabaseManager";

	
	// Interface
	public static final int I_KidsAdd 		= 11;
	public static final int I_KidsMain 		= 12;
	public static final int I_KidsSetting 	= 13;
	public static final int I_KidsUpdate 	= 14;
	
	private Context mContext;
	private DBSQL	event;
	private Cursor  mCursor;
	
	Handler mHandler = new Handler();
//	PickerWidget mPicker;
	
	public DatabaseManager(Context context) {
		this.mContext = context;
		event = new DBSQL(context);
//		mPicker = new PickerWidget();
	}
	
	public TJListItem getAudioAlbumsInfo(Context context, String uriString) {
		String value = RegexManager.getConvertEscapeSingleQuote(uriString);
		String[] projection = null;
		String selection = null;
		String[] selectionArgs = null;
		String sortOrder = null;
		Log.d(TAG, "uriString=" + uriString);
		selection = MediaStore.Audio.Media.DATA + " like '%" + value + "'";
		Cursor cursor2 = context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
				projection, selection, selectionArgs, sortOrder);
		
		TJListItem item = null;
		ArrayList<TJListItem> Items = new ArrayList<TJListItem>();
		String _id = null;
		String album_id = null;
		if(cursor2 != null && cursor2.getCount() !=0) {
			cursor2.moveToFirst();
			Log.d(TAG, "cursor2.getCount():"+cursor2.getCount());
			while (!cursor2.isAfterLast()) {
//				_id = 	cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media._ID));
//				album_id = cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID));
//				item = new TJListItem(
//						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)),
//						cursor2.getString(0));
//				Log.d(TAG, "item = " + item.getColumns(0) + ", " +item.getColumns(1));
				item = new TJListItem(
						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media._ID)),
						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)),
						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.TITLE)),
						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.ARTIST)),
						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)),
						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.ALBUM)),
						cursor2.getString(cursor2.getColumnIndex(MediaStore.Audio.Media.BOOKMARK)));
				Log.i(TAG, "TJListItem[0] = " + item.getColumns(0) + ", " + item.getColumns(1) + ", "  
						+ item.getColumns(2) + ", "  + item.getColumns(3) + ", "  + item.getColumns(4)
						+ item.getColumns(5) + ", "  + item.getColumns(6) + ",  Name " + cursor2.getColumnName(0)
				);
				
				cursor2.moveToNext();
				break;
			}
		}
		cursor2.close();
		return item;
//		projection = new String[]{MediaStore.Audio.Albums._ID,
//				MediaStore.Audio.Albums.ALBUM_ID,
//				MediaStore.Audio.Albums.ALBUM,
//				MediaStore.Audio.Albums.ALBUM_ART,
//				MediaStore.Audio.Albums.ARTIST
//		};
//		projection = null;
//		projection = null;
//		selection = null;
//		selectionArgs = null;
//		sortOrder = null;
//		
//		selection = MediaStore.Audio.Media._ID + " = ? ";
////		selection = MediaStore.Audio.Albums.ALBUM_ID + " = ? ";
//		selectionArgs = new String[]{_id};
////		selectionArgs = new String[]{album_id};
//		Cursor cursor = context.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, 
//				null,
//				selection,
//				selectionArgs, 
//				sortOrder);
//		
//		int i=0;
//		if(cursor != null && cursor.getCount() !=0) {
//			int colCount = cursor.getColumnCount();
//			Log.d(TAG, "cursor.getCount():"+cursor.getCount() + ", colCount=" + colCount);
//			cursor.moveToFirst();
//			while (!cursor.isAfterLast()) {
//				item = new TJListItem(
//						album_id,
//						cursor.getString(0),
////						cursor.getString(1),
////						cursor.getString(2),
////						cursor.getString(3),
////						cursor.getString(4),
////						cursor.getString(5),
////						cursor.getString(6),
////						cursor.getString(7),
////						cursor.getString(9)
//						cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)),
//						cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)),
//						cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM)),
//						cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.BOOKMARK)),
//						cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME))
//						);
//				Items.add(item);
//				Log.i(TAG, "TJListItem[" + i + "] = " + item.getColumns(0) + ", " + item.getColumns(1) + ", "  
//						+ item.getColumns(2) + ", "  + item.getColumns(3) + ", "  + item.getColumns(4)
//						+ item.getColumns(5) + ", "  + item.getColumns(6) + ",  Name " + cursor.getColumnName(0)
////						+ item.getColumns(7)
////						+ item.getColumns(8) + ", "  + item.getColumns(9) + ", Name " + cursor.getColumnName(2)
//						);
//				cursor.moveToNext();
//				i++;
////				break;
//			}
//		}
//		cursor.close();
//		return item;
	}
	
//	public long insertSchedule(int I_id, ContentValues values) {
//		long rowId = -1L;
//		// query syntex
//		String[] returnColumns = null;
//		String selection = null;
//		String[] selectionArgs = null;
//		String groupBy = DBConst.P_S01_SDATE;
//		String having = null;
//		String orderBy = null;
//		
//		String sdate = (String) values.get(DBConst.P_S01_SDATE);
//		String edate = (String) values.get(DBConst.P_S01_EDATE);
//		Calendar c1 = Calendar.getInstance();
//		Calendar c2 = Calendar.getInstance();
//		c1.setTimeInMillis(Long.valueOf(sdate));
//		c2.setTimeInMillis(Long.valueOf(edate));
//		boolean nextDayFlag = mPicker.getDateFormatter(c1.getTime()).equalsIgnoreCase(mPicker.getDateFormatter(c2.getTime()));
//		
//		String pattenDays = (String) values.get(DBConst.P_S01_PATTERN_DATES);
//		Log.i(TAG, "ETC pattenDays = '" + pattenDays + "'");
//		
//		StringBuilder	sb = new StringBuilder();
//		sb.append("((" + DBConst.P_S01_STIME + " BETWEEN ? AND ?)");
//		sb.append(" AND ");
//		// defualt today/
//		if(pattenDays.contains("/")) {
//			sb.append("(");
//			String[] days = pattenDays.split("/");
//			int last = days.length-1;
//			for(int i=0; i<days.length; i++) {
//				if(i != last) {
//					sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//					sb.append(" OR ");
//				} else {
//					sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')))");
//				}
//			}
//			selectionArgs = new String[2];
////			String[] data = getBetweenData(sdate, edate);
//			selectionArgs[0] = "00:00";
//			selectionArgs[1] = "24:00";
//			selection = sb.toString();
//		}
//		
//		Log.e(TAG, "insert DB = " + sb.toString());
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1,
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		boolean result = false;
//		if(mCursor.getCount() != 0) {
//			Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//			// 금일 00:00 ~ 24:00 사이의 시간 범위에서 입력하려는 시간 데이터의 중복 체크
//			result = checkUpTimeValueInDBTime(values);
//		} else {
//			mCursor.close();
//		}
//		// 기준일 2012/01/12 이면 01/12일 데이터 목록 중복 체크한다.
//		if(!result) {
//			result = checkUpTimeValuesFromEndTimeLessthanStartTime(rowId, values, false);
//		}
//		// 기준일 2012/01/12 이면 01/13일 데이터 목록 중복 체크한다.
//		if(!result) {
//			if(!nextDayFlag)
//				result = checkUpTimeValuesFromEndTimeLessthanStartTime(rowId, values, true);
//		}
//		
//		if(!result) {
//			rowId = event.insertDB(DBConst._TABLENAME1, values);
//		}
//		mCursor.close();
//		return rowId;
//	}
//	
//	private boolean checkUpTimeValueInDBTime(ContentValues values) {
//		boolean result = false;
//		StringBuilder sb1 = new StringBuilder();
//		StringBuilder sb2 = new StringBuilder();
//		String sdate = (String) values.get(DBConst.P_S01_STIME);
//		String edate = (String) values.get(DBConst.P_S01_ETIME);
//		String[] temp1 = sdate.split(":");
//		String[] temp2 = edate.split(":");
//		for(int i=0; i<temp1.length; i++) {
//			sb1.append(temp1[i]);
//			sb2.append(temp2[i]);
//		}
//		int stime = Integer.valueOf(sb1.toString());
//		int etime = Integer.valueOf(sb2.toString());
//		if(stime > etime) {
//			etime = 2400;
//		}
//		sb1.setLength(0);
//		sb2.setLength(0);
//		
//		Serialization seri;
//		while(!mCursor.isAfterLast()) {
//			seri = new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_STIME)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETIME))
//			);
//			String[] s_split = seri.getColumns(1).split(":");
//			String[] e_split = seri.getColumns(2).split(":");
//			for(int i=0; i<s_split.length; i++) {
//				sb1.append(s_split[i]);
//				sb2.append(e_split[i]);
//			}
//			int temp_stime = Integer.valueOf(sb1.toString());
//			int temp_etime = Integer.valueOf(sb2.toString());
//			sb1.setLength(0);
//			sb2.setLength(0);
//			if(temp_stime > temp_etime) {
//				temp_etime = 2400;
//			}
//			
//			result = (temp_stime <= stime) && (stime < temp_etime);
//			if(result) {
//				break;
//			}
//			result = (temp_stime < etime) && (etime < temp_etime);
//			if(result) {
//				break;
//			}
//			result = (stime < temp_stime) && (temp_stime < etime);
//			if(result) {
//				break;
//			}
//			result = (stime < temp_etime) && (temp_etime < etime);
//			if(result) {
//				break;
//			}
//			
//			
//			mCursor.moveToNext();
//		}
//		mCursor.close();
//		return result;
//	}
//	
//	
//	/*
//	 * boolean Nextday is false 이전날, true is 다음날
//	 */
//	private boolean checkUpTimeValuesFromEndTimeLessthanStartTime(long rowId, ContentValues values, boolean Nextday) {
//		Log.i(TAG, "checkUpTimeValuesFromEndTimeLessthanStartTime");
//		boolean result = false;
//		String[] returnColumns = null;
//		String selection = null;
//		String[] selectionArgs = null;
//		String groupBy = DBConst.P_S01_SDATE;
//		String having = null;
//		String orderBy = null;
//		
//		String sdate = (String) values.get(DBConst.P_S01_SDATE);
//		String edate = (String) values.get(DBConst.P_S01_EDATE);
//		Calendar c1 = Calendar.getInstance();
//		Calendar c2 = Calendar.getInstance();
//		c1.setTimeInMillis(Long.valueOf(sdate));
//		c2.setTimeInMillis(Long.valueOf(edate));
//		boolean nextDayFlag = mPicker.getDateFormatter(c1.getTime()).equalsIgnoreCase(mPicker.getDateFormatter(c2.getTime()));
//		
//		String pattenDays = (String) values.get(DBConst.P_S01_PATTERN_DATES);
//		Log.i(TAG, "ETC pattenDays = '" + pattenDays + "'");
//		StringBuilder	sb = new StringBuilder();
//
//		if(!Nextday) {
//			pattenDays = getPriviousDay(pattenDays); 
//			Log.e(TAG, "Convert ETC PriviouspattenDays = '" + pattenDays + "'");
//			sb.append("((" + DBConst.P_S01_ID + " != ? )");
//			sb.append(" AND ");
//			sb.append("((" + DBConst.P_S01_STIME + " > " + DBConst.P_S01_ETIME + ")");
//			sb.append(" AND ");
//			// defualt today/
//			if(pattenDays.contains("/")) {
//				sb.append("(");
//				String[] days = pattenDays.split("/");
//				int last = days.length-1;
//				for(int i=0; i<days.length; i++) {
//					if(i != last) {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//						sb.append(" OR ");
//					} else {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%'))))");
//					}
//				}
//				selectionArgs = new String[1];
//				selectionArgs[0] = String.valueOf(rowId);
//				selection = sb.toString();
//			}
//		} else {
//			pattenDays = getNextDay(pattenDays); 
//			Log.e(TAG, "Convert ETC NextpattenDays = '" + pattenDays + "'");
//			sb.append("((" + DBConst.P_S01_ID + " != ? )");
//			sb.append(" AND ");
//			sb.append("(" + DBConst.P_S01_STIME + " BETWEEN ? AND ?)");
//			sb.append(" AND ");
//			// defualt today/
//			if(pattenDays.contains("/")) {
//				sb.append("(");
//				String[] days = pattenDays.split("/");
//				int last = days.length-1;
//				for(int i=0; i<days.length; i++) {
//					if(i != last) {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//						sb.append(" OR ");
//					} else {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')))");
//					}
//				}
//				selectionArgs = new String[3];
//				selectionArgs[0] = String.valueOf(rowId);
//				selectionArgs[1] = "00:00";
//				selectionArgs[2] = "24:00";
//				selection = sb.toString();
//			}
//		}
//		
//		Log.e(TAG, "query DB = " + sb.toString());
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1,
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//
//		if(mCursor.getCount() != 0) {
//			Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//			// 이전날 24시 넘는 종료시간 목록을 가져와서 데이터 중복 체크해준다.
//			if(!Nextday) {
//				result = checkUpTimeOfPreviousDay(values);
//			} else {
//				result = checkUpTimeOfNextDay(values);
//			}
//		} 
//		mCursor.close();
//		return result;
//	}
//	
//	private String getPriviousDay(String str) {
//		StringBuilder sb = new StringBuilder();
//		String[] days = str.split("/");
//		Calendar cal = Calendar.getInstance();
//		for(int i=0; i<days.length; i++) {
//			String[] arr = days[i].split("-");
//			int year = Integer.valueOf(arr[0]);
//			int month = Integer.valueOf((arr[1]))-1;
//			int dayOfMonth = Integer.valueOf(arr[2]);
//			cal.set(year, month, dayOfMonth, 0, 0, 0);
//			cal.add(Calendar.DAY_OF_MONTH, -1);
//			sb.append(mPicker.getDateFormatter(cal.getTime())+"/");
//		}
//		return sb.toString();
//	}
//	
//	private String getNextDay(String str) {
//		StringBuilder sb = new StringBuilder();
//		String[] days = str.split("/");
//		Calendar cal = Calendar.getInstance();
//		for(int i=0; i<days.length; i++) {
//			String[] arr = days[i].split("-");
//			int year = Integer.valueOf(arr[0]);
//			int month = Integer.valueOf((arr[1]))-1;
//			int dayOfMonth = Integer.valueOf(arr[2]);
//			cal.set(year, month, dayOfMonth, 0, 0, 0);
//			cal.add(Calendar.DAY_OF_MONTH, 1);
//			sb.append(mPicker.getDateFormatter(cal.getTime())+"/");
//		}
//		return sb.toString();
//	}
//	
//	private boolean checkUpTimeOfPreviousDay(ContentValues values) {
//		Log.d(TAG, "checkUpTimeOfPreviousDay");
//		boolean result = false;
//		StringBuilder sb1 = new StringBuilder();
//		StringBuilder sb2 = new StringBuilder();
//		String sdate = (String) values.get(DBConst.P_S01_STIME);
//		String edate = (String) values.get(DBConst.P_S01_ETIME);
//		String[] temp1 = sdate.split(":");
//		String[] temp2 = edate.split(":");
//		for(int i=0; i<temp1.length; i++) {
//			sb1.append(temp1[i]);
//			sb2.append(temp2[i]);
//		}
//		int stime = Integer.valueOf(sb1.toString());
//		int etime = Integer.valueOf(sb2.toString());
//		if(stime > etime) {
//			etime = 2400;
//		}
//		sb1.setLength(0);
//		sb2.setLength(0);
//		
//		
//		Serialization seri;
//		while(!mCursor.isAfterLast()) {
//			seri = new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_STIME)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETIME))
//			);
//			String[] s_split = seri.getColumns(1).split(":");
//			String[] e_split = seri.getColumns(2).split(":");
//			for(int i=0; i<s_split.length; i++) {
//				sb1.append(s_split[i]);
//				sb2.append(e_split[i]);
//			}
//			int temp_stime = 0000;
//			int temp_etime = Integer.valueOf(sb2.toString());
//			sb1.setLength(0);
//			sb2.setLength(0);
//			
//			result = (temp_stime <= stime) && (stime < temp_etime);
//			if(result) {
//				break;
//			}
//			result = (temp_stime < etime) && (etime < temp_etime);
//			if(result) {
//				break;
//			}
//			result = (stime < temp_stime) && (temp_stime < etime);
//			if(result) {
//				break;
//			}
//			result = (stime < temp_etime) && (temp_etime < etime);
//			if(result) {
//				break;
//			}
//			mCursor.moveToNext();
//		}
//		mCursor.close();
//		return result;
//	}
//	
//	private boolean checkUpTimeOfNextDay(ContentValues values) {
//		Log.d(TAG, "checkUpTimeOfNextDay");
//		boolean result = false;
//		StringBuilder sb1 = new StringBuilder();
//		StringBuilder sb2 = new StringBuilder();
//		String sdate = (String) values.get(DBConst.P_S01_STIME);
//		String edate = (String) values.get(DBConst.P_S01_ETIME);
//		String[] temp1 = sdate.split(":");
//		String[] temp2 = edate.split(":");
//		for(int i=0; i<temp1.length; i++) {
//			sb1.append(temp1[i]);
//			sb2.append(temp2[i]);
//		}
//		int stime = Integer.valueOf(sb1.toString());
//		int etime = Integer.valueOf(sb2.toString());
//		if(stime > etime) {
//			stime = 0000;
//		}
//		sb1.setLength(0);
//		sb2.setLength(0);
//		
//		
//		Serialization seri;
//		while(!mCursor.isAfterLast()) {
//			seri = new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_STIME)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETIME))
//					);
//			String[] s_split = seri.getColumns(1).split(":");
//			String[] e_split = seri.getColumns(2).split(":");
//			for(int i=0; i<s_split.length; i++) {
//				sb1.append(s_split[i]);
//				sb2.append(e_split[i]);
//			}
//			int temp_stime = Integer.valueOf(sb1.toString());
//			int temp_etime = Integer.valueOf(sb2.toString());
//			if(temp_stime > temp_etime) {
//				temp_etime = 2400;
//			}
//			sb1.setLength(0);
//			sb2.setLength(0);
//			
//			result = (temp_stime <= stime) && (stime < temp_etime);
//			if(result) {
//				break;
//			}
//			result = (temp_stime < etime) && (etime < temp_etime);
//			if(result) {
//				break;
//			}
//			result = (stime < temp_stime) && (temp_stime < etime);
//			if(result) {
//				break;
//			}
//			result = (stime < temp_etime) && (temp_etime < etime);
//			if(result) {
//				break;
//			}
//			mCursor.moveToNext();
//		}
//		mCursor.close();
//		return result;
//	}
//	
//	
//	public String[] getBetweenData(String sdate, String edate) {
//		String[] data = new String[2];
//		Calendar c1 = Calendar.getInstance();
//		Calendar c2 = Calendar.getInstance();
//		c1.setTimeInMillis(Long.valueOf(sdate));	
//		c2.setTimeInMillis(Long.valueOf(edate));
//		
//		c1.add(Calendar.MINUTE, 1);
//		c2.add(Calendar.MINUTE, -1);
//		
//		String temp_start = "";
//		String temp_end = "";
//		Date start = c1.getTime();
//		Date end = c2.getTime();
//		
//		temp_start = mPicker.getTimeFormatter(start);
//		temp_end = mPicker.getTimeFormatter(end);
////		if(!mPicker.getDateFormatter(start).equalsIgnoreCase(mPicker.getDateFormatter(end))) {
////			temp_start = mPicker.getTimeFormatter(start);
////			temp_end = mPicker.getTimeFormatter(1, end);
////			Log.e(TAG, "true");
////		} else {
////			temp_start = mPicker.getTimeFormatter(start);
////			temp_end = mPicker.getTimeFormatter(0, end);
////			Log.e(TAG, "false");
////		}
//		Log.e(TAG, "temp start = " + temp_start + ", temp_end = " + temp_end);
//		data[0] = temp_start;
//		data[1] = temp_end;
//		return data;
//	}
//
//	public Serialization[] qureyEventInDB(long stime) {
//		Serialization[] seri = null;
//		/*
//		 * 마지막 종료시간 보다 작은 시간의 범위를 체크하기 위한 설정.
//		 */
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(stime);
//		String sdate = mPicker.getDateFormatter(c.getTime());
//		
//		String[] returnColumns = null;
//		String selection = null;
//		
//		String[] selectionArgs = null;
//		String groupBy = null;
//		String having = null;
//		String orderBy = DBConst.P_S01_STIME;
//		
//		selection = "(" 
//			+ DBConst.P_S01_PATTERN_DATES + " like '%" + sdate + "%') OR " +
//			"(" + DBConst.P_S01_ETC + " like '%" + sdate + "%')"+";"; 
//
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1, 
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		if(mCursor.getCount() != 0) {
//			seri = new Serialization[mCursor.getCount()];
//		} else {
//			mCursor.close();
//		}
//		int i =0;
//		while(!mCursor.isAfterLast()) {
//			seri[i] = new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_TITLE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ALARM_MILLIS)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_SDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_COLOR)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_FLAG)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_NM)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_CONTACT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_MEMO)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_PATTERN_DATES)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_STIME)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETIME)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETC))
//			);
//			Log.d(TAG, "seri[" + i + "] = " + seri[i].getColumns(0) + ", " + seri[i].getColumns(1) + ", ");
//			i++;
//			mCursor.moveToNext();
//		}
//		mCursor.close();
//		return seri;
//	}
//	
//	public String getToFindCloseToDate(long time, String action) {
//		/*
//		 * long time : time is Left or Right
//		 * String action : action is "Left" or "Right" 
//		 * 
//		 * ex)
//		 * Left : 2011-11-15 / 00:00
//		 * today : 2011-11-16 / 00:00
//		 * Right : 2011-11-17 / 00:00
//		 */
//		String date = null;		// return values, If date is NULL, It couldn't find to close to any date
//		final long oneDay = 1000*60*60*24;
//		
//		Calendar pivot = Calendar.getInstance();
//		pivot.setTimeInMillis(time);
//		int year = pivot.get(Calendar.YEAR);
//		int month = pivot.get(Calendar.MONTH);
//		int day = pivot.get(Calendar.DAY_OF_MONTH);
//		pivot.set(year, month, day, 0, 0, 0);
//		
//		Serialization[] result;
//		if("Left".equalsIgnoreCase(action)) {
//			for(int i=0; i<7; i++) {
//				pivot.add(Calendar.DAY_OF_MONTH, -1);
//				result = qureyEventInDB(pivot.getTimeInMillis());
//				if(result != null) {
//					return date = mPicker.getDateFormatter(pivot.getTime());
//				}
//			}
//		} else {
//			for(int i=0; i<7; i++) {
//				result = qureyEventInDB(pivot.getTimeInMillis());
//				if(result != null) {
//					return date = mPicker.getDateFormatter(pivot.getTime());
//				}
//				pivot.add(Calendar.DAY_OF_MONTH, +1);
//			}
//		}
//		Log.i(TAG, "7일 이내 데이터 체크 없음");
//		mCursor.close();
//		////////////////////////////////////////////////////////////////////////
//		// New Query
//		String[] returnColumns = null;
//		String selection = null;
//		String[] selectionArgs = null;
//		String groupBy = null;
//		String having = null;
//		String orderBy = null;
//		
//		Calendar log3 = Calendar.getInstance();
//		log3.setTimeInMillis(time);
//		Log.e(TAG, "기준일 = " + mPicker.getDateFormatter(log3.getTime()));
//		
//		if("Left".equalsIgnoreCase(action)) {
//			String sql = "SELECT *"
//						+ " FROM " + DBConst._TABLENAME1 + " "
//						+ " WHERE "+ DBConst.P_S01_REPEAT_EDATE + " < " + String.valueOf(time) + " "
//						+ " ORDER BY "+ DBConst.P_S01_REPEAT_EDATE +" DESC";
//			mCursor = event.getRawQuery(sql);
//		} else {
//			String sql = "SELECT *"
//					+ " FROM " + DBConst._TABLENAME1
//					+ " WHERE "+ DBConst.P_S01_SDATE + " > " + String.valueOf(time)
//					+ " ORDER BY "+ DBConst.P_S01_SDATE +" ASC";
//			mCursor = event.getRawQuery(sql);
//		}
//		
//		long last_day = 0L;
//		if(mCursor.getCount() != 0) {
//			try {
//				last_day = Long.valueOf(mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT_EDATE)));
//			} catch (Exception e) {
//				// TODO: handle exception
//				e.printStackTrace();
//				mCursor.close();
//				date = null;
//				return date;
//			}
//			
//			long PivotDay = 0L;
//			// 마지막 일자부터 1주일 간의 데이터를 가져와서 가장 가까운 최근 일자를 돌려준다.
//			if("Left".equalsIgnoreCase(action)) {
//				selection = "(" + DBConst.P_S01_REPEAT_EDATE + " Between ? AND ?);"; 
//				selectionArgs = new String[2];
//				// 기준일로 1주일 이전 일자의 범위를 설정
//				Calendar c1 = Calendar.getInstance();
//				c1.setTimeInMillis(last_day);
//				c1.add(Calendar.DAY_OF_MONTH, -7);
//				selectionArgs[0] = String.valueOf(c1.getTimeInMillis());
//				selectionArgs[1] = String.valueOf(last_day+oneDay);
//				mCursor.close();
//				mCursor = event.getFullTableScan(DBConst._TABLENAME1, 
//						returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//			} else {
////				String sql = "SELECT *"
////						+ " FROM " + DBConst._TABLENAME1
////						+ " WHERE " + DBConst.P_S01_SDATE + " > " + String.valueOf(time)
////						+ " ORDER BY " + DBConst.P_S01_SDATE;
////				Calendar log = Calendar.getInstance();
////				log.setTimeInMillis(time);
////				Log.e(TAG, "log = " + mPicker.getDateFormatter(log.getTime()));
////				mCursor.close();
////				mCursor = event.getRawQuery(sql);
//				PivotDay = last_day;
//			}
//			
//			Log.e(TAG, "mCursor.count = " + mCursor.getCount());
//			
//			Calendar c1 = Calendar.getInstance();
//			Calendar c2 = Calendar.getInstance();
//			Calendar ctemp = Calendar.getInstance();
//			while(!mCursor.isAfterLast()) {
//				long sdate = Long.valueOf(mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_SDATE)));
//				long edate = Long.valueOf(mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_EDATE)));
//				long repeat_edate = Long.valueOf(mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT_EDATE)));
//				int repeat = Integer.valueOf(mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT)));
//				
//				c1.setTimeInMillis(Long.valueOf(sdate));
//				c2.setTimeInMillis(Long.valueOf(edate));
//				boolean nextDayFlag = mPicker.getDateFormatter(c1.getTime()).equalsIgnoreCase(mPicker.getDateFormatter(c2.getTime()));
//			
//				if("Left".equalsIgnoreCase(action)) {
//					int count = getLastValueOfRepeat(repeat_edate, repeat);
//					// 반복 설정이 없는 날과 매일 반복설정의 플래그를 구분해주기 위해 체크
//					long temp = 0L;
//					if(254==count) {
//						temp = Long.valueOf(repeat_edate);
//					} else {
//						temp = Long.valueOf(repeat_edate);
//						Log.d(TAG, "count = " + count);
//						temp = temp - (oneDay*count);
//					}
//					
//					if(!nextDayFlag) {
//						temp = temp + oneDay;
//					}
//					
//					if(PivotDay < temp) {
//						PivotDay = temp;
//						ctemp.setTimeInMillis(PivotDay);
//						date = mPicker.getDateFormatter(ctemp.getTime());
//						Log.e(TAG, "Left PivotDay date = " + date);
//					} else {
////						Log.e(TAG, "F");
//					}
//				} else {
//					int count = getFirstValueOfRepeat(sdate, repeat);
//					
//					// 반복 설정이 없는 날과 매일 반복설정의 플래그를 구분해주기 위해 체크
//					long temp = 0L;
//					if(254==count) {
//						temp = Long.valueOf(sdate);
//					} else {
//						temp = Long.valueOf(sdate);
//						temp = temp + (oneDay*count);
//					}
////					if(PivotDay == 0) {
////						PivotDay = temp;
////						ctemp.setTimeInMillis(temp);
////						date = mPicker.getDateFormatter(ctemp.getTime());
////					}
//					if(PivotDay > temp) {
//						Log.e(TAG, "T");
//						PivotDay = temp;
//						ctemp.setTimeInMillis(PivotDay);
//						date = mPicker.getDateFormatter(ctemp.getTime());
//						Log.e(TAG, "Right PivotDay date = " + date);
//					} else {
////						Log.e(TAG, "F");
//					}
//				}
//				mCursor.moveToNext();
//			}
//		} else {
//			date = null;
//		}
//		mCursor.close();
//		return date;
//	}
//	
//	public int getFirstValueOfRepeat(long start, int repeat) {
//		int arr = 0;
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(start);
//		int var1 = repeat;
//		int day_of_week = c.get(Calendar.DAY_OF_WEEK);
//		if(((int)Math.pow(2, day_of_week) & repeat) != 0) {
//			return arr = 254;
//		}
//		
//		int var2 = 0;
//		int result = 0;
//		int count = 1;
//		for (int i = 0; i < 7; i++) {
//			if (day_of_week >= 7) {
//				day_of_week = 1;
//			} else {
//				day_of_week++;
//			}
//			System.out.println("day = " + day_of_week);
//			var2 = (int) Math.pow(2, day_of_week);
//			result = var1 & var2;
//			if (result != 0) {
//				return count;
//			}
//			count++;
//		}
//		return arr;
//	}
//	
//	public int getLastValueOfRepeat(long start, int repeat) {
//		int arr = 0;
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(start);
//		int var1 = repeat;
//		int day_of_week = c.get(Calendar.DAY_OF_WEEK);
//		if(((int)Math.pow(2, day_of_week) & repeat) != 0) {
//			return arr = 254;
//		}
//		System.out.println("day = " + day_of_week);
//		int var2 = 0;
//		int result = 0;
//		int count = 1;
//		for (int i = 1; i <= 7; i++) {
//			if (day_of_week <= 1) {
//				day_of_week = 7;
//			} else {
//				day_of_week--;
//			}
//			System.out.println("day = " + day_of_week);
//			var2 = (int) Math.pow(2, day_of_week);
//			result = var1 & var2;
//			if (result != 0) {
//				System.out.print("result = " + result + ", ");
//				System.out.println("count = " + count + ", ");
//				return count;
//			}
//			count++;
//		}
//		return arr;
//	}
//	
//	// Set Up Alarm By rowId
//	public Serialization queryDBByRowId(long rowId, long time) {
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(time);
//		String date = mPicker.getDateFormatter(c.getTime());
//		String[] returnColumns = null;
//		
//		String selection = "(" + DBConst.P_S01_ID + " = ? and "
//			+ DBConst.P_S01_PATTERN_DATES + " like '%" + date +"%');";
//		String[] selectionArgs = new String[1]; 
//		selectionArgs[0] = String.valueOf(rowId);
//		String groupBy = null;
//		String having = null;
//		String orderBy = null;
//		
//		mCursor = event.getCDInfoAll(DBConst._TABLENAME1, 
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		Serialization seri = null;
//		if(mCursor.getCount() != 0) {
//			Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//		}
//		while(!mCursor.isAfterLast()) {
//			seri = new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_TITLE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ALARM_MILLIS)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_SDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_COLOR)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_FLAG)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_NM)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_CONTACT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_MEMO)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_PATTERN_DATES)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETC))
//			);
//			Log.d(TAG, "seri = " + seri.getColumns(0) + ", " + seri.getColumns(1) + ", "
//					+ seri.getColumns(2) + ", " + seri.getColumns(3) + ", "
//					+ seri.getColumns(4) + ", " + seri.getColumns(5) + ", ");
//			mCursor.moveToNext();
//		}
//		mCursor.close();
//		return seri;
//	}
//	
//	public Serialization queryDBByRowId(long rowId) {
//		String[] returnColumns = null;
//		String selection = DBConst.P_S01_ID + " = ?";
//		String[] selectionArgs = new String[1]; 
//		selectionArgs[0] = String.valueOf(rowId);
//		String groupBy = null;
//		String having = null;
//		String orderBy = null;
//		
//		mCursor = event.getCDInfoAll(DBConst._TABLENAME1, 
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		Serialization seri = null;
//		if(mCursor.getCount() != 0) {
//			Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//		}
//		while(!mCursor.isAfterLast()) {
//			seri = new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_TITLE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_SDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_COLOR)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_FLAG)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_NM)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_CONTACT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_MEMO)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_PATTERN_DATES)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ALARM_MILLIS)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETC))
//			);
//			Log.d(TAG, "seri = " + seri.getColumns(0) + ", " + seri.getColumns(1) + ", "
//					+ seri.getColumns(2) + ", " + seri.getColumns(3) + ", "
//					+ seri.getColumns(4) + ", " + seri.getColumns(5) + ", ");
//			mCursor.moveToNext();
//		}
//		mCursor.close();
//		return seri;
//	}
//	
//	public Boolean checkupWeekBeing(long time, String action) {
//		// New Query
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(time);
//		
//		mCursor = event.getCheckUpWeekBeing(time, action);
//		
//		Boolean weekBeing = false;
//		
//		if(mCursor.getCount() != 0) {
//			weekBeing = true;
//			Log.e(TAG, "mCursor.count() = " + mCursor.getCount());
//		}else{
//			weekBeing = false;
//			Log.e(TAG, "mCursor.count() = " + 0);
//		}
//
//		mCursor.close();
//		return weekBeing;
//	}
//	
//	/*
//	 * Sample Libraries
//	 */
//	public int[] getRepeatArray(Long start, int repeat) {
//		int[] arr = null;
//		Vector<Integer> v = new Vector<Integer>();
//		Enumeration<Integer> eum;
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(start);
//		int var1 = repeat;
//		int day_of_week = c.get(Calendar.DAY_OF_WEEK);
//		int var2 = 0;
//		int result = 0;
//		int count = 1;
//		for(int i=0; i<7; i++) {
//			if(day_of_week >= 7) {
//				day_of_week = 1;
//			} else {
//				day_of_week++;
//			}
//			System.out.println("day = " + day_of_week);
//			var2 = (int) Math.pow(2, day_of_week);
//			result = var1 & var2;
//			if(result != 0) {
////				System.out.print("result = " + result + ", ");
////				System.out.println("check day repeat = " + day_of_week);
//				System.out.print("count = " + count + ", ");
//				v.add(count);
//			}
//			count++;
//		}
//		if(!v.isEmpty()) {
//			eum = v.elements();
//			arr = new int[v.size()];
//			int i=0;
//			while (eum.hasMoreElements()) {
//				Integer element = (Integer) eum.nextElement();
//				arr[i] = element;
//				System.out.println("arr[" + i +"] = " + arr[i]);
//				i++;
//			}
//		}
//		return arr;
//	}
//	
//	public boolean updateSchedule(int key, long rowId, ContentValues values) {
//		Log.d(TAG, "updateSchedule = " + rowId);
//		boolean updateResult = false;
//		boolean result = false;
//		switch (key) {
//		case I_KidsUpdate:
//			// query syntex
//			String[] returnColumns = null;
//			String selection = null;
//			String[] selectionArgs = null;
//			String groupBy = DBConst.P_S01_SDATE;
//			String having = null;
//			String orderBy = null;
//			
//			String _id = String.valueOf(rowId);
//			
//			String sdate = (String) values.get(DBConst.P_S01_SDATE);
//			String edate = (String) values.get(DBConst.P_S01_EDATE);
//			String stime = (String) values.get(DBConst.P_S01_STIME);
//			String etime = (String) values.get(DBConst.P_S01_ETIME);
//			Calendar c1 = Calendar.getInstance();
//			Calendar c2 = Calendar.getInstance();
//			c1.setTimeInMillis(Long.valueOf(sdate));
//			c2.setTimeInMillis(Long.valueOf(edate));
//			
//			String pattenDays = (String) values.get(DBConst.P_S01_PATTERN_DATES);
//			Log.e(TAG, "ETC pattenDays = '" + pattenDays + "'");
////				String pattenDays = "2011-11-15/2011-11-17/2011-11-23/2011-11-25/";
//			boolean nextDayFlag = mPicker.getDateFormatter(c1.getTime()).equalsIgnoreCase(mPicker.getDateFormatter(c2.getTime()));
//			
//			StringBuilder	sb = new StringBuilder();
//			sb.append("((" + DBConst.P_S01_ID + " != ? )");
//			sb.append(" AND ");
//			sb.append("(" + DBConst.P_S01_STIME + " BETWEEN ? AND ?)");
//			sb.append(" AND ");
//			// defualt today/
//			if(pattenDays.contains("/")) {
//				sb.append("(");
//				String[] days = pattenDays.split("/");
//				int last = days.length-1;
//				for(int i=0; i<days.length; i++) {
//					if(i != last) {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//						sb.append(" OR ");
//					} else {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')))");
//					}
//				}
//				selectionArgs = new String[3];
//				String[] data = getBetweenData(sdate, edate);
//				selectionArgs[0] = _id;
//				selectionArgs[1] = "00:00";
//				selectionArgs[2] = "24:00";
//				selection = sb.toString();
//			}
//			
//			Log.e(TAG, "update DB = " + sb.toString());
////			for(int i=0; i<selectionArgs.length; i++) {
////				Log.i(TAG, selectionArgs[i] + "/");
////			}
//			mCursor.close();
//			mCursor = event.getFullTableScan(DBConst._TABLENAME1,
//					returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//			
//			if(mCursor.getCount() != 0) {
//				Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//				// 금일 00:00 ~ 24:00 사이의 시간 범위에서 입력하려는 시간 데이터의 중복 체크
//				result = checkUpTimeValueInDBTime(values);
//			} else {
//				mCursor.close();
//			}
//			// 기준일 2012/01/12 이면 01/12일 데이터 목록 중복 체크한다.
//			if(!result) {
//				result = checkUpTimeValuesFromEndTimeLessthanStartTime(rowId, values, false);
//			}
//			
//			// 기준일 2012/01/12 이면 01/13일 데이터 목록 중복 체크한다.
//			if(!result) {
//				if(!nextDayFlag)
//					result = checkUpTimeValuesFromEndTimeLessthanStartTime(rowId, values, true);
//			}
//			
//			if(!result) {
//				updateResult = event.updateDBByID(DBConst._TABLENAME1, rowId, values);
//			}
//		}
//		mCursor.close();
//		return updateResult;
//	}
//	
//	public Serialization getReadEvent(long id) {
//		Serialization object = null; 
//		mCursor = event.getDBInfoID(DBConst._TABLENAME1, id);
//		mCursor.moveToFirst();
//		if(mCursor.getCount() > 0){
//			object =  new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_TITLE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_SDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_EDATE)),
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_STIME)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETIME)),
////					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_STIME_M)),
////					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETIME_M)),
//					
//					
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_COLOR)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_FLAG)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst .P_S01_REPEAT_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_REPEAT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_NM)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_CONTACT)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_MEMO)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_PATTERN_DATES)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETC))
//			);
//		}
//		mCursor.close();
//		return object;
//	}
//	
//	public Serialization getInfoForSMS(long id) {
//		Serialization object = null; 
//		mCursor = event.getDBInfoID(DBConst._TABLENAME1, id);
//		mCursor.moveToFirst();
//		if(mCursor.getCount() > 0){
//			object =  new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_TITLE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_SDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_NM)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_CONTACT))
//			);
//			Log.d(TAG, "SMS contact " + mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_CONTACT)));
//		}
//		mCursor.close();
//		return object;
//	}
//	
//	public Serialization[] qureyListEventInDB(long stime) {
//		Serialization[] seri = null;
//		/*
//		 * 마지막 종료시간 보다 작은 시간의 범위를 체크하기 위한 설정.
//		 */
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(stime);
//		String sdate = mPicker.getDateFormatter(c.getTime());
//		
//		String[] returnColumns = null;
//		String selection = null;
//		
//		String[] selectionArgs = null;
//		String groupBy = null;
//		String having = null;
//		String orderBy = DBConst.P_S01_STIME;
//		
//		selection = "(" + DBConst.P_S01_PATTERN_DATES + " like '%" + sdate + "%') OR " +
//		"(" + DBConst.P_S01_ETC + " like '%" + sdate + "%')"+";"; 
//			
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1, 
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		if(mCursor.getCount() != 0) {
//			seri = new Serialization[mCursor.getCount()];
//		}
//		int i = 0;
//		while(!mCursor.isAfterLast()) {
//			seri[i] = new Serialization(
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ID)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_TITLE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_SDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_EDATE)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_COLOR)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_FLAG)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_STIME)),
//					mCursor.getString(mCursor.getColumnIndex(DBConst.P_S01_ETIME))
//					
//			);
//			Log.d(TAG, "seri[" + i + "] = " + seri[i].getColumns(0) + ", " + seri[i].getColumns(1) + ", "
//					+ seri[i].getColumns(2) + ", " + seri[i].getColumns(3) + ", "
//					+ seri[i].getColumns(4) + ", " + seri[i].getColumns(5) + ", ");
//			i++;
//			mCursor.moveToNext();
//		}
//		mCursor.close();
//		//전날 검색
//		return seri;
//	}
//	
//	public boolean deleteSchedule(long id) {
//		// New Query
//		Boolean result = false;
//		result = event.deleteDBByID(DBConst._TABLENAME1, id);
//
//		mCursor.close();
//		return result;
//	}
//	
//	public boolean isEmptySchedule() {
//		// New Query
//		Boolean result = false;
//		mCursor = event.beingBTCDB(DBConst._TABLENAME1);
//		
//		if(mCursor!=null && mCursor.getCount() != 0){
//			result = false;
//		}else{
//			result = true;
//		}
//		mCursor.close();
//		return result;
//	}
//	
//	public boolean isEmptyForTuple(long rowId) {
//		boolean result = false;
//		String[] returnColumns = null;
//		String selection = DBConst.P_S01_ID + " = ?";
//		String[] selectionArgs = new String[1]; 
//		selectionArgs[0] = String.valueOf(rowId);
//		String groupBy = null;
//		String having = null;
//		String orderBy = null;
//		
//		mCursor = event.getCDInfoAll(DBConst._TABLENAME1, 
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		if(mCursor.getCount() != 0) {
//			Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//			result = true;
//		}
//		mCursor.close();
//		return result;
//	}
//	
//	
//	public int qureyIsOverlapEventInDB(long stime, String id) {
//		
//		int pastdayOverLap = 0; 	//어제시작 겹치는 날 일정
//		int thisdayOverLap = 0;		//오늘시작 겹치는 날 일정
//		
//		Calendar c = Calendar.getInstance();
//		c.setTimeInMillis(stime);
//		String sdate = mPicker.getDateFormatter(c.getTime());
//		
//		String[] returnColumns = null;
//		String selection = null;
//		
//		String[] selectionArgs = null;
//		String groupBy = null;
//		String having = null;
//		String orderBy = DBConst.P_S01_STIME;
//		
//		selection = "(" + DBConst.P_S01_ID + " = " + id + ") AND " +
//					"(" + DBConst.P_S01_PATTERN_DATES + " like '%" + sdate + "%') AND " +
//					"(" + DBConst.P_S01_STIME + " >= " + DBConst.P_S01_ETIME + ");"; 
//			
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1, 
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		if(mCursor.getCount() != 0) {
//			thisdayOverLap = 2;
//		}
//	
//		c.add(Calendar.DAY_OF_MONTH, -1);
//		String sdatePast = mPicker.getDateFormatter(c.getTime());
//		
//		mCursor.close();
//		
//		selection =
//			"(" + DBConst.P_S01_ID + " = " + id + ") AND " +
//			"(" + DBConst.P_S01_PATTERN_DATES + " like '%" + sdatePast + "%') AND " +
//			"(" + DBConst.P_S01_STIME + " >= " + DBConst.P_S01_ETIME +");"; 
//		
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1, 
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);	
//		
//		if(mCursor.getCount() != 0) {
//			pastdayOverLap = 1;
//		}	
//		
//		mCursor.close();
//		return (pastdayOverLap + thisdayOverLap);
//	}
//	
//	/*
//	 * **************************************************************************************************
//	 * Test Case
//	 * **************************************************************************************************
//	 */
//	private boolean checkOverNextDay(long rowId, ContentValues values) {
//		// query syntex
//		String[] returnColumns = null;
//		String selection = null;
//		String[] selectionArgs = null;
//		String groupBy = DBConst.P_S01_SDATE;
//		String having = null;
//		String orderBy = null;
//		
//		String sdate = (String) values.get(DBConst.P_S01_SDATE);
//		String edate = (String) values.get(DBConst.P_S01_EDATE);
//		
//		String stime = (String) values.get(DBConst.P_S01_STIME);
//		String etime = (String) values.get(DBConst.P_S01_ETIME);
//		Calendar c1 = Calendar.getInstance();
//		Calendar c2 = Calendar.getInstance();
//		c1.setTimeInMillis(Long.valueOf(sdate));
//		c2.setTimeInMillis(Long.valueOf(edate));
//		String pattenDays = (String) values.get(DBConst.P_S01_PATTERN_DATES);
//		Log.i(TAG, "pattenDays = '" + pattenDays + "'");
//		
//		boolean nextDayFlag = mPicker.getDateFormatter(c1.getTime()).equalsIgnoreCase(mPicker.getDateFormatter(c2.getTime()));
//		
//		StringBuilder	sb = new StringBuilder();
//		if("-1".equalsIgnoreCase(String.valueOf(rowId))) {
//			sb.append("(((" + DBConst.P_S01_ETIME + " BETWEEN ? AND ? )");
//			sb.append(" AND (");
//			sb.append("" + DBConst.P_S01_STIME + " > " + DBConst.P_S01_ETIME);
//			sb.append("))");
//			if(!nextDayFlag) {
//				selectionArgs = new String[2];
//				String[] data = getBetweenData(sdate, edate);
//				selectionArgs[0] = "00:00";
//				selectionArgs[1] = data[1];	// end time (ex 11:00 -> 10:49) if same day with start, not
//			} else {
//				selectionArgs = new String[2];
//				String[] data = getBetweenData(sdate, edate);
//				selectionArgs[0] = data[0];
//				selectionArgs[1] = data[1];	// end time (ex 11:00 -> 10:49) if same day with start, not
//			}
//		} else {
//			sb.append("" + DBConst.P_S01_ID + " != ? ");
//			sb.append(" AND ");
//			sb.append("(((" + DBConst.P_S01_ETIME + " BETWEEN ? AND ? )");
//			sb.append(" AND (");
//			sb.append("" + DBConst.P_S01_STIME + " > " + DBConst.P_S01_ETIME);
//			sb.append("))");
//			if(!nextDayFlag) {
//				selectionArgs = new String[3];
//				selectionArgs[0] = String.valueOf(rowId);
//				String[] data = getBetweenData(sdate, edate);
//				selectionArgs[1] = "00:00";
//				selectionArgs[2] = data[1];	// end time (ex 11:00 -> 10:49) if same day with start, not
//			} else {
//				selectionArgs = new String[3];
//				selectionArgs[0] = String.valueOf(rowId);
//				String[] data = getBetweenData(sdate, edate);
//				selectionArgs[1] = data[0];
//				selectionArgs[2] = data[1];	// end time (ex 11:00 -> 10:49) if same day with start, not
//			}
//		}
//		
//		// defualt today/
//		if(pattenDays.contains("/")) {
//			sb.append(" AND (");
//			String[] days = pattenDays.split("/");
//			int last = days.length-1;
//			for(int i=0; i<days.length; i++) {
//				if(i != last) {
//					sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//					sb.append(" OR ");
//				} else {
//					sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//					sb.append("))");
//				}
//			}
//			selection = sb.toString();
//		}
//		Log.e(TAG, "ETC insert DB = " + sb.toString());
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1,
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		if(mCursor.getCount() != 0) {
//			Log.d(TAG, "ETC mCursor.getCount() = " + mCursor.getCount());
//			return true;
//		}
//		return false;
//	}
//	
//	
//	public long insertScheduleBackUp2(int I_id, ContentValues values) {
//		long rowId = -1L;
//		// query syntex
//		String[] returnColumns = null;
//		String selection = null;
//		String[] selectionArgs = null;
//		String groupBy = DBConst.P_S01_SDATE;
//		String having = null;
//		String orderBy = null;
//		
//		String sdate = (String) values.get(DBConst.P_S01_SDATE);
//		String edate = (String) values.get(DBConst.P_S01_EDATE);
//		
//		String stime = (String) values.get(DBConst.P_S01_STIME);
//		String etime = (String) values.get(DBConst.P_S01_ETIME);
//		Calendar c1 = Calendar.getInstance();
//		Calendar c2 = Calendar.getInstance();
//		c1.setTimeInMillis(Long.valueOf(sdate));
//		c2.setTimeInMillis(Long.valueOf(edate));
//		String pattenDays = (String) values.get(DBConst.P_S01_PATTERN_DATES);
//		Log.i(TAG, "pattenDays = '" + pattenDays + "'");
//		
//		boolean nextDayFlag = mPicker.getDateFormatter(c1.getTime()).equalsIgnoreCase(mPicker.getDateFormatter(c2.getTime()));
//		
//		StringBuilder	sb = new StringBuilder();
//		sb.append("(((" + DBConst.P_S01_STIME + " BETWEEN ? AND ? )");
//		sb.append(" OR (");
//		sb.append("" + DBConst.P_S01_ETIME + " BETWEEN ? AND ? )");
//		if(!nextDayFlag) {
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " BETWEEN ? AND ?)");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_ETIME + " BETWEEN ? AND ?)");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_ETIME + " BETWEEN ? AND ?))");
//			
//			selectionArgs = new String[8];
//			String[] data = getBetweenData(sdate, edate);
//			selectionArgs[0] = data[0];
//			selectionArgs[1] = "24:00"; 
//			selectionArgs[2] = data[0];
//			selectionArgs[3] = "24:00";
////			selectionArgs[1] = data[1];	// end time (ex 11:00 -> 10:49) if same day with start, not 
////			selectionArgs[2] = data[0];	// start time (ex 10:00 -> 10:01)
//		
//			selectionArgs[4] = "00:00";
//			selectionArgs[5] = data[1];
//			
//			selectionArgs[6] = "00:00";
//			selectionArgs[7] = data[1];
//		} else {
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " < ? AND ? < " + DBConst.P_S01_ETIME +" )");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " < ? AND ? < " + DBConst.P_S01_ETIME +" )");
//			sb.append(")");
//			selectionArgs = new String[8];
//			String[] data = getBetweenData(sdate, edate);
//			selectionArgs[0] = stime;
//			selectionArgs[1] = data[1];	// end time (ex 11:00 -> 10:49) if same day with start, not 
//			selectionArgs[2] = data[0];	// start time (ex 10:00 -> 10:01)
//			selectionArgs[3] = etime;
//			
//			selectionArgs[4] = stime;
//			selectionArgs[5] = stime;
//			selectionArgs[6] = etime;
//			selectionArgs[7] = etime;
//		}
//		
//		// defualt today/
//		if(pattenDays.contains("/")) {
//			sb.append(" AND (");
//			String[] days = pattenDays.split("/");
//			int last = days.length-1;
//			for(int i=0; i<days.length; i++) {
//				if(i != last) {
//					sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//					sb.append(" OR ");
//				} else {
//					sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//					sb.append("))");
//				}
//			}
//			selection = sb.toString();
//		}
//		Log.e(TAG, "insert DB = " + sb.toString());
//		mCursor = event.getFullTableScan(DBConst._TABLENAME1,
//				returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		boolean result = false;
//		if(mCursor.getCount() != 0) {
//			result = true;
//			Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//		} else {
//			result = false;
//			result = checkOverNextDay(rowId, values);
//		}
//		
//		if(!result) {
//			rowId = event.insertDB(DBConst._TABLENAME1, values);
//		}
//		
//		mCursor.close();
//		return rowId;
//	}
//
//	public long insertScheduleBackUp(int key, ContentValues values) {
//		long rowId = -1L;
//		switch (key) {
//		case I_KidsAdd:
//			// query syntex
//			String[] returnColumns = null;
//			String selection = null;
//			String[] selectionArgs = null;
//			String groupBy = DBConst.P_S01_SDATE;
//			String having = null;
//			String orderBy = null;
//			
//			StringBuilder	sb = new StringBuilder();
//			sb.append("((" + DBConst.P_S01_STIME + " BETWEEN ? AND ? )");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_ETIME + " BETWEEN ? AND ? )");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " <= ? and " + DBConst.P_S01_ETIME +" >= ?)");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " < ? and " + DBConst.P_S01_ETIME +" >= ?)");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " <= ? and " + DBConst.P_S01_ETIME +" > ?))");
//			String sdate = (String) values.get(DBConst.P_S01_SDATE);
//			String edate = (String) values.get(DBConst.P_S01_EDATE);
//			String stime = (String) values.get(DBConst.P_S01_STIME);
//			String etime = (String) values.get(DBConst.P_S01_ETIME);
//			
//			String pattenDays = (String) values.get(DBConst.P_S01_PATTERN_DATES);
//			Log.i(TAG, "pattenDays = '" + pattenDays + "'");
//			// defualt today/
//			if(pattenDays.contains("/")) {
//				sb.append(" AND (");
//				String[] days = pattenDays.split("/");
//				int last = days.length-1;
//				for(int i=0; i<days.length; i++) {
//					if(i != last) {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//						sb.append(" OR ");
//					} else {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//						sb.append(")");
//					}
//				}
//				selection = sb.toString();
//				selectionArgs = new String[10];
//				String[] data = getBetweenData(sdate, edate);
//				selectionArgs[0] = stime;
//				selectionArgs[1] = data[1];	// end time (ex 11:00 -> 10:49)
//				selectionArgs[2] = data[0];	// start time (ex 10:00 -> 10:01)
//				selectionArgs[3] = etime;
//				
//				selectionArgs[4] = stime;
//				selectionArgs[5] = etime;
//				selectionArgs[6] = etime;
//				selectionArgs[7] = etime;
//				selectionArgs[8] = stime;
//				selectionArgs[9] = stime;
//			}
//			
//			mCursor = event.getFullTableScan(DBConst._TABLENAME1,
//					returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//			
//			boolean result = false;
//			if(mCursor.getCount() != 0) {
//				result = true;
//				Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//			} else {
//				result = false;
//			}
//			
//			if(!result) {
//				rowId = event.insertDB(DBConst._TABLENAME1, values);
//			}
//		}
//		mCursor.close();
//		return rowId;
//	}
//	
//	public boolean updateScheduleBackUp(int key, long rowId, ContentValues values) {
//		Log.d(TAG, "updateSchedule = " + rowId);
//		boolean updateResult = false;
//		boolean result = false;
//		switch (key) {
//		case I_KidsUpdate:
//			// query syntex
//			String[] returnColumns = null;
//			String selection = null;
//			String[] selectionArgs = null;
//			String groupBy = DBConst.P_S01_SDATE;
//			String having = null;
//			String orderBy = null;
//			
//			StringBuilder	sb = new StringBuilder();
//			sb.append("(" + DBConst.P_S01_ID + " != ? )");
//			sb.append(" AND ((");
//			sb.append("" + DBConst.P_S01_STIME + " BETWEEN ? AND ? )");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_ETIME + " BETWEEN ? AND ? )");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " <= ? and " + DBConst.P_S01_ETIME +" >= ?)");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " < ? and " + DBConst.P_S01_ETIME +" >= ?)");
//			sb.append(" OR (");
//			sb.append("" + DBConst.P_S01_STIME + " <= ? and " + DBConst.P_S01_ETIME +" > ?))");
//			String _id = String.valueOf(rowId);
//			String sdate = (String) values.get(DBConst.P_S01_SDATE);
//			String edate = (String) values.get(DBConst.P_S01_EDATE);
//			String stime = (String) values.get(DBConst.P_S01_STIME);
//			String etime = (String) values.get(DBConst.P_S01_ETIME);
//			
//			String pattenDays = (String) values.get(DBConst.P_S01_PATTERN_DATES);
//			Log.e(TAG, "pattenDays = '" + pattenDays + "'");
////				String pattenDays = "2011-11-15/2011-11-17/2011-11-23/2011-11-25/";
//			if(pattenDays.contains("/")) {
//				sb.append(" AND (");
//				String[] days = pattenDays.split("/");
//				int last = days.length-1;
//				for(int i=0; i<days.length; i++) {
//					if(i != last) {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//						sb.append(" OR ");
//					} else {
//						sb.append("(" + DBConst.P_S01_PATTERN_DATES + " like '%" + days[i] +"%')");
//						sb.append(")");
//					}
//				}
//				selection = sb.toString();
//				Log.i(TAG, "" + selection);
//				selectionArgs = new String[11];
//				selectionArgs[0] = _id;
//				// between a and b
//				String[] data = getBetweenData(sdate, edate);
//				selectionArgs[1] = stime;
//				selectionArgs[2] = data[1];
//				selectionArgs[3] = data[0];
//				selectionArgs[4] = etime;
//				
//				selectionArgs[5] = stime;
//				selectionArgs[6] = etime;
//				selectionArgs[7] = etime;
//				selectionArgs[8] = etime;
//				selectionArgs[9] = stime;
//				selectionArgs[10] = stime;
//			}
//			
//			mCursor = event.getFullTableScan(DBConst._TABLENAME1,
//					returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//			
//			Log.d(TAG, "selection = " + selection);
//			
//			if(mCursor.getCount() != 0) {
//				result = true;
//				Log.d(TAG, "mCursor.getCount() = " + mCursor.getCount());
//			} else {
//				result = false;
//			}
//			if(!result) {
//				updateResult = event.updateDBByID(DBConst._TABLENAME1, rowId, values);
//			}
//		}
//		
//		mCursor.close();
//		return updateResult;
//	}
	
}
