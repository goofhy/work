package com.tjmedia.android.tjdebugger.sensor;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Log;

public class TJSensor extends Activity {
	    private final String TAG = "Sensor";
		private SensorManager mSensorManager;
		private List<Sensor> mSensor;
		private Sensor sensorGrav, sensorMag, sensorOrient;
	    TextView[] mTVs = new TextView[4];
	    
	    public static float[] mGravity = new float[3];
		public static float[] mMagentic = new float[3];
		public static float[] mAzimuth = new float[3];
		public static float[] mDegrees = new float[3];
	    
	    /** Called when the activity is first created. */
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.gsensor_main);
	        
	        mTVs[0] = (TextView) findViewById(R.id.ACCELEROMETER);
	        mTVs[1] = (TextView) findViewById(R.id.MAGNETIC_FIELD);
	        mTVs[2] = (TextView) findViewById(R.id.ORIENTATION);
	        mTVs[3] = (TextView) findViewById(R.id.ORIENTATION1);
	        
	        mSensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
	        
	        mSensor = mSensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
	        if (mSensor.size() > 0) {
	        	sensorGrav = mSensor.get(0);
	        }
	        
	        mSensor = mSensorManager.getSensorList(Sensor.TYPE_MAGNETIC_FIELD);
	        if (mSensor.size() > 0) {
	        	sensorMag = mSensor.get(0);
	        }
	        
	        mSensor = mSensorManager.getSensorList(Sensor.TYPE_ORIENTATION);
	        if (mSensor.size() > 0) {
	        	sensorOrient = mSensor.get(0);
	        }
	    }
	    

		@Override
		protected void onResume() {
			super.onResume();
			Log.i(TAG, "onResume()");
			mSensorManager.registerListener(AccelatorSensor, sensorGrav,
					SensorManager.SENSOR_DELAY_NORMAL);
			mSensorManager.registerListener(MagneticSensor, sensorMag,
					SensorManager.SENSOR_DELAY_NORMAL);
			mSensorManager.registerListener(OrientationSensor, sensorOrient,
					SensorManager.SENSOR_DELAY_NORMAL);
		}

		@Override
		protected void onPause() {
			super.onStop();
			mSensorManager.unregisterListener(AccelatorSensor);
			mSensorManager.unregisterListener(MagneticSensor);
			mSensorManager.unregisterListener(OrientationSensor);
		}
		
		SensorEventListener AccelatorSensor = new SensorEventListener() {
			
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				switch (event.sensor.getType()) {
				case Sensor.TYPE_ACCELEROMETER:
					mGravity = event.values;
					if(mGravity!=null) {
						mTVs[1].setText("Accelerometer: " 
								+ String.format("%.1f", mGravity[0]) + ", " 
								+ String.format("%.1f", mGravity[1]) + ", "
								+ String.format("%.1f", mGravity[2]));
					}
					break;
				}
			}
			
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
				
			}
		};
		
		SensorEventListener MagneticSensor = new SensorEventListener() {
			
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				switch (event.sensor.getType()) {
				case Sensor.TYPE_MAGNETIC_FIELD:
					mMagentic = event.values;
					if(mMagentic!=null) {
						mTVs[2].setText("Magnetic: " 
								+ String.format("%.1f", mMagentic[0]) + ", " 
								+ String.format("%.1f", mMagentic[1]) + ", "
								+ String.format("%.1f", mMagentic[2]));
					}
					break;
				}
				if(mGravity != null && mMagentic != null) {
					float[] temp = new float[3];
					float[] inR = new float[9];
					float[] outR = new float[9];
					SensorManager.getRotationMatrix(inR, null, mGravity, mMagentic);
//					SensorManager.remapCoordinateSystem(inR, SensorManager.AXIS_X, SensorManager.AXIS_Z, outR);
					SensorManager.remapCoordinateSystem(inR, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, outR);
					SensorManager.getOrientation(outR, temp);
					temp[0] = (float) Math.toDegrees(temp[0]);
					temp[1] = (float) Math.toDegrees(temp[1]);
					temp[2] = (float) Math.toDegrees(temp[2]);
					mDegrees = temp;
					
					mTVs[4].setText("Orientation01: " 
							+ String.format("%.1f", mDegrees[0]) + ", " 
							+ String.format("%.1f", mDegrees[1]) + ", "
							+ String.format("%.1f", mDegrees[2]));
				}
			}
			
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
			}
		};
		SensorEventListener OrientationSensor = new SensorEventListener() {
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				switch (event.sensor.getType()) {
				case Sensor.TYPE_ORIENTATION:
//					Log.i(TAG, "onSensorChanged() = " + event.sensor.getType());
					mAzimuth = event.values;
					if(mAzimuth!=null) {
						mTVs[3].setText("Orientation: " 
								+ String.format("%.1f", mAzimuth[0]) + ", " 
								+ String.format("%.1f", mAzimuth[1]) + ", "
								+ String.format("%.1f", mAzimuth[2]));
					}
					break;
				}
			}
			
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
			}
		};
		
}
