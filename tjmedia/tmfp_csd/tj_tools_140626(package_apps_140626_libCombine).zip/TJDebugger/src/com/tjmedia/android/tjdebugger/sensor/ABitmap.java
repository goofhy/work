package com.tjmedia.android.tjdebugger.sensor;


public abstract class ABitmap {
	public int x;
	public int y;
	public int width;
	public int height;
	public int index = 0;

	public abstract int getX();

	public abstract int getY();

	public abstract int getWidth();

	public abstract int getHeight();

	public abstract void setIndex(int index);
	
	public abstract void getIndex();
	
	public abstract void activeView();
}
