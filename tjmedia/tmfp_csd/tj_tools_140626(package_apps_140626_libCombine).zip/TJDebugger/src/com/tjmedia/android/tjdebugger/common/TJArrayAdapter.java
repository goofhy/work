/**
 * Copyright (C) 2010 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Mobile Communication Division,
 * Digital Media & Communications Business, Samsung Electronics Co., Ltd.
 *
 * This software and its documentation are confidential and proprietary
 * information of Samsung Electronics Co., Ltd.  No part of the software and
 * documents may be copied, reproduced, transmitted, translated, or reduced to
 * any electronic medium or machine-readable form without the prior written
 * consent of Samsung Electronics.
 *
 * Samsung Electronics makes no representations with respect to the contents,
 * and assumes no responsibility for any errors that might appear in the
 * software and documents. This publication and the contents hereof are subject
 * to change without notice.
 */
package com.tjmedia.android.tjdebugger.common;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.tjmedia.android.tjdebugger.R;

/**
 * 
 * Desc : 
 * @Company : 
 * @Author  : Jimmy
 * @Date    : 2011. 8. 4. 
 * @History : 
 *
 */

public class TJArrayAdapter extends ArrayAdapter<TJListItem> {
	private static final String TAG = "TJArrayAdapter";
	
	private LayoutInflater mInflater;
	private int mLayoutID;
	private ArrayList<TJListItem> mObject;

	public TJArrayAdapter(Context context, int layoutId, ArrayList<TJListItem> object) {
		super(context, layoutId, object);
		mInflater = LayoutInflater.from(context);
		mLayoutID = layoutId;
		mObject = object;
	}

	int CurrentPosition = 0;
	
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			convertView = mInflater.inflate(mLayoutID, null);
		}
		
		CurrentPosition = position;
		final TJListItem item = getItem(position);
		
		if (item != null) {
			final ViewHolder holder = new ViewHolder();
		
			switch (mLayoutID) {
				case R.layout.tj_main_list_row:
					holder.layoutToggle = (LinearLayout)convertView.findViewById(R.id.TJ_Main_List_LL01);
					if(item.isItemChecked()) {
						holder.layoutToggle.setBackgroundResource(R.drawable.s_focus);
					} else {
						holder.layoutToggle.setBackgroundResource(R.drawable.s_not_focus);
					}
					holder.mfirst = (TextView)convertView.findViewById(R.id.TJ_Main_List_Column01);
					holder.mfirst.setText(item.getColumns(0));
					holder.msecond = (TextView)convertView.findViewById(R.id.TJ_Main_List_Column02);
					holder.msecond.setText(item.getColumns(1));
					holder.mthird = (TextView)convertView.findViewById(R.id.TJ_Main_List_Column03);
					holder.mthird.setText(item.getColumns(2));
					convertView.setTag(holder);
					break;
				case R.layout.tj_list_row_twoline:
					holder.layoutToggle = (LinearLayout)convertView.findViewById(R.id.TJ_List_Row_TwoLine_LL01);
					if(item.isItemChecked()) {
						holder.layoutToggle.setBackgroundResource(R.drawable.s_focus);
					} else {
						holder.layoutToggle.setBackgroundResource(R.drawable.s_not_focus);
					}
					holder.mfirst = (TextView)convertView.findViewById(R.id.TJ_List_Row_TwoLine_Index01);
					holder.mfirst.setText(item.getColumns(0));
					holder.msecond = (TextView)convertView.findViewById(R.id.TJ_List_Row_TwoLine_Index02);
					holder.msecond.setText(item.getColumns(1));
					convertView.setTag(holder);
					break;
				default:
					// No_items
					Log.i(TAG, "default");
					break;
			}
		}
		
		return convertView;
	}
	
	
	public ArrayList<TJListItem> getListItem() {
		return mObject;
	}
	
	
	public void setListItem(ArrayList<TJListItem> object) {
		this.mObject = object;
	}

		
	static class ViewHolder {
		LinearLayout layoutToggle;
		FrameLayout framelayoutToggle;
		
		TextView mfirst;
		TextView msecond;
		TextView mthird;
		TextView mfourth;
		TextView mfifth;
		TextView msixth;
		TextView mseventh;
		TextView meighth;
		TextView mninth;
		TextView mtenth;
		
		CheckBox mCheckBox;
		EditText mEditText;
		ImageView mImage;
		TextView mSfifth;
	}
	
}
