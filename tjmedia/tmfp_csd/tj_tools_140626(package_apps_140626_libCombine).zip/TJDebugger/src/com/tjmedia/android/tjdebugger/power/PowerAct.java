package com.tjmedia.android.tjdebugger.power;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class PowerAct extends Activity implements OnSeekBarChangeListener {   
   
	private static final String TAG = "PowerAct";



	PowerManager pm;
	Button mTitleExit;
	SoundPoolManager mPoolManger;	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.power_main);    
        
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		 initObjInfo();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();		
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {

	}

	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		Power.mComponetListView = (ListView) findViewById(R.id.Power_main_ListView);
		Power.mComponet01 = (TextView) findViewById(R.id.Power_main_index01);
		
		Power.mComponet02 = (Button)  findViewById(R.id.Power_main_index02);
		Power.mComponet03 = (Button)  findViewById(R.id.Power_main_index03);
		Power.mComponet03.setVisibility(View.INVISIBLE);
		Power.mComponet02.setOnClickListener(mClickListener);
		Power.mComponet03.setOnClickListener(mClickListener);

		
		Power.mComponet04 = (Button)  findViewById(R.id.Power_main_index04);
		Power.mComponet05 = (Button)  findViewById(R.id.Power_main_index05);
		Power.mComponet06 = (SeekBar) findViewById(R.id.Power_main_index06);
		
		Power.mComponet04.setOnClickListener(mClickListener);
		Power.mComponet05.setOnClickListener(mClickListener);
				
		Power.mComponet06.setOnSeekBarChangeListener(this);
		
		
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		Power.mComponetListView.setAdapter(mAdapter);
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}		
		
		pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
	}
	
	@Override
	 public void onProgressChanged(SeekBar seekBar, int progress,
	   boolean fromUser) {
	  // TODO Auto-generated method stub
		int time = seekBar.getProgress() * 1000;
		String str = "Alarm : " + time + "msec";
		mItem.add(0, str);
		mAdapter.notifyDataSetChanged();
		mListIndex++;
		
		if (0 == mListIndex%50)
		{
			mItem.clear();
		}			
	 }
	 @Override
	 public void onStartTrackingTouch(SeekBar seekBar) {
	  // TODO Auto-generated method stub
	 }
	 @Override
	 public void onStopTrackingTouch(SeekBar seekBar) {
	  // TODO Auto-generated method stub
	 }
	
	void SetAlarm(boolean onoff , int time)
	{
		Intent intent = new Intent();
		intent.setAction("TMFP.ALARM");
		intent.putExtra("onoff", onoff);
		intent.putExtra("time", time);		
		sendBroadcast(intent);
	}
	
	private long mListIndex = 0;
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
				case R.id.top_exit:
					finish();
					break;
				case R.id.Power_main_index02:
					setPowerEvent(0);
					break;
				case R.id.Power_main_index03:
					break;
					
				case R.id.Power_main_index04:					
				{
					int mtime = Power.mComponet06.getProgress() * 1000;
					String str = "Enable, Alarm : " + mtime + "msec";
					ToastManager.showToast(getApplicationContext(),
							str, Toast.LENGTH_SHORT);
					
					mItem.add(0, str);
					mAdapter.notifyDataSetChanged();
					mListIndex++;
					
					if (0 == mListIndex%50)
					{
						mItem.clear();
					}										
				}
					SetAlarm(true,Power.mComponet06.getProgress() * 1000);
					break;
				case R.id.Power_main_index05:
					String str = "Disable, Alarm";
					SetAlarm(false,0);
					break;
					
				default:
					break;
				
			}
		}
	};
	
	private void setPowerEvent(int key) {
		switch (key) {
			case 0:
				popUpDialogForReboot();
				break;
		}
	}
	
	
	
	
	private int			mRebootOrShutdownType=0;
	static final int 	PROGRESS_DIALOG = 0;
	private void popUpDialogForReboot() {
		final CharSequence[] items =
			{
				"REBOOT : normal", 
				"REBOOT : without view", 
				"SHUTDOWN : normal",
				"SHUTDOWN : without view"
			};
			
	        AlertDialog.Builder builder = new AlertDialog.Builder(this);
	        builder.setTitle("select reboot or shutdown type");
	        
	        builder.setItems(items, new DialogInterface.OnClickListener() 
	        {
				public void onClick(DialogInterface dialog, int item) 
				{
					mRebootOrShutdownType=item;
					
					showDialog(PROGRESS_DIALOG);
					Toast.makeText(getApplicationContext(),
							items[item], Toast.LENGTH_SHORT).show();
				}
			});
	        AlertDialog alert = builder.create();
	        alert.show();
	}
	
	
	ProgressThread progressThread;
	ProgressDialog progressDialog;
	protected Dialog onCreateDialog(int id) {
		switch (id) {
			case PROGRESS_DIALOG:
				
				progressDialog = new ProgressDialog(this);
				progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				
				if (mRebootOrShutdownType==0 || mRebootOrShutdownType==1) {
					progressDialog.setMessage("Reboot");
				} else {
					progressDialog.setMessage("Shutdown");
				}
				progressThread = new ProgressThread(handler);
				progressThread.start();
				return progressDialog;
			default:
				return null;
		}
	}
	
	final Handler handler = new Handler() {
		public void handleMessage(Message msg) 
		{
			int total = msg.getData().getInt("total");
			
			progressDialog.setProgress(total);
			
			if (total>100) {
				dismissDialog(PROGRESS_DIALOG);
				progressThread.setState(ProgressThread.STATE_DONE);
				
				switch (mRebootOrShutdownType) {
					case 0:
						if (!Log.getTJ())
						pm.reboot("1");
						break;
					case 1: 
						if (!Log.getTJ())
						pm.reboot("1");
						break;
					case 2: 	
						if (!Log.getTJ())
						pm.reboot("1");
						break;
					case 3: 
						//if(Log.getCSD())
						if (!Log.getTJ())
							pm.reboot("1");
						//TDMKMisc_Service.POWER_Shutdown(TDMKMisc_Service.POWER__SHUTDOWN_WITHOUT_VIEW);
						break;
				}
			}
		}
	};
	

	private class ProgressThread extends Thread {
		Handler mHandler;
		final static int STATE_DONE = 0;
		final static int STATE_RUNNING = 1;
		int mState;
		int total;
		
		ProgressThread(Handler h) {
			mHandler = h;
		}
		
		public void run() {
			mState = STATE_RUNNING;
			total = 0;
			while (mState == STATE_RUNNING) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					;
				}
				Message msg = mHandler.obtainMessage();
				Bundle b = new Bundle();
				b.putInt("total", total);
				msg.setData(b);
				mHandler.sendMessage(msg);
				total+=5;
			}
		}

		public void setState(int state) {
			mState = state;
		}
	}
	
	
	static class Power {
		private static ListView 		mComponetListView;
		private static TextView		mComponet01;		// Button display Viewer
		
		private static Button 			mComponet02;		// Reboot
		private static Button 			mComponet03;		// Power Off
		private static Button 			mComponet04;		// Alram On
		private static Button 			mComponet05;		// Alram Off
		
		private static SeekBar 			mComponet06;	    //alram time 
		
		private static RadioButton 	mComponet90;
		private static RadioButton 	mComponet91;
		private static Button 			mComponet98;		// Aging Start
		private static Button 			mComponet99;		// Aging Stop
	}
    
}
	
	

