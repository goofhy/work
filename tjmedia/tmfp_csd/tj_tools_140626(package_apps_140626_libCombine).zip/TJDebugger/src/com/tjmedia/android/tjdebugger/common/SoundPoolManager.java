package com.tjmedia.android.tjdebugger.common;

import java.io.File;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnSeekCompleteListener;
import android.media.SoundPool;
import android.net.Uri;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.audio.AudioAct;

public class SoundPoolManager {
	public final String TAG = "SoundPoolManager";
	public static SoundPool mSoundPool;

	// sound's names in raw directory.
//	public static int EXPLOSION = R.raw.explosion;
//	public static int VULCAN = R.raw.vulcan;
	public static Uri URI_TOUCH = Uri.fromFile(new File("/system/media/audio/ui/Effect_Tick.ogg"));
	private static Uri URI_SHUTTER = Uri.fromFile(new File("/system/media/audio/ui/camera_click.ogg"));
	private static Uri URI_TINKERBELL = Uri.fromFile(new File("/system/media/audio/notifications/Tinkerbell.ogg"));

	public static int ID_TOUCH;
	public int ID_SHUTTER;
	public int[] I_SOUND_LEVEL = {0, 1, 2, 3, 4, 5};
	
	private static final int SE_SIZE = 5;
	private static final int SE_NONE = -1;
	
	private MediaPlayer[] mPlyr = new MediaPlayer[SE_SIZE];
	public static final int SE_TOUCH = 0;
	public static final int SE_SHUTTER = 1;
	public static final int SE_TINKERBELL = 2;
	public static final int SE_PLAYTEST = 3;
	public static final int SE_PLAYTEST_INDEX01 = 4;
	
	private static final OnSeekCompleteListener OnSeekCompleteListener = null;
	
	public static int I_SOUNDID_LEFT = 0;
	public static int I_SOUNDID_RIGHT = 0;
	public static int I_SOUNDID_ALL = 0;
	
	Context mContext;
	
	public SoundPoolManager(Context context) {
		loadMediaSound(context);
	}
	
	public SoundPoolManager(Context context, int priority) {
		loadMediaSound(context);
	}

//	public SoundPoolManager(Context context, int id, int test) {
//		mSoundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
//		MediaPlayer mp = MediaPlayer.create(context, Uri.fromFile( new File( "/system/media/audio/ui/Effect_Tick.ogg")));
//		mPlyr[ SE_TOUCH ] = MediaPlayer.create(context,
//				Uri.fromFile( new File( "/system/media/audio/ui/Effect_Tick.ogg" ) ) );
//		
//		Uri parser = Uri.parse(URI_TOUCH.toString());
//		Log.e(TAG, "parser:" + parser);
//		ID_TOUCH = mSoundPool.load(context.getApplicationContext(), mp.getAudioSessionId(), 1);
//		mClick = mSoundPool.load(context, R.raw.left, 1);
//		ID_TOUCH = mSoundPool.load(URI_TOUCH.getPath(), 1);
//		Log.e(TAG, "parser:" + URI_TOUCH.getPath());
//	}
	
	public boolean play(int no) {
		if ( mPlyr[no] == null ) return false;
		mPlyr[no].start();
		return true;
	}
	
	public int getDuration(int no) {
		// Total Play Time == getDuration();
		int duration = -1;
		if ( mPlyr[no] == null ) return duration;
		duration = mPlyr[no].getDuration();
		return duration;
	}
	
	public int getCurrentTime(int no) {
		// Total Play Time == getDuration();
		int duration = -1;
		if ( mPlyr[no] == null ) return duration;
		duration = mPlyr[no].getCurrentPosition();
		return duration;
	}
	
	public void setCurrentTime(int no, int msec) {
		if ( mPlyr[no] == null ) return;
		mPlyr[no].seekTo(msec);
	}
	
	public boolean isPlaying(int no) {
		if ( mPlyr[no] == null ) return false;
		return mPlyr[no].isPlaying();
	}
	
	
	public boolean getPlayingStatus(int no) {
		boolean duration = false;
		if ( mPlyr[no] == null ) return duration;
		duration = mPlyr[no].isPlaying();
		return duration;
	}
	
	
	public boolean pause(int no) {
		if ( mPlyr[no] == null ) return false;
		mPlyr[no].pause();
		return true;
	}
	
	public boolean stop(Context context, int no) {
		if ( mPlyr[no] == null ) return false;
		mPlyr[no].stop();
		loadMediaSound(context);
		return true;
	}
	
	public static Uri I_FILE_URL =  null;
	
	private void loadMediaSound(Context context) {
		mContext = context;
		mSoundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
		I_SOUNDID_LEFT = mSoundPool.load(context, R.raw.left, 1);
		I_SOUNDID_RIGHT = mSoundPool.load(context, R.raw.right, 1);
		I_SOUNDID_ALL = mSoundPool.load(context, R.raw.all, 1);
		
		mPlyr[SE_TOUCH] = MediaPlayer.create(context, URI_TOUCH);
		mPlyr[SE_SHUTTER] = MediaPlayer.create(context, URI_SHUTTER);
		mPlyr[SE_TINKERBELL] = MediaPlayer.create(context, URI_TINKERBELL);
		mPlyr[SE_PLAYTEST] = MediaPlayer.create(context, R.raw.test1);
		if (I_FILE_URL == null) {
			mPlyr[SE_PLAYTEST_INDEX01] = MediaPlayer.create(context, R.raw.test2);
		} else {
			mPlyr[SE_PLAYTEST_INDEX01] = MediaPlayer.create(context, I_FILE_URL);
		}
		
		mPlyr[SE_PLAYTEST_INDEX01].setOnSeekCompleteListener(mSeekCompleteListener);
		mPlyr[SE_PLAYTEST_INDEX01].setOnCompletionListener(mOnCompleteListener);
//		mPlyr[SE_PLAYTEST_INDEX01].setOnErrorListener(mErrorListener);
//		mPlyr[SE_PLAYTEST_INDEX01].setOnInfoListener(mInfoListener);
//		mPlyr[SE_PLAYTEST_INDEX01].setOnPreparedListener(mPreparedListener);
		
	}
	
	public void setRepeatMedia(int id, boolean bool) {
		mPlyr[id].setLooping(bool);
	}
	
	
	synchronized public void seekMediaSound(Context context, boolean flag) {
		// flag = false if the MediaPlayer is seeking left , true otherwise.
		if (mPlyr[SE_PLAYTEST_INDEX01].isPlaying()) {
			int currentMillis = mPlyr[SE_PLAYTEST_INDEX01].getCurrentPosition();
			Log.d(TAG, "currentMillis=" + currentMillis);
			if (flag) {
				currentMillis+=5000;
			} else {
				currentMillis-=5000;
			}
			mPlyr[SE_PLAYTEST_INDEX01].seekTo(currentMillis);
		}
	}
	
	public void release() {
		if (mSoundPool == null) {
			return;
		}
		for (int i=0; i<mPlyr.length; i++) {			
			if (null != mPlyr[i])
			mPlyr[i].stop();
		}
		mSoundPool.release();
		mSoundPool = null;
	}
	
	// volume, 0 is mute, 1 is 50%, 2 is 100% 
	public void setVolume(int index, int volume) {
		float setVolume = 0.0f;
		if (volume == 0)
			setVolume = 0.0f;
		else if (volume == 1)
			setVolume = 0.5f;
		else if (volume == 2) {
			setVolume = 1;
		} else {
			setVolume = 0.5f;
		}
		mPlyr[index].setVolume(setVolume, setVolume);
	}
	
//	MediaPlayer.OnErrorListener mErrorListener = new MediaPlayer.OnErrorListener() {
//		
//		@Override
//		public boolean onError(MediaPlayer mp, int what, int extra) {
//			// TODO Auto-generated method stub
//			Log.d(TAG, "mErrorListener");
//			
//			return false;
//		}
//	};
//	
//	MediaPlayer.OnBufferingUpdateListener mBufferListener = new MediaPlayer.OnBufferingUpdateListener() {
//		@Override
//		public void onBufferingUpdate(MediaPlayer mp, int percent) {
//			// TODO Auto-generated method stub
//			Log.d(TAG, "mBufferListener");
//			
//		}
//	};
//	
//	MediaPlayer.OnInfoListener mInfoListener = new MediaPlayer.OnInfoListener() {
//		@Override
//		public boolean onInfo(MediaPlayer mp, int what, int extra) {
//			// TODO Auto-generated method stub
//			Log.d(TAG, "mBufferListener");
//			
//			return false;
//		}
//	};
//	
//	MediaPlayer.OnPreparedListener mPreparedListener = new MediaPlayer.OnPreparedListener() {
//		
//		@Override
//		public void onPrepared(MediaPlayer mp) {
//			// TODO Auto-generated method stub
//			Log.d(TAG, "mPreparedListener");
//			
//		}
//	};
	
	
	MediaPlayer.OnSeekCompleteListener mSeekCompleteListener = new MediaPlayer.OnSeekCompleteListener() {
		@Override
		public void onSeekComplete(MediaPlayer mp) {
			// TODO Auto-generated method stub
			Log.d(TAG, "mSeekCompleteListener");
//			AudioAct.FLAG_LONG_LOOP = false;
		}
	};
	
//	public static boolean FLAG_OnCOMPLETELISTENER = false;
	MediaPlayer.OnCompletionListener mOnCompleteListener = new MediaPlayer.OnCompletionListener() {
		@Override
		public void onCompletion(MediaPlayer mp) {
			// TODO Auto-generated method stub
			Log.d(TAG, "mOnCompleteListener");
			if (mPlyr[SE_PLAYTEST_INDEX01].isLooping()) {
				mPlyr[SE_PLAYTEST_INDEX01].reset();
				mPlyr[SE_PLAYTEST_INDEX01].start();
			} else {
				AudioAct.stopAudio(mContext);
				
			}
		}
	};
	
	
	/*
	 * ************************************************************
	 * Demo
	 * ************************************************************
	 */
	
	public void play(int soundID, boolean bool) {
		int repeat = 0;
		float temp = 0.0f;
		if (mSoundPool == null) {
			return;
		}
		repeat = bool == false ? 0 : -1;
		mSoundPool.play(soundID, 1, 1, 0, repeat, 1);
	}
	
	public void setRepeat(int soundID, boolean bool) {
		int repeat = 0;
		if (bool) { 
			repeat = -1; 
		} else  {
			repeat = 0; 
		}
		Log.d(TAG, "setRepeat=" + repeat);
		mSoundPool.setLoop(soundID, repeat);
	}
	
	public void stop(int streamID) {
		if (mSoundPool == null) {
			return;
		}
		mSoundPool.stop(streamID);
	}
	
	public void resume(int streamID) {
		if (mSoundPool == null) {
			return;
		}
		mSoundPool.resume(streamID);
	}
	
	synchronized public boolean playTouchSe() {
		return play(SE_TOUCH);
	}
	
	public void terminate() {
		for ( MediaPlayer pl : mPlyr ) {
			if ( pl != null ) pl.release();
		}
		mPlyr = null;
	}
}
