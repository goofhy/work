package com.tjmedia.android.tjdebugger.storage;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.text.style.LineHeightSpan.WithDensity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
//import com.tjmedia.android.tjdebugger.activity.TJDebugger.InnerFactory;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJArrayAdapter;
import com.tjmedia.android.tjdebugger.common.TJListItem;
import com.tjmedia.android.tjdebugger.common.ToastManager;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class StorageAct extends Activity {   
   
	private static final String TAG = "StorageAct"; 	
	String message ="";
	Button mTitleExit;
	SoundPoolManager mPoolManger;
	UpdateThread updateThread = null;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storage_main);    
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		if (null != updateThread)
		{
			updateThread.stop();
			updateThread.stopThread();
		}
		mLoopHandler2.stop();
		mLoopHandler.stop();
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
	}
    
//	public ArrayAdapter<String> mAdapter;
//	ArrayList<String> mItem;
	public ArrayAdapter<TJListItem> mAdapter;
	ArrayList<TJListItem> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		Storage.mComponet01 = (ListView) findViewById(R.id.Storage_Main_ListView);
		
//		Storage.mComponet02 = (Button) findViewById(R.id.Storage_Main_Index02);
		Storage.mComponet03 = (Button) findViewById(R.id.Storage_Main_Index03);
		Storage.mComponet04 = (Button) findViewById(R.id.Storage_Main_Index04);
		Storage.mComponet05 = (Button) findViewById(R.id.Storage_Main_Index05);
//		Storage.mComponet06 = (Button) findViewById(R.id.Storage_Main_Index06);
		Storage.mComponet07 = (Button) findViewById(R.id.Storage_Main_Index07);
		Storage.mComponet08 = (Button) findViewById(R.id.Storage_Main_Index08);
		Storage.mComponet09 = (Button) findViewById(R.id.Storage_Main_Index09);		
		Storage.mComponet12 = (Button) findViewById(R.id.Storage_Main_Index10);
		
		Storage.mComponet98 = (Button) findViewById(R.id.Storage_Main_Index98);
		Storage.mComponet99 = (Button) findViewById(R.id.Storage_Main_Index99);
		Storage.mComponet11 = (Button) findViewById(R.id.Storage_Main_Index11);
//		Storage.mComponet02.setOnClickListener(mClickListener);
		Storage.mComponet03.setOnClickListener(mClickListener);
		Storage.mComponet04.setOnClickListener(mClickListener);
		Storage.mComponet05.setOnClickListener(mClickListener);
//		Storage.mComponet06.setOnClickListener(mClickListener);
		Storage.mComponet07.setOnClickListener(mClickListener);
		Storage.mComponet08.setOnClickListener(mClickListener);
		Storage.mComponet09.setOnClickListener(mClickListener);
		Storage.mComponet11.setOnClickListener(mClickListener);
		Storage.mComponet12.setOnClickListener(mClickListener);

		Storage.mComponet98.setOnClickListener(mClickListener);
		Storage.mComponet99.setOnClickListener(mClickListener);
		
		mItem = new ArrayList<TJListItem>();
		mAdapter = new TJArrayAdapter(getApplicationContext(), R.layout.tj_list_row_twoline, mItem);

		Storage.mComponet01.setAdapter(mAdapter);
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}		
	}
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			// SD event 3~5, USB Event 6~8
			case R.id.Storage_Main_Index03:
				setExternStorageEvent(0);
				break;
			case R.id.Storage_Main_Index04:
				setExternStorageEvent(1);
				break;
			case R.id.Storage_Main_Index05:
				setExternStorageEvent(2);
				break;
			case R.id.Storage_Main_Index07:
				setExternStorageEvent(3);
				break;
			case R.id.Storage_Main_Index08:
				setExternStorageEvent(4);
				break;
			case R.id.Storage_Main_Index09:
				setExternStorageEvent(5);
				break;
			case R.id.Storage_Main_Index10:
				startActivity(new Intent(Settings.ACTION_MEMORY_CARD_SETTINGS));
				break;
				
			case R.id.Storage_Main_Index11:
				{
					Storage.mComponet11.setEnabled(false);
					String uriString = "/storage/usb/";
					String ext = null;
					String mount_path = null;
					File file = new File(uriString);
					File[] files = file.listFiles();
					if (null != files) {
						ext = Environment.MEDIA_MOUNTED;
						mount_path = uriString;
					} else {
						ext = Environment.MEDIA_UNMOUNTED;
						mount_path = Environment.MEDIA_UNMOUNTED;
						ToastManager.showToast(getApplicationContext(), "USB MemoryStick이 인식되지 않았습니다.", Toast.LENGTH_LONG);
						Storage.mComponet11.setEnabled(true);
						break;
					}
				}
								
				updateThread = new UpdateThread();
				message = "Kernel Update";
				updateThread.start();
				mLoopHandler2.start();
				//mLoopHandler2.stop();
				break;
				
			case R.id.Storage_Main_Index98:
//				if(Storage.mComponet10.isChecked()) {
//					Frequency = 1000;
//				} else {
//					Frequency = 2000;
//				}
				ToastManager.showToast(getApplicationContext(), "Aging Start", Toast.LENGTH_SHORT);
				mLoopHandler.start();
				break;
			case R.id.Storage_Main_Index99:
				ToastManager.showToast(getApplicationContext(), "Aging Stop", Toast.LENGTH_SHORT);
				mLoopHandler.stop();
				break;
			default:
				break;
				
			}
		}
	};
	
	
	String[] mSTORAGETEST_TEXT = {"Hello World", "Bye Bye"};
	boolean mFLAG_SDWRITE = false;
	boolean mFLAG_USBWRITE = false;
	public void setExternStorageEvent(int key) {
		switch (key) {
			case 0:
				performStorageEvent(0, true);
				break;
			case 1:
				performStorageEvent(1, true);
				break;
			case 2:
				performStorageEvent(2, true);
				break;
			case 3:
				performStorageEvent(0, false);
				break;
			case 4:
				performStorageEvent(1, false);
				break;
			case 5:
				performStorageEvent(2, false);
				break;
			default:
				break;
		}
	}
	
	private void performStorageEvent(int key, boolean flag) {
		// flag, if ture is SDCard, false otherwise
		String ext = null;
		String mount_path = null;
		String tag_bottom = flag == true ? "SD " :  "USB "; 
		switch (key) {
			case 0:
				if (flag) {
					// sd mount info
					String uriString = "/storage/sdcard1/";
					File file = new File(uriString);
					File[] files = file.listFiles();
					// Lost.dir directory check
					if (files != null/* && 1 == (result = TDMKMisc_Service.USB_CheckDevice()) */) {
						ext = Environment.MEDIA_MOUNTED;
						mount_path = uriString;
					} else {
						ext = Environment.MEDIA_UNMOUNTED;
						mount_path = Environment.MEDIA_UNMOUNTED;
					}
				} else {
					String uriString = "/storage/usb/";
					File file = new File(uriString);
					File[] files = file.listFiles();
					if (null != files) {
						ext = Environment.MEDIA_MOUNTED;
						mount_path = uriString;
					} else {
						ext = Environment.MEDIA_UNMOUNTED;
						mount_path = Environment.MEDIA_UNMOUNTED;
					}
					
				}
				updateListView(ext, tag_bottom + "Mount Path : " + mount_path);
				break;
			case 1:
				// write file event
				if (flag) {
					String uriString = "/storage/sdcard1";
					File file = new File(uriString);
					if (file.canRead()) {
						ext = Environment.MEDIA_MOUNTED;
//						mount_path = Environment.getExternalStorageDirectory().getAbsolutePath();
						mount_path = uriString;
						File filedir = new File(mount_path, "TJ_STORAGE");
						if (!filedir.exists()) {
							if (!filedir.mkdirs()) {
								Log.e(TAG, "failed to create directory");
								return;
							}
						}
						
						try {
							File filename = new File(filedir.getPath() + File.separator + "sdfile.txt");
							FileWriter fw = new FileWriter(filename);
							BufferedWriter bw = new BufferedWriter(fw);
	//						FileOutputStream  fos = new FileOutputStream(filename);
	//			            BufferedOutputStream bos = new BufferedOutputStream(fos);
	//			            byte[] result = filename.toString().getBytes();
	//			            byte[] result = "Hello World".getBytes();
							String result = null;
							mFLAG_SDWRITE = mFLAG_SDWRITE == false ? true : false;
							if (mFLAG_SDWRITE)
								result = mSTORAGETEST_TEXT[0];
							else
								result = mSTORAGETEST_TEXT[1];
				            bw.write(result);
				            bw.close();
				            fw.close();
				            mount_path = filename.toString();
						} catch (FileNotFoundException fe) {
							fe.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						ext = Environment.MEDIA_UNMOUNTED;
						mount_path = Environment.MEDIA_UNMOUNTED;
					}
				} else {
					String uriString = "/storage/usb";
					File file = new File(uriString);
					if (file.canRead()) {
						ext = Environment.MEDIA_MOUNTED;
//						mount_path = Environment.getExternalStorageDirectory().getAbsolutePath();
						mount_path = uriString;
						File filedir = new File(mount_path, "TJ_STORAGE");
						if (!filedir.exists()) {
							if (!filedir.mkdirs()) {
								Log.e(TAG, "failed to create directory");
								return;
							}
						}
						
						try {
							File filename = new File(filedir.getPath() + File.separator + "usbfile.txt");
							FileWriter fw = new FileWriter(filename);
							BufferedWriter bw = new BufferedWriter(fw);
	//						FileOutputStream  fos = new FileOutputStream(filename);
	//			            BufferedOutputStream bos = new BufferedOutputStream(fos);
	//			            byte[] result = filename.toString().getBytes();
	//			            byte[] result = "Hello World".getBytes();
							String result = null;
							mFLAG_USBWRITE = mFLAG_USBWRITE == false ? true : false;
							if (mFLAG_USBWRITE)
								result = mSTORAGETEST_TEXT[0];
							else
								result = mSTORAGETEST_TEXT[1];
				            bw.write(result);
				            bw.close();
				            fw.close();
				            mount_path = filename.toString();
						} catch (FileNotFoundException fe) {
							fe.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						ext = Environment.MEDIA_UNMOUNTED;
						mount_path = Environment.MEDIA_UNMOUNTED;
					}
				}
				updateListView(ext, tag_bottom  + "Write : " + mount_path);
				break;
			case 2:
				// read file event 
				if (flag) {
					String uriString = "/storage/sdcard1";					
					File file = new File(uriString, "TJ_STORAGE");
					if (file.canRead()) {
						ext = Environment.MEDIA_MOUNTED;
						try {
							File filename = new File(file.getPath() + File.separator + "sdfile.txt");
							FileReader fr = new FileReader(filename);
							BufferedReader br = new BufferedReader(fr);
							StringBuffer sb = new StringBuffer();
							String temp = null;
				            while ((temp=br.readLine()) != null) {
				            	sb.append(temp);
				            }
				            br.close();
				            fr.close();
				            mount_path = sb.toString();
						} catch (FileNotFoundException fe) {
							fe.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						ext = Environment.MEDIA_UNMOUNTED;
						mount_path = Environment.MEDIA_UNMOUNTED;
					}
				} else {
					String uriString = "/storage/usb";					
					File file = new File(uriString, "TJ_STORAGE");
					if (file.canRead()) {
						ext = Environment.MEDIA_MOUNTED;
						try {
							File filename = new File(file.getPath() + File.separator + "usbfile.txt");
							FileReader fr = new FileReader(filename);
							BufferedReader br = new BufferedReader(fr);
							StringBuffer sb = new StringBuffer();
							String temp = null;
				            while ((temp=br.readLine()) != null) {
				            	sb.append(temp);
				            }
				            br.close();
				            fr.close();
				            mount_path = sb.toString();
						} catch (FileNotFoundException fe) {
							fe.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					} else {
						ext = Environment.MEDIA_UNMOUNTED;
						mount_path = Environment.MEDIA_UNMOUNTED;
					}
				}
				updateListView(ext, tag_bottom + "Read : " + mount_path);
				break;
			default:
				break;
		}
	}
	
	private long mListIndex = 0L;
	private void updateListView(String top, String bottom) {
		TJListItem obj = null;
		String t_top = "Index[" + mListIndex + "] : " + top;
		String t_bottom = bottom;
		obj = new TJListItem(t_top, t_bottom);
		mItem.add(0, obj);
		mAdapter.notifyDataSetChanged();
		mListIndex++;
	}
	
	public final int Frequency = 1000;
	private LoopHandler mLoopHandler = new LoopHandler();
	public void loop() {
		setExternStorageEvent(mLoopHandler.count % 6);
		mLoopHandler.count++;
		mLoopHandler.sleep(Frequency);
	}
	
	class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			loop();
		}
	};
	
	public final int Frequency2 = 1000;
	private LoopHandler2 mLoopHandler2 = new LoopHandler2();
	public void loop2() {
		ToastManager.showToast(getApplicationContext(), message +" 중입니다. 잠시만 기다려주세요.", Toast.LENGTH_LONG);
		mLoopHandler2.sleep(Frequency2);
	}
	
	class LoopHandler2 extends Handler {
		private int count = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop2();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			loop2();
		}
	};	
	
	class UpdateThread extends Thread {
    	public boolean FLAG_RUN = true;
		@Override
		public void run() {
			// TODO Auto-generated method stub
			while (FLAG_RUN) {
//				message = "Kernel Update";
//				TDMKMisc_Service.SYSTEM_Run("/vendor/data/fireman/init.fireman kernel restore /usbdisk/TM10_1");
//				message = "RamDisk Update";
//				TDMKMisc_Service.SYSTEM_Run("/vendor/data/fireman/init.fireman ramdisk restore /usbdisk/TM10_2");
//				message = "System Update";
//				TDMKMisc_Service.SYSTEM_Run("/vendor/data/fireman/init.fireman system restore /usbdisk/TM10_3");
//				message = "Vendor Update";
//				TDMKMisc_Service.SYSTEM_Run("/vendor/data/fireman/init.fireman vendor restore /usbdisk/TM10_5");
//				message = "Reboot";
//				TDMKMisc_Service.POWER_Reboot(TDMKMisc_Service.POWER__REBOOT_NORMAL);	
				this.FLAG_RUN = false; 
			}
		}
		
		public void stopThread() { 
	        this.FLAG_RUN = false; 
	    } 
	};
 	
	
	static class Storage {
		private static ListView 			mComponet01;
		
//		private static Button 				mComponet02;
		private static Button 				mComponet03;
		private static Button 				mComponet04;
		private static Button 				mComponet05;
//		private static Button 				mComponet06;
		private static Button 				mComponet07;
		private static Button 				mComponet08;
		private static Button 				mComponet09;
		private static Button 				mComponet12;
		
//		private static EditText 	mComponet11;
		private static RadioButton 		mComponet10;
		private static Button 			mComponet11;
		
		private static Button 				mComponet98;
		private static Button 				mComponet99;
	}
	
}
	
	

