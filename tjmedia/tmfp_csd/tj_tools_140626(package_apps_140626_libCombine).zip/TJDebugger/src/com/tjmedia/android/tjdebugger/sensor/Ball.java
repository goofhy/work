package com.tjmedia.android.tjdebugger.sensor;

import java.util.Random;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

public class Ball extends ABitmap {
	private final String TAG = "Ball";	
	private int xAxis;
	private int yAxis;
	private int zAxis;
	private int move = 5;

	public static final Random rnd = new Random();
	
	// diameter of the balls in meters
    public static final float sBallDiameter = 0.008f;
    public static final float sBallDiameter2 = sBallDiameter * sBallDiameter;
    private float mXDpi;
    private float mYDpi;
    public float mMetersToPixelsX;
    public float mMetersToPixelsY;
    public float mXOrigin;
    public float mYOrigin;
    public float mSensorX;
    public float mSensorY;
    public long mSensorTimeStamp;
    public long mCpuTimeStamp;

	public Ball(Context context, SensorSurface view) {
		DisplayMetrics metrics = new DisplayMetrics();
		((WindowManager)context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(metrics);
		mXDpi = metrics.xdpi;
        mYDpi = metrics.ydpi;
        mMetersToPixelsX = mXDpi / 0.0254f;
        mMetersToPixelsY = mYDpi / 0.0254f;
//        Log.d(TAG, "Ball(). mXDpi           =" + mXDpi + ", mYDpi=" + mYDpi);
//        Log.d(TAG, "Ball(). mMetersToPixelsX=" + mMetersToPixelsX + ", mMetersToPixelsY=" + mMetersToPixelsY);
	}

	public void activeView() {
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public void getIndex() {
		// TODO Auto-generated method stub
		
	}
}
