package com.tjmedia.android.tjdebugger.sensor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.view.Display;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.WindowManager;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Log;

public class SensorSurface extends SurfaceView implements Callback, SensorEventListener {
	private final String TAG = "AMSensorSurface";

	SurfaceHolder mHolder = null;
	private LoopHandler mLoopHandler = new LoopHandler();

	/**
	 * [Notice] u have to set this Frequency value between 10~300
	 */
	public int Frequency = 0;
	public int ConcentrateRate = 0;
	public int PLAY_LEVEL = 0;


	private final ParticleSystem mParticleSystem = new ParticleSystem();
	private Display mDisplay;
	private WindowManager mWindowManager;
	private float mHorizontalBound;
    private float mVerticalBound;
 // friction of the virtual table and air
    private static final float sFriction = 0.1f;
    private long mLastT;
    private float mLastDeltaT;
    Ball mBall;
	Bitmap mBitmap;
	
	private PowerManager mPowerManager;
    private WakeLock mWakeLock;

	public SensorSurface(Context context) {
		super(context);
		mHolder = getHolder();
		mHolder.addCallback(this);
		mSensorManager = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
		mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		mWindowManager = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
		
		// Get an instance of the PowerManager
        mPowerManager = (PowerManager) getContext().getSystemService(Context.POWER_SERVICE);
        
		mWakeLock = mPowerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, getClass()
                .getName());
		mDisplay = mWindowManager.getDefaultDisplay();

		mBall = new Ball(getContext(), this);
		loadBall();
		
	}

	class LoopHandler extends Handler {
		private boolean bStop;

		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			loop();
		}
	};


	public void loop() {
		drawCanvas();
		mLoopHandler.sleep(Frequency);
	}

	private void drawCanvas() {
		Canvas canvas = mHolder.lockCanvas();
		Paint bPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
		bPaint.setColor(0xffA0FFA0);
		canvas.drawPaint(bPaint);

        final ParticleSystem particleSystem = mParticleSystem;
        final long now = mBall.mSensorTimeStamp + (System.nanoTime() - mBall.mCpuTimeStamp);
        final float sx = mBall.mSensorX;
        final float sy = mBall.mSensorY;
        
        particleSystem.update(sx, sy, now);

        final float xc = mBall.mXOrigin;
        final float yc = mBall.mYOrigin;
        final float xs = mBall.mMetersToPixelsX;
        final float ys = mBall.mMetersToPixelsY;
        float x = xc + particleSystem.getPosX(0) * xs;
        float y = yc - particleSystem.getPosY(0) * ys;
        x = setcurrentx;
        y = setcurrenty;
        
        bPaint.setColor(Color.RED);
        bPaint.setStyle(Paint.Style.STROKE);
        bPaint.setStrokeWidth(1);        
//        canvas.drawRect(1179/2,0,1179/2 + 100,100, bPaint);
//        canvas.drawRect(1179, 493/2, 1179 + 100, 493/2 + 100, bPaint);
//        canvas.drawRect(0, 493/2, 0 + 100,493/2 + 100, bPaint);
//        canvas.drawRect(1179/2, 493, 1179/2 + 100, 493 + 100, bPaint);
//
        canvas.drawRect(1280/2-100, 500/2-50, 1280/2 + 100, 500/2 +150, bPaint);
        
        // orginal
        canvas.drawBitmap(mBitmap, x, y, null);
        //canvas.drawBitmap(mBitmap, setcurrentx, setcurrenty, null);        
        
        currentx = x;
        currenty = y;
        
        bPaint.setColor(Color.BLUE);
        bPaint.setStyle(Paint.Style.FILL);
        bPaint.setStrokeWidth(1);
        bPaint.setTextSize(30);
        
        float [] pos = new float[] {500,200,510,200};
        pos[0] = x+5;
        pos[1] = y+32;
        pos[2] = pos[0] + 20;
        pos[3] = pos[1];
        // ←↑↓→
        switch (currentmode) {
			case 0:	canvas.drawPosText("←←",pos,bPaint);	break;
			case 1:	canvas.drawPosText("↓↓",pos,bPaint);	break;
			case 2:	canvas.drawPosText("→→",pos,bPaint);	break;
			case 3:	canvas.drawPosText("↑↑",pos,bPaint);	break;
			case 4:	canvas.drawPosText("++",pos,bPaint);	break;
			case 5:	canvas.drawPosText("OK",pos,bPaint);	break;
			case 6:	bPaint.setColor(Color.RED);	canvas.drawPosText("NG",pos,bPaint);	break;
		default:
			break;
		}               
                
                
        
        {
            float [] fcal = new float[]
            		{
            		100-50,100,120-50,100,
            		140-50,100,160-50,100,
            		170-50,100,190-50,100,
            		210-50,100,230-50,100,
            		250-50,100,260-50,100,
            		280-50,100,300-50,100,
            		320-50,100,340-50,100,
            		 	
            		};
            if (beforecurrentmode >= 0)
            	canvas.drawPosText("CALIBRATION:OK",fcal,bPaint);   
            else
            	canvas.drawPosText("CALIBRATION:  ",fcal,bPaint);
            float [] fleft = new float[]
            		{
            		100-50,130,120-50,130,
            		140-50,130,160-50,130,
            		180-50,130,200-50,130,
            		220-50,130
            		};
            if (beforecurrentmode >= 1)
            	canvas.drawPosText("LEFT:OK",fleft,bPaint);
            else
            	canvas.drawPosText("LEFT:  ",fleft,bPaint);
 
            float [] fdown = new float[]
            		{
            		100-50,160,120-50,160,
            		140-50,160,160-50,160,
            		180-50,160,200-50,160,
            		220-50,160
            		};
            if (beforecurrentmode >= 2)
            	canvas.drawPosText("DOWN:OK",fdown,bPaint);
            else
            	canvas.drawPosText("DOWN:  ",fdown,bPaint);
  
            float [] fright = new float[]
            		{
            		100-50,190,120-50,190,
            		130-50,190,150-50,190,
            		170-50,190,190-50,190,
            		210-50,190,230-50,190
            		};
            if (beforecurrentmode >= 3)
        		canvas.drawPosText("RIGHT:OK",fright,bPaint);
            else
            	canvas.drawPosText("RIGHT:  ",fright,bPaint);
            
            float [] fup = new float[]
            		{
            		100-50,220,120-50,220,
            		140-50,220,160-50,220,
            		180-50,220,200-50,220,
            		220-50,220
            		};
            if (beforecurrentmode >= 4)
        		canvas.drawPosText("UP  :OK",fup,bPaint);
            else
            	canvas.drawPosText("UP  :  ",fup,bPaint);
            
            float [] fcenter = new float[]
            		{
            		100-50,250,120-50,250,
            		140-50,250,160-50,250,
            		180-50,250,200-50,250,
            		220-50,250,240-50,250,
            		260-50,250
            		};
            if (beforecurrentmode >= 5)
        		canvas.drawPosText("CENTER:OK",fcenter,bPaint);
            else
            	canvas.drawPosText("CENTER:  ",fcenter,bPaint);            
            
        }        
        
        //Log.d(TAG,"ball x,y = " +  x + "," + y);
        invalidate();
		mHolder.unlockCanvasAndPost(canvas);
	}
	
	private float currentx = 0;
	private float currenty = 0;
	private float setcurrentx = 0;
	private float setcurrenty = 0;
	
	private int currentmode = -1;
	private int beforecurrentmode = -1;
	
	public float[] getBallPos()
	{
		float [] pos = new float[] {0,0};
		pos[0] = currentx;
		pos[1] = currenty;
		return pos;
	}
	
	public void setBallPos(float x, float y)
	{
		setcurrentx = x;
		setcurrenty = y;
	}	
	
	public void setCheckBallPos(int nMode)
	{		
		beforecurrentmode = currentmode;
		currentmode = nMode;
	}

	private void loadBall() {
		Bitmap ballImg = BitmapFactory.decodeResource(getResources(), R.drawable.ball);
		final int dstWidth = (int) (Ball.sBallDiameter * mBall.mMetersToPixelsX + 0.5f);
        final int dstHeight = (int) (Ball.sBallDiameter * mBall.mMetersToPixelsY + 0.5f);
        mBitmap = Bitmap.createScaledBitmap(ballImg, dstWidth, dstHeight, true);
	}

	int testRate = 0;
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		Log.i(TAG, "onTouchEvent");
//		int action = event.getAction();
//		if (action == MotionEvent.ACTION_DOWN) {
//			if (testRate > 100) {
//				testRate = 0;
//				setFrequecy(testRate);
//			} else {
//				testRate += 19;
//				setFrequecy(testRate);
//				if(testRate > 100) testRate = 0;
//			}
//		}
//		Log.i(TAG, "Touch = " + Frequency);
		return super.onTouchEvent(event);
	}

	public void setFrequecy(int rate) {
		Log.i("setFrequecy", "setFrequecy.rate = " + rate);
		/*
		 * rate between 0 and 100;
		 */
		byte key = 0;
		if (rate == key) {
			key = 0;
		} else if (rate > 0 && rate < 20) {
			key = 1;
		} else if (rate >= 20 && rate < 40) {
			key = 2;
		} else if (rate >= 40 && rate < 60) {
			key = 3;
		} else if (rate >= 60 && rate < 80) {
			key = 4;
		} else if (rate >= 80 && rate <= 100) {
			key = 5;
		} else if (rate < 0 || rate > 100) {
			key = (byte)rate;
		}
		// Frequency 10~500, Max speed 20, Min = 300;
		switch (key) {
			case 0:
				mLoopHandler.stop();
				PLAY_LEVEL = 0;
				ConcentrateRate = 0;
				drawCanvas();
				break;
			case 1:
				PLAY_LEVEL = 1;
				Frequency = 50;
				ConcentrateRate = rate;
				mLoopHandler.start();
				break;
			case 2:
				PLAY_LEVEL = 2;
				Frequency = 40;
				ConcentrateRate = rate;
				mLoopHandler.start();
				break;
			case 3:
				PLAY_LEVEL = 3;
				Frequency = 30;
				ConcentrateRate = rate;
				mLoopHandler.start();
				break;
			case 4:
				PLAY_LEVEL = 4;
				Frequency = 20;
				ConcentrateRate = rate;
				mLoopHandler.start();
				break;
			case 5:
				Frequency = 10;
				PLAY_LEVEL = 5;
				ConcentrateRate = rate;
				mLoopHandler.start();
				break;
			default:
				PLAY_LEVEL = 0;
				ConcentrateRate = 0;
				mLoopHandler.stop();
				drawCanvas();
				break;
		}
	}
	
	private SensorManager mSensorManager;
	private Sensor mAccelerometer;

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		Log.i(TAG, "surfaceCreated");
		mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_UI);
		mWakeLock.acquire();
		drawCanvas();
		mLoopHandler.start();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		Log.i(TAG, "surfaceDestroyed");
		mSensorManager.unregisterListener(this);
		mWakeLock.release();
		mLoopHandler.stop();
		recycleBitmap();
	}

	private void recycleBitmap() {
		mBitmap.recycle();
	}
	
	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER)
            return;
		
		switch (mDisplay.getRotation()) {
	        case Surface.ROTATION_0:
//	        	Log.d(TAG, "Surface.ROTATION_0");
	            mBall.mSensorX = event.values[0];
	            mBall.mSensorY = event.values[1];
//	            Log.d(TAG, "ROTATION0=x:" + event.values[0] + ", " 
//	            		+ event.values[1] + ", "
//	            		+ event.values[2] 
//	            		);
	            break;
	        case Surface.ROTATION_90:
//	        	Log.d(TAG, "Surface.ROTATION_90");
	        	mBall.mSensorX = -event.values[1];
	        	mBall.mSensorY = event.values[0];
//	        	Log.d(TAG, "ROTATION90=x:" + event.values[0] + ", " 
//	        			+ event.values[1] + ", "
//	        			+ event.values[2] 
//	        			);
	            break;
	        case Surface.ROTATION_180:
//	        	Log.d(TAG, "Surface.ROTATION_180");
	        	mBall.mSensorX = -event.values[0];
	        	mBall.mSensorY = -event.values[1];
//	        	Log.d(TAG, "ROTATION180=x:" + event.values[0] + ", " 
//	        			+ event.values[1] + ", "
//	        			+ event.values[2] 
//	        			);
	            break;
	        case Surface.ROTATION_270:
//	        	Log.d(TAG, "Surface.ROTATION_270");
	        	mBall.mSensorX = event.values[1];
	        	mBall.mSensorY = -event.values[0];
//	        	Log.d(TAG, "ROTATION270=x:" + event.values[0] + ", " 
//	        			+ event.values[1] + ", "
//	        			+ event.values[2] 
//	        			);
	            break;
		}
		mBall.mSensorTimeStamp = event.timestamp;
		mBall.mCpuTimeStamp = System.nanoTime();
	}
	
	@Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        // compute the origin of the screen relative to the origin of
        // the bitmap
    	Log.d(TAG, "onSizeChanged()");
        mBall.mXOrigin = (w - mBitmap.getWidth()) * 0.5f;
        mBall.mYOrigin = (h - mBitmap.getHeight()) * 0.5f;
        mHorizontalBound = ((w / mBall.mMetersToPixelsX - Ball.sBallDiameter) * 0.5f);
        mVerticalBound = ((h / mBall.mMetersToPixelsY - Ball.sBallDiameter) * 0.5f);
    }
	
	class Particle {
        private float mPosX;
        private float mPosY;
        private float mAccelX;
        private float mAccelY;
        private float mLastPosX;
        private float mLastPosY;
        private float mOneMinusFriction;

        Particle() {
            // make each particle a bit different by randomizing its
            // coefficient of friction
            final float r = ((float) Math.random() - 0.5f) * 0.2f;
            mOneMinusFriction = 1.0f - sFriction + r;
        }

        public void computePhysics(float sx, float sy, float dT, float dTC) {
            final float m = 1000.0f; // mass of our virtual object
            final float gx = -sx * m;
            final float gy = -sy * m;

            final float invm = 1.0f / m;
            final float ax = gx * invm;
            final float ay = gy * invm;

            final float dTdT = dT * dT;
            final float x = mPosX + mOneMinusFriction * dTC * (mPosX - mLastPosX) + mAccelX
                    * dTdT;
            final float y = mPosY + mOneMinusFriction * dTC * (mPosY - mLastPosY) + mAccelY
                    * dTdT;
            mLastPosX = mPosX;
            mLastPosY = mPosY;
            mPosX = x;
            mPosY = y;
            mAccelX = ax;
            mAccelY = ay;
        }

        /*
         * Resolving constraints and collisions with the Verlet integrator
         * can be very simple, we simply need to move a colliding or
         * constrained particle in such way that the constraint is
         * satisfied.
         */
        public void resolveCollisionWithBounds() {
            final float xmax = mHorizontalBound;
            final float ymax = mVerticalBound;
            final float x = mPosX;
            final float y = mPosY;
            if (x > xmax) {
                mPosX = xmax;
            } else if (x < -xmax) {
                mPosX = -xmax;
            }
            if (y > ymax) {
                mPosY = ymax;
            } else if (y < -ymax) {
                mPosY = -ymax;
            }
        }
    }
	
	class ParticleSystem {
        static final int NUM_PARTICLES = 1;
        private Particle mBalls[] = new Particle[NUM_PARTICLES];

        ParticleSystem() {
            /*
             * Initially our particles have no speed or acceleration
             */
            for (int i = 0; i < mBalls.length; i++) {
                mBalls[i] = new Particle();
            }
        }

        /*
         * Update the position of each particle in the system using the
         * Verlet integrator.
         */
        private void updatePositions(float sx, float sy, long timestamp) {
            final long t = timestamp;
            if (mLastT != 0) {
//            	final float dT = (float) (t - mLastT) * (1.0f / 1000000000.0f);
                final float dT = (float) (t - mLastT) * (1.0f / 10000000000.0f);
                if (mLastDeltaT != 0) {
                    final float dTC = dT / mLastDeltaT;
                    final int count = mBalls.length;
                    for (int i = 0; i < count; i++) {
                        Particle ball = mBalls[i];
                        ball.computePhysics(sx, sy, dT, dTC);
                    }
                }
                mLastDeltaT = dT;
            }
            mLastT = t;
        }

        /*
         * Performs one iteration of the simulation. First updating the
         * position of all the particles and resolving the constraints and
         * collisions.
         */
        public void update(float sx, float sy, long now) {
            // update the system's positions
            updatePositions(sx, sy, now);

            // We do no more than a limited number of iterations
            final int NUM_MAX_ITERATIONS = 10;

            /*
             * Resolve collisions, each particle is tested against every
             * other particle for collision. If a collision is detected the
             * particle is moved away using a virtual spring of infinite
             * stiffness.
             */
            boolean more = true;
            final int count = mBalls.length;
            for (int k = 0; k < NUM_MAX_ITERATIONS && more; k++) {
                more = false;
                for (int i = 0; i < count; i++) {
                    Particle curr = mBalls[i];
                    for (int j = i + 1; j < count; j++) {
                        Particle ball = mBalls[j];
                        float dx = ball.mPosX - curr.mPosX;
                        float dy = ball.mPosY - curr.mPosY;
                        float dd = dx * dx + dy * dy;
                        // Check for collisions
                        if (dd <= Ball.sBallDiameter2) {
                            /*
                             * add a little bit of entropy, after nothing is
                             * perfect in the universe.
                             */
                            dx += ((float) Math.random() - 0.5f) * 0.0001f;
                            dy += ((float) Math.random() - 0.5f) * 0.0001f;
                            dd = dx * dx + dy * dy;
                            // simulate the spring
                            final float d = (float) Math.sqrt(dd);
                            final float c = (0.5f * (Ball.sBallDiameter - d)) / d;
                            curr.mPosX -= dx * c;
                            curr.mPosY -= dy * c;
                            ball.mPosX += dx * c;
                            ball.mPosY += dy * c;
                            more = true;
                        }
                    }
                    /*
                     * Finally make sure the particle doesn't intersects
                     * with the walls.
                     */
                    curr.resolveCollisionWithBounds();
                }
            }
        }

        public int getParticleCount() {
            return mBalls.length;
        }

        public float getPosX(int i) {
            return mBalls[i].mPosX;
        }

        public float getPosY(int i) {
            return mBalls[i].mPosY;
        }
    }
	
	/*
	 * ****************************************************************************************
	 *  Demo test
	 * ****************************************************************************************
	*/

	private BroadcastReceiver concentrationReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
//			int temp = intent.getIntExtra(BCIConstants.EXTRA_CONCENTRATION, 0);
//			Log.i(TAG, "concentrationReceiver = " + temp);
//			if (StopFlag) {
//				setFrequecy(temp);
//			}

//			int randomValue = (int)(Math.random() * 101);
//			intent.getIntExtra(BCIConstants.EXTRA_CONCENTRATION, 0);
//			Log.i(TAG, "concentrationReceiver = " + randomValue);
//			if(StopFlag) {
//				setFrequecy(randomValue);
//			}

		}
	};

}
