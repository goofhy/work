package com.tjmedia.android.tjdebugger.serial;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.bluetooth.AndroidExplorerActivity.DrawLoopHandler;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class SerialAct extends Activity {   
   
	private static final String TAG = "SerialAct"; 	

	DrawLoopHandler mDraw;
	Button mTitleExit;
	SoundPoolManager mPoolManger;
	com.tjmedia.service.ITJMedia_ServiceInterface TJService;
	
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.serial_main);    
 
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
		Intent intent = new Intent("com.tjmedia.service.TJMedia_ServiceInterface");
		bindService(intent, con, Context.BIND_AUTO_CREATE);
		mDraw.sleep(300);
		mDraw.start();
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		unbindService(con);
		mDraw.stop();
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
		mDraw = new DrawLoopHandler();
	}
	
	
	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		Serial.mComponetListView = (ListView) findViewById(R.id.Serial_main_ListView);
		Serial.mComponet01 = (TextView) findViewById(R.id.Serial_main_index01);
		for(int i=0; i<Serial.mComponets.length; i++) {
			Serial.mComponets[i] = (Button)  findViewById(Const.I_SERIAL_NUMS[i]);
			Serial.mComponets[i].setOnClickListener(mClickListener);
		}
		Serial.mComponet22 = (Button)  findViewById(R.id.Serial_main_index22);
		Serial.mComponet23 = (Button)  findViewById(R.id.Serial_main_index23);
		Serial.mComponet22.setOnClickListener(mClickListener);
		Serial.mComponet23.setOnClickListener(mClickListener);
		
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		Serial.mComponetListView.setAdapter(mAdapter);
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
//		String temp_serial = null;
//		try {
//			if (TJService != null)
//			temp_serial = TJService.SYSTEM_GetSerialNumber();
//		} catch (RemoteException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		if (temp_serial != null && temp_serial.length() != 0) {
//			if (TJService != null)
//				try {
//					updateList(0, TJService.SYSTEM_GetSerialNumber());
//				} catch (RemoteException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//		} else {
//			updateList(0, "failed to read this SerialNumber : NG");
//		}
	}
	
	private ServiceConnection con = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {

			TJService = com.tjmedia.service.ITJMedia_ServiceInterface.Stub.asInterface(service);
			if (TJService == null)
			{
				Log.d(TAG, "onServiceConnected>------------ TJService is NULL ------------");
			}
			else
			{
				Log.d(TAG, "onServiceConnected>------------ TJService = " + TJService);
				
				String temp_serial = null;
				try {					
					temp_serial = TJService.SYSTEM_GetSerialNumber();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if (temp_serial != null && temp_serial.length() != 0) {
						try {
							updateList(0, TJService.SYSTEM_GetSerialNumber());
						} catch (RemoteException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				} else {
					updateList(0, "failed to read this SerialNumber : NG");
				}				
			}			
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			Log.d(TAG, "onServiceDisconnected> TJService = " + TJService);		
			TJService = null;
		}		
	};	
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.top_exit:
				mPoolManger.playTouchSe();
				finish();
				break;
			case R.id.Serial_main_index02:	// 0
				mPoolManger.playTouchSe();
				setDigitEvent(0);
				break;
			case R.id.Serial_main_index03:	// 1
				mPoolManger.playTouchSe();
				setDigitEvent(1);
				break;
			case R.id.Serial_main_index04:	// 2
				mPoolManger.playTouchSe();
				setDigitEvent(2);
				break;
			case R.id.Serial_main_index05:	// 3
				mPoolManger.playTouchSe();
				setDigitEvent(3);
				break;
			case R.id.Serial_main_index06:	// 4
				mPoolManger.playTouchSe();
				setDigitEvent(4);
				break;
			case R.id.Serial_main_index07:	// 5
				mPoolManger.playTouchSe();
				setDigitEvent(5);
				break;
			case R.id.Serial_main_index08:	// 6
				mPoolManger.playTouchSe();
				setDigitEvent(6);
				break;
			case R.id.Serial_main_index09:	// 7
				mPoolManger.playTouchSe();
				setDigitEvent(7);
				break;
			case R.id.Serial_main_index10:	// 8
				mPoolManger.playTouchSe();
				setDigitEvent(8);
				break;
			case R.id.Serial_main_index11:	// 9
				mPoolManger.playTouchSe();
				setDigitEvent(9);
				break;
				
			case R.id.Serial_main_index22:	// Save
				mPoolManger.playTouchSe();
				removeDialog(DIALOG_POPUP_ITEM01);
				showDialog(DIALOG_POPUP_ITEM01);
				break;
			case R.id.Serial_main_index23:	// Clear
				clearData();
				break;
			default:
				break;
			}
		}
	};
	
	final int DIALOG_POPUP_ITEM01 = 10;
	protected Dialog onCreateDialog(int id) {
		switch(id) {
			case DIALOG_POPUP_ITEM01:
				AlertDialog.Builder b = new AlertDialog.Builder(this);
				b.setIcon(R.drawable.ic_launcher)
				.setTitle("Inand Info")
				.setMessage("Do you want to change this serial number?")
				.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						new I_AsynTask().execute(10);
					}
				})
				.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						finish();
					}
				});
				return b.create();
		}
		return super.onCreateDialog(id);
	};
	
	ProgressDialog mProgress;
	class I_AsynTask extends AsyncTask<Integer, Integer, Integer> {
		int mCount = 0;
		protected void onPreExecute() {
			mCount = 0;
			mProgress = new ProgressDialog(SerialAct.this);
			mProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mProgress.setMessage("Progressing...");
			mProgress.setProgress(0);
			mProgress.show();
		}
			
		protected Integer doInBackground(Integer... arg0) {
			while (isCancelled() == false) { 
				if (mCount <= 4) {
					publishProgress(mCount);
				} else {
					break;
				}
				try { 
					Thread.sleep(200); 
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				mCount++;
			}
			return mCount;
		}
		protected void onProgressUpdate(Integer... progress) {
			mProgress.setProgress(progress[0]);     
		}
		    
		protected void onPostExecute(Integer result) { 
			mProgress.dismiss();
			saveSerialNumber();
		}
		    
	}
	
	
	StringBuilder mSBDigit = new StringBuilder();
	private void setDigitEvent(int flag) {
		if(mSBDigit.length() == 6) {
			mSBDigit.setLength(0);
		}
//		if(mSBDigit.length() == 4) {
//			mSBDigit.append("-");
//		}
		mSBDigit.append(flag);
		Serial.mComponet01.setText(mSBDigit.toString());
	}
	
	

	final int MAX_SERIAL_LEN = 6;
	private void saveSerialNumber() {
		String str = mSBDigit.toString();
		String strSN = "";
		String args = String.format("%06d", Integer.valueOf(str));		
		//TDMKMisc_Service.SYSTEM_SetSerialNumber("AK"+args);
		if (TJService != null)
			try {
				if (Log.getCSD())
					strSN = "AK"+args;					
				else if (Log.getTMFP())
					strSN = "AN"+args;
				TJService.SYSTEM_SetSerialNumber(strSN);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//TDMKMisc_Service.BLUETOOTH_ChangeDeviceName("TM10-AK"+args);
		clearData();
		updateList(1, strSN);
		
		
	}
	
	private int mListIndex = 0;
	private void updateList(int index, String serialNum) {
		if (0 != index) {
			mItem.add(0, "Update-SN[" + mListIndex + "] : "
					+ serialNum  + "\n");
		} else {
			mItem.add(0, "Current-SN[" + mListIndex + "] : "
					+ serialNum  + "\n");
		}
		mAdapter.notifyDataSetChanged();
		Serial.mComponet01.invalidate();
		mListIndex++;
	}
	
	
	private void clearData() {
		mSBDigit.setLength(0);
		Serial.mComponet01.setText("");
	}
	
	public class DrawLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (this.bStop == false) {							
				Serial.mComponet01.invalidate();
				sleep(300);
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}
		
		public boolean isStoped() {
			return this.bStop;
		}
		
		public void stop() {
			this.bStop = true;
		}

		private void start() {
			this.bStop = false;							
		}
	};
	
	static class Serial {
		private static ListView 			mComponetListView;
		private static TextView				mComponet01;		// Button display Viewer
		private static Button[] 			mComponets = new Button[10];		// start 0 btn
		
		private static Button 				mComponet22;		// Save
		private static Button 				mComponet23;		// Clear 
		
		
	}
	
}
	
	

