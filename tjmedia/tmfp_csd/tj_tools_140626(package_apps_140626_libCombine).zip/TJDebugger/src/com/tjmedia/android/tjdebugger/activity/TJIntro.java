package com.tjmedia.android.tjdebugger.activity;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.*;



/**
 * 
 * Desc : 2초간 intro 이미지를 보여 준 후 자동으로 Login 화면이로 이동한다.
 * @Company : Onycom. Inc
 * @Author  : demian
 * @Date    : 2011. 4. 29. 
 * @History : 
 *
 */
public class TJIntro extends Activity {		
	String strManufacturer = android.os.Build.MANUFACTURER;	
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.intro);
    }
    
   
    protected void onResume() {	
		super.onResume();	
//		mHandler.sendEmptyMessageDelayed(Const.MOVE_ACTIVITY, Const.INTRO_SHOWING_TIME);		
//		mHandler.sendEmptyMessageDelayed(Const.MOVE_ACTIVITY, 2000);
		mHandler.sendEmptyMessageDelayed(Const.MOVE_ACTIVITY, 1000);
	}

        
	Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {		
	    	switch(msg.what) {	   
	    	case Const.MOVE_ACTIVITY:	    	
	    		Log.d("=========test2","=========test2");
	    		Intent intent;
	    		intent = new Intent(TJIntro.this, TJDebugger.class);
//	    		intent = new Intent(TJIntro.this, TJDevelopMode.class);
//	    		Intent intent = new Intent(TJIntro.this, TJDebuggerActivity.class);
//	    		intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);	    			    		
	    		startActivity(intent);
	    		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
				finish();				
	    		break;	    
	    	}
		}
	};
	 		
}
