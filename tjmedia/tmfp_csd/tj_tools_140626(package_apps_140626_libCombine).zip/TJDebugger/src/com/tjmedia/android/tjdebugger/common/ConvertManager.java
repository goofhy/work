package com.tjmedia.android.tjdebugger.common;

import java.util.Calendar;

import android.content.Context;


public class ConvertManager {
	public static final String TAG = "ConvertManager";
	
	Context mContext;
	
	public ConvertManager(Context context) {
		mContext = context;
	}
	
	public static Byte[] convertFromStringToHexByte(String str) {
		Byte[] numByte = new Byte[str.length()];
//		String str = "123411";
//		String[] arr = str.split("-");
//		StringBuilder sb = new StringBuilder();
//		for(int i=0; i<arr.length; i++) {
//			System.out.println("arr[" + i + "]=" + arr[i]);
//			sb.append(arr[i]);
//		}
		String[] arr2 = str.toString().split("");
		System.out.println("str.len=" + str.length());
		System.out.println("arr2.len=" + arr2.length);
		for(int i=1, j=0; j<numByte.length; i++, j++) {
			try {
				System.out.println("arr2[" + i + "]=" + Byte.valueOf(String.format("%h", arr2[i])));
				numByte[j] = Byte.valueOf(String.format("%h", arr2[i]));
			} catch (ArrayIndexOutOfBoundsException ae) {
				numByte[j] = 0;
			}
		}
		return numByte;
	}
	
	public static Byte[] convertFromStringToHexByte(String str, int len) {
		Byte[] numByte = new Byte[len];
		String[] arr2 = str.toString().split("");
//		System.out.println("str.len=" + str.length());
//		System.out.println("arr2.len=" + arr2.length);
		for(int i=1, j=0; j<numByte.length; i++, j++) {
			try {
//				System.out.println("arr2[" + i + "]=" + Byte.valueOf(String.format("%h", arr2[i])));
				numByte[j] = Byte.valueOf(String.format("%h", arr2[i]));
			} catch (ArrayIndexOutOfBoundsException ae) {
				numByte[j] = 0;
			}
		}
		return numByte;
	}

	public static String getConvertFromStringToByte(String str, int offset, int len) {
		byte[] b = str.getBytes();
		StringBuilder sb = new StringBuilder();
		int checklen = 0;
//		for(int i=0; i<b.length; i++) {
//			System.out.println("b" + i + " = " + b[i]);
//		}
		
		System.out.println("b = " + b.length);
		
		byte[] hangle = new byte[3];
		
		if(b.length>len) {
			System.out.println(true);
			for(int i=0; i<len; i++) {
				if((b[i] & 0x80) == 0x80) {
					System.out.println("0x80");
					checklen += 2;
					hangle[0] = b[i];
					hangle[1] = b[++i];
					hangle[2] = b[++i];
					sb.append(new String(hangle));
				} else {
					System.out.println("-");
					checklen +=1;
					sb.append((char)b[i]);
				}
				if(checklen>len) {
					break;
				}
			}
		} else {
			System.out.println(false);
			sb.append(str);
		}
		return sb.toString();
	}
	
	public static int[] covertFromDecToBinary(int bin) {
		int[] state = new int[8];
		int dec = bin;
		byte mok = 0, nmg = 0;
		for(int i=0; i<state.length; i++) {
			mok = (byte) (dec/2);
			nmg = (byte) (dec - mok*2);
			dec = mok;
			state[i] = nmg;
		}
		for(int i=0; i<state.length; i++) {
			Log.d(TAG, "state[" + i + "] = " + state[i]);
		}
		return state;
	}
	
	public static int covertFromBinaryToDec(int[] arr) {
		int state = 0;
		int temp = 0;
		for(int i=1; i<arr.length; i++) {
			System.out.println(i + " = " + arr[i]);
			temp += (int)Math.pow(2, i) * arr[i];
		}
		state = temp;
		System.out.println("state = " + state);
		return state;
	}
	
	public static int getRepeatPattern(Long s_time, Long e_time) {
		boolean flag = true;
		int repeat = 0;
		int count = 0;
		
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		c1.setTimeInMillis(s_time);
		c2.setTimeInMillis(e_time);

		int year1 = c1.get(Calendar.YEAR);
		int month1 = c1.get(Calendar.MONTH);
		int day1 = c1.get(Calendar.DAY_OF_MONTH);
		c1.set(year1, month1, day1);
		int year2 = c2.get(Calendar.YEAR);
		int month2 = c2.get(Calendar.MONTH);
		int day2 = c2.get(Calendar.DAY_OF_MONTH);
		c2.set(year2, month2, day2);
		
//		Log.d(TAG, "smillis = " + s_millis + ", ");
		while (flag) {
			int temp = c1.get(Calendar.DAY_OF_WEEK);

			if(count == 7)
				break;
			repeat += Math.pow(2, temp);
//			Log.d(TAG, "temp = " + temp + ", repeat = " + repeat);
			
			c1.add(Calendar.DAY_OF_MONTH, 1);
			flag = (c1.getTimeInMillis() < c2.getTimeInMillis()) ? true : false;
			count++;
		}
		
		return repeat;
	}
	
	
	
}
