package com.tjmedia.android.tjdebugger.version;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJJni;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : Jimmy
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class VersionAct extends Activity {
   
	private static final String TAG = "VersionAct"; 	
	private static final int		nText=10;
	private static BluetoothAdapter mBluetoothAdapter = null;

	SoundPoolManager mPoolManger;	
	BluetoothCheckThread btThread = null;
	Button mTitleExit;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.version_main);            
        initObjInfo();
        initViewID();
    }
	
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		if (null != btThread)
		{
			btThread.stop();
			btThread.stopThread();
		}
		Log.d(TAG, "onDestroy()");
//		TDMKMisc_Service.Finalize();
	}
	
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
//		mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
//		if (null != mBluetoothAdapter && !mBluetoothAdapter.isEnabled())
//		{
//			mBluetoothAdapter.enable();
//			String strBtName = getBluetoothAdaptername();
//			if (null == strBtName)
//			{
//				btThread = new BluetoothCheckThread();
//				btThread.start();
//			}
//		}
	}

	String getSerialNumber()
	{
		
		String sn = "?";
		return sn;
	}				
	
	String getBluetoothAdaptername()
	{		
		String name = null;
		if (null != mBluetoothAdapter)
		{
			name = mBluetoothAdapter.getName();			
		}
		if (null != name && name.length() > 0)
		{
			return name;
		}
		return null;
	}				
	
	class BluetoothCheckThread extends Thread {
    	public boolean FLAG_RUN = true;
		@Override
		public void run() {
			// TODO Auto-generated method stub
			while (FLAG_RUN) {
				try {
					String strBtname = getBluetoothAdaptername();
					if (null != strBtname)
					{
						this.FLAG_RUN = false; 								
						runOnUiThread(subthread);
						break;
					}
					sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
		public void stopThread() { 
	        this.FLAG_RUN = false; 
	    } 
	};
 	
	private Runnable subthread = new Runnable()
	{
		@Override
		public void run()
		{		
			mVersionResult[9] = getBluetoothAdaptername();
			Version.mComponets[9].setText(mVersionResult[9]);			
		}
	};
	
	void initViewID() {
//		TDMKMisc_Service.Initalize();
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		for(int i=0; i<Version.mComponets.length; i++) {
			Version.mComponets[i] = (TextView)  findViewById(Const.I_VERSION_INDEX[i]);
		}
		
		Version.mComponet13 = (Button)  findViewById(R.id.Version_main_index13);
		Version.mComponet13.setOnClickListener(mClickListener);
		
		Version.mComponet12 = (Button)  findViewById(R.id.Version_main_index12);
		Version.mComponet12.setOnClickListener(mClickListener);

//		mVersionResult[0] = TDMKMisc_Service.VERSION_Info_t.szBootloader.toString();
//		mVersionResult[1] = TDMKMisc_Service.VERSION_Info_t.szKernel.toString();
//		mVersionResult[2] = TDMKMisc_Service.VERSION_Info_t.szAndroid.toString();
//		mVersionResult[3] = TDMKMisc_Service.VERSION_Info_t.szWifi.toString();
//		mVersionResult[4] = TDMKMisc_Service.VERSION_Info_t.szBluetooth.toString();
//		mVersionResult[5] = TDMKMisc_Service.VERSION_Info_t.szTouchScreen.toString();
//		mVersionResult[6] = TDMKMisc_Service.VERSION_Info_t.szMiscDriver.toString();
//		mVersionResult[7] = TDMKMisc_Service.VERSION_Info_t.szMiscHelper.toString();
		
		for(int i=0; i<Version.mComponets.length; i++) {
			Version.mComponets[i].setText(mVersionResult[i]);
		}
//		TDMKMisc_Service.Finalize();
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}			
	}
	

	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
				case R.id.top_exit:
					finish();
					break;
				case R.id.Version_main_index12:
					setVersionEvent();
					break;
					
				case R.id.Version_main_index13:
					startActivity(new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS));
					break;
					
				default:
					break;
				
			}
		}
	};

	private void setVersionEvent() {
		new I_AsynTask().execute(10);
	}
	
	private int mCount = 0;
	ProgressDialog mProgress;
	String[] mVersionResult = new String[nText];
	class I_AsynTask extends AsyncTask<Integer, Integer, Integer> {
		protected void onPreExecute() {
			mCount = 0;
			mProgress = new ProgressDialog(VersionAct.this);
//			mProgress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			mProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mProgress.setMessage("Updating...");
//			mProgress.setCancelable(false);
			mProgress.setProgress(0);
//			mProgress.setButton("Cancel", new DialogInterface.OnClickListener() {
//				@Override
//				public void onClick(DialogInterface dialog, int which) {
//				// TODO Auto-generated method stub
//					cancel(true);
//				}
//			});
			mProgress.show();
		}
			
		protected Integer doInBackground(Integer... arg0) {
//			TDMKMisc_Service.Initalize();
			while (isCancelled() == false) { 
				if (mCount <= nText) {
					publishProgress(mCount);
				} else {
					break;
				}
				try { 
					Thread.sleep(100); 
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				mCount++;
			}
			return mCount;
		}
		
		
		protected void onProgressUpdate(Integer... progress) {
			int index = progress[0];
			switch (index) {
//			case 0:
//				mVersionResult[0] = TDMKMisc_Service.VERSION_Info_t.szBootloader.toString();
//				break;
//			case 1:
//				mVersionResult[1] = TDMKMisc_Service.VERSION_Info_t.szKernel.toString();
//				break;
//			case 2:
//				mVersionResult[2] = TDMKMisc_Service.VERSION_Info_t.szAndroid.toString();
//				break;
//			case 3:
//				mVersionResult[3] = TDMKMisc_Service.VERSION_Info_t.szWifi.toString();
//				break;
//			case 4:
//				mVersionResult[4] = TDMKMisc_Service.VERSION_Info_t.szBluetooth.toString();
//				break;
//			case 5:
//				mVersionResult[5] = TDMKMisc_Service.VERSION_Info_t.szTouchScreen.toString();
//				break;
//			case 6:
//				mVersionResult[6] = TDMKMisc_Service.VERSION_Info_t.szMiscDriver.toString();
//				break;
//			case 7:
//				mVersionResult[7] = TDMKMisc_Service.VERSION_Info_t.szMiscHelper.toString();
//				break;
				
			case 8:
				mVersionResult[8] = getSerialNumber();
				break;			
//			case 9:
//				try {
//					mVersionResult[9] = //getBluetoothAdaptername();						
//							TJJni.TJJNI_GetProperty("tdmk.system.bt.name");
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				break;												
//				
				
			default:
				break;
			}
			mProgress.setProgress(progress[0]);     
		}
		    
		protected void onPostExecute(Integer result) { 
			mProgress.dismiss();
			for(int i=0; i<Version.mComponets.length; i++) {
				Version.mComponets[i].setText(mVersionResult[i]);
			}
//			TDMKMisc_Service.Finalize();
		}
				    
	}
	
	static class Version {
		private static TextView[]		mComponets = new TextView[nText];		// Button display Viewer
		
		private static Button 			mComponet12;		// Update version info
		private static Button 			mComponet13;		// Android Device info
	}
    
}
	
	

