package com.tjmedia.android.tjdebugger.audio;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewDebug.FlagToString;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.bluetooth.BluetoothFileTransRecv.BtBuff;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.RegexManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJListItem;
import com.tjmedia.android.tjdebugger.common.ToastManager;
import com.tjmedia.android.tjdebugger.database.DatabaseManager;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 */

public class AudioAct extends Activity {   
   
	private static final String TAG = "AudioAct";
	
	Button mTitleExit;
	static SoundPoolManager mPoolManger;
	

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.audio_main);    
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");
		
	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
		stopAudio(getApplicationContext());
		releaseResources();
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private static final Uri sArtworkUri = Uri.parse("content://media/external/audio/albumart");
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
         
		if (resultCode == RESULT_FIRST_USER) {
        	String uri = data.getStringExtra("flag");
        	Log.d(TAG, "onActivityResult()=" +uri);
        	boolean result = RegexManager.isAudioFormatInfo(uri);
        	if (!result) {
        		ToastManager.showToast(getApplicationContext(), "The media format is not supported", Toast.LENGTH_SHORT);
        		return;
        	}
        	File filename = new File(uri);
        	SoundPoolManager.I_FILE_URL = Uri.fromFile(filename);
        	Uri uri2 = Uri.fromFile(filename);
        	
        	Log.d(TAG, "" + uri2.toString()
        			+ ",11 =  " + uri2.getEncodedFragment()
        			+ ",22 = " + uri2.getFragment()
        			+ ",22 = " + uri2.getLastPathSegment()
        			+ ",22 = " + uri2.getPath()
        			);;
        			
//        	TJListItem item = mDBMgr.getAudioAlbumsInfo(getApplicationContext(), ("file://"+uri));
        	TJListItem item = mDBMgr.getAudioAlbumsInfo(getApplicationContext(), uri);
        	
//        	int id = 1;
        	Uri uri_add = ContentUris.withAppendedId(sArtworkUri, Integer.valueOf(item.getColumns(1)));
        	Log.d(TAG, "uri_add=" + uri_add + "'");
        	InnerSound.mFileExplorer02.setImageURI(uri_add);
        	InnerSound.mFileExplorer03.setText("TITLE : "+ item.getColumns(2));
        	InnerSound.mFileExplorer04.setText("ARTIST : " + item.getColumns(3));
        	InnerSound.mFileExplorer05.setText("ALBUM : " + item.getColumns(4));
        	
        	
        	
//        	Bitmap img = BitmapFactory.decodeFile(item.getColumns(2));
//        	InnerSound.mFileExplorer02.setImageBitmap(img);
//        	Log.d(TAG, "File Name=" +filename.getName() + ", " + imgPreview);
//        	String temp = item.getColumns(2);
//        	Uri imgPreview = Uri.parse(uri);
//        	InnerSound.mFileExplorer02.setImageBitmap(img);
//        	filename = new File(item.getColumns(2));
//        	Log.d(TAG, "File Name=" +filename.getName() + "'");
//        	InnerSound.mFileExplorer02.setImageURI(Uri.fromFile(filename));
        	
        	stopAudio(getApplicationContext());
        	mPLAY_STATUS = false;
        	playAudio();
        }
        super.onActivityResult(requestCode, resultCode, data);
    } 

	
	private void initObjInfo() {
	}
    
	
	AudioManager mAudioMgr;
	DatabaseManager mDBMgr;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext(), 1);
		}

		for(int i=0; i<InnerSound.mComponets.length; i++) {
			InnerSound.mComponets[i] = (Button) findViewById(Const.I_AUDIO_INDEX[i]);
			InnerSound.mComponets[i].setOnClickListener(mClickListener);
		}
//		InnerSound.mComponets[3].setOnTouchListener(mTouchListener);
//		InnerSound.mComponets[6].setOnTouchListener(mTouchListener);
//		InnerSound.mComponets[3].setOnLongClickListener(mLongSeekLeftClickListener);
//		InnerSound.mComponets[6].setOnLongClickListener(mLongSeekRightClickListener);
		
		InnerSound.mSeekBar01 = (SeekBar) findViewById(R.id.Audio_Main_SeekBar_Index01);
		InnerSound.mSeekBar01.setOnSeekBarChangeListener(mSeekListener);
		InnerSound.mSeekBar02 = (TextView) findViewById(R.id.Audio_Main_SeekBar_Index02);
		
		InnerSound.mVolumes[0] = (Button) findViewById(R.id.Audio_Main_Volume_Index01);
		InnerSound.mVolumes[1] = (Button) findViewById(R.id.Audio_Main_Volume_Index02);
		InnerSound.mVolumes[2] = (Button) findViewById(R.id.Audio_Main_Volume_Index03);
		InnerSound.mVolumes[3] = (Button) findViewById(R.id.Audio_Main_Volume_Index04);
		for (int i=0; i<InnerSound.mVolumes.length; i++) {
			InnerSound.mVolumes[i].setOnClickListener(mClickListener);	
		}
		
		InnerSound.mRecording = (ImageView) findViewById(R.id.Audio_Main_Recording_Index01);
		setVolumeControlStream(AudioManager.STREAM_MUSIC);
		mAudioMgr = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		
		InnerSound.mFileExplorer01 = (Button) findViewById(R.id.Audio_Main_FILE_Index01);
		InnerSound.mFileExplorer02 = (ImageView) findViewById(R.id.Audio_Main_FILE_Index02);
		InnerSound.mFileExplorer03 = (TextView) findViewById(R.id.Audio_Main_FILE_Index03);
		InnerSound.mFileExplorer04 = (TextView) findViewById(R.id.Audio_Main_FILE_Index04);
		InnerSound.mFileExplorer05 = (TextView) findViewById(R.id.Audio_Main_FILE_Index05);
		InnerSound.mFileExplorer01.setOnClickListener(mClickListener);
//		InnerSound.mFileExplorer02.setVisibility(View.INVISIBLE);
		
		mDBMgr = new DatabaseManager(getApplicationContext());
		
	}
	
	private void stopResurces() {
		mLoopHandler.stop();
		mRecordLoopHandler.stop();
	}
	
	private void releaseResources() {
		SoundPoolManager.I_FILE_URL = null;
		
		if (mPoolManger != null) {
			mPoolManger.release();
			mPoolManger = null;
		}
		
		if (mPlayer != null) {
			mPlayer.stop();
			mPlayer.release();
			mPlayer = null;
		}
		if (mRecorder != null) {
			mRecorder.stop();
			mRecorder.release();
			mRecorder = null;
		}
	}
	
	boolean mRepeat = false;
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
				case R.id.top_exit:
					finish();
					break;
				// Speaker Components 11 ~ 13 
				case R.id.Audio_Main_Index11:
					mPoolManger.play(SoundPoolManager.I_SOUNDID_LEFT, false);
					break;
				case R.id.Audio_Main_Index12:
					mPoolManger.play(SoundPoolManager.I_SOUNDID_RIGHT, false);
					break;
				case R.id.Audio_Main_Index13:
					mPoolManger.play(SoundPoolManager.I_SOUNDID_ALL, false);
					break;
					
				// Play Components 14 ~ 18 
				case R.id.Audio_Main_Index14:
					Log.d(TAG, "OnClickListener_left");
					mPoolManger.seekMediaSound(getApplicationContext(), false);
					break;
				case R.id.Audio_Main_Index15:
					Log.d(TAG, "mPLAY_STATUS=" + mPLAY_STATUS);
					playAudio();
					break;
				case R.id.Audio_Main_Index16:
					stopAudio(getApplicationContext());
					break;
				case R.id.Audio_Main_Index17:
					Log.d(TAG, "OnClickListener_right");
					mPoolManger.seekMediaSound(getApplicationContext(), true);
					break;
				case R.id.Audio_Main_Index18:
					if (mRepeat) {
						mPoolManger.setRepeatMedia(SoundPoolManager.SE_PLAYTEST_INDEX01, false);
						InnerSound.mComponets[7].setText("REPEAT OFF");
						mRepeat = false;
					} else {
						mPoolManger.setRepeatMedia(SoundPoolManager.SE_PLAYTEST_INDEX01, true);
						InnerSound.mComponets[7].setText("REPEAT ON");
						mRepeat = true;
					}
					break;
				// Recording Components 19 ~ 20 
				case R.id.Audio_Main_Index19:	// Rec Start
				{
					String ext = Environment.getExternalStorageState();
					if (ext.equals(Environment.MEDIA_MOUNTED))
					{
						setRecordingVoice();
					}
					else
					{
						ToastManager.showToast(getApplicationContext(), "NG,SDCARD", Toast.LENGTH_SHORT);
					}
					break;
				}
				case R.id.Audio_Main_Index20:	// Stop
				{
					String ext = Environment.getExternalStorageState();
					if (ext.equals(Environment.MEDIA_MOUNTED))
					{					
						playRecordingVoice();
					}
					else
					{
						ToastManager.showToast(getApplicationContext(), "NG,SDCARD", Toast.LENGTH_SHORT);
					}
					break;
				}
				// Volume Components 01 ~ 04
				case R.id.Audio_Main_Volume_Index01:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 1);
					break;
				case R.id.Audio_Main_Volume_Index02:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 
							mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/4, 1);
					break;
				case R.id.Audio_Main_Volume_Index03:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 
							mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/2, 1);
					break;
				case R.id.Audio_Main_Volume_Index04:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 
							mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 1);
					break;
				case R.id.Audio_Main_FILE_Index01:
//					mPLAY_STATUS = true;
//					playAudio();
					Intent i = new Intent();
					i.setAction("tjmedia.intent.ACTION_EXPLORER");			
					startActivityForResult(i,RESULT_FIRST_USER);
					break;
				default:
					break;
			}
		}
	};
	
	
	/*
	 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
	 * 		[Play Test]
	 * 
	 */
	public static boolean mPLAY_STATUS = false;
	private void playAudio() {
//		SoundPoolManager.FLAG_OnCOMPLETELISTENER = false;
		if (mPLAY_STATUS) {
//			ToastManager.showToast(getApplicationContext(), "PAUSE", Toast.LENGTH_SHORT);
			mPoolManger.pause(SoundPoolManager.SE_PLAYTEST_INDEX01);
			mLoopHandler.stop();
			InnerSound.mComponets[4].setText("PLAY");
			mPLAY_STATUS = false;
		} else {
			totalTime = mPoolManger.getDuration(SoundPoolManager.SE_PLAYTEST_INDEX01);
			mLoopHandler.start(getApplicationContext());
			mPoolManger.play(SoundPoolManager.SE_PLAYTEST_INDEX01);
			if (mRepeat) {
				mPoolManger.setRepeatMedia(SoundPoolManager.SE_PLAYTEST_INDEX01, true);
			}
			InnerSound.mComponets[4].setText("PAUSE");
			mPLAY_STATUS = true;
		}
	}
	
	public static void stopAudio(Context context) {
		ToastManager.showToast(context, "STOP", Toast.LENGTH_SHORT);
		mLoopHandler.stop();
		mPoolManger.stop(context, SoundPoolManager.SE_PLAYTEST_INDEX01);
		InnerSound.mComponets[4].setText("PLAY");
		totalTime = 0;
		updateEvent();
		mPLAY_STATUS = false;
	}
	
	public static final int FREQUENCY = 1000;
	public static LoopHandler mLoopHandler = new LoopHandler();

	public static void loop() {
		Log.d(TAG, "loop()");
//		if (SoundPoolManager.FLAG_OnCOMPLETELISTENER) {
//			stopAudio(mLoopHandler.context);
//			return;
//		}
		updateEvent();
		mLoopHandler.sleep(FREQUENCY);
	}
	
	public static class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private Context context;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		public void stop() {
			bStop = true;
		}

		private void start(Context context) {
			bStop = false;
			this.context = context;
			loop();
		}
	};
	
	static int totalTime = 0;
	private static void updateEvent() {
		int currentTime = 0;
		float tempTime = 0;
		if (currentTime < totalTime) {
			tempTime  = currentTime = mPoolManger.getCurrentTime(SoundPoolManager.SE_PLAYTEST_INDEX01);
			currentTime = totalTime - currentTime;
		} else {
			currentTime = 0;
		}
		InnerSound.mSeekBar02.setText("" + getTimeFormatter(currentTime));
		float progress = ((tempTime / totalTime) * 500.0f);
//		Log.d(TAG, "progress=" + progress);
		InnerSound.mSeekBar01.setProgress((int)progress);
	}
	
	
	static Calendar c1 = Calendar.getInstance();
	private static String getTimeFormatter(int currentTime) {
		c1.set(1970, 0, 1, 0, 0, 0);
//		c1.setTimeInMillis(currentTime);
		int var = currentTime / 1000;
		c1.add(Calendar.MINUTE, var);
		Date date = c1.getTime();
//		StringBuilder sb = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		String temp = sdf.format(date);
//		String[] arr = temp.split(":");
//		for(int i=0; i<arr.length; i++) {
//			sb.append(arr[i]);
//		}
//		sb.append("00");
//		return sb.toString();
		return temp;
	}
	
	private SeekBar.OnSeekBarChangeListener mSeekListener =new SeekBar.OnSeekBarChangeListener() {
		boolean wasPlaying = false;
		
		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
		}
		
		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
			wasPlaying = mPoolManger.isPlaying(SoundPoolManager.SE_PLAYTEST_INDEX01);
			if (wasPlaying) {
				mPLAY_STATUS = true;
				playAudio();
			}
		}
		int count = 0;
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress,
				boolean fromUser) {
			// TODO Auto-generated method stub
			if (fromUser) {
				float msec = 0.0f;
				msec = (progress / 500.0f) * mPoolManger.getDuration(SoundPoolManager.SE_PLAYTEST_INDEX01);
				mPoolManger.setCurrentTime(SoundPoolManager.SE_PLAYTEST_INDEX01, (int)msec);
				mPLAY_STATUS = false;
				playAudio();
			}
		}
	};
	
	
//	// Update Seek Loop
//	public SeekLoopHandler mSeekLoopHandler = new SeekLoopHandler();
//	public void seekLoop() {
//		if (mSeekLoopHandler.FLAG_CLICK == true) {
//			mPoolManger.seekMediaSound(getApplicationContext(), true);
//		} else {
//			mPoolManger.seekMediaSound(getApplicationContext(), false);
//		}
//		updateEvent();
//		mSeekLoopHandler.sleep(FREQUENCY);
//	}
//	
//	class SeekLoopHandler extends Handler {
//		private int count = 0;
//		private boolean bStop;
//		// FLAG_CLIJCK, if false is seeking left, true otherwise. 
//		boolean FLAG_CLICK = false;
//
//		@Override
//		public void handleMessage(Message msg) {
//			if (bStop == false) {
//				seekLoop();
//			}
//			super.handleMessage(msg);
//		}
//
//		private void sleep(long delayMillis) {
//			this.removeMessages(0);
//			sendMessageDelayed(obtainMessage(0), delayMillis);
//		}
//
//		private void stop() {
//			bStop = true;
//		}
//
//		private void start() {
//			bStop = false;
//			seekLoop();
//		}
//	};
//	
//	private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
//	int count = 0;
//	@Override
//	public boolean onTouch(View v, MotionEvent event) {
//		// TODO Auto-generated method stub
//		final int action = event.getAction();
////		Log.d(TAG, "View.TAG=" + v.getId() + ", " + action);
//		switch (action & MotionEvent.ACTION_MASK) {
//			case MotionEvent.ACTION_DOWN:
//				v.setFocusable(true);
//				if (count == 0) {
//					if (R.id.Audio_Main_Index14 == v.getId()) {
//						mSeekLoopHandler.FLAG_CLICK = false;	// left Seek
//						mSeekLoopHandler.start();
//					} else {
//						mSeekLoopHandler.FLAG_CLICK = true;	// right Seek
//						mSeekLoopHandler.start();
//					}
//					count++;
//				}
//				break;
//			case MotionEvent.ACTION_UP:
//					v.setFocusable(false);
//					mSeekLoopHandler.stop();
//					count = 0;
//				break;
//        	case R.id.Audio_Main_Index14:
//        		break;
//        	case R.id.Audio_Main_Index17:
//        		break;
//		}
//		return true;
//	}
//};


//private View.OnLongClickListener mLongSeekLeftClickListener = new View.OnLongClickListener() {
//	@Override
//	public boolean onLongClick(View v) {
//		// TODO Auto-generated method stub
//		Log.d(TAG, "mLongSeekLeftClickListener()");
//		FLAG_LONG_LOOP = true;
//		FLAG_LONG_CLICK = false;
//		mSeekLoopHandler.start();
//		return false;
//	}
//};

//private View.OnLongClickListener mLongSeekRightClickListener = new View.OnLongClickListener() {
//	@Override
//	public boolean onLongClick(View v) {
//		// TODO Auto-generated method stub
//		Log.d(TAG, "mLongSeekRightClickListener()");
//		FLAG_LONG_LOOP = true;
//		FLAG_LONG_CLICK = true;
//		mSeekLoopHandler.start();
//		return false;
//	}
//};
	
	/*
	 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
	 * 		[Record Test]
	 * 
	 */
	final private static String RECORDED_FILE = "/sdcard/tjdebugger_recorded.mp4";
    MediaPlayer mPlayer;
    MediaRecorder mRecorder;
    boolean FLAT_RECORDING_STATUS = true;
    boolean FLAT_PLAYING_STATUS = true;
    
	synchronized private void setRecordingVoice() {
		if (!FLAT_PLAYING_STATUS) {
			ToastManager.showToast(getApplicationContext(), "Try to stop the play", Toast.LENGTH_SHORT);
			return;
		}
		
		if (FLAT_RECORDING_STATUS) {
			if (mRecorder != null) {
	        	mRecorder.stop();
	        	mRecorder.reset();
	            mRecorder.release();
	            mRecorder = null;
	        }
	
	        mRecorder = new MediaRecorder();
	
	        mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
	        mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
	        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
	        mRecorder.setOutputFile(RECORDED_FILE);
	
	        try {
	        	mRecorder.prepare();
	        	Log.e("SampleAudioRecorder", "Start()");
	        	mRecorder.start();
	        } catch (Exception ex) {
	            Log.e("SampleAudioRecorder", "Exception : ", ex);
	        }
	        ToastManager.showToast(getApplicationContext(), "Recording", Toast.LENGTH_SHORT);
	        InnerSound.mComponets[8].setText(getResources().getText(R.string.audio_main_index20));
	        mRecordLoopHandler.start();
	        FLAT_RECORDING_STATUS = false;
		} else {
	        if (mRecorder == null)
	            return;
	
	        mRecorder.stop();
	        mRecorder.reset();
	        mRecorder.release();
	        mRecorder = null;
	
	        ToastManager.showToast(getApplicationContext(), "Stop recording", Toast.LENGTH_SHORT);
	        InnerSound.mComponets[8].setText(getResources().getText(R.string.audio_main_index19));
	        mRecordLoopHandler.stop();
	        InnerSound.mRecording.setImageResource(mRecordingImages[0]);
	        FLAT_RECORDING_STATUS = true;
		}
	}
	
	private void playRecordingVoice() {
		if (!FLAT_RECORDING_STATUS) {
			ToastManager.showToast(getApplicationContext(), "Try to stop recording", Toast.LENGTH_SHORT);
			return;
		}
		
		if (FLAT_PLAYING_STATUS) {
			if (mPlayer != null) {
	        	mPlayer.stop();
	            mPlayer.release();
	            mPlayer = null;
	        }
	        try {
	        	mPlayer = new MediaPlayer ();
	        	mPlayer.setOnCompletionListener(mOnCompleteListener);
	
	            mPlayer.setDataSource(RECORDED_FILE);
	            mPlayer.prepare();
	            mPlayer.start();
	        } catch (Exception e) {
	            Log.w(TAG, "", e);
	            Toast.makeText(getApplicationContext(), "Try to record a file", Toast.LENGTH_LONG).show();
	            return;
	        }
	        ToastManager.showToast(getApplicationContext(), "PLAY", Toast.LENGTH_SHORT);
	        InnerSound.mComponets[9].setText(getResources().getText(R.string.audio_main_index22));
	        FLAT_PLAYING_STATUS = false;
		} else {
	        if (mPlayer == null)
	        	return;
	        mPlayer.stop();
	        mPlayer.release();
	        mPlayer = null;
	        ToastManager.showToast(getApplicationContext(), "STOP", Toast.LENGTH_SHORT);
	        InnerSound.mComponets[9].setText(getResources().getText(R.string.audio_main_index21));
	        FLAT_PLAYING_STATUS = true;
		}
	}
	
	MediaPlayer.OnCompletionListener mOnCompleteListener = new MediaPlayer.OnCompletionListener() {
		@Override
		public void onCompletion(MediaPlayer mp) {
			// TODO Auto-generated method stub
			Log.d(TAG, "mOnCompleteListener");
			FLAT_PLAYING_STATUS = false;
			playRecordingVoice();
			
		}
	};
	
	
	public final int RECORD_FREQUENCY = 1000;
	public RecordLoopHandler mRecordLoopHandler = new RecordLoopHandler();
	int[] mRecordingImages = {R.drawable.btn_circle_focused, R.drawable.btn_circle_pressed};
	
	public void recordLoop() {
		Log.d(TAG, "recordLoop()");
		mRecordLoopHandler.flag_image = mRecordLoopHandler.flag_image == 0 ? 1 : 0;
		InnerSound.mRecording.setImageResource(mRecordingImages[mRecordLoopHandler.flag_image]);
		mRecordLoopHandler.sleep(RECORD_FREQUENCY);
	}
	
	class RecordLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private int flag_image = 0;

		@Override
		public void handleMessage(Message msg) {
			if (bStop == false) {
				recordLoop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			recordLoop();
		}
	};
	
	static class InnerSound {
		
		/*
		 *  Components {
		 * 			left, right, All, 
		 * 			|<<, Play/Pause, STOP, >>|, Repeat
		 * 			RecStart/Stop, Play/Stop,
		 *  } 
		 */
		private static Button[] 		mComponets = new Button[10];
		
		private static SeekBar			mSeekBar01;
		private static TextView		mSeekBar02;
		
		private static Button[]			mVolumes = new Button[4];
		
		private static ImageView		mRecording;
		private static Button			mFileExplorer01;
		private static ImageView		mFileExplorer02;
		private static TextView		mFileExplorer03;	// Title
		private static TextView		mFileExplorer04;	// Artist
		private static TextView		mFileExplorer05;	// AlbumInfo
	}
	
	
	
	/*
	 * ********************************************************
	 * Demo Test
	 * ********************************************************
	 */
//	class MediaThread extends Thread {
//	boolean timeFlag = false;
//	int totalTime = 0;
//	int currentTime = 0;
//	public void run() {
//		// TODO Auto-generated method stub
//		super.run();
//		totalTime = mPoolManger.getDuration(SoundPoolManager.SE_PLAYTEST_INDEX01);
//		try {
//			while (!timeFlag) {
//				if (totalTime < currentTime) timeFlag = true;
//				
//				if (mPoolManger != null) {
//					currentTime = mPoolManger.getCurrentTime(SoundPoolManager.SE_PLAYTEST_INDEX01);
//					InnerSound.mSeekBar02.setText("" + currentTime);
////					Log.d(TAG, "currentTime=" + currentTime);
//				}
//				sleep(1000);
//			}
//		} catch (InterruptedException ie) {
//			ie.printStackTrace();
//		} finally {
//			timeFlag = false;
//			totalTime = 0;
//			currentTime = 0;
//		}
//	}
//	
//	public void stopMedia() {
//		timeFlag = false;
//	}
//	
//}
	
}
	
	

