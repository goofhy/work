/**
 * Copyright (C) 2010 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Mobile Communication Division,
 * Digital Media & Communications Business, Samsung Electronics Co., Ltd.
 *
 * This software and its documentation are confidential and proprietary
 * information of Samsung Electronics Co., Ltd.  No part of the software and
 * documents may be copied, reproduced, transmitted, translated, or reduced to
 * any electronic medium or machine-readable form without the prior written
 * consent of Samsung Electronics.
 *
 * Samsung Electronics makes no representations with respect to the contents,
 * and assumes no responsibility for any errors that might appear in the
 * software and documents. This publication and the contents hereof are subject
 * to change without notice.
 */
package com.tjmedia.android.tjdebugger.common;


import java.io.IOException;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedManager {
	private final static String TAG = "SharedManager";

	private static final String PREFS_TJDEBUGGER = "tjdebugger";
	
	public static final String PREFS_CAMERA_MODE = "camera_mode";
	public static final String PREFS_CAMERA_FLASH = "camera_flash";
	public static final String PREFS_CAMERA_BALANCE = "camera_balance";
	public static final String PREFS_CAMERA_RESOLUTION = "camera_resolution";
	public static final String PREFS_BRIGHTNESS_LEVEL = "brightness_level";
	public static final String PREFS_APP_VERSION_NAME = "version_name";
	public static final String PREFS_APP_VERSION_CODE = "version_code";
	public static final String PREFS_WIFI_STATUS = "wifi_status";
	public static final String PREFS_BLUETOOTH_STATUS = "bluetooth_status";
	public static final String PREFS_AUDIO_VOLUME = "audio_volume";
	
	public static void setSettingCameraMode(Context context, int var){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putInt(PREFS_CAMERA_MODE, var);
		ed.commit();
	}
	
	public static void setSettingCameraFlash(Context context, int var){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putInt(PREFS_CAMERA_FLASH, var);
		ed.commit();
	}
	
	public static void setSettingCameraBalance(Context context, int var){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putInt(PREFS_CAMERA_BALANCE, var);
		ed.commit();
	}
	
	public static void setSettingCameraSetting(Context context, int var){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putInt(PREFS_CAMERA_RESOLUTION, var);
		ed.commit();
	}
	
	public static void setSettingBrightnessLevel(Context context, int var){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putInt(PREFS_BRIGHTNESS_LEVEL, var);
		ed.commit();
	}
	
	public static void setVersionName(Context context, String var) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putString(PREFS_APP_VERSION_NAME, var);
		ed.commit();
	}
	
	public static void setVersionCode(Context context, int var) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putInt(PREFS_APP_VERSION_NAME, var);
		ed.commit();
	}
	
	public static void setWifiStatus(Context context, boolean bool) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putBoolean(PREFS_WIFI_STATUS, bool);
		ed.commit();
	}
	
	public static void setBluetoothStatus(Context context, boolean bool) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putBoolean(PREFS_BLUETOOTH_STATUS, bool);
		ed.commit();
	}
	
	public static void setAudioVolume(Context context, int var) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		SharedPreferences.Editor ed = pref.edit();
		ed.putInt(PREFS_AUDIO_VOLUME, var);
		ed.commit();
	}
	
	public static int getAudioVolume(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getInt(PREFS_AUDIO_VOLUME, 0);
	}
	
	public static boolean getBluetoothStatus(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getBoolean(PREFS_BLUETOOTH_STATUS, false);
	}
	
	public static boolean getWifiStatus(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getBoolean(PREFS_WIFI_STATUS, false);
	}
	
	public static String getVersionName(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getString(PREFS_APP_VERSION_NAME, "0");
	}
	
	public static int getVersionCode(Context context) {
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getInt(PREFS_APP_VERSION_CODE, 0);
	}
	
	public static int getSettingCameraMode(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getInt(PREFS_CAMERA_MODE, 2);
	}
	
	public static int getSettingCameraFlash(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getInt(PREFS_CAMERA_FLASH, 0);
	}
	
	public static int getSettingCameraBalance(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getInt(PREFS_CAMERA_BALANCE, 4);
	}
	
	public static int getSettingCameraSetting(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getInt(PREFS_CAMERA_RESOLUTION, 0);
	}
	
	public static int getSettingBrightnessLevel(Context context){
		SharedPreferences pref = context.getSharedPreferences(PREFS_TJDEBUGGER, Context.MODE_PRIVATE);
		return pref.getInt(PREFS_BRIGHTNESS_LEVEL, 10);
	}
	

	
}
