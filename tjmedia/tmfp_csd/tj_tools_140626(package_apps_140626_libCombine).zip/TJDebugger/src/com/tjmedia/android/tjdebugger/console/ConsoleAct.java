package com.tjmedia.android.tjdebugger.console;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

import org.w3c.dom.Text;

//import junit.runner.Version;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.text.method.ScrollingMovementMethod;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJArrayAdapter;
import com.tjmedia.android.tjdebugger.common.TJListItem;
import com.tjmedia.android.tjdebugger.common.ToastManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class ConsoleAct extends Activity {   
   
	private static final String TAG = "ConsoleAct"; 	

	SoundPoolManager mPoolManger;
	
	Button mTitleExit;	
	
	com.tjmedia.service.ITJMedia_ServiceInterface TJService;
	
	DrawLoopHandler mDrawHandler;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.console_main);    
        
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		initObjInfo();		
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		removeModulesInfo();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private ServiceConnection con = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
//			TJService = com.tjmedia.serviceapi.ITJMedia_ServiceInterface.Stub.asInterface(service);
			TJService = com.tjmedia.service.ITJMedia_ServiceInterface.Stub.asInterface(service);
			if (TJService == null)
			{
				Log.d(TAG, "onServiceConnected>------------ TJService is NULL ------------");
			}
			else
			{
				Log.d(TAG, "onServiceConnected>------------ TJService = " + TJService);
			}			
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			Log.d(TAG, "onServiceDisconnected> TJService = " + TJService);		
			TJService = null;
		}		
	};
	
	
	private void initObjInfo() {
		
		Intent intent = new Intent("com.tjmedia.service.TJMedia_ServiceInterface");
		bindService(intent, con, Context.BIND_AUTO_CREATE);
		
		mDrawHandler = new DrawLoopHandler();
		mDrawHandler.sleep(1000);
		mDrawHandler.start();
	}
	
	private void removeModulesInfo() {
			
		mDrawHandler.stop();
		if (TJService != null)
			unbindService(con);
		
	}
	
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		Console.mComponet01 = (EditText) findViewById(R.id.EditTextConsoleInput);
		Console.mComponet02 = (TextView) findViewById(R.id.EditTextConsoleOutput);
		Console.mCButton01 = (Button) findViewById(R.id.button1);
		Console.mCButton02 = (Button) findViewById(R.id.button2);
		Console.mCButton03 = (Button) findViewById(R.id.button3);
		Console.mCButton04 = (Button) findViewById(R.id.button4);
		
		Console.mCButton01.setOnClickListener(mClickListener);
		Console.mCButton02.setOnClickListener(mClickListener);
		Console.mCButton03.setOnClickListener(mClickListener);
		Console.mCButton04.setOnClickListener(mClickListener);
		
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
		Console.mComponet02.setMovementMethod(new ScrollingMovementMethod());
		
		Console.mComponet01.setOnEditorActionListener(new OnEditorActionListener() {
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				int i;
				if (actionId == EditorInfo.IME_ACTION_DONE)
				{
					CharSequence t = v.getText();
//					char[] text = new char[t.length()];
					String szText = "";
					for (i=0; i<t.length(); i++) {
//						text[i] = t.charAt(i);
						szText += t.charAt(i);
					}
					
					Log.d(TAG, "input:" +szText);
					String ret = null;
					try {
						ret = TJService.SystemCall(szText,true);
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Console.mComponet02.setText(ret);								
				}
				return false;

			}
		});
	}
	String msg = "";
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.button1:
				msg = "Do you want to the logcat ? (about 1 min)";
				removeDialog(DIALOG_POPUP_ITEM01);
				showDialog(DIALOG_POPUP_ITEM01);
				mMode = 0;
				break;
			case R.id.button2:
				msg = "Do you want to save the logcat ? (about 1 min)";
				removeDialog(DIALOG_POPUP_ITEM01);
				showDialog(DIALOG_POPUP_ITEM01);
				mMode = 1;
				//SaveLogcat();
				break;
			case R.id.button3:
				msg = "Do you want to the Dmesge ? (about 1 min)";
				removeDialog(DIALOG_POPUP_ITEM01);
				showDialog(DIALOG_POPUP_ITEM01);
				mMode = 2;
//				Dmesg();
				break;	
			case R.id.button4:
				msg = "Do you want to save the Dmesge? (about 1 min)";
				removeDialog(DIALOG_POPUP_ITEM01);
				showDialog(DIALOG_POPUP_ITEM01);
				mMode = 3;
				//SaveDmesg();
				break;					
			case R.id.top_exit:
				finish();
				break;
			default:
				break;
				
			}
		}
	};
	
	final int DIALOG_POPUP_ITEM01 = 10;
	int mMode = 0;
	protected Dialog onCreateDialog(int id) {
		switch(id) {
			case DIALOG_POPUP_ITEM01:
				AlertDialog.Builder b = new AlertDialog.Builder(this);
				b.setIcon(R.drawable.ic_launcher)
				.setTitle("Console Info")
				.setMessage(msg)
				.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						new I_AsynTask().execute(DIALOG_POPUP_ITEM01);
					}
				})
				.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						finish();
					}
				});
				return b.create();				
		}
		return super.onCreateDialog(id);
	};	
	
	ProgressDialog mProgress;
	class I_AsynTask extends AsyncTask<Integer, Integer, Integer> {
		int mCount = 0;
		protected void onPreExecute() {
			mCount = 0;
			mProgress = new ProgressDialog(ConsoleAct.this);
			mProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mProgress.setMessage("Progressing...");
			mProgress.setProgress(0);
			mProgress.show();
		}
			
		protected Integer doInBackground(Integer... arg0) {
			while (isCancelled() == false) { 
				if (mCount <= 4) {
					publishProgress(mCount);
				} else {
					break;
				}
				try { 
					Thread.sleep(200); 
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				mCount++;
			}
			return mCount;
		}
		protected void onProgressUpdate(Integer... progress) {
			mProgress.setProgress(progress[0]);  
		}
		    
		protected void onPostExecute(Integer result) { 
			switch(mMode)
			{
				case 0:	Logcat();	break;
				case 1:	SaveLogcat();	break;
				case 2:	Dmesg();	break;
				case 3:	SaveDmesg();	break;
			}
			mProgress.dismiss();			
		}
		    
	}	
	public class DrawLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;
		private long mDelay = 1000;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {								
				Console.mComponet02.invalidate();	
				sendMessageDelayed(obtainMessage(0), mDelay);
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			mDelay = delayMillis;
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}
		
		public boolean isStoped() {
			return bStop;
		}
		
		public void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;							
		}
	};
	
	void Logcat()
	{
		try {			
			Console.mComponet02.setText(TJService.SystemCall("logcat -t 1000 -v time",true));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	void Dmesg()
	{
		try {			
			Console.mComponet02.setText(TJService.SystemCall("dmesg",true));
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	void SaveLogcat()
	{
		Date date = new Date();
		int m = date.getMinutes();
		int s = date.getSeconds();
		int h = date.getHours();
		
		String uriString = "/storage/usb/";
		File file = new File(uriString);
		File[] files = file.listFiles();
		long leng = file.length();
		// Lost.dir directory check
		if (leng > 0) {        		
    		try {
				TJService.SystemCall("logcat -t 1000 -v time",true);
        		TJService.SystemCall("sync",false);
        		TJService.SystemCall("cp /data/data/com.tjmedia.service/files/ret.txt /storage/usb/logcat_" + h + "_" + m + "_" + s,false);
        		TJService.SystemCall("sync",false);		        		
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		ShowConsoleMessageBox2("Result logcat", 1);
		}
		else
		{
			ShowConsoleMessageBox2("Result logcat", 0);
		}    		
	}
	
	void SaveDmesg()
	{
		Date date = new Date();
		int m = date.getMinutes();
		int s = date.getSeconds();
		int h = date.getHours();
		
		String uriString = "/storage/usb/";
		File file = new File(uriString);
		long leng = file.length();
		File[] files = file.listFiles();
		// Lost.dir directory check
		if (leng > 0) {        		
    		try {
				TJService.SystemCall("dmesg",true);
        		TJService.SystemCall("sync",false);
        		TJService.SystemCall("cp /data/data/com.tjmedia.service/files/ret.txt /storage/usb/dmesg_" + h + "_" + m + "_" + s,false);
        		TJService.SystemCall("sync",false);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	  
    		ShowConsoleMessageBox2("Result dmesg", 1);
		}  
		else
		{
			ShowConsoleMessageBox2("Result dmesg", 0);
		}
	}	
	
	private	AlertDialog ad2 = null;
	public void ShowConsoleMessageBox2(String Title, int nMode)
	{
		Context mContext = this;	
		EditText mPassword = null;
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.console_dialog2,(ViewGroup) findViewById(R.id.console_dialog_layout_root2));
        //setContentView(R.layout.custom_dialog);        
        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle(Title);
        aDialog.setView(layout);        
        
        Console.mConsoleOutput2 = (TextView)layout.findViewById(R.id.TextViewConsoleOutput);
        
        Console.mConsoleOutput2.setMovementMethod(new ScrollingMovementMethod());	
		
		String szResult = "";
		
		switch(nMode)
		{
			case 0:
				try {
					szResult = "<<USB ERROR>>\n" + TJService.SystemCall("ls -l /storage/usb",true);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 1: 
				try {
					szResult =TJService.SystemCall("ls -l /storage/usb",true);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
		}
		
		Console.mConsoleOutput2.setText(szResult);
             		
        aDialog.setNegativeButton("exit", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which)
            {           					
            }
        });        
                
        ad2 = aDialog.create();        
        ad2.show();        
	}				
	
	static class Console {
		private static EditText mComponet01;	//input
		private static TextView mComponet02;	//output
		private static Button mCButton01;
		private static Button mCButton02;
		private static Button mCButton03;
		private static Button mCButton04;
		
		private static TextView mConsoleOutput2;	//output
	}
    
}
	
	

