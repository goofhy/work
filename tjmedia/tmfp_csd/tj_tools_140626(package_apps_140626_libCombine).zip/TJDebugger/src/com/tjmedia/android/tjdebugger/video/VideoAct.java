package com.tjmedia.android.tjdebugger.video;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import android.R.string;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.PowerManager.WakeLock;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.audio.AudioAct;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.RegexManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : Jimmy
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class VideoAct extends Activity {   
   
	private static final String TAG = "MovieAct";
	private PowerManager mPowerManager;
	private WakeLock mWakeLock;	
	Button mTitleExit;
	private int		mSelectDir = 0;
	ArrayList ar = new ArrayList();

	
//	static SoundPoolManager mPoolManger;

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_main);    
 
        initObjInfo();
        initViewID();
        initMediaView();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");
		
	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		mPLAY_STATUS = true;
		playVideo();
	}
	
	static boolean FLAG_ACTIVITYRESULT = false;
	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		Log.d(TAG, "onRestart()");
		if (!FLAG_ACTIVITYRESULT) {
	//		stopVideo();
			InnerVideo.mVideoView01.seekTo((int)mCurrentTime);
			float progress = ((mCurrentTime / mTotalTime) * 500.0f);
			Log.d(TAG, "progress=" + progress);
			InnerVideo.mComponet01.setProgress((int)progress);
			Log.d(TAG, "mCurrentTime=" + mCurrentTime + ", " + mTotalTime);
	//		updateEvent();
	//		mPLAY_STATUS = false;
	//		playVideo();
		}
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
		FLAG_ACTIVITYRESULT = false;
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
		stopVideo();
		mWakeLock.release();
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if (Const.DEBUG)
		finish();
	}
		
	public boolean onTouchEvent(MotionEvent ev) {
		
		final int action = ev.getAction();
	        
	    switch (action & MotionEvent.ACTION_MASK) {
		        case MotionEvent.ACTION_UP:
		        	if (View.INVISIBLE == mAllLayout.getVisibility())
		        	{
			        	mLoopHandler2.stop();
			        	mAllLayout.setVisibility(View.VISIBLE);
			        	mLoopHandler2.start(getApplicationContext());
		        	}
		        	break;
	    }
	    return true;
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
         
		if (resultCode == RESULT_FIRST_USER) {
			String uri = data.getStringExtra("flag");
			
			if (!RegexManager.isVideoFormatInfo(uri)) {
				ToastManager.showToast(getApplicationContext(), "The media format is not supported", Toast.LENGTH_SHORT);
        		return;
			}
						
			if (1 == mSelectDir)
			{
				stopVideo();
				DEFAULT_URI = uri;
				String[] args = uri.split("/");				
				int len = args.length;
				if (len > 1)
				{					
					for (int i = 0; i < len-1; i++)
					{
						if (i == 0)
						{
							DEFAULT_DIR = args[i];
						}
						else
						{
							DEFAULT_DIR += "/" + args[i];
						}
					}
				}				
				mSelectDir = 0;	
				mTotalTime = 0;
				FLAG_ACTIVITYRESULT = true;
				mPLAY_STATUS = false;
				AddList();				
				playVideo();
			}
			else
			{
				DEFAULT_DIR = null;
			}
						
			DEFAULT_URI = null;
//        	File filename = new File(uri);
//        	SoundPoolManager.I_FILE_URL = Uri.fromFile(filename);
//        	DEFAULT_URI = Uri.fromFile(filename).toString();
			FLAG_ACTIVITYRESULT = true;
        	DEFAULT_URI = uri;
        	Log.d(TAG, "onActivityResult()=" +uri + ", " + DEFAULT_URI);
        	mTotalTime = 0;
        	stopVideo();
        	mPLAY_STATUS = false;
        	playVideo();
        }
        super.onActivityResult(requestCode, resultCode, data);
    } 

	
	private void initObjInfo() {
		
		mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = mPowerManager.newWakeLock(
				PowerManager.SCREEN_BRIGHT_WAKE_LOCK, getClass().getName());
		mWakeLock.acquire();
	}
    
	
	AudioManager mAudioMgr;
	FrameLayout mAllLayout;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		mAllLayout = (FrameLayout)findViewById(R.id.Video_Main_FL_Index01);
		DEFAULT_URI = "android.resource://" + this.getPackageName()+"/"+R.raw.tjintro;
		INIT_URI = DEFAULT_URI;	
		InnerVideo.mVideoView01 = (VideoView) findViewById(R.id.Video_Main_VideoView_Index01);
		InnerVideo.mComponet01 = (SeekBar) findViewById(R.id.Video_Main_Index01);
		InnerVideo.mComponet02 = (TextView) findViewById(R.id.Video_Main_Index02);
		InnerVideo.mComponet03 = (TextView) findViewById(R.id.Video_Main_Index03);
		InnerVideo.mComponet04 = (Button) findViewById(R.id.Video_Main_Index04);
		InnerVideo.mComponet05 = (Button) findViewById(R.id.Video_Main_Index05);
		InnerVideo.mComponet06 = (Button) findViewById(R.id.Video_Main_Index06);
		
		
		InnerVideo.mComponet16 = (TextView) findViewById(R.id.Video_Main_Index16);		
		InnerVideo.mComponet17 = (CheckBox) findViewById(R.id.Video_Main_Index17);
		InnerVideo.mVideoView01.setOnClickListener(mClickListener);
		InnerVideo.mComponet17.setOnClickListener(mClickListener);
		
		InnerVideo.mComponet01.setOnSeekBarChangeListener(mSeekListener);
		InnerVideo.mComponet04.setOnClickListener(mClickListener);
		InnerVideo.mComponet05.setOnClickListener(mClickListener);
		InnerVideo.mComponet06.setOnClickListener(mClickListener);
		
		InnerVideo.mComponet11 = (Button) findViewById(R.id.Video_Main_Volume_Index01);
		InnerVideo.mComponet12 = (Button) findViewById(R.id.Video_Main_Volume_Index02);
		InnerVideo.mComponet13 = (Button) findViewById(R.id.Video_Main_Volume_Index03);
		InnerVideo.mComponet14 = (Button) findViewById(R.id.Video_Main_Volume_Index04);
		InnerVideo.mComponet15 = (Button) findViewById(R.id.Video_Main_EXIT);
		InnerVideo.mComponet11.setOnClickListener(mClickListener);
		InnerVideo.mComponet12.setOnClickListener(mClickListener);
		InnerVideo.mComponet13.setOnClickListener(mClickListener);
		InnerVideo.mComponet14.setOnClickListener(mClickListener);
		InnerVideo.mComponet15.setOnClickListener(mClickListener);
		
		InnerVideo.mComponet21 = (Button) findViewById(R.id.Video_Main_FILE_Index01);
		InnerVideo.mComponet21.setOnClickListener(mClickListener);


		setVolumeControlStream(AudioManager.STREAM_MUSIC);
		mAudioMgr = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		
		InnerVideo.mVideoView01.setOnCompletionListener(mOnCompleteListener);
		InnerVideo.mVideoView01.setOnErrorListener(mOnErrorListener);		
		
	}
	
	String DEFAULT_URI = null;
	String INIT_URI = null;
	String DEFAULT_DIR = null;
	ArrayList<String>	mList = new ArrayList<String>();
	int					mListCount = 0;
	private void AddList()
	{
		if (null != DEFAULT_DIR)
		{	
			if (0 < mList.size())
				mList.clear();
							
			  /* 주어진 주소값에 대한 File 객체 생성 및 하위 디렉토리/파일 행렬 생성 */
			  File f = new File(DEFAULT_DIR);
			  File[] files = f.listFiles();
			  mListCount = 0;
			  for (int i = 0; i < files.length ; i++)
			  {
				  File file = files[i];
				  if (!file.isDirectory() && RegexManager.isVideoFormatInfo(file.getPath()))
					  mList.add(file.getPath());
//				  {
//					  DEFAULT_URI = file.getPath();					  
//				  }				  
			  }			
//			  for (int i = 0; i < files.length ; i++)
//			  {
//				  File file = files[(int) (Math.random() % files.length)];
//				  if (!file.getPath().equalsIgnoreCase(DEFAULT_URI) && RegexManager.isVideoFormatInfo(file.getPath()))
//				  {
//					  DEFAULT_URI = file.getPath();
//					  break;					  
//				  }
//			  }
		}		
	}
	private void initMediaView() {
//		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
//		}
//		MediaController mc = new MediaController(this);
//		InnerVideo.mVideoView01.setMediaController(mc);
		
		
		
		InnerVideo.mVideoView01.setVideoURI(Uri.parse(DEFAULT_URI));
		InnerVideo.mComponet16.setText(DEFAULT_URI);
		InnerVideo.mVideoView01.requestFocus();
	}
	
	boolean mRepeat = false;
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			switch (v.getId()) {
				case R.id.top_exit:
				case R.id.Video_Main_EXIT:
					finish();
					break;
				// Play Components 04 ~ 06 
				case R.id.Video_Main_Index04:
					Log.d(TAG, "OnClickListener_left");
					seekMediaSeekTo(getApplicationContext(), false);
					break;
				case R.id.Video_Main_Index05:
					Log.d(TAG, "mPLAY_STATUS=" + mPLAY_STATUS);
					playVideo();
					break;
				case R.id.Video_Main_Index06:
					Log.d(TAG, "OnClickListener_right");
					seekMediaSeekTo(getApplicationContext(), true);
					break;
				// Volume Components 01 ~ 04
				case R.id.Video_Main_Volume_Index01:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 1);
					break;
				case R.id.Video_Main_Volume_Index02:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 
							mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/4, 1);
					break;
				case R.id.Video_Main_Volume_Index03:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 
							mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC)/2, 1);
					break;
				case R.id.Video_Main_Volume_Index04:
					mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, 
							mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 1);
					break;
				case R.id.Video_Main_FILE_Index01:					
					if (InnerVideo.mComponet17.isChecked())
						mSelectDir = 1;
					else
						mSelectDir = 0;
					Intent i = new Intent();
					i.setAction("tjmedia.intent.ACTION_EXPLORER");			
					startActivityForResult(i,RESULT_FIRST_USER);
					break;
					
				case R.id.Video_Main_Index17:
					if (InnerVideo.mComponet17.isChecked())
					{
						if (null == DEFAULT_DIR)
						{														
							if (DEFAULT_URI.equalsIgnoreCase(INIT_URI))	return;
							
							String uri = DEFAULT_URI;
							String[] args = uri.split("/");				
							int len = args.length;
							if (len > 1)
							{					
								for (int a = 0; a < len-1; a++)
								{
									if (a == 0)
									{
										DEFAULT_DIR = args[a];
									}
									else
									{
										DEFAULT_DIR += "/" + args[a];
									}
								}
							}
							AddList();							
						}						
					}
					
					break;
					
				case R.id.Video_Main_VideoView_Index01:
					mAllLayout.setVisibility(View.VISIBLE);
					break;
					
				default:
					break;
			}
		}
	};
	
	
	MediaPlayer.OnErrorListener mOnErrorListener = new MediaPlayer.OnErrorListener() {

		@Override
		public boolean onError(MediaPlayer mp, int what, int extra) {
			// TODO Auto-generated method stub
			Log.d(TAG, "mOnErrorListener");
			//mAllLayout.setVisibility(View.VISIBLE);
			ToastManager.showToast(getApplicationContext(),DEFAULT_URI + "is not played!!!!", Toast.LENGTH_LONG);
			Log.d(TAG,DEFAULT_URI + "is not played!!!!");
			SystemClock.sleep(2000);
			stopVideo();
			if (null != DEFAULT_DIR && InnerVideo.mComponet17.isChecked())
			{
				mListCount++;
				if (mList.size() > 0 && mListCount >= mList.size())
					mListCount = 0;
				DEFAULT_URI = mList.get(mListCount);
				InnerVideo.mComponet16.setText(DEFAULT_URI);
				InnerVideo.mVideoView01.setVideoURI(Uri.parse(DEFAULT_URI));
				playVideo();
				
	        	mLoopHandler2.stop();
	        	mAllLayout.setVisibility(View.VISIBLE);
	        	mLoopHandler2.start(getApplicationContext());				
			}
			else
			{
				if (InnerVideo.mComponet17.isChecked())
				{
					playVideo();
					InnerVideo.mComponet16.setText(DEFAULT_URI);
					
		        	mLoopHandler2.stop();
		        	mAllLayout.setVisibility(View.VISIBLE);
		        	mLoopHandler2.start(getApplicationContext());
				}				
				else
				{
		        	mLoopHandler2.stop();
		        	mAllLayout.setVisibility(View.VISIBLE);					
				}
			}			
			return true;
		}
		
	};
	
	MediaPlayer.OnCompletionListener mOnCompleteListener = new MediaPlayer.OnCompletionListener() {
		@Override
		public void onCompletion(MediaPlayer mp) {
			// TODO Auto-generated method stub
			Log.d(TAG, "mOnCompleteListener");
			//mAllLayout.setVisibility(View.VISIBLE);
			stopVideo();
			if (null != DEFAULT_DIR && InnerVideo.mComponet17.isChecked())
			{
				mListCount++;
				if (mList.size() > 0 && mListCount >= mList.size())
					mListCount = 0;
				DEFAULT_URI = mList.get(mListCount);
				InnerVideo.mComponet16.setText(DEFAULT_URI);
				InnerVideo.mVideoView01.setVideoURI(Uri.parse(DEFAULT_URI));
				playVideo();
				
	        	mLoopHandler2.stop();
	        	mAllLayout.setVisibility(View.VISIBLE);
	        	mLoopHandler2.start(getApplicationContext());				
			}
			else
			{
				if (InnerVideo.mComponet17.isChecked())
				{
					playVideo();
					InnerVideo.mComponet16.setText(DEFAULT_URI);
					
		        	mLoopHandler2.stop();
		        	mAllLayout.setVisibility(View.VISIBLE);
		        	mLoopHandler2.start(getApplicationContext());
				}
				else
				{
		        	mLoopHandler2.stop();
		        	mAllLayout.setVisibility(View.VISIBLE);					
				}
			}
		}
	};
	
	private SeekBar.OnSeekBarChangeListener mSeekListener =new SeekBar.OnSeekBarChangeListener() {
		boolean wasPlaying = false;
		
		@Override
		public void onStopTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
		}
		
		@Override
		public void onStartTrackingTouch(SeekBar seekBar) {
			// TODO Auto-generated method stub
//			wasPlaying = mPoolManger.isPlaying(SoundPoolManager.SE_PLAYTEST_INDEX01);
			wasPlaying = InnerVideo.mVideoView01.isPlaying();
			if (wasPlaying) {
				mPLAY_STATUS = true;
				playVideo();
			}
		}
		int count = 0;
		@Override
		public void onProgressChanged(SeekBar seekBar, int progress,
				boolean fromUser) {
			// TODO Auto-generated method stub
			if (fromUser) {
				float msec = 0.0f;
//				msec = (progress / 500.0f) * mPoolManger.getDuration(SoundPoolManager.SE_PLAYTEST_INDEX01);
//				mPoolManger.setCurrentTime(SoundPoolManager.SE_PLAYTEST_INDEX01, (int)msec);
				msec = (progress / 500.0f) * InnerVideo.mVideoView01.getDuration();
				InnerVideo.setCurrentTime((int)msec);
				mPLAY_STATUS = false;
				playVideo();
			}
		}
	};
	
	
	/*
	 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
	 * 		[Play Test]
	 * 
	 */
	public static boolean mPLAY_STATUS = false;
	private void playVideo() {
		if (mPLAY_STATUS) {
			mLoopHandler2.stop();
			mLoopHandler.stop();
			InnerVideo.mVideoView01.pause();
			InnerVideo.mComponet05.setText("PLAY");
			mPLAY_STATUS = false;
		} else {
			mLoopHandler.start(getApplicationContext());
			mLoopHandler2.start(getApplicationContext());
			InnerVideo.mVideoView01.start();
			InnerVideo.mComponet05.setText("PAUSE");
			mPLAY_STATUS = true;
		}
	}
	
	public void stopVideo() {
		InnerVideo.mVideoView01.stopPlayback();
	
		mLoopHandler.stop();
//		mTotalTime = 0;
		mPLAY_STATUS = false;
		InnerVideo.mComponet05.setText("PLAY");
		initMediaView();
		updateEvent();
	}
	
	private final int FREQUENCY = 1000;
	public LoopHandler mLoopHandler = new LoopHandler();

	public void loop() {
		Log.d(TAG, "loop()");
		updateEvent();
		mLoopHandler.sleep(FREQUENCY);
	}
	
	public class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		public void stop() {
			bStop = true;
		}

		private void start(Context context) {
			bStop = false;
			
			loop();
		}
	};
	
	public LoopHandler2 mLoopHandler2 = new LoopHandler2();
	
	public class LoopHandler2 extends Handler {
		private int count = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				mAllLayout.setVisibility(View.INVISIBLE);
				mLoopHandler2.sleep(10000);
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		public void stop() {
			bStop = true;
			mAllLayout.setVisibility(View.VISIBLE);
		}

		private void start(Context context) {
			bStop = false;			
			mLoopHandler2.sleep(10000);
		}
	};	
	
	float mTotalTime = 0;
	float mCurrentTime = 0;
	float mBeforeTime = 0;
	private void updateEvent() {
		if (mCurrentTime < mTotalTime) {
			mCurrentTime = InnerVideo.mVideoView01.getCurrentPosition();
			//mAllLayout.setVisibility(View.INVISIBLE);
		} else {
			mCurrentTime = 0;						
		}
		mTotalTime = InnerVideo.mVideoView01.getDuration();
		InnerVideo.mComponet02.setText("" + getTimeFormatter((int)mCurrentTime));
		InnerVideo.mComponet03.setText("" + getTimeFormatter((int)mTotalTime));
		float progress = ((mCurrentTime / mTotalTime) * 500.0f);
		Log.d(TAG, "progress=" + progress);
		InnerVideo.mComponet01.setProgress((int)progress);
		InnerVideo.mComponet01.invalidate();
		mBeforeTime = progress;
	}
	
	
	static Calendar c1 = Calendar.getInstance();
	private static String getTimeFormatter(int mCurrentTime) {
		c1.set(1970, 0, 1, 0, 0, 0);
		int var = mCurrentTime / 1000;
		c1.add(Calendar.MINUTE, var);
		Date date = c1.getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		String temp = sdf.format(date);
		return temp;
	}
	
	public void seekMediaSeekTo(Context context, boolean flag) {
		// flag = false if the MediaPlayer is seeking left , true otherwise.
		if (InnerVideo.mVideoView01.isPlaying()) {
			int currentMillis = InnerVideo.mVideoView01.getCurrentPosition();
			Log.d(TAG, "currentMillis=" + currentMillis);
			if (flag) {
				currentMillis+=5000;
			} else {
				currentMillis-=10000;
//				currentMillis-=10000;
			}			
			InnerVideo.mVideoView01.seekTo(currentMillis);			
		}
	}

	
	static class InnerVideo {
		
		public static VideoView				mVideoView01;
		private static Button					mComponet22;	// File Folder
		private static Button					mComponet21;	// File Folder
		
		private static SeekBar					mComponet01;	// current seekbar
		private static TextView 				mComponet02;	// start time
		private static TextView 				mComponet03;	// end time
		private static Button					mComponet04;	// left seek
		private static Button					mComponet05;	// play, pause
		private static Button					mComponet06;	// rigth seek
		
		// volume
		private static Button					mComponet11;	// mute
		private static Button					mComponet12;	// 25%
		private static Button					mComponet13;	// 50%
		private static Button					mComponet14;	// 100%
		private static Button					mComponet15;	// 100%
		private static TextView 				mComponet16;	// title
		private static CheckBox 				mComponet17;	// check
		
		public static void setCurrentTime(int currentMillis) {
			// flag = false if the MediaPlayer is seeking left , true otherwise.
			if (mVideoView01.isPlaying()) {
				Log.d(TAG, "currentMillis=" + currentMillis);
				mVideoView01.seekTo(currentMillis);
			}
		}
		
	}
}