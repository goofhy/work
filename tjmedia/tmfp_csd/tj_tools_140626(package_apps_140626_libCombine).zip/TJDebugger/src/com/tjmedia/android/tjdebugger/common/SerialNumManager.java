package com.tjmedia.android.tjdebugger.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;



public class SerialNumManager {
	public static final String TAG = "SerialNumManager";
	
	
	public static boolean isServerStatusForSerialNUM(Context context) {
		String uriString = "/mnt/usbdisk";
		File usbpath = new File(uriString);
		if (usbpath.canRead()) {
			File fileDir = new File(uriString, "TJDebugger");
			if (!fileDir.exists()) {
				if (!fileDir.mkdirs()) {
//					Log.e(TAG, "failed to create directory");
					ToastManager.showToast(context, "failed to create directory", Toast.LENGTH_SHORT);
					return false;
				}
			}
			
			try {
				File filename = new File(fileDir.getPath() + File.separator + "TJ_Serial_Numbers.csv");
				if (filename.canRead()) {
					return true;
				}
				FileWriter fw = new FileWriter(filename);
				BufferedWriter bw = new BufferedWriter(fw);
				String result = "";
				bw.write(result);
	            bw.close();
	            fw.close();
	            ToastManager.showToast(context, "File created", Toast.LENGTH_SHORT);
				return true;
			} catch (IOException ie) {
				ie.printStackTrace();
			}
		} else {
			// unmounted;
			return false;
		}
		// other error;
		return false;
	}
	
	public static TJListItem readLastSerialNumberByUSB(Context context) {
    	TJListItem item = null;
    	String uriString = "/mnt/usbdisk";
		File fileDir = new File(uriString, "TJDebugger");
		File filename = new File(fileDir.getPath() + File.separator + "TJ_Serial_Numbers.csv");
		
		if (!filename.canRead()) {
			ToastManager.showToast(context, "Can not read the TJ_Serial_Numbers.csv file.", Toast.LENGTH_SHORT);
			return item;
		}
		FileReader fr;
		try {
			fr = new FileReader(filename);
			BufferedReader bw = new BufferedReader(fr);
			String line = "";
			long maxIndex, _id;
			maxIndex = _id = 0L;
			while ((line=bw.readLine()) != null) {
//				System.out.println(line);
				Log.e(TAG, line);
				String[] values = line.split(",");
				_id = Long.valueOf(values[0]);
				if (maxIndex <= _id) {
					item = new TJListItem(values[0], values[1]);
//					item = new TJListItem(values[0], values[1], values[2]);
				}
			}
			bw.close();
			fr.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
    	return item;
    }
	
	public static boolean compareSerialNUM(String str, TJListItem item) {
		String[] result = str.split(",");
		
		if (result[0].equals(item.getColumns(0)) && result[1].equals(item.getColumns(1))) {
			return true;
		}
		return false;
	}
	
	public static boolean writeSerialInfoToUSB(TJListItem item) {
		Log.d(TAG, "writeSerialInfoToUSB()=" + item.getColumns(0)
				+ ", " + item.getColumns(1)
				);
		String uriString = "/mnt/usbdisk";
		File fileDir = new File(uriString, "TJDebugger");
		try {
			File filename = new File(fileDir.getPath() + File.separator + "TJ_Serial_Numbers.csv");
			if (filename.canRead()) {
				FileWriter fw = new FileWriter(filename, true);
				BufferedWriter bw = new BufferedWriter(fw);
				String result = item.getColumns(0) + "," + item.getColumns(1) + "\r\n";
				bw.write(result);
	            bw.close();
	            fw.close();
				return true;
			}
		} catch (IOException ie) {
			ie.printStackTrace();
		}
		// other error;
		return false;
	}
	
}
