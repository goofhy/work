package com.tjmedia.android.tjdebugger.bluetooth;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.tjmedia.android.tjdebugger.R;


public class AndroidViewrActivity extends Activity {
 /* item은 탐색기에 표시될 내용, path는 item 클릭시 이동할 경로이다. */
 
    ImageView 		mBluetoothImagview;	
    TextView		mText;
 @Override
 public void onCreate(Bundle savedInstanceState) {
     super.onCreate(savedInstanceState);
     setContentView(R.layout.bluetooth_view);  
     /* myPath 뷰어 설정 */	
     Intent intent = getIntent(); // 값을 받아온다.
     String strRecvFilename = intent.getStringExtra("param1");
     
     mText = (TextView)findViewById(R.id.bt_view_text);
     mText.setText(strRecvFilename);
     
     mBluetoothImagview = (ImageView)findViewById(R.id.bt_view_imageView);
     Uri uri = Uri.parse(strRecvFilename);
     mBluetoothImagview.setImageURI(uri);    
 }
 
 }

