package com.tjmedia.android.tjdebugger.sensor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.AssetManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJJni;
import com.tjmedia.android.tjdebugger.common.TJListItem;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class GSensorAct extends Activity {   
   
	private static final String TAG = "GsensorAct"; 	
	String strManufacturer = android.os.Build.MANUFACTURER;	
	
	Button mTitleExit;
	
	Button mCalibration;
	SoundPoolManager mPoolManger;	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gsensor_main);    
 
        initObjInfo();
        initViewID();
        initGyroView();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
		registerSensor(SensorManager.SENSOR_DELAY_UI);
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		unRegisterSensor();
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		mLoopHandler.stop();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	void initObjInfo() {
		
		
	}
	
	
	private SensorManager mSensorManager;
	private List<Sensor> mSensor;
	private Sensor sensorGrav, sensorMag, sensorOrient;
    TextView[] mTVs = new TextView[4];
    
    public static float[] mGravity = new float[3];
	public static float[] mMagentic = new float[3];
	public static float[] mAzimuth = new float[3];
	public static float[] mDegrees = new float[3];
	
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		mTVs[0] = (TextView) findViewById(R.id.ACCELEROMETER);
        mTVs[1] = (TextView) findViewById(R.id.MAGNETIC_FIELD);
        mTVs[2] = (TextView) findViewById(R.id.ORIENTATION);
        mTVs[3] = (TextView) findViewById(R.id.ORIENTATION1);
        
        mSensorManager = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        mSensor = mSensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
        if (mSensor.size() > 0) {
        	sensorGrav = mSensor.get(0);
        }
        mSensor = mSensorManager.getSensorList(Sensor.TYPE_MAGNETIC_FIELD);
        if (mSensor.size() > 0) {
        	sensorMag = mSensor.get(0);
        }
        mSensor = mSensorManager.getSensorList(Sensor.TYPE_ORIENTATION);
        Log.d(TAG, "Orientation=" + mSensor);
        if (mSensor.size() > 0) {
        	sensorOrient = mSensor.get(0);
        }
        if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}	
        
        mCalibration = (Button) findViewById(R.id.GSensor_Index21);
        mCalibration.setOnClickListener(mClickListener);
        
		
	}
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
				case R.id.top_exit:
					finish();
					break;
				case R.id.GSensor_Index21:
					// Calbration Format
					mLoopHandler.stop();
					unRegisterSensor();
					//TJJni.TJJNI_SYSTEM_Run("echo 0,0,0 > /sys/devices/platform/s3c2440-i2c.4/i2c-4/4-0001/haam375_calibration");					
					//TDMKMisc_Service.SYSTEM_Run("echo 0,0,0 > /sys/devices/platform/s3c2440-i2c.4/i2c-4/4-0001/haam375_calibration");
//					if (strManufacturer.equalsIgnoreCase("tjmedia"))
//					if (Log.getTJ())
//						TDMKMisc_Service.GSENSOR_SetCalibarationData(0,0,0);
					mCalOK = false;
					new AsyCalibration().execute("");
					break;
				default:
					break;
				
			}
		}
	};
	
	final float GRAVITY_EARTH	= 9.80665f;
	final float LSG						= 64.0f;
	final float SENSOR_DIVIDER	= GRAVITY_EARTH/LSG;
	
	private class AsyCalibration extends AsyncTask<String, Void, Void> {   
    	private ProgressDialog Dialog = new ProgressDialog(GSensorAct.this);
    	TJListItem item = null;
    	float[][] equalize = new float[7][3];
    	float rangeX = 0f;
		float rangeY = 0f;
		float rangeZ = 0f;
		
    	int x = 0;
		int y = 0;
		int z = 0;
		
    	protected void onPreExecute() {
   		Dialog.setMessage("Loading...");   
    		Dialog.show();
    	}   


    	protected Void doInBackground(String... arg0) {
    		registerSensor(SensorManager.SENSOR_DELAY_FASTEST);   	
    		for(int i=0; i<5; i++) {
    			for(int j=0; j<3; j++) {
    				equalize[i][j] = mGravity[j]/SENSOR_DIVIDER;
    				Log.d(TAG, "ready equalize[" + i + "][ " + j + "] : " + equalize[i][j]);
    			}
    			try {
    				Thread.sleep(500);    				
    			} catch (InterruptedException ie) {
    				ie.printStackTrace();
    			}
    			//SystemClock.sleep(500);
    		}
    		unRegisterSensor();
    		registerSensor(SensorManager.SENSOR_DELAY_UI);   
    		for(int i=0; i<equalize.length; i++) {
    			for(int j=0; j<3; j++) {
    				equalize[i][j] = mGravity[j]/SENSOR_DIVIDER;
    				Log.d(TAG, "equalize[" + i + "][ " + j + "] : " + equalize[i][j]);
    			}
    			try {
    				Thread.sleep(500);
    			} catch (InterruptedException ie) {
    				ie.printStackTrace();
    			}
    			//SystemClock.sleep(500);
    		}
    		for(int i=0; i<equalize.length; i++) {
    			if(equalize[i][0] > 127) {
    				rangeX += 127;
    				x += 127;
    			} else if (equalize[i][0] < -128){
    				rangeX += -128;
    				x += -128;
    			} else {
    				rangeX += equalize[i][0];
    				x += equalize[i][0];
    			}
    			Log.d(TAG, "x : " + rangeX);
    		}
    		for(int i=0; i<equalize.length; i++) {
    			if(equalize[i][1] > 127) {
    				rangeY += 127;
    				y += 127;
    			} else if (equalize[i][1] < -128){
    				rangeY += -128;
    				y += -128;
    			} else {
    				rangeY += equalize[i][1];
    				y += equalize[i][1];
    			}
    		}
    		for(int i=0; i<equalize.length; i++) {
    			if(equalize[i][2] > 127) {
    				rangeZ += 127;
    				z += 127;
    			} else if (equalize[i][2] < -128){
    				rangeZ += -128;
    				z += -128;
    			} else {
    				rangeZ += equalize[i][2];
    				z += equalize[i][2];
    			}
    		}
    		unRegisterSensor();
    		registerSensor(SensorManager.SENSOR_DELAY_FASTEST);   
    		
    		for(int i=0; i<5; i++) {
    			for(int j=0; j<3; j++) {
    				equalize[i][j] = mGravity[j]/SENSOR_DIVIDER;
    				Log.d(TAG, "ready equalize[" + i + "][ " + j + "] : " + equalize[i][j]);
    			}
    			try {
    				Thread.sleep(10);
    			} catch (InterruptedException ie) {
    				ie.printStackTrace();
    			}    
    			//SystemClock.sleep(10);
    		}
    		unRegisterSensor();
    		registerSensor(SensorManager.SENSOR_DELAY_NORMAL); 
	    	return null;    				
		}
    	
    	protected void onPostExecute(Void unused) {
    		Dialog.dismiss();
    		String cal;
    		int zcal = 64 - ((int)rangeZ/equalize.length);
    		Log.d(TAG, "String.Fromat():" + String.format("%d,%d,%d", (int)-rangeX/equalize.length, (int)rangeY/equalize.length,zcal));
    		
    		mTVs[1].setText("Calibration(x, y, z) : " 
    					+ String.format("%.0f", -rangeX/equalize.length) + ","
    					+ String.format("%.0f", rangeY/equalize.length) + ","
    					+ zcal + "\t\t"
    					+ "(" + -x/equalize.length + ","
    					+ y/equalize.length + "," 
    					+ zcal + ")"
    					);
//    		if (strManufacturer.equalsIgnoreCase("tjmedia"))
    		if (Log.getTJ())
    		{
//    			TDMKMisc_Service.GSENSOR_SetCalibarationData(
//    				(int)-rangeX/equalize.length,(int)rangeY/equalize.length,zcal);
    		}
    		
    		mCalflag = true;
    		mCalCheckCount = 0;
    		mFLGyro.removeAllViews();
    		initGyroView();    		
	    }   
	}
	
	
	int displayWidth = 0;
	FrameLayout mFLGyro;
	SensorSurface mSurface;
	boolean	mCalflag = false;
	boolean	mCalOK = false;
	private static int	mCalCheckCount = 0;
	private void initGyroView() {
		displayWidth = checkDisplay();
		mFLGyro = (FrameLayout)findViewById(R.id.AM_Main_Gyro_FL);

		mSurface = new SensorSurface(this); 
		Log.i(TAG, "displayWidth = " + displayWidth);
		mFLGyro.addView(mSurface);
	}

	private int checkDisplay() {
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		Log.i(TAG, "checkDisplay = w = " + metrics.widthPixels + ", h = " + metrics.heightPixels);
		if (metrics.widthPixels == 1024) {
			return metrics.widthPixels;
		} else if (metrics.widthPixels == 800) {
			return metrics.widthPixels;
		} else {
			return metrics.widthPixels;
		}
	}
	
	private void registerSensor(int Delay) {
		mSensorManager.registerListener(AccelatorSensor, sensorGrav,
				Delay);
		mSensorManager.registerListener(MagneticSensor, sensorMag,
				Delay);
		mSensorManager.registerListener(OrientationSensor, sensorOrient,
				Delay);
	}
	
	private void unRegisterSensor() {
		mSensorManager.unregisterListener(AccelatorSensor);
		mSensorManager.unregisterListener(MagneticSensor);
		mSensorManager.unregisterListener(OrientationSensor);
	}
	
	Toast		mToast = null;
	public void printToast(String messageToast) {
		if (null != mToast)
			mToast.cancel();
		mToast = Toast.makeText(this, messageToast, Toast.LENGTH_LONG);
		mToast.setGravity(Gravity.CENTER,0, 0);
		mToast.show();
		
	}	
	
	/*
	 * 센서 계산 -128 ~ 127
	 * (mGravity[0]*19.6133f)/1.56f)
	 * (mGravity[1]*19.6133f)/1.56f)
	 * (mGravity[2]*19.6133f)/1.56f)
	 */
	float force;
	SensorEventListener AccelatorSensor = new SensorEventListener() {
		public void onSensorChanged(SensorEvent event) {
			// TODO Auto-generated method stub
			switch (event.sensor.getType()) {
			case Sensor.TYPE_ACCELEROMETER:
				mGravity = event.values;
				
				force = (float) (Math.sqrt(mGravity[0]*mGravity[0]+mGravity[1]*mGravity[1]+mGravity[2]*mGravity[2]) ); 
				if(mGravity!=null) {
					mTVs[0].setText("Accelerometer(x, y, z, v) : " 														
							+ String.format("%.1f", mGravity[0]) + ", " 
							+ String.format("%.1f", mGravity[1]) + ", "
							+ String.format("%.1f", mGravity[2]) + ", "
							+ String.format("%.2f", force)
							+ "\t("
							+ String.format("%.1f", (mGravity[0] / SENSOR_DIVIDER)) + ","							
							+ String.format("%.1f", (mGravity[1] / SENSOR_DIVIDER)) + ","							
							+ String.format("%.1f", (mGravity[2] / SENSOR_DIVIDER)) + ")"							
							);
//					
					float scrx , scry;
					
					if (0 > mGravity[0] / SENSOR_DIVIDER)					
						scrx = (64.0f + (-mGravity[0] / SENSOR_DIVIDER)) * 10.0f;//9.2f;																	
					else
						scrx = (64.0f + (-mGravity[0] / SENSOR_DIVIDER)) * 10.0f;//9.2f;

					if (0 > mGravity[1] / SENSOR_DIVIDER)					
						scry = (64.0f + (mGravity[1] / SENSOR_DIVIDER)) * 4.6328125f;																	
					else
						scry = (64.0f + (mGravity[1] / SENSOR_DIVIDER)) * 4.6328125f;
					
					if (scrx < 0) scrx = 0;
					if (scry < 0) scry = 0;

					if (scrx > 1230) scrx = 1230;
					if (scry > 543) scry = 543;
					
					mSurface.setBallPos(scrx,scry);
					
					if (mCalflag && 4 <= mCalCheckCount++)
					{
											
						if ((2.0f > mGravity[0] && -2.0f < mGravity[0]) 
							&&( 2.0f > mGravity[1] && -2.0f < mGravity[1] )
							&&( 11.0f > mGravity[2] && 8.5f < mGravity[2] ))
						{
							printToast("OK, Calibration!!!!");
							mCalOK = true;
//							if (strManufacturer.equals("tjmedia"))
							if (Log.getTJ())
							{
//								TDMKMisc_Service.GSENSOR_SetAxisAdjust();								
							}
							if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TINKERBELL);														
						}
						else
						{
							printToast("NG, Retry Calibration!!!!");
							mCalOK = false;
							if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_SHUTTER);
							Log.e(TAG, "***************" + mTVs[0].getText());														
						}	
						if (mCalOK)
						{
							mLoopHandler.start();		
							mLoopHandler.sleep(500);
						}
						mCalflag = false;
						mCalCheckCount = 0;						
					}
				}
				break;
			}
			
		}
		
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
			// TODO Auto-generated method stub
			
		}
	};
	
	SensorEventListener MagneticSensor = new SensorEventListener() {
		
		public void onSensorChanged(SensorEvent event) {
			// TODO Auto-generated method stub
			switch (event.sensor.getType()) {
			case Sensor.TYPE_MAGNETIC_FIELD:
				mMagentic = event.values;
				if(mMagentic!=null) {
					mTVs[1].setText("Magnetic: " 
							+ String.format("%.1f", mMagentic[0]) + ", " 
							+ String.format("%.1f", mMagentic[1]) + ", "
							+ String.format("%.1f", mMagentic[2]));
				}
				break;
			}
			if(mGravity != null && mMagentic != null) {
				float[] temp = new float[3];
				float[] inR = new float[9];
				float[] outR = new float[9];
				SensorManager.getRotationMatrix(inR, null, mGravity, mMagentic);
//				SensorManager.remapCoordinateSystem(inR, SensorManager.AXIS_X, SensorManager.AXIS_Z, outR);
				SensorManager.remapCoordinateSystem(inR, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, outR);
				SensorManager.getOrientation(outR, temp);
				temp[0] = (float) Math.toDegrees(temp[0]);
				temp[1] = (float) Math.toDegrees(temp[1]);
				temp[2] = (float) Math.toDegrees(temp[2]);
				mDegrees = temp;
				mTVs[2].setText("Orientation: " 
						+ String.format("%.1f", mDegrees[0]) + ", " 
						+ String.format("%.1f", mDegrees[1]) + ", "
						+ String.format("%.1f", mDegrees[2]));
			}
		}
		
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
			// TODO Auto-generated method stub
		}
	};
	
	SensorEventListener OrientationSensor = new SensorEventListener() {
		public void onSensorChanged(SensorEvent event) {
			// TODO Auto-generated method stub
			switch (event.sensor.getType()) {
			case Sensor.TYPE_ORIENTATION:
//				Log.i(TAG, "onSensorChanged() = " + event.sensor.getType());
				mAzimuth = event.values;
				if(mAzimuth!=null) {
					mTVs[3].setText("Orientation(Angle Meter): " 
							+ String.format("%.1f", mAzimuth[0]) + ", " 
							+ String.format("%.1f", mAzimuth[1]) + ", "
							+ String.format("%.1f", mAzimuth[2]));
				}
				break;
			}
		}
		
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
			// TODO Auto-generated method stub
		}
	};
	
	
	public int Frequency = 500;
	public int timeoutcount = 40;
	int mCalCheckMODE = -1;
	private LoopHandler mLoopHandler = new LoopHandler();
	
	class LoopHandler extends Handler {
		private int count = 0;		
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
			//Log.d(TAG, "handleMessage" + bStop + ","  + !mCalflag);
			if (bStop == false) {
				if (mCalOK)
				{
					int nextFrequency = Frequency;
					float [] pos = new float[] {0,0};
					mSurface.setCheckBallPos(mCalCheckMODE);
					pos = mSurface.getBallPos();
					switch(mCalCheckMODE)
					{
					
						case 0:	// left
							if (0 <= pos[0] && 150 >= pos[0])
							{
								mCalCheckMODE = 1;
								nextFrequency = 1;
								count = 0;		
							}
							else
							{
								count++;
								if (count > timeoutcount)
								{
									//실패 메시지
									printToast("G-SENSOR : X(LEFT) - NG!!!!!!");
									mCalCheckMODE = 6;
									mSurface.setCheckBallPos(mCalCheckMODE);
									bStop = true;
									count = 0;
								}
							}
						break;		
						
						case 1: // down
							if (393 <= pos[1] && 543 >= pos[1])
							{
								mCalCheckMODE = 2;
								nextFrequency = 1;
								count = 0;
							}
							else
							{
								count++;
								if (count > timeoutcount)
								{
									//실패 메시지
									printToast("G-SENSOR : Y(DOWN) - NG!!!!!!");
									mCalCheckMODE = 6;
									mSurface.setCheckBallPos(mCalCheckMODE);
									bStop = true;
									count = 0;
								}
							}
						break;	
						
						case 2: //right
							if (1130 <= pos[0] && 1280 >= pos[0])
							{
								mCalCheckMODE = 3;
								nextFrequency = 1;
								count = 0;
							}
							else
							{
								count++;
								if (count > timeoutcount)
								{
									//실패 메시지
									printToast("G-SENSOR : X(RIGHT) - NG!!!!!!");
									mCalCheckMODE = 6;
									mSurface.setCheckBallPos(mCalCheckMODE);
									bStop = true;
									count = 0;
								}
							}
						break;	
						
						case 3: // up
							if (0 <= pos[1] && 150 >= pos[1])
							{
								mCalCheckMODE = 4;
								nextFrequency = 1;
								count = 0;
								mFLGyro.removeAllViews();
					    		initGyroView();
							}
							else
							{
								count++;
								if (count > timeoutcount)
								{
									//실패 메시지
									printToast("G-SENSOR : Y(UP) - NG!!!!!!");
									mCalCheckMODE = 6;
									mSurface.setCheckBallPos(mCalCheckMODE);
									bStop = true;
									count = 0;
								}
							}
						break;	
						
						case 4: // center
							//1280/2-100, 500/2-50, 1280/2 + 100, 500/2 +150
							if (1280/2-100 <= pos[0]+25 && 1280/2 + 100 >= pos[0]+25
								&& 500/2-50 <= pos[1]+25 && 500/2 + 150 >= pos[1]+25)
							{
								mCalCheckMODE = 5;
								nextFrequency = 1;
								count = 0;
								mFLGyro.removeAllViews();
					    		initGyroView();
							}
							else
							{
								count++;
								if (count > timeoutcount)
								{
									//실패 메시지
									printToast("G-SENSOR : Y(UP) - NG!!!!!!");
									mCalCheckMODE = 6;
									mSurface.setCheckBallPos(mCalCheckMODE);
									bStop = true;
									count = 0;
								}
							}
						break;							
						
						case 5:
							//성공 message
							printToast("G-SENSOR : OK!!!!!!");
							mSurface.setCheckBallPos(mCalCheckMODE);
							bStop = true;
							count = 0;
						break;						
					}
					mLoopHandler.sleep(nextFrequency);
				}
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
			count = 0;
			mCalCheckMODE = -1;
		}

		private void start() {
			bStop = false;			
			if (mCalOK)
			{
				mCalCheckMODE = 0;
			}
		}
	};	
	
	
	/*
	 * ****************************************************************************************
	 *  Demo test
	 * ****************************************************************************************
	*/
	
	private void writeFile() {
//		if(Constants.TesTFLAG) {
//			try {
//				insertToDb();
//			} catch (IOException e) {		
//				e.printStackTrace();
//			}
//		}
	}
	public void insertToDb()throws IOException {
		File outfile = new File(
			"/data/data/com.onycom.btc/databases/BTC.db");
		
		AssetManager assetManager = getResources().getAssets();
		InputStream is 
			= assetManager.open("database/BTC.db", AssetManager.ACCESS_BUFFER);
		
		long filesize = is.available();
		
		if (outfile.length() < filesize) {
			byte[] tempdata = new byte[(int)filesize];
			is.read(tempdata);
			is.close();
			outfile.createNewFile();
			FileOutputStream fo = new FileOutputStream(outfile);
			fo.write(tempdata);
			fo.close();
		}
	}
	
	
	
}
	
	

