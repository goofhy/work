package com.tjmedia.android.tjdebugger.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;



public class TJCalendarManager {
	public static final String TAG = "TJCalendarManager";
	
	
	public static TJListItem getNextSerialFormat(TJListItem item) {
		if (item == null) return null;
		TJListItem result = null;
		Date date = new Date();
		
		// serial compare
		long lastId = Long.valueOf(item.getColumns(0));
		lastId++;
		String lastdata = item.getColumns(1);
		String [] sn = lastdata.split("AK");
		long lastSN = Long.parseLong(sn[1]);
		lastSN++;
		StringBuilder sb = new StringBuilder();		
		sb.append(String.format("AK%06d", lastSN));				
//		long lastSN = Long.valueOf(item.getColumns(1));	
//		long lastdate = lastSN / 10000;
//		
//		Calendar cal = Calendar.getInstance();
//		cal.setTime(date);
//		int weeks = cal.get(Calendar.WEEK_OF_YEAR);
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
//		long currentdate = Long.valueOf(sdf.format(date)+weeks);
//		
//		Log.d(TAG, "lastdate='" + lastdate + "', curdate='" + currentdate + "'");
//		if (lastdate < currentdate) {
//			lastdate = currentdate * 10000 + 1;
//		} else {
//			lastSN++;
//			lastdate = lastSN;
//		}
//		StringBuilder sb = new StringBuilder();
//		sb.append(lastdate);
//		Log.d(TAG, "lastdate='" + lastdate + "', curdate='" + currentdate + "'");
		
//		sb.append(String.format("%04d", lastId));
		
//		// date
//		SimpleDateFormat formatter = new SimpleDateFormat ( "yyyyMMddHHmmss", Locale.KOREA );
//		String dTime = formatter.format (date);
//		result = new TJListItem(String.valueOf(lastId), sb.toString(), dTime);
		result = new TJListItem(String.valueOf(lastId), sb.toString());
		return result;
	}
	
	public static String getNextDateFormat(Date date, TJListItem item) {
		long lastId = Long.valueOf(item.getColumns(0));
		lastId++;
		long lastSN = Long.valueOf(item.getColumns(1));
		long lastdate = lastSN / 10000;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.format(date);
		
		StringBuilder sb = new StringBuilder();
		sb.append(sdf.format(date));
		sb.append(String.format("%04d", lastId));
		return sb.toString();
	}
	
	public static String getDateFormatter(Date date) {
		StringBuilder sb = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String temp = sdf.format(date);
//		String[] arr = temp.split("-");
//		for(int i=0; i<arr.length; i++) {
//			sb.append(arr[i]);
//		}
//		return sb.toString();
		return temp;
	}
	
	public static String getTimeFormatter(Date date) {
		StringBuilder sb = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		String temp = sdf.format(date);
//		String[] arr = temp.split(":");
//		for(int i=0; i<arr.length; i++) {
//			sb.append(arr[i]);
//		}
//		return sb.toString();
		return temp;
	}
	
	
}
