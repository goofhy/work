package com.tjmedia.android.tjdebugger.nfc;

import java.util.ArrayList;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentFilter.MalformedMimeTypeException;
import android.nfc.NfcAdapter;
import android.nfc.tech.NfcF;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJArrayAdapter;
import com.tjmedia.android.tjdebugger.common.TJListItem;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 */

public class NFCAct extends Activity {   
   
	private static final String TAG = "NFCAct"; 	

	
	Button 			mTitleExit;
	TextView 		mNFCStatus;
	Button 			mSettingNFC;
	CheckBox		mSetNFC;
	ListView 			mComponetListView;
	
	SoundPoolManager mPoolManger;
	
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nfc_main);    
 
        initObjInfo();
        initViewID();
        initNFCInfo();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
		mNfcAdapter.enableForegroundDispatch(this, mPendingIntent, mFilters, mTechLists);
		updateNFCInfo();
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		mNfcAdapter.disableForegroundDispatch(this);
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
	}
	
	public ArrayAdapter<TJListItem> mAdapter;
	ArrayList<TJListItem> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
		
//		mNFCTEXT = (TextView)findViewById(R.id.NFC_Main_Index01);
//		mNFCTEXT.setText("Scan a tag");
		mNFCStatus = (TextView)findViewById(R.id.NFC_Main_Index02);
		mSettingNFC = (Button)findViewById(R.id.NFC_Main_Index03);
		mSetNFC = (CheckBox)findViewById(R.id.NFC_Main_Index04);
		mSetNFC.setOnClickListener(mClickListener);
		mSettingNFC.setOnClickListener(mClickListener);
	
		mComponetListView = (ListView) findViewById(R.id.NFC_main_ListView);
		mItem = new ArrayList<TJListItem>();
		mAdapter = new TJArrayAdapter(getApplicationContext(), R.layout.tj_list_row_twoline, mItem);

		mComponetListView.setAdapter(mAdapter);
		
    }

	private NfcAdapter mNfcAdapter;
    private PendingIntent mPendingIntent;
    private IntentFilter[] mFilters;
    private String[][] mTechLists;
    private int mCount = 0;
    private void initNFCInfo() {
    	mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        Log.d(TAG, "mAdapter.NFC=" + mNfcAdapter.isEnabled());
        String nfcStatus = mNfcAdapter.isEnabled() == true ? "NFC ON" : "NFC OFF";
        mNFCStatus.setText(nfcStatus);
        // Create a generic PendingIntent that will be deliver to this activity. The NFC stack
        // will fill in the intent with the details of the discovered tag before delivering to
        // this activity.
        mPendingIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);

        // Setup an intent filter for all MIME based dispatches
        IntentFilter ndef = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
        try {
            ndef.addDataType("*/*");
        } catch (MalformedMimeTypeException e) {
            throw new RuntimeException("fail", e);
        }
        mFilters = new IntentFilter[] { ndef, };

        // Setup a tech list for all NfcF tags
        mTechLists = new String[][] { new String[] { NfcF.class.getName() } };
//        boolean isEnabled;
//      isEnabled = Settings.System.getInt(getContentResolver(), Settings.System.AIRPLANE_MODE_RADIOS, 0) == 1;
//      Log.e(TAG, "isEnabled=" + isEnabled	);
//      isEnabled = Settings.System.putInt(getContentResolver(), Settings.System.AIRPLANE_MODE_RADIOS, 1);
//      isEnabled = Settings.System.getInt(getContentResolver(), Settings.System.AIRPLANE_MODE_RADIOS, 0) == 1;
//      Log.e(TAG, "isEnabled Setting ON=" + isEnabled);
	}
    
	private long mListIndex = 0;
	private void updateList(String str) {
		TJListItem obj = null;
		String top = "Index[" + mListIndex + "] : "+ "NFC OK";
		String bottom = str;
		obj = new TJListItem(top, bottom);
		mItem.add(0, obj);
		mAdapter.notifyDataSetChanged();
		mListIndex++;
	}
	
    @Override
    public void onNewIntent(Intent intent) {
    	Log.d(TAG, "intent.getAction=" + intent.getAction());
    	if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TINKERBELL);
    	updateList(intent.toString());
//        mNFCTEXT.setText("Discovered tag " + ++mCount + " with intent: " + intent);
    }
    
    private void updateNFCInfo() {
    	if(mAdapter != null) {
			String nfcStatus = mNfcAdapter.isEnabled() == true ? "NFC ON" : "NFC OFF";
			if (mNfcAdapter.isEnabled())
				mSetNFC.setChecked(true);
			else
				mSetNFC.setChecked(false);
	        mNFCStatus.setText(nfcStatus);
		} else {
			mNFCStatus.setText("NFC OFF");
		}
    }
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
				case R.id.top_exit:
					finish();
					break;
				case R.id.NFC_Main_Index03:
					Intent i = new Intent();
					i.setAction(Settings.ACTION_WIRELESS_SETTINGS);					
					startActivityForResult(i, RESULT_OK);					
					break;
				case R.id.NFC_Main_Index04:
					if (mNfcAdapter.isEnabled())
					{
//						mNfcAdapter.disable();		
					}
					else
					{
//						mNfcAdapter.enable();
					}
					onPause();
					onResume();
					
					updateNFCInfo();
					break;
				default:
					break;
				
			}
		}
	};

}
	
	

