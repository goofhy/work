package com.tjmedia.android.tjdebugger.tjpackage;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.R.drawable;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.RegexManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
import com.tjmedia.android.tjdebugger.wifi.WifiAct;
import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *.tjpackage.PackageAct
 */

public class TJPackageAct extends Activity {   
   
	private static final String TAG = "PakageAct"; 	
	SoundPoolManager mPoolManger;
	private	AlertDialog ad = null;
	Button mTitleExit;
	Button mInstall;
	
	public TJPackageAct() {
	}
	
	public TJPackageAct(Context context) {		
	}
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tj_pakage_main);    
 
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
	}
	
	
	public ArrayAdapter<String> mAdapter1;
	ArrayList<String> mItem1;	
	
	Package[] mPackageList;	
	
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);		
		mInstall = (Button)findViewById(R.id.Pakage_main_BtnInstall);
		mInstall.setOnClickListener(mClickListener);	
		TJPakage.mComponetListView1 = (ListView) findViewById(R.id.Pakage_main_ListView1);		
		
		mItem1 = new ArrayList<String>();
		mAdapter1 = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1,mItem1);
		
		
		TJPakage.mComponetListView1.setAdapter(mAdapter1);
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
		
		updatePackageList();
		
		TJPakage.mComponetListView1.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View view, int pos,long id) {
				// TODO Auto-generated method stub		
				//								
	    		//Get Mac Address
				//mPoolManger.playTouchSe();				
				ShowDeleteMessageBox("Uninstall the Package",mItem1.get(pos),"OK");	

			}
			
		});			

		
	}

	public void ShowDeleteMessageBox(String Title,final String Message, String ButtonStr)
	{
		Context mContext = TJPackageAct.this;	
		
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.package_custom_dialog,(ViewGroup) findViewById(R.id.package_custom_dialog_layout_root));
        //setContentView(R.layout.custom_dialog);        
        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle(Title);
        aDialog.setView(layout);
        aDialog.setMessage("Uninstall the package : " + Message);        
                
        aDialog.setPositiveButton("Uninstall", new DialogInterface.OnClickListener() 
        {
        	@Override		
            public void onClick(DialogInterface dialog, int which) 
            {   
        		mPoolManger.playTouchSe();
//        		Uri uri = Uri.fromParts("package", Message, null);
//        		Intent it = new Intent(Intent.ACTION_DELETE,uri);
//        		startActivity(it);
//        		if (0 == TDMKMisc_Service.SYSTEM_Run("pm uninstall " + Message))
//        		{
//        			if (false == ToastManager.ToastState)
//        				ToastManager.showToast(getApplicationContext(), "Success, UnInstall the Pakage:" + Message, Toast.LENGTH_SHORT);			
//        			mPoolManger.playTouchSe();        			
//        		}
//        		else
        		{
        			if (false == ToastManager.ToastState)
        				ToastManager.showToast(getApplicationContext(), "Fail, UnInstall the Pakage:" + Message, Toast.LENGTH_SHORT);			
        			mPoolManger.playTouchSe();        			
        		}
        		mAdapter1.clear();
        		updatePackageList();        		
        		
            }
        });
        
        aDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which) 
            {   
        		mPoolManger.playTouchSe();
            }
        });      
        ad = aDialog.create();        
        ad.show();           
	}
	
	public void ShowInstallMessageBox(String Title,final String Message, String ButtonStr)
	{
		Context mContext = TJPackageAct.this;	
		
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.package_custom_dialog,(ViewGroup) findViewById(R.id.package_custom_dialog_layout_root));
        //setContentView(R.layout.custom_dialog);        
        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle(Title);
        aDialog.setView(layout);
        aDialog.setMessage("Install the package : " + Message);        
                
        aDialog.setPositiveButton("Install", new DialogInterface.OnClickListener() 
        {
        	@Override		
            public void onClick(DialogInterface dialog, int which) 
            {   
        		mPoolManger.playTouchSe();
        		
//				File file = new File(Message);
//				if(file == null) return;
//				Intent intent = new Intent();
//				intent.setAction(android.content.Intent.ACTION_VIEW);
//				intent.setDataAndType(Uri.fromFile(file), "application/vnd.android.package-archive");
//				intent.putExtra("forceToInstall",true);
//				startActivity(intent);        		
//        		if (0 == TDMKMisc_Service.SYSTEM_Run("pm install -r " + Message))
//        		{
//        			if (false == ToastManager.ToastState)
//        				ToastManager.showToast(getApplicationContext(), "Success, Install the Pakage:" + Message, Toast.LENGTH_SHORT);			
//        			mPoolManger.playTouchSe();        			
//        		}
//        		else
        		{
        			if (false == ToastManager.ToastState)
        				ToastManager.showToast(getApplicationContext(), "Fail, Install the Pakage:" + Message, Toast.LENGTH_SHORT);			
        			mPoolManger.playTouchSe();        			
        		}
        		mAdapter1.clear();
        		updatePackageList();
        		  		
        		
            }
        });
        
        aDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which) 
            {   
        		mPoolManger.playTouchSe();
            }
        });      
        ad = aDialog.create();        
        ad.show();           
	}	
				
	private void updatePackageList()
	{
		PackageManager manager = getPackageManager();				
		Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
		mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		List<ResolveInfo> apps = manager.queryIntentActivities(mainIntent, 0);		
		
		for (int i = 0; i < apps.size(); i++) {
			ResolveInfo info = apps.get(i);			
			String app_name = info.activityInfo.applicationInfo.packageName;
			//info.activityInfo
			updateList1(0,app_name);
		}

	}
	
	
	private long mListIndex1 = 0;
	private void updateList1(int key, String result) {
		switch (key) {
		case 0:								
			mItem1.add(result);
			mAdapter1.notifyDataSetChanged();
			mListIndex1++;
			break;
		default:
			break;
		}
	}
	
	private long mListIndex2 = 0;
	private void updateList2(int key, String result) {
		switch (key) {
		case 0:					

			break;
		default:
			break;
		}
	}
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.top_exit:
				mPoolManger.playTouchSe();
				finish();
				break;
				
			case R.id.Pakage_main_BtnInstall:
				Intent i = new Intent();
				i.setAction("tjmedia.intent.ACTION_EXPLORER");			
				startActivityForResult(i,RESULT_FIRST_USER);
				break;

			default:
				break;
			}
		}
	};
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
         
		if (resultCode == RESULT_FIRST_USER) {
        	String uri = data.getStringExtra("flag");
        	Log.d(TAG, "onActivityResult()=" +uri);
        	boolean result = RegexManager.isPackageFormatInfo(uri);
        	if (!result) {
        		ToastManager.showToast(getApplicationContext(), "The APK format is not supported", Toast.LENGTH_SHORT);
        		return;
        	}
        	ShowInstallMessageBox("Install the Package",uri,"OK");	
		}
	};
	

	
	static class TJPakage {

		public static ListView mComponetListView1;
		public static ListView mComponetListView2;
		
	}
	

}
	
	

