package com.tjmedia.android.tjdebugger.bluetooth;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.PowerManager.WakeLock;
import android.provider.MediaStore;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.SerialNumManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJCalendarManager;
import com.tjmedia.android.tjdebugger.common.TJListItem;
import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

public class BluetoothAct extends Activity implements OnClickListener {
    /** Called when the activity is first created. */
	// Local Bluetooth adapter
    private static BluetoothAdapter mBluetoothAdapter = null;
    private BluetoothDevice mBluetoothDevice = null;
    private BluetoothDevice mTmpBluetoothDevice = null;
    public static String EXTRA_DEVICE_ADDRESS = "device_address";
    String strManufacturer = android.os.Build.MANUFACTURER;	
    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_NONE = 0;
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;    
    public static final int MESSAGE_TOAST = 5;
    
    public static final int MESSAGE_RECV_FILE_NAME = 6;
    public static final int MESSAGE_RECV_STATUS = 7;
    public static final int MESSAGE_RECV_END = 8;
    
    public static final int MESSAGE_TRANS_FILE_NAME = 9;
    public static final int MESSAGE_TRANS_STATUS = 10;
    public static final int MESSAGE_TRANS_END = 11;    
    public static final int MESSAGE_DISCONNECT = 12;
    
    public static final int MESSAGE_SNREAD = 13;    
    public static final int MESSAGE_SNWRITE = 14;
    public static final int MESSAGE_SNSAVE = 15;
    
    public static String strSendImage;
    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";
    int						mnAndroidShared = 0;
    int						mFileServiceFlag = 0;
    
    
    private ArrayAdapter<String> mPairedDevicesArrayAdapter;
    private ArrayAdapter<String> mNewDevicesArrayAdapter;
    private ArrayAdapter<String> mStatusAdapter;
    
    
    static BluetoothFileService mFileService = null;
    
    Button		btnBluetoothOnOff = null;   
    Button		btnBluetoothScan = null;
    Button		btnBluetoothPaired = null;
    Button		btnSharedMessage = null;
    Button		btnSettings = null;
    Button		btnTransFile = null;
    Button		btnCallImg = null;
    Button		btnMessage = null;
    CheckBox	cbxSNSERVER = null;
    CheckBox	cbxRETRY = null;
    ImageView 	imgView;  
    TextView	editDeviceName = null;
    ListView	listBTPairlist = null;
    ListView	listBTScanlist = null;
    ListView	listBTStatuslist = null;
    ProgressBar	progressbarstatus = null;
    String		strRecvFilename = null;
    Uri 		mFileuri = null;
    
//    TextView	editFileTransRecvStatus = null;
//    ProgressBar	progFileTransRecvStatus = null;
//    
    Toast		mToast = null;
    static		int mSendMessgeCount = 0;
    //private		Handler	mTransFileHandler;
    BluetoothFileTransRecv	mFileTR = null;
	private static final String TAG = "BluetoothAct"; 	

	SoundPoolManager mPoolManger;	
	Button mTitleExit;
	static BluetoothCheck btThread = null;
	
	TJListItem mLastitem = null;
	private PowerManager mPowerManager;
	private WakeLock mWakeLock;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bluetooth_main);
        
		mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = mPowerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, 
				getClass().getName());        
		mWakeLock.acquire();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (null != mBluetoothAdapter)
        {
        	if (BluetoothAdapter.STATE_TURNING_OFF == mBluetoothAdapter.getState()
        			&& BluetoothAdapter.STATE_OFF == mBluetoothAdapter.getState())
        	mBluetoothAdapter.enable();        	        
        }
        
        btThread = new BluetoothCheck();   
        btThread.start();
        
        
        btnBluetoothOnOff = (Button) findViewById(R.id.bt_main_btnBluetoothONOFF);        
        btnBluetoothScan = (Button) findViewById(R.id.bt_main_btnScan);
        btnBluetoothPaired = (Button) findViewById(R.id.bt_main_btnPaired);
        btnSharedMessage = (Button) findViewById(R.id.bt_main_btnSharedMessage);
        btnSettings = (Button) findViewById(R.id.bt_main_btnSettings);
        btnTransFile = (Button) findViewById(R.id.bt_main_btnTransFile);  
        btnCallImg =  (Button) findViewById(R.id.bt_main_btnCallImg);
        btnMessage =   (Button) findViewById(R.id.bt_main_btnMessage);
        editDeviceName = (TextView) findViewById(R.id.bt_main_textDeviceName);
        progressbarstatus = (ProgressBar) findViewById(R.id.bt_main_progressBar1);
        cbxSNSERVER = (CheckBox) findViewById(R.id.bt_checkBox_index01);
        cbxRETRY = (CheckBox) findViewById(R.id.bt_checkBox_index02);
        progressbarstatus.setMax(1000);
        imgView = (ImageView)findViewById(R.id.bt_main_view);
//        editFileTransRecvStatus = (TextView)findViewById(R.id.textView3);
//        progFileTransRecvStatus = (ProgressBar)findViewById(R.id.progressBar1);
//        
        
        btnBluetoothOnOff.setOnClickListener(this);        
        btnBluetoothScan.setOnClickListener(this);
        btnBluetoothPaired.setOnClickListener(this);
        btnSharedMessage.setOnClickListener(this);  
        btnMessage.setOnClickListener(this);
        btnTransFile.setOnClickListener(this);
        btnSettings.setOnClickListener(this);
        imgView.setOnClickListener(this);
        btnTransFile.setEnabled(false);
        btnSharedMessage.setEnabled(false);
        btnCallImg.setOnClickListener(this);
        imgView.setOnClickListener(this);
        cbxSNSERVER.setChecked(false);
        cbxSNSERVER.setOnClickListener(this);
        cbxRETRY.setOnClickListener(this);
        btnCallImg.setEnabled(false);
        
        
        mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(this);
		
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}		        
        
        listBTScanlist = (ListView) findViewById(R.id.bt_main_listView2);	        
        listBTPairlist = (ListView) findViewById(R.id.bt_main_listView1);        
        listBTStatuslist = (ListView) findViewById(R.id.bt_main_listView3);        

        
     // Initialize array adapters. One for already paired devices and
        // one for newly discovered devices
        mPairedDevicesArrayAdapter = new ArrayAdapter<String>(this, R.layout.bluetooth_device_name);
        mNewDevicesArrayAdapter = new ArrayAdapter<String>(this, R.layout.bluetooth_device_name);  
        mStatusAdapter = new ArrayAdapter<String>(this, R.layout.bluetooth_device_name);
               
        
        listBTScanlist.setAdapter(mNewDevicesArrayAdapter);
        listBTPairlist.setAdapter(mPairedDevicesArrayAdapter);
        listBTStatuslist.setAdapter(mStatusAdapter);
        
        
        listBTScanlist.setOnItemClickListener(mDeviceClickListener);
        listBTPairlist.setOnItemClickListener(mDeviceClickListener);
        listBTStatuslist.setOnItemClickListener(mDeviceClickListener2);

        
        // Register for broadcasts when a device is discovered
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        
        this.registerReceiver(mReceiver, filter);   
//        filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
//        this.registerReceiver(mReceiver);

        
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);        
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 0);
        startActivity(discoverableIntent);
        
//        Settings.System.putInt(getContentResolver(), 
//        		Settings.System.BLUETOOTH_DISCOVERABILITY, 0); 
//        
//        Settings.System.putInt(getContentResolver(), 
//        		Settings.System.BLUETOOTH_DISCOVERABILITY_TIMEOUT, 300);
                      
        ShowPowerStatButtonText();
        
        mFileService = new BluetoothFileService(this, mHandler);   
        if (mBluetoothAdapter != null)
        {
	        if (BluetoothAdapter.STATE_ON == mBluetoothAdapter.getState())
	        {	    
	        	mFileServiceFlag = 1;
	        	mFileService.start();
	        }
        }
        
    }
    
    
    @Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		
        InputMethodManager  mInput = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        mInput.hideSoftInputFromWindow(editDeviceName.getWindowToken(), 0);   		
	}
	
    public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if (Const.DEBUG) finish();
	}
	

	@Override
    protected void onDestroy() {
        super.onDestroy();    
        mWakeLock.release();
        if (mReceiver != null)
        {
        	unregisterReceiver(mReceiver);
        }        
        if (null != mFileTR)
		{
			try {
				mFileTR.StopTranRecv();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mFileTR = null;
		}        
        if (mFileService != null)
        {
        	synchronized (this)
        	{
        	mFileService.setExitFlag(1);
        	}
        	mFileService.stop();        	
        }           
        
        // Make sure we're not doing discovery anymore
        if (mBluetoothAdapter != null) {
        	if (mBluetoothAdapter.isDiscovering()) {
        		mBluetoothAdapter.cancelDiscovery();
        	}
        }    
        
		if (null != btThread)
		{
			btThread.stop();
			btThread.stopThread();
			btThread = null;
		}
        finish();
    }
	

 
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
         
		if (resultCode == RESULT_FIRST_USER){
        	strSendImage = data.getStringExtra("flag");
        	Log.d("onActivityResult",strSendImage);

        	if (1 == mnAndroidShared)
        	{
        		AndroidShared();
        	}
        	else if (null != mFileTR)
			{				

				try {
					FileTransRecvStart();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				mFileTR.SetTransFile(strSendImage);
				mFileTR.SetTransEvent(MESSAGE_WRITE, mFileTR.BT_REQ_CMD_FILE_NAME);										
			}
        	
        	mnAndroidShared = 0;
        }
         
        super.onActivityResult(requestCode, resultCode, data);
    } 

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		mPoolManger.playTouchSe();
		switch (v.getId()) {
		
		case R.id.bt_main_view:
			try {
				callBackGallary();
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		
		case R.id.top_exit:
			finish();
			break;
		case R.id.bt_main_btnBluetoothONOFF:
			SetBlueToothPower();
			break;
			
		case R.id.bt_main_btnScan:
			ScanBluetooth();
			break;
			
		case R.id.bt_main_btnPaired:
			GetPairedBluetooth();
			break;
			
		case R.id.bt_main_btnSharedMessage:
			{
				mnAndroidShared = 1;		
				Intent i = new Intent();
				i.setAction("tjmedia.intent.ACTION_EXPLORER");			
				startActivityForResult(i,RESULT_FIRST_USER);
			}
			break;
			
		case R.id.bt_main_btnSettings:
			AndroidSettings();
			btnSharedMessage.setEnabled(true);
			break;
			
		case R.id.bt_main_btnTransFile:
			{
				mnAndroidShared = 0;
				Intent i = new Intent();
				i.setAction("tjmedia.intent.ACTION_EXPLORER");			
				startActivityForResult(i,RESULT_FIRST_USER);
			}
			break;
			
		case R.id.bt_main_btnMessage:	
			if (null != mFileTR)
			{
				try {
					FileTransRecvStart();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				mFileTR.SetMessage(getAdaptername());
				mFileTR.SetTransEvent(MESSAGE_WRITE, mFileTR.BT_REQ_CMD_DEVID);					
			}
			break;
		
		case R.id.bt_main_btnCallImg:
			try {
				callBackGallary();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
		case R.id.bt_checkBox_index01:
			if(cbxSNSERVER.isChecked())
			{
				boolean status = SerialNumManager.isServerStatusForSerialNUM(getApplicationContext());
				Log.d(TAG, "checkbox.status=" + status);
				if (status) {
					TJListItem item = SerialNumManager.readLastSerialNumberByUSB(getApplicationContext());
					if (item == null) {
						mLastitem = new TJListItem("0", "AK000000", "0");
					} else {
						mLastitem = new TJListItem(item.getColumns(0), item.getColumns(1), item.getColumns(2));
					}
				} else {
					removeDialog(DIALOG_UNMOUNTED);
					showDialog(DIALOG_UNMOUNTED);
				}
				ShowPowerStatButtonText();
				//AgingUSBTest();
			}
			break;
		case R.id.bt_checkBox_index02:
			if(cbxRETRY.isChecked())
			{
				setAndroidSystemTime();								
			}
			break;
			
		default:
			break;
		}
	}
	
	private void setAndroidSystemTime() {
		 try {
			 //값 구하기
			 int autoTime = android.provider.Settings.System.getInt(getContentResolver(),
					 	android.provider.Settings.System.AUTO_TIME);
			 //값
			 boolean autuTimeCheck = autoTime==1 ? true : false; // 1:true(자동), 0:false(수동)
			 //확인
			 Log.d("test", "autotime check : "+autuTimeCheck );
			 // 반대로 설정값을 저장 할 수도있다.
			 android.provider.Settings.System.putInt(getContentResolver(),
					 android.provider.Settings.System.AUTO_TIME, autuTimeCheck==true ? 0 : 1);
		 } catch (SettingNotFoundException e) {
			 e.printStackTrace();
		 }
	}
	
	final int DIALOG_UNMOUNTED = 1;
	final int DIALOG_CLIENT = 2;
	@Override
	protected Dialog onCreateDialog(int id) {
		Log.d(TAG, "onCreateDialog().id = " + id);
		if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TINKERBELL);
		switch (id) {
			case DIALOG_UNMOUNTED:
				AlertDialog.Builder b = new AlertDialog.Builder(this);	
				b.setIcon(android.R.drawable.ic_dialog_alert);
//				.setTitle(getResources().getString(R.string.Bluetooth_main_index22));
				b.setMessage(getResources().getString(R.string.Bluetooth_main_index22));
				b.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						cbxSNSERVER.setChecked(false);
					}
				});
				return b.create();
			case DIALOG_CLIENT:
				
				
				
//				Calendar cal = Calendar.getInstance(Locale.KOREA);
//				String dTime = TJCalendarManager.getDateFormatter(cal.getTime())
//						+ ", " + TJCalendarManager.getTimeFormatter(cal.getTime());
				SimpleDateFormat formatter = new SimpleDateFormat ("yyyy/MM/dd HH:mm");
				Calendar cal = new GregorianCalendar( TimeZone.getTimeZone("GMT+09:00"),Locale.KOREA);
				Date date = new Date();
				TimeZone tz = TimeZone.getTimeZone("Asia/Seoul");
				formatter.setTimeZone(tz);
				String dTime = formatter.format(date);
				Log.d(TAG,formatter.format(date));
				
				AlertDialog.Builder b2 = new AlertDialog.Builder(this);	
				b2.setIcon(android.R.drawable.ic_dialog_alert);
				b2.setTitle(getResources().getString(R.string.Bluetooth_main_index23));
				b2.setMessage("SN : " + mLastitem.getColumns(1) + "\n"
						+ "Time : " + dTime + " Bluetooth Device Name: " + getAdaptername());
				b2.setPositiveButton(getResources().getString(R.string.ok), new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						finish();
					}
				});
				return b2.create();
		}
		return super.onCreateDialog(id);
	}
	
	@Override
	protected void onPrepareDialog(int id, Dialog dialog) {
		super.onPrepareDialog(id, dialog);
		Log.d(TAG, "onPrepareDialog()");
		switch (id) {
			case DIALOG_UNMOUNTED:
				break;
			case DIALOG_CLIENT:
				break;
		}
	}
	
	
	static String getAdaptername()
	{
        String strBtName = mBluetoothAdapter.getName();
		if (null == strBtName || strBtName.length() <= 0)
		{
			if (null != btThread)
			{		
				btThread.stopThread();									
				btThread.startThread();
				return "waiting..";
			}
		}
		return strBtName;	
	}
	
	public void FileTransRecvStart() throws IOException
	{
		if (true == GetBlueToothConnection())
		{
			if (null != mFileTR)
			{
				Log.d("STOP","=========================mFileTR Stop==================");
				mFileTR.StopTranRecv();
				mFileTR = null;
			}
			btnCallImg.setEnabled(false);
			Log.d("START","=========================mFileTR Start==================");
			mFileTR = new BluetoothFileTransRecv(this, mTransRecvFileHandler);	
			mFileTR.StartTranRecv();
		}
	}
	
	class BluetoothCheck extends Thread {
    	public boolean FLAG_RUN = true;
		@Override
		public void run() {
			// TODO Auto-generated method stub
			while (FLAG_RUN) {
				try {
					String strBtname = mBluetoothAdapter.getName();
					if (null != strBtname && BluetoothAdapter.STATE_ON == mBluetoothAdapter.getState())
					{						 							
						runOnUiThread(subthread);		
						this.FLAG_RUN = false;
					}
					sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
		public void stopThread() { 
	        this.FLAG_RUN = false; 
	    } 
		public void startThread() { 
	        this.FLAG_RUN = true; 
	    } 		
	};
 	
	private Runnable subthread = new Runnable()
	{
		@Override
		public void run()
		{		
			editDeviceName.setText(getAdaptername());
			if (mFileServiceFlag == 0)
	    	{
		    	mFileService.start();
		    	mFileServiceFlag = 1;
	    	}
		}
	};
	
	public void ShowPowerStatButtonText()
	{
        if (mBluetoothAdapter != null)
        {
	        int nStat = mBluetoothAdapter.getState();
	        if (nStat == BluetoothAdapter.STATE_ON || nStat == BluetoothAdapter.STATE_TURNING_ON)
	        {
	        	try {
	        		btnBluetoothOnOff.setText("Bluetooth Power OFF");	        			        		
				} catch (Exception e) {
					// TODO: handle exception
				}	        	
	        	
	        }
	        else
	        {
	        	try {
	        		btnBluetoothOnOff.setText("Bluetooth Power ON");	
				} catch (Exception e) {
					// TODO: handle exception
				}	        	

	        }
	        editDeviceName.setText(getAdaptername());
        }	
        
        
	}
	
	public void ShowMessageBox(String Title,String Message, String ButtonStr)
	{
		AlertDialog alertDlg = new AlertDialog.Builder(this)
				.setIcon(R.drawable.ic_launcher)
				.setTitle(Title)
				.setMessage(Message)
				.setPositiveButton(ButtonStr,new DialogInterface.OnClickListener() 
				{

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						mPoolManger.playTouchSe();
						
					}
					
				}				
				)				
				.show();				
	}	
	
	public void ShowMessageBox2(String Title,String Message, String ButtonStr, String ButtonStr2)
	{
		boolean ret = false;
		AlertDialog alertDlg = new AlertDialog.Builder(this)
				.setIcon(R.drawable.ic_launcher)
				.setTitle(Title)
				.setMessage(Message)
				.setPositiveButton(ButtonStr,new DialogInterface.OnClickListener() 
				{

					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub	
						mPoolManger.playTouchSe();
					}
					
				}				
				)
				.setPositiveButton(ButtonStr2,new DialogInterface.OnClickListener() 
				{
					
					@Override
					public void onClick(DialogInterface dialog, int which) 
					{
						// TODO Auto-generated method stub			
						mPoolManger.playTouchSe();
					}
				}				
				)
				.show();				
	}		
	public void printToast(String messageToast) {
		if (null != mToast)
			mToast.cancel();
		mToast = Toast.makeText(this, messageToast, Toast.LENGTH_LONG);
		mToast.setGravity(Gravity.TOP,0, 0);
		mToast.show();
		
	}	
	
	public boolean GetBlueToothReady()
	{
		if (null == mBluetoothAdapter) return false;
			
		int nStat = mBluetoothAdapter.getState();
		return (nStat == BluetoothAdapter.STATE_ON)? true:false;
	}
	
	public static boolean GetBlueToothConnection()
	{
		if (null == mBluetoothAdapter || null == mFileService) return false;
			
		if (mFileService.getState() == BluetoothFileService.STATE_CONNECTED)	return true;
		
		return false;
	}	
	
	public void SetBlueToothPower()
	{
		if (null == mBluetoothAdapter)
		{
			ShowMessageBox("BLUETOOTH STATUS","Device does not support Bluetooth","OK");
			return;
		}	
		int nStat = mBluetoothAdapter.getState();
		switch(nStat)
		{
			case BluetoothAdapter.STATE_ON:						
				mBluetoothAdapter.disable();				
				printToast("Bluetooth power is turn off");																									
				break;
			case BluetoothAdapter.STATE_TURNING_ON:						
				printToast("Sorry,Bluetooth Power is turning on");
				break;					
			case BluetoothAdapter.STATE_OFF:
				mBluetoothAdapter.enable();				
				printToast("Bluetooth power is turn on");
				break;					
			case BluetoothAdapter.STATE_TURNING_OFF:					
				printToast("Sorry,Bluetooth Power is turning off");
				break;					
		}
		ShowPowerStatButtonText();
	}
	
	/**
     * Start device discover with the BluetoothAdapter
     */
    private void ScanBluetooth() {

        // Indicate scanning in the title        
        //setTitle("scan ���Դϴ�.");
    	btnTransFile.setEnabled(false);
    	btnSharedMessage.setEnabled(false);
		if (false == GetBlueToothReady())
		{
			ShowMessageBox("BLUETOOTH STATUS","Device does not support Bluetooth","OK");
			return;
		}
		if(mBluetoothAdapter.isDiscovering())
		{
			mBluetoothAdapter.cancelDiscovery();
		}

		mNewDevicesArrayAdapter.clear();
        // Request discover from BluetoothAdapter
		mBluetoothAdapter.startDiscovery();
    }	
	
	public void GetPairedBluetooth()
	{		
		if (false == GetBlueToothReady())
		{
			ShowMessageBox("BLUETOOTH STATUS","Device does not support Bluetooth","OK");
			return;
		}
		mPairedDevicesArrayAdapter.clear();
		Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
		
		ArrayList<String> result = new ArrayList<String>();
		
		if (pairedDevices.size() > 0) 
		{
	         for (BluetoothDevice device : pairedDevices) 
	         {	        	 	        	 
        		 if (null != mTmpBluetoothDevice &&
        				 device.getAddress().equalsIgnoreCase(mTmpBluetoothDevice.getAddress()))
        		 {
        			 mPairedDevicesArrayAdapter.insert("connected:" + device.getName() + device.getAddress(),0);
        			 mBluetoothDevice = mTmpBluetoothDevice;
        		 }
        		 else
        		 {
        			 mPairedDevicesArrayAdapter.insert(device.getName() + device.getAddress(),0);
        		 }
	             
	         }
	         		         
	     }				
	}
	
    // The on-click listener for all devices in the ListViews
    private OnItemClickListener mDeviceClickListener = new OnItemClickListener() {
        
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			// TODO Auto-generated method stub
			mBluetoothAdapter.cancelDiscovery();
			
			if (true == GetBlueToothConnection())
			{
				if (null != mBluetoothDevice )
				{					
					printToast("Disconnecting:"+ mBluetoothDevice.getName());
					mBluetoothDevice = mTmpBluetoothDevice = null;
//					mFileService.stop();
//					mFileService.start();
				}
			}
			
			btnTransFile.setEnabled(false);
			btnSharedMessage.setEnabled(false);
            // Get the device MAC address, which is the last 17 chars in the View
            String info = ((TextView)view).getText().toString();
            String address = info.substring(info.length() - 17);
            
            SetParing(address);		
			
		}
    };	
    
    private OnItemClickListener mDeviceClickListener2 = new OnItemClickListener() {
    	@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {    	
    	}
    };
    
    public boolean SetParing(String address)
    {
    	mTmpBluetoothDevice = mBluetoothAdapter.getRemoteDevice(address);
    	    	    	
    	//mFileService = new BluetoothFileService(this, mHandler);        	
    	mFileService.connect(mTmpBluetoothDevice, false);
		return true;
    }
    
    // The BroadcastReceiver that listens for discovered devices and
    // changes the title when discovery is finished
    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        
    	@Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            // When discovery finds a device
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Get the BluetoothDevice object from the Intent
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // If it's already paired, skip it, because it's been listed already
                if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
                	
                	for(int i = 0; i < mNewDevicesArrayAdapter.getCount(); i++)
                	{
                		if (true == mNewDevicesArrayAdapter.getItem(i).
                				equalsIgnoreCase(device.getName() + " " + device.getAddress()) )
                		{
                			return;
                		}
                	}
                	
                    mNewDevicesArrayAdapter.add(device.getName() + " " + device.getAddress());
                }
            // When discovery is finished, change the Activity title
            } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                setProgressBarIndeterminateVisibility(false);
                setTitle("new devices");
                if (mNewDevicesArrayAdapter.getCount() == 0) {                    
                    mNewDevicesArrayAdapter.insert("no Devices",0);
                }
            } 
        }
		
    };   
    
    
    
    void AndroidShared()
    {
		Intent i = new Intent(Intent.ACTION_SEND);
		File file = new File(strSendImage);
		
		Uri uri =Uri.fromFile(file);
		i.setType("image/jpeg");    
		i.putExtra(Intent.EXTRA_STREAM, uri); 
		startActivity(i);//Intent.createChooser(i, "Send Image"));	    		
    }
    
    void AndroidSettings()
    {
    	startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));    	 
//    	Intent intent = new Intent(Intent.ACTION_MAIN);
//		intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.ProxySelector"));
//		startActivity(intent);			    	
    }    
    
//	mStatArrayAdapter.clear();
//	mStatArrayAdapter.add("���� data:" + readMessage);
    void Tdmk_SetDate(String str)
    {
    	Calendar cal = new GregorianCalendar( TimeZone.getTimeZone("GMT+09:00"),Locale.KOREA);
	    Date date = new Date();
	    String[] values = str.split("-");
	    
	    cal.set(
	    		Integer.parseInt(values[0]),
	    		Integer.parseInt(values[1])-1,
	    		Integer.parseInt(values[2]),
	    		Integer.parseInt(values[3]),
	    		Integer.parseInt(values[4]),
	    		0);	    
	    long when = cal.getTimeInMillis();  
	    if (when / 1000 < Integer.MAX_VALUE) {
	      SystemClock.setCurrentTimeMillis(when);            
	    }
	      
	    SimpleDateFormat formatter = new SimpleDateFormat ("yyyyMMddHHmmss");                   
	    TimeZone tz = TimeZone.getTimeZone("Asia/Seoul");
	    formatter.setTimeZone(tz);
	    Log.d(TAG,formatter.format(date));
    }
    
    String readySNData = null;
    private final Handler mTransRecvFileHandler = new Handler()
    {
     	@Override
        public void handleMessage(Message msg) {
     		 switch (msg.what) {
     		 	
  		 	case MESSAGE_TRANS_FILE_NAME:
		 			{
		 				Log.e(TAG, "mTransRecvFileHandler");
		 				mFileuri = null;
		 				byte[] readBuf = new byte[msg.arg1]; 
	 		 			readBuf = (byte[]) msg.obj;		 			
	 		 			String readMessage = new String(readBuf, 0, msg.arg1); 		
	 		 			strRecvFilename = readMessage;
	 		 			mStatusAdapter.insert("Trans File Info:" + readMessage + " (" + msg.arg2 + ")",0);     
	 		 			progressbarstatus.setMax(msg.arg2);
	 		 			btnCallImg.setText("View Trans File");
	 		 			Uri uri = Uri.parse(strRecvFilename);
		 				imgView.setImageURI(uri); 
	 		 			btnCallImg.setEnabled(false);
		 			}
		 			break;
		 			
  		 	case MESSAGE_TRANS_STATUS:
		 			{
//		 				byte[] readBuf = new byte[msg.arg1]; 
//		 				readBuf = (byte[]) msg.obj;		 			
//		 				String readMessage = new String(readBuf, 0, msg.arg1);
//		 				mStatusAdapter.insert("���� ����� :" + readMessage + " (" + msg.arg2 + ")", 0);  
		 				progressbarstatus.setProgress(msg.arg2);
		 			}
		 			break;
		 		
  		 	case MESSAGE_TRANS_END:
		 			{
		 				byte[] readBuf = new byte[msg.arg1];
	 		 			readBuf = (byte[]) msg.obj;
	 		 			String readMessage = new String(readBuf, 0, msg.arg1); 		 						 				
		 				mStatusAdapter.insert("END:" + readMessage + " (" + msg.arg2 + ")",0);
		 				
		 				MediaScannerConnection.scanFile(getApplicationContext(), new String[] { strRecvFilename }, null, mMscListener);
		 				btnCallImg.setText("View Trans File");
		 				btnCallImg.setEnabled(true);
		 				progressbarstatus.setProgress(msg.arg2);
		 				Uri uri = Uri.parse(strRecvFilename);
		 				imgView.setImageURI(uri);     

		 				printToast("END:" + readMessage + " (" + msg.arg2 + ")");
		 			}
		 			break;     		 
     		 
     		 	case MESSAGE_RECV_FILE_NAME:
 		 			{
 		 				byte[] readBuf = new byte[msg.arg1]; 
 	 		 			readBuf = (byte[]) msg.obj;		 	
 	 		 			mFileuri = null;
 	 		 			String readMessage = new String(readBuf, 0, msg.arg1); 		
 	 		 			strRecvFilename = readMessage;
 	 		 			mStatusAdapter.insert("Recv File Info :" + readMessage + " (" + msg.arg2 + ")",0);     
 	 		 			progressbarstatus.setMax(msg.arg2);	 		 	
 	 		 			btnCallImg.setText("View Recv File");
 	 					btnTransFile.setEnabled(false);
 	 					btnSharedMessage.setEnabled(false);
 		 			}
 		 			break;

     		 	case MESSAGE_RECV_STATUS:
 		 			{
// 		 				byte[] readBuf = new byte[msg.arg1]; 
// 		 				readBuf = (byte[]) msg.obj;		 			
// 		 				String readMessage = new String(readBuf, 0, msg.arg1);
// 		 				mStatusAdapter.insert("���� ������ :" + readMessage + " (" + msg.arg2 + ")", 0);  
 		 				progressbarstatus.setProgress(msg.arg2);
 		 			}
 		 			break;
 		 		
     		 	case MESSAGE_RECV_END:
 		 			{
 		 				byte[] readBuf = new byte[msg.arg1];
 	 		 			readBuf = (byte[]) msg.obj;
 	 		 			String readMessage = new String(readBuf, 0, msg.arg1); 		 				
 		 				
 		 				mStatusAdapter.insert("END :" + readMessage + " (" + msg.arg2 + ")",0);
 		 				
 		 				MediaScannerConnection.scanFile(getApplicationContext(), new String[] { strRecvFilename }, null, mMscListener);
 	 					btnTransFile.setEnabled(true);
 	 					btnSharedMessage.setEnabled(true); 		 				
 		 				progressbarstatus.setProgress(msg.arg2);
 		 				btnCallImg.setEnabled(true);
		 				Uri uri = Uri.parse(strRecvFilename);
		 				imgView.setImageURI(uri);     
 		 				
 		 				printToast("END:" + readMessage + " (" + msg.arg2 + ")");
 		 			}
 		 			break;     		 		
     		 	
     		 	case MESSAGE_READ:
     		 		{
	     		 		byte[] readBuf = new byte[msg.arg1]; 
	     		 		readBuf = (byte[]) msg.obj;
	     		 		String readMessage = new String(readBuf, 0, msg.arg1); 		 						 			
			 			mStatusAdapter.insert(readMessage,0);
	     		 	}
     		 		break;
     		 		
     		 	case MESSAGE_SNREAD:
	     		 	{
	     		 		byte[] readBuf = new byte[msg.arg1]; 
	     		 		readBuf = (byte[]) msg.obj;
	     		 		String readMessage = new String(readBuf, 0, msg.arg1); 	
	     		 		readySNData = new String(readBuf, 0, msg.arg1);			 						 						 			
	     		 	}
     		 		break;
     		 		
     		 	case MESSAGE_SNSAVE:
     		 		{
			 			mStatusAdapter.insert("SerialNumber:"+ readySNData,0);			 			
			 			// writeSN("") setRTC("");
			 			String[] args = readySNData.split(",");
			 			mLastitem = new TJListItem(args[0], args[1]);		
			 			
			 			if (!(strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
//			 			if (!Log.getTJ())
						{
			 				mBluetoothAdapter.setName(args[1]);
			 				SystemClock.sleep(200);
			 				ShowPowerStatButtonText();
			 				printToast("bluetooth device name 변경:" + getAdaptername());
						}
			 			else
			 			{
				 			Tdmk_SetDate(args[2]);
				 			TDMKMisc_Service.SYSTEM_SetSerialNumber(args[1]);
				 			//mBluetoothAdapter.setName("TM10-"+args[1]);
				 			TDMKMisc_Service.BLUETOOTH_ChangeDeviceName("TM10-"+args[1]);
				 			SystemClock.sleep(200);
				 			ShowPowerStatButtonText();
				 			removeDialog(DIALOG_CLIENT);
				 			if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TINKERBELL);
				 			showDialog(DIALOG_CLIENT);
			 			}
     		 		}
     		 		break;
     		 		
     		 	case MESSAGE_SNWRITE:
	     		 	{
	     		 		byte[] readBuf = new byte[msg.arg1]; 
	     		 		readBuf = (byte[]) msg.obj;
	     		 		String readMessage = new String(readBuf, 0, msg.arg1);
	     		 		
     		 			boolean result = SerialNumManager.compareSerialNUM(readMessage, mLastitem);
     		 			Log.d(TAG, "Write:" 
     		 					+ mLastitem.getColumns(0) + ","
     		 					+ mLastitem.getColumns(1)
     		 					);
     		 			Log.e(TAG, "MESSAGE_SNWRITE=" + readMessage + ", result=" + result);
     		 			if (result && !cbxRETRY.isChecked()) {
     		 				String[] args = readMessage.split(",");
     		 				mLastitem = new TJListItem(args[0], args[1]);
     		 				SerialNumManager.writeSerialInfoToUSB(mLastitem);
         		 			mStatusAdapter.insert("Recv SN:" + readMessage, 0);			 			
    			 			printToast("전송된 SN:" + readMessage);
    			 			if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_SHUTTER);
    			 			mFileTR.SetTransEvent(MESSAGE_WRITE, mFileTR.BT_CMD_OK_SN);
     		 			}
     		 			else if (result && cbxRETRY.isChecked()) {
     		 				String[] args = readMessage.split(",");
     		 				mLastitem = new TJListItem(args[0], args[1]);
         		 			mStatusAdapter.insert("Retry Recv SN:" + readMessage, 0);			 			
    			 			printToast("전송된 SN:" + readMessage);
    			 			if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_SHUTTER);
    			 			mFileTR.SetTransEvent(MESSAGE_WRITE, mFileTR.BT_CMD_OK_SN);
     		 			}     		 			
     		 			else
     		 			{
							Log.e(TAG, "SN Compare Error => RETRY!!!:" + mLastitem.getColumns(0) + ","+ mLastitem.getColumns(1));
//							SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd-HH-mm");
//							Calendar cal = Calendar.getInstance(Locale.KOREA);
//							String dTime = formatter.format(cal.getTime());
							
							SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd-HH-mm");
							Calendar cal = new GregorianCalendar( TimeZone.getTimeZone("GMT+09:00"),Locale.KOREA);
							Date date = new Date();
							TimeZone tz = TimeZone.getTimeZone("Asia/Seoul");
							formatter.setTimeZone(tz);
							String dTime = formatter.format(date);
							Log.d(TAG,formatter.format(date));
							
							mFileTR.SetMessage(mLastitem.getColumns(0) + ","+ mLastitem.getColumns(1) + "," + dTime);
							mFileTR.SetTransEvent(MESSAGE_WRITE, mFileTR.BT_REQ_CMD_SN);
     		 			}
     		 			
     		 		}
	 		 		break;     		 		
     		 		
     		 }
     	}
    };
    
        
    private void callBackGallary() throws InterruptedException {
    	if (null != strRecvFilename && null != mFileuri)
    	{    		            
    		//Intent i = new Intent(Intent.ACTION_VIEW, mFileuri);
    		//startActivity(i);
    		    		
    		Intent intent = new Intent("tjmedia.intent.ACTION_VIEW");
			intent.putExtra("param1", strRecvFilename); 
			startActivity(intent);
    		
    	}
    }
    
   	
    MediaScannerConnection.OnScanCompletedListener mMscListener = 
			new MediaScannerConnection.OnScanCompletedListener() {
		@Override
		public void onScanCompleted(String arg0, Uri arg1) {
			Log.i("ExternalStorage", "Scanned " + arg0 + ":");
			Log.i("ExternalStorage", "-> uri=" + arg1);
			mFileuri = arg1;					
		}
	};    
	
	private long getThelastImageUriInfoFromMediaStore() {
		long ImageNum = 0;
		String[] projection = {"MAX(" + MediaStore.Images.Media._ID +")",
				MediaStore.Images.Media.DATA,
				MediaStore.Images.Media.DISPLAY_NAME,
				MediaStore.Images.Media.SIZE,
				MediaStore.Images.Media.MIME_TYPE};
//		Uri uri = Uri.parse("MediaStore.Images.Media.EXTERNAL_CONTENT_URI");
		
		String selection = null;
		String[] selectionArgs = null;
		String sortOrder = MediaStore.Images.Media._ID + " DESC";
//		if (ImageNum != 0) {
//			selection = "MAX(" + MediaStore.Images.Media._ID +")";
//			selectionArgs = new String[] {String.valueOf(ImageNum)};
//		}
		Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, 
				selection, selectionArgs, sortOrder);
//		TJListItem item = null;
//		ArrayList<TJListItem> Items = new ArrayList<TJListItem>();
		int i=0;
		try {
			if(cursor != null && cursor.getCount() !=0) {
//				Log.d(TAG, "cursor.getCount():"+cursor.getCount());
				cursor.moveToFirst();
//				item = new TJListItem(cursor.getString(0), cursor.getString(1), cursor.getString(2), 
//						cursor.getString(3), cursor.getString(4));
//				Items.add(item);
//				Log.i(TAG, "TJListItem[" + i + "] = " + item.getColumns(0) + ", " + item.getColumns(1) + ", "  
//						+ item.getColumns(2) + ", "  + item.getColumns(3) + ", "  + item.getColumns(4));
				try {
					ImageNum = Integer.valueOf(cursor.getString(0));
				} catch (NumberFormatException nfe) {
//					Log.d(TAG, "NumberFormatException : " + nfe.getMessage());
				}
			}
			cursor.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ImageNum;
//		return null;
	}	
    
	private final Handler mHandler = new Handler() 
    {
    	@Override
    	synchronized public void handleMessage(Message msg) {
            switch (msg.what) {
            
            case MESSAGE_WRITE:                   	
                break;
            case MESSAGE_READ:
            	{            		
//            		byte[] readBuf = (byte[]) msg.obj;
//            		// construct a string from the valid bytes in the buffer
//            		String readMessage = new String(readBuf, 0, msg.arg1);
//            		//printToast("���� data:" + readMessage);
//            		mStatArrayAdapter.clear();
//            		mStatArrayAdapter.add("���� data:" + readMessage);
            		Log.e(TAG, "mHandler");
            		byte[] readBuf = (byte[]) msg.obj;
            		if (null != mFileTR)
            		{            			
            			mFileTR.WriteBuff(MESSAGE_READ, readBuf, msg.arg1);
            		}
            		else
            		{
            			String readMessage = new String(readBuf, 0, msg.arg1);
            			mStatusAdapter.add("message:" + readMessage);
            		}
            	}            
                break;
            case MESSAGE_STATE_CHANGE:
            	
                switch (msg.arg1) {
                case BluetoothFileService.STATE_CONNECTED:                	
                    break;
                case BluetoothFileService.STATE_CONNECTING:
                	if (null != mTmpBluetoothDevice)
                		printToast("STATE_CONNECTING:"+ mTmpBluetoothDevice.getName() );                	
                    break;
                case BluetoothFileService.STATE_LISTEN:                
                	//printToast("STATE_LISTEN");
                	GetPairedBluetooth();
                    break;
                case BluetoothFileService.STATE_NONE:
                	//printToast("STATE_NONE");
                	GetPairedBluetooth();
                	break;
                }            	                
            	break;
            case MESSAGE_DEVICE_NAME:
            	// Serial Number Server
            	
                String address = msg.getData().getString(DEVICE_NAME);
                mTmpBluetoothDevice = mBluetoothAdapter.getRemoteDevice(address);
                if (null != mTmpBluetoothDevice)                
                
                btnTransFile.setEnabled(true);
				btnSharedMessage.setEnabled(true); 		 				
	 			progressbarstatus.setProgress(0);
	 			btnCallImg.setEnabled(false);                
                
                try {
					FileTransRecvStart();
					if (cbxSNSERVER.isChecked())
					{
						try {
							FileTransRecvStart();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						// Serial number is comparing.
						if (mLastitem != null) {
							TJListItem item = null;
							if (!cbxRETRY.isChecked()) {
								item = TJCalendarManager.getNextSerialFormat(mLastitem);
							} else {
								item = SerialNumManager.readLastSerialNumberByUSB(getApplicationContext());
							}
							// para { Id, Serial, Date}
							if (item != null) {
								mLastitem = new TJListItem(item.getColumns(0), item.getColumns(1));
								Log.e(TAG, "TRANSTART:" + mLastitem.getColumns(0) + ","+ mLastitem.getColumns(1));
//								SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd-HH-mm");
//								Calendar cal = Calendar.getInstance(Locale.KOREA);
//								String dTime = formatter.format(cal.getTime());
								
								SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd-HH-mm");
								Calendar cal = new GregorianCalendar( TimeZone.getTimeZone("GMT+09:00"),Locale.KOREA);
								Date date = new Date();
								TimeZone tz = TimeZone.getTimeZone("Asia/Seoul");
								formatter.setTimeZone(tz);
								String dTime = formatter.format(date);
								Log.d(TAG,formatter.format(date));
								
								mFileTR.SetMessage(mLastitem.getColumns(0) + ","+ mLastitem.getColumns(1) + "," + dTime);
								mFileTR.SetTransEvent(MESSAGE_WRITE, mFileTR.BT_REQ_CMD_SN);
							} else {
								printToast("File is empty");
							}
						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                printToast("Connected to "+ mTmpBluetoothDevice.getName());                
                GetPairedBluetooth();
                break;
                
                //connectionFailed , connectionLost
            case MESSAGE_DISCONNECT:
            	mTmpBluetoothDevice = null;
            	if (null != mFileTR)
    			{
    				try {
						mFileTR.StopTranRecv();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    				mFileTR = null;
    			}            	
            	GetPairedBluetooth();
            	printToast(msg.getData().getString(TOAST));
            	
//        		if(mBluetoothAdapter.isDiscovering())
//        		{
//        			mBluetoothAdapter.cancelDiscovery();
//        		}
//        		mBluetoothAdapter.startDiscovery();
            	//mFileService.start();
                break;
            }
        }
    };
    
    void AgingUSBTest()
    {
    	int i = 0;
    	while(i++ < 9999)
    	{
	    	TJListItem item = null;
			item = TJCalendarManager.getNextSerialFormat(mLastitem);
			// para { Id, Serial, Date}
			if (item != null) {
				mLastitem = new TJListItem(item.getColumns(0), item.getColumns(1));
				Log.e(TAG, "TRANSTART[" + i + "]:" + mLastitem.getColumns(0) + ","+ mLastitem.getColumns(1));
				SerialNumManager.writeSerialInfoToUSB(mLastitem);
				SystemClock.sleep(1);
				
			}
	    	
    	}
    }
    
    
 
}
