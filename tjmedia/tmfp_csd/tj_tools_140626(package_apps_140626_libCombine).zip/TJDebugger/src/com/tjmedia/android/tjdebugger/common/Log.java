package com.tjmedia.android.tjdebugger.common;

public class Log {
	public static final String TAG = "TJDebugger";
	public static final boolean DEBUG = true;

	public static final void v(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.v(TAG, tag + "." + msg);
		}
	}

	public static final void e(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.e(TAG, tag + "." + msg);
		}
	}

	public static final void e(String tag, String msg, Exception ex) {
		if (DEBUG) {
			android.util.Log.e(TAG, tag + "." + msg, ex);
		}
	}
	
	public static final void w(String tag, String msg, Exception ex) {
		if (DEBUG) {
			android.util.Log.e(TAG, tag + "." + msg, ex);
		}
	}

	public static final void d(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.d(TAG, tag + "." + msg);
		}
	}

	public static final void i(String tag, String msg) {
		if (DEBUG) {
			android.util.Log.i(TAG, tag + "." + msg);
		}
	}
	
	public static boolean getTMFP()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia") || strManufacturer.equals("TJMEDIA")) && (strProduct.equals("fptm") || strProduct.equals("tmfp")))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	public static boolean getCSD()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia") || strManufacturer.equals("TJMEDIA")) && (strProduct.equals("csd")))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	
	public static boolean getTmpCSD()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if (strProduct.equals("csd"))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
	
	public static boolean getTJ()
	{
		String strManufacturer = android.os.Build.MANUFACTURER;	
		String strProduct = android.os.Build.HARDWARE;
		if (strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia") || strManufacturer.equals("TJMEDIA"))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}	
}