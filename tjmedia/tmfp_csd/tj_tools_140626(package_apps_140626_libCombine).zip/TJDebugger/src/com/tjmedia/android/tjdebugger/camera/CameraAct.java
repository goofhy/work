package com.tjmedia.android.tjdebugger.camera;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.CamcorderProfile;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.MediaStore;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SharedManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJListItem;
import com.tjmedia.android.tjdebugger.common.ToastManager;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : Jimmy
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class CameraAct extends Activity {   
   
	private static final String TAG = "CameraAct"; 	
	
	private TJCameraView mPreview;
	Button mTitleExit;
	Handler mHandler = new Handler();
	SoundPoolManager mPoolManger;
	private PowerManager mPowerManager;
    private WakeLock mWakeLock;

	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.camera_main);
        initViewInfo();
        initMediaInfo();
        initObjects();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
		initCameraSurfaceView();
		mWakeLock.acquire();
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		releaseMediaRecorder();
		releaseCamera();
		mWakeLock.release();
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
		mCameraResolution.removeAllViews();
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if (Const.DEBUG)
		finish();
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
		if (resultCode == RESULT_OK) {
//			initViewInfo();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
	
	android.hardware.Camera mCamera;
	FrameLayout mCameraResolution;
	private void initViewInfo() {
//		mCamera = TJCameraView.getCameraInstance();
//		mPreview = new TJCameraView(this, mCamera);
		mCameraResolution = (FrameLayout) findViewById(R.id.Camera_Main_FL01);
		int settingIndex = SharedManager.getSettingCameraSetting(getApplicationContext());
		setHolderSize(getApplicationContext(), settingIndex);
		
		InnerCamera.mComponet01 = (Button)findViewById(R.id.Camera_Main_INDEX01);
		InnerCamera.mComponet02 = (Button)findViewById(R.id.Camera_Main_INDEX02);
		InnerCamera.mComponet03 = (Button)findViewById(R.id.Camera_Main_INDEX03);
		InnerCamera.mComponet04 = (Button)findViewById(R.id.Camera_Main_INDEX04);
		InnerCamera.mComponet05 = (Button)findViewById(R.id.Camera_Main_INDEX05);
		InnerCamera.mComponet06 = (Button)findViewById(R.id.Camera_Main_INDEX06);
		InnerCamera.mComponet07 = (Button)findViewById(R.id.Camera_Main_INDEX07);
		InnerCamera.mComponet08 = (ImageView)findViewById(R.id.Camera_Main_INDEX08);
		InnerCamera.mComponet99 = (ImageView)findViewById(R.id.Camera_Main_INDEX99);
		
		InnerCamera.mComponet01.setOnClickListener(mClickListener);
		InnerCamera.mComponet02.setOnClickListener(mClickListener);
		InnerCamera.mComponet03.setOnClickListener(mClickListener);
		InnerCamera.mComponet04.setOnClickListener(mClickListener);
		InnerCamera.mComponet05.setOnClickListener(mClickListener);
		InnerCamera.mComponet06.setOnClickListener(mClickListener);
		InnerCamera.mComponet07.setOnClickListener(mClickListener);
		InnerCamera.mComponet08.setOnClickListener(mClickListener);
		InnerCamera.mComponet11 = (LinearLayout)findViewById(R.id.Camera_Main_INDEX11);
		InnerCamera.mComponet12 = (LinearLayout)findViewById(R.id.Camera_Main_INDEX12);
		InnerCamera.mComponet13 = (LinearLayout)findViewById(R.id.Camera_Main_INDEX13);
		InnerCamera.mComponet14 = (LinearLayout)findViewById(R.id.Camera_Main_INDEX14);
		
		if (Log.getTMFP() ||Log.getCSD())
		{
			InnerCamera.mComponet01.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet02.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet03.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet04.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet05.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet06.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet07.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet08.setVisibility(View.INVISIBLE);
			InnerCamera.mComponet99.setVisibility(View.INVISIBLE);
		}
		
	}
	
	private void initMediaInfo() {
		mountInfoExternalStorage();
//		TJListItem item = null;
//		item = getThelastImageUriInfoFromMediaStore();
//		if (item != null) {
//			updateViewImage(item);
//		}
		
	}
	
	private void initCameraSurfaceView() {
		mCamera = TJCameraView.getCameraInstance();
		mPreview = new TJCameraView(this, mCamera);
		mCameraResolution.addView(mPreview, mDisplayWidth, mDisplayHeight);
		//SystemClock.sleep(300);
		updateSettingInfoForCamera();
	}
	
	
	void initObjects() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
		mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = mPowerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, 
				getClass().getName());
	}
	
	private boolean mMUTEX_Camera_SnapShot = false;
	private View.OnClickListener mClickListener = new View.OnClickListener() {
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.top_exit:
				mPoolManger.playTouchSe();
				if (isRecording)
				{
					mMUTEX_Camera_SnapShot = false;
		            mMediaRecorder.stop();  // stop the recording
		            releaseMediaRecorder(); // release the MediaRecorder object
		            mCamera.lock();         // take camera access back from MediaRecorder
		            
		            isRecording = false;
				}
				releaseMediaRecorder();
				releaseCamera();
				deleteStorageDirectory();
				finish();
				break;
			case R.id.Camera_Main_INDEX01:
				if (mMUTEX_Camera_SnapShot) return;
				mPoolManger.playTouchSe();
				InnerCamera.removeAllComponent(1);
				if(!FLAG_POPUP_STATE_EXPOSE) {
					showPopUpForExposureCompensation(FLAG_MODE_EXPOSE);
					FLAG_POPUP_STATE_EXPOSE = true;
				} else {
					InnerCamera.mComponet11.removeAllViews();
					FLAG_POPUP_STATE_EXPOSE = false;
				}
				break;
			case R.id.Camera_Main_INDEX02:
				if (mMUTEX_Camera_SnapShot) return;
				mPoolManger.playTouchSe();
				InnerCamera.removeAllComponent(2);
				if(!FLAG_POPUP_STATE_FLASH) {
					showPopUpForCameraFLASH(FLAG_MODE_FLASH);
					FLAG_POPUP_STATE_FLASH = true;
				} else {
					InnerCamera.mComponet12.removeAllViews();
					FLAG_POPUP_STATE_FLASH = false;
				}
				break;
			case R.id.Camera_Main_INDEX03:
				if (mMUTEX_Camera_SnapShot) return;
				mPoolManger.playTouchSe();
				InnerCamera.removeAllComponent(3);
				if(!FLAG_POPUP_STATE_BALANCE) {
					showPopUpForCameraBALACE(FLAG_MODE_BALANCE);
					FLAG_POPUP_STATE_BALANCE = true;
				} else {
					InnerCamera.mComponet13.removeAllViews();
					FLAG_POPUP_STATE_BALANCE = false;
				}
				break;
			case R.id.Camera_Main_INDEX04:
				if (mMUTEX_Camera_SnapShot) return;
				mPoolManger.playTouchSe();
				InnerCamera.removeAllComponent(4);
				if(!FLAG_POPUP_STATE_SETTING) {
					showPopUpForCameraSetting(FLAG_MODE_SETTING);
					FLAG_POPUP_STATE_SETTING = true;
				} else {
					InnerCamera.mComponet14.removeAllViews();
					FLAG_POPUP_STATE_SETTING = false;
				}
				break;
			case R.id.Camera_Main_INDEX05:		// snapshot
				if (isRecording) {
					ToastManager.showToast(getApplicationContext(), "please, Stop recording!!!", Toast.LENGTH_SHORT);
					return;
				}
				else if(I_MEDEA_IMAGE_CONTEXT_TYPE == true) {
					ToastManager.showToast(getApplicationContext(), "SD Card unmounted, not prepare", Toast.LENGTH_SHORT);
					return;
				}

				InnerCamera.removeAllComponent(-1);
				if (!mMUTEX_Camera_SnapShot) {
					mMUTEX_Camera_SnapShot = true;
					mPoolManger.playTouchSe();
					mPreview.takeASnapShot();
					mHandler.postDelayed(mRunnableSnapShot, 3000);
				}
				break;
			case R.id.Camera_Main_INDEX06:		// Video
				mountInfoExternalStorage();
				mPoolManger.playTouchSe();
				InnerCamera.removeAllComponent(-1);
				Log.e(TAG, "I_MEDEA_IMAGE_CONTEXT_TYPE =" + I_MEDEA_IMAGE_CONTEXT_TYPE);
				if(I_MEDEA_IMAGE_CONTEXT_TYPE == true) {
					ToastManager.showToast(getApplicationContext(), "SD Card unmounted, not prepare", Toast.LENGTH_SHORT);
					return;
				}
				videoRecodingEvent();
				break;
				
			case R.id.Camera_Main_INDEX07:
//				if (isRecording)
//				{
//					ToastManager.showToast(getApplicationContext(), "please,Stop recording!!!", Toast.LENGTH_SHORT);
//					break;
//				}
//				releaseMediaRecorder();
//				releaseCamera();
//				finish();
				break;
				
			case R.id.Camera_Main_INDEX08:
				if (mMUTEX_Camera_SnapShot) return;
//				if(I_MEDEA_IMAGE_CONTEXT_TYPE == true) {
//					ToastManager.showToast(getApplicationContext(), "Gallary only open external files.", Toast.LENGTH_SHORT);
//					return;
//				}
				mPoolManger.playTouchSe();
//				callBackGallary(ImageNum);
				callBackGallary_Item01();
				break;
			default:
				break;
				
			}
		}
	};
	
	static int FLAG_MODE_EXPOSE = 2;
	static boolean FLAG_POPUP_STATE_EXPOSE = false;
	private void showPopUpForExposureCompensation(int index) {
		final LinearLayout linear = (LinearLayout)
				View.inflate(this, R.layout.camera_main_dialog_popup_exposure, null);
		InnerCamera.mComponet11.addView(linear);
		RadioButton rb01 = (RadioButton)linear.findViewById(R.id.Camera_Dialog_Popup_Exposure_Index_RG01);
		rb01.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.d(TAG, "");
				mPoolManger.playTouchSe();
				FLAG_MODE_EXPOSE = 0;
				mPreview.setExposureCompensation(FLAG_MODE_EXPOSE);
				SharedManager.setSettingCameraMode(getApplicationContext(), FLAG_MODE_EXPOSE);
				InnerCamera.mComponet11.removeAllViews();
			}
		});
		RadioButton rb02 = (RadioButton)linear.findViewById(R.id.Camera_Dialog_Popup_Exposure_Index_RG02);
		rb02.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_EXPOSE = 1;
				mPoolManger.playTouchSe();
				mPreview.setExposureCompensation(FLAG_MODE_EXPOSE);
				SharedManager.setSettingCameraMode(getApplicationContext(), FLAG_MODE_EXPOSE);
				InnerCamera.mComponet11.removeAllViews();
			}
		});
		RadioButton rb03 = (RadioButton)linear.findViewById(R.id.Camera_Dialog_Popup_Exposure_Index_RG03);
		rb03.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_EXPOSE = 2;
				mPoolManger.playTouchSe();
				mPreview.setExposureCompensation(FLAG_MODE_EXPOSE);
				SharedManager.setSettingCameraMode(getApplicationContext(), FLAG_MODE_EXPOSE);
				InnerCamera.mComponet11.removeAllViews();
			}
		});
		RadioButton rb04 = (RadioButton)linear.findViewById(R.id.Camera_Dialog_Popup_Exposure_Index_RG04);
		rb04.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_EXPOSE = 3;
				mPoolManger.playTouchSe();
				mPreview.setExposureCompensation(FLAG_MODE_EXPOSE);
				SharedManager.setSettingCameraMode(getApplicationContext(), FLAG_MODE_EXPOSE);
				InnerCamera.mComponet11.removeAllViews();
			}
		});
		RadioButton rb05 = (RadioButton)linear.findViewById(R.id.Camera_Dialog_Popup_Exposure_Index_RG05);
		rb05.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_EXPOSE = 4;
				mPoolManger.playTouchSe();
				mPreview.setExposureCompensation(FLAG_MODE_EXPOSE);
				SharedManager.setSettingCameraMode(getApplicationContext(), FLAG_MODE_EXPOSE);
				InnerCamera.mComponet11.removeAllViews();
			}
		});
		Log.d(TAG, "index = " + index);
		if(index == 0) {
			rb01.setChecked(true);
		} else if(index == 1) { 
			rb02.setChecked(true);
		} else if(index == 2) { 
			rb03.setChecked(true);
		} else if(index == 3) { 
			rb04.setChecked(true);
		} else if(index == 4) { 
			rb04.setChecked(true);
		} else { 
			rb03.setChecked(true);
		}
	}
	
	static int FLAG_MODE_FLASH = 0;
	static boolean FLAG_POPUP_STATE_FLASH = false;
	private void showPopUpForCameraFLASH(int index) {
		final LinearLayout linear = (LinearLayout)
				View.inflate(this, R.layout.camera_main_dialog_popup_flash, null);
		InnerCamera.mComponet12.addView(linear);
		RadioButton rb01 = (RadioButton)linear.findViewById(R.id.camera_dialog_popup_Flash_index_RG01);
		rb01.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.d(TAG, "");
				mPoolManger.playTouchSe();
				FLAG_MODE_FLASH = 0;
				mPreview.setFLASH(FLAG_MODE_FLASH);
				SharedManager.setSettingCameraFlash(getApplicationContext(), FLAG_MODE_FLASH);
				InnerCamera.mComponet12.removeAllViews();
			}
		});
		RadioButton rb02 = (RadioButton)linear.findViewById(R.id.camera_dialog_popup_Flash_index_RG02);
		rb02.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_FLASH = 1;
				mPoolManger.playTouchSe();
				mPreview.setFLASH(FLAG_MODE_FLASH);
				SharedManager.setSettingCameraFlash(getApplicationContext(), FLAG_MODE_FLASH);
				InnerCamera.mComponet12.removeAllViews();
			}
		});
		if(index == 0) {
			rb01.setChecked(true);
		} else if(index == 1) { 
			rb02.setChecked(true);
		} else { 
			rb01.setChecked(true);
		}
	}
	
	static int FLAG_MODE_BALANCE = 4; 
	static boolean FLAG_POPUP_STATE_BALANCE = false;
	private void showPopUpForCameraBALACE(int index) {
		final LinearLayout linear = (LinearLayout)
				View.inflate(this, R.layout.camera_main_dialog_popup_balance, null);
		InnerCamera.mComponet13.addView(linear);
		RadioButton rb01 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Balance_Index_RG01);
		rb01.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.d(TAG, "");
				mPoolManger.playTouchSe();
				FLAG_MODE_BALANCE = 0;
				mPreview.setBalance(FLAG_MODE_BALANCE);
				SharedManager.setSettingCameraBalance(getApplicationContext(), FLAG_MODE_BALANCE);
				InnerCamera.mComponet13.removeAllViews();
			}
		});
		RadioButton rb02 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Balance_Index_RG02);
		rb02.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_BALANCE = 1;
				mPoolManger.playTouchSe();
				mPreview.setBalance(FLAG_MODE_BALANCE);
				SharedManager.setSettingCameraBalance(getApplicationContext(), FLAG_MODE_BALANCE);
				InnerCamera.mComponet13.removeAllViews();
			}
		});
		RadioButton rb03 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Balance_Index_RG03);
		rb03.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_BALANCE = 2;
				mPoolManger.playTouchSe();
				mPreview.setBalance(FLAG_MODE_BALANCE);
				SharedManager.setSettingCameraBalance(getApplicationContext(), FLAG_MODE_BALANCE);
				InnerCamera.mComponet13.removeAllViews();
			}
		});
		RadioButton rb04 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Balance_Index_RG04);
		rb04.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_BALANCE = 3;
				mPoolManger.playTouchSe();
				mPreview.setBalance(FLAG_MODE_BALANCE);
				SharedManager.setSettingCameraBalance(getApplicationContext(), FLAG_MODE_BALANCE);
				InnerCamera.mComponet13.removeAllViews();
			}
		});
		RadioButton rb05 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Balance_Index_RG05);
		rb05.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_BALANCE = 4;
				mPoolManger.playTouchSe();
				mPreview.setBalance(FLAG_MODE_BALANCE);
				SharedManager.setSettingCameraBalance(getApplicationContext(), FLAG_MODE_BALANCE);
				InnerCamera.mComponet13.removeAllViews();
			}
		});
		if(index == 0) {
			rb01.setChecked(true);
		} else if(index == 1) { 
			rb02.setChecked(true);
		} else if(index == 2) { 
			rb03.setChecked(true);
		} else if(index == 3) { 
			rb04.setChecked(true);
		} else if(index == 4) { 
			rb05.setChecked(true);
		} else { 
			rb05.setChecked(true);
		}
	}
	
	static int FLAG_MODE_SETTING = 0; 
	static boolean FLAG_POPUP_STATE_SETTING = false;
	private void showPopUpForCameraSetting(int index) {
		final LinearLayout linear = (LinearLayout)
				View.inflate(this, R.layout.camera_main_dialog_popup_setting, null);
		InnerCamera.mComponet14.addView(linear);
		RadioButton rb01 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Setting_Index_RG01);
		rb01.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Log.d(TAG, "");
				mPoolManger.playTouchSe();
				FLAG_MODE_SETTING = 0;
				setHolderSize(getApplicationContext(), FLAG_MODE_SETTING);
				SharedManager.setSettingCameraSetting(getApplicationContext(), FLAG_MODE_SETTING);
				InnerCamera.mComponet14.removeAllViews();
				releaseCamera();
				mCameraResolution.removeAllViews();
				initCameraSurfaceView();
			}
		});
		RadioButton rb02 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Setting_Index_RG02);
		rb02.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_SETTING = 1;
				mPoolManger.playTouchSe();
				setHolderSize(getApplicationContext(), FLAG_MODE_SETTING);
				SharedManager.setSettingCameraSetting(getApplicationContext(), FLAG_MODE_SETTING);
				InnerCamera.mComponet14.removeAllViews();
				releaseCamera();
				mCameraResolution.removeAllViews();
				initCameraSurfaceView();
			}
		});
		RadioButton rb03 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Setting_Index_RG03);
		rb03.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_SETTING = 2;
				mPoolManger.playTouchSe();
				FLAG_POPUP_STATE_SETTING = false;
				setHolderSize(getApplicationContext(), FLAG_MODE_SETTING);
				SharedManager.setSettingCameraSetting(getApplicationContext(), FLAG_MODE_SETTING);
				InnerCamera.mComponet14.removeAllViews();
				releaseCamera();
				mCameraResolution.removeAllViews();
				initCameraSurfaceView();
			}
		});
		RadioButton rb04 = (RadioButton)linear.findViewById(R.id.Cm_Dialog_Popup_Setting_Index_RG04);
		rb04.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FLAG_MODE_SETTING = 3;
				mPoolManger.playTouchSe();
				FLAG_POPUP_STATE_SETTING = false;
				setHolderSize(getApplicationContext(), FLAG_MODE_SETTING);
				SharedManager.setSettingCameraSetting(getApplicationContext(), FLAG_MODE_SETTING);
				InnerCamera.mComponet14.removeAllViews();
				releaseCamera();
				mCameraResolution.removeAllViews();
				initCameraSurfaceView();
			}
		});
		if(index == 0) {
			rb01.setChecked(true);
		} else if(index == 1) { 
			rb02.setChecked(true);
		} else if(index == 2) { 
			rb03.setChecked(true);
		} else if(index == 3) { 
			rb04.setChecked(true);
		} else { 
			rb04.setChecked(true);
		}
	}
	
	Runnable mRunnableSnapShot = new Runnable() {
		File filename;
		@Override
		public void run() {
			TJListItem item = null;
			try {
//				item = getThelastImageUriInfoFromMediaStore();
				File path = Environment.getExternalStoragePublicDirectory(
		                Environment.DIRECTORY_PICTURES);
		        File filedir = new File(path, "TJ_PICTURE");

		        if(filedir.exists()) {
		        	filename = new File(filedir.getAbsolutePath() + File.separator + "tj_snapshot.jpg");
		        	I_MEDEA_IMAGE_CONTEXT_TYPE = false;
		        } else {
		        	filename = new File("/data/data/" + getApplicationContext().getPackageName() + "/files/"
		    				+ File.separator + "tj_snapshot.jpg");
		        	I_MEDEA_IMAGE_CONTEXT_TYPE = true;
		        }
		        if (filename.exists()) {
		        	item = new TJListItem("", filename.getAbsolutePath());
		        	Log.e(TAG, "mRunnableSnapShot." + item.getColumns(1));
		        }
			} catch (Exception e) {
				e.printStackTrace();
			}
			updateViewImage(item);
		}
	};
	
	private void mountInfoExternalStorage() {
		String ext = null;
		ext = Environment.getExternalStorageState();
		if (ext.equals(Environment.MEDIA_MOUNTED)) {
			File path = Environment.getExternalStoragePublicDirectory(
	                Environment.DIRECTORY_PICTURES);
	        File filedir = new File(path, "TJ_PICTURE");

        	if(!filedir.exists()) {
        		 if (!filedir.mkdirs()){
     	            Log.d(TAG, "failed to create directory");
     	        }
        	}
			I_MEDEA_IMAGE_CONTEXT_TYPE = false;
		} else {
			I_MEDEA_IMAGE_CONTEXT_TYPE = true;
		}
	}
	
	String uriString = null;
	public void updateViewImage(TJListItem item) {
		if(item == null) {
			Log.e(TAG, "item = null");
			return;
		}
		
		uriString = item.getColumns(1); // MediaStore.Images.Media.DATA
		if(uriString != null) {
			Log.d(TAG, "uriString=" + uriString);
			Bitmap image = BitmapFactory.decodeFile(uriString);
			InnerCamera.mComponet08.setImageBitmap(image);
//			Uri imgPreview = Uri.parse(uriString);
//			Log.d(TAG, "uriString=" + uriString);
//			Log.d(TAG, "imgPreview=" + imgPreview);
//			InnerCamera.mComponet08.setImageURI(imgPreview);
		}
		mMUTEX_Camera_SnapShot = false;
	}
	
	private void updateSettingInfoForCamera() {
		FLAG_MODE_EXPOSE = SharedManager.getSettingCameraMode(getApplicationContext());
		FLAG_MODE_FLASH = SharedManager.getSettingCameraFlash(getApplicationContext());
		FLAG_MODE_BALANCE = SharedManager.getSettingCameraBalance(getApplicationContext());
		mPreview.setExposureCompensation(FLAG_MODE_EXPOSE);
		mPreview.setFLASH(FLAG_MODE_FLASH);
		mPreview.setBalance(FLAG_MODE_BALANCE);
	}
	
	static long ImageNum = 0;
	private boolean I_MEDEA_IMAGE_CONTEXT_TYPE = false;
	private TJListItem getThelastImageUriInfoFromMediaStore() {
		String[] projection = {"MAX(" + MediaStore.Images.Media._ID +")",
				MediaStore.Images.Media.DATA,
				MediaStore.Images.Media.DISPLAY_NAME,
				MediaStore.Images.Media.SIZE,
				MediaStore.Images.Media.MIME_TYPE};
		
		String selection = null;
		String[] selectionArgs = null;
		String sortOrder = MediaStore.Images.Media._ID + " DESC";
		
		Cursor cursor = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, 
				selection, selectionArgs, sortOrder);
		
		if(cursor == null) {
			Log.d(TAG, "INTERNAL_CONTENT_URI");
			I_MEDEA_IMAGE_CONTEXT_TYPE = true;
			cursor = getContentResolver().query(MediaStore.Images.Media.INTERNAL_CONTENT_URI, projection, 
					selection, selectionArgs, sortOrder);
		}
		
		TJListItem item = null;
		ArrayList<TJListItem> Items = new ArrayList<TJListItem>();
		int i=0;
		try {
			if(cursor != null && cursor.getCount() !=0) {
				Log.d(TAG, "cursor.getCount():"+cursor.getCount());
				cursor.moveToFirst();
				item = new TJListItem(cursor.getString(0), cursor.getString(1), cursor.getString(2), 
						cursor.getString(3), cursor.getString(4));
				Items.add(item);
				Log.i(TAG, "TJListItem[" + i + "] = " + item.getColumns(0) + ", " + item.getColumns(1) + ", "  
						+ item.getColumns(2) + ", "  + item.getColumns(3) + ", "  + item.getColumns(4));
				try {
					ImageNum = Integer.valueOf(item.getColumns(0));
				} catch (NumberFormatException nfe) {
					Log.d(TAG, "NumberFormatException : " + nfe.getMessage());
				}
				cursor.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return item;
//		return null;
	}	
	
	MediaRecorder mMediaRecorder;
	public boolean prepareVideoRecorder(){
//	    mCamera = CMCameraView.getCameraInstance();
	    mMediaRecorder = new MediaRecorder();

	    // Step 1: Unlock and set camera to MediaRecorder
	    mPreview.mCamera.unlock();
	    mMediaRecorder.setCamera(mPreview.mCamera);

	    // Step 2: Set sources
	    mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.CAMCORDER);
	    mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);

	    
	    // Step 3: Set a CamcorderProfile (requires API Level 8 or higher)
	    mMediaRecorder.setProfile(CamcorderProfile.get(CamcorderProfile.QUALITY_HIGH));

	    // Step 4: Set output file
	    mMediaRecorder.setOutputFile(mPreview.getOutputMediaFile(TJCameraView.MEDIA_TYPE_VIDEO).toString());

	    // Step 5: Set the preview output
	    mMediaRecorder.setPreviewDisplay(mPreview.getHolder().getSurface());

	    // Step 6: Prepare configured MediaRecorder
	    try {
	        mMediaRecorder.prepare();
	    } catch (IllegalStateException e) {
	        Log.d(TAG, "IllegalStateException preparing MediaRecorder: " + e.getMessage());
	        releaseMediaRecorder();
	        return false;
	    } catch (IOException e) {
	        Log.d(TAG, "IOException preparing MediaRecorder: " + e.getMessage());
	        releaseMediaRecorder();
	        return false;
	    }
	    return true;
	}
    
	private void releaseMediaRecorder() {
		if (mMediaRecorder != null) {
            mMediaRecorder.reset();   // clear recorder configuration
            mMediaRecorder.release(); // release the recorder object
            mMediaRecorder = null;
            mCamera.lock();           // lock camera for later use
        }
	}
	
	private void releaseCamera() {
        if (mCamera != null){
        	mCamera.release();        // release the camera for other applications
        	mCamera = null;
        }
    }
	
	boolean isRecording = false;
	private void videoRecodingEvent() {
		if (isRecording) {
			mMUTEX_Camera_SnapShot = false;
            // stop recording and release camera
            mMediaRecorder.stop();  // stop the recording
            releaseMediaRecorder(); // release the MediaRecorder object
            mCamera.lock();         // take camera access back from MediaRecorder
            
            // inform the user that recording has stopped
            InnerCamera.mComponet06.setText("Video");
            ToastManager.showToast(this, "Success : Video Recoder", Toast.LENGTH_SHORT);
            isRecording = false;
            releaseCamera();
            initCameraSurfaceView();
        } else {
        	if (mMUTEX_Camera_SnapShot) return;
        	mMUTEX_Camera_SnapShot = true;
            // initialize video camera
            if (prepareVideoRecorder()) {
                // Camera is available and unlocked, MediaRecorder is prepared,
                // now you can start recording
                mMediaRecorder.start();

                // inform the user that recording has started
                InnerCamera.mComponet06.setText("Stop");
                isRecording = true;
                
            } else {
                // prepare didn't work, release the camera
                releaseMediaRecorder();
                // inform user
            }
        }
	}
	
	static int mDisplayWidth = 640;
	static int mDisplayHeight = 480;
	public void setHolderSize(Context context, int index) {
		Display display;
		switch (index) {
		case 0:
			display = getWindowManager().getDefaultDisplay();
			mDisplayWidth = display.getWidth();
			mDisplayHeight = display.getHeight();
			Log.d(TAG, "W=" + mDisplayWidth + ", H=" + mDisplayHeight);
			break;
		case 1:
			mDisplayWidth = 840;
			mDisplayHeight = 480;
			break;
		case 2:
			mDisplayWidth = 720;
			mDisplayHeight = 480;
			break;
		case 3:
			mDisplayWidth = 640;
			mDisplayHeight = 480;
			break;
		default:
			display = getWindowManager().getDefaultDisplay();
			mDisplayWidth = display.getWidth();
			mDisplayHeight = display.getHeight();
			break;
		}
	}
	
	private void callBackGallary_Item01() {
		if (uriString == null) return;
		
		Intent intent = new Intent(CameraAct.this, GallaryViewAct.class);
		intent.putExtra("uri", uriString); 
		startActivityForResult(intent, RESULT_OK);
//		if (I_MEDEA_IMAGE_CONTEXT_TYPE == true) {
//			Intent intent = new Intent(CameraAct.this, GallaryViewAct.class);
//			intent.putExtra("uri", uriString); 
//			startActivityForResult(intent, RESULT_OK);
//		} else {
//			Intent i = new Intent(Intent.ACTION_VIEW); 
//			i.putExtra("uri", uriString); 
//			startActivityForResult(i, RESULT_OK);
//		}
	}
	
	private void callBackGallary(long id) {
		Uri uri = null;
		if (I_MEDEA_IMAGE_CONTEXT_TYPE != true) {
			Log.e(TAG, "EXTERNAL_CONTENT_URI");
			uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);  
		} else {
			Log.e(TAG, "INTERNAL_CONTENT_URI");
//			uri = ContentUris.withAppendedId(MediaStore.Images.Media.INTERNAL_CONTENT_URI, id);  
			uri = Uri.parse(uriString);
		}
		if (uri != null) {
			Log.d(TAG, "Uri=" + uri  + ", getAuthority=" + uri.getAuthority());
			if (I_MEDEA_IMAGE_CONTEXT_TYPE == true) {
				Intent intent = new Intent(CameraAct.this, GallaryViewAct.class);
				intent.putExtra("uri", uri.toString()); 
//				startActivity(intent);
				startActivityForResult(intent, RESULT_OK);
//				InnerCamera.mComponet99.setImageURI(uri);
			} else {
				Intent i = new Intent(Intent.ACTION_VIEW, uri); 
//				startActivity(i);'
				startActivityForResult(i, RESULT_OK);
			}
		}
	}
	
	public static class InnerCamera {
		static Button 				mComponet01;	// Mode
		static Button 				mComponet02;	// Flash
		static Button 				mComponet03;	// Balance
		static Button 				mComponet04;	// Setting
		static Button 				mComponet05;	// SnapShot
		static Button 				mComponet06;	// Video
		static Button 				mComponet07;	// EXIT
		static ImageView 		mComponet08;	// Thumbnail Image View
		static ImageView 		mComponet99;	// Thumbnail Image View
		
		static LinearLayout 		mComponet11;
		static LinearLayout 		mComponet12;
		static LinearLayout 		mComponet13;
		static LinearLayout 		mComponet14;
		
		static void removeAllComponent(int index) {
			switch (index) {
				case 1:
//					InnerCamera.mComponet11.removeAllViews();
					InnerCamera.mComponet12.removeAllViews();
					InnerCamera.mComponet13.removeAllViews();
					InnerCamera.mComponet14.removeAllViews();
//					FLAG_POPUP_STATE_EXPOSE = false;
					FLAG_POPUP_STATE_FLASH = false;
					FLAG_POPUP_STATE_BALANCE = false;
					FLAG_POPUP_STATE_SETTING = false;
					break;
				case 2:
					InnerCamera.mComponet11.removeAllViews();
//					InnerCamera.mComponet12.removeAllViews();
					InnerCamera.mComponet13.removeAllViews();
					InnerCamera.mComponet14.removeAllViews();
					FLAG_POPUP_STATE_EXPOSE = false;
//					FLAG_POPUP_STATE_FLASH = false;
					FLAG_POPUP_STATE_BALANCE = false;
					FLAG_POPUP_STATE_SETTING = false;
					break;
				case 3:
					InnerCamera.mComponet11.removeAllViews();
					InnerCamera.mComponet12.removeAllViews();
//					InnerCamera.mComponet13.removeAllViews();
					InnerCamera.mComponet14.removeAllViews();
					FLAG_POPUP_STATE_EXPOSE = false;
					FLAG_POPUP_STATE_FLASH = false;
//					FLAG_POPUP_STATE_BALANCE = false;
					FLAG_POPUP_STATE_SETTING = false;
					break;
				case 4:
					InnerCamera.mComponet11.removeAllViews();
					InnerCamera.mComponet12.removeAllViews();
					InnerCamera.mComponet13.removeAllViews();
//					InnerCamera.mComponet14.removeAllViews();
					FLAG_POPUP_STATE_EXPOSE = false;
					FLAG_POPUP_STATE_FLASH = false;
					FLAG_POPUP_STATE_BALANCE = false;
//					FLAG_POPUP_STATE_SETTING = false;
					break;
				default:
					InnerCamera.mComponet11.removeAllViews();
					InnerCamera.mComponet12.removeAllViews();
					InnerCamera.mComponet13.removeAllViews();
					InnerCamera.mComponet14.removeAllViews();
					FLAG_POPUP_STATE_EXPOSE = false;
					FLAG_POPUP_STATE_FLASH = false;
					FLAG_POPUP_STATE_BALANCE = false;
					FLAG_POPUP_STATE_SETTING = false;
					break;
			}
				
		}
	}
	
	private void deleteStorageDirectory() {
		File[] childFile;
		// Check External Storage
		File path = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File filedir = new File(path, "TJ_PICTURE");
        
        if (filedir.exists()) {
        	childFile = filedir.listFiles();
            boolean confirm = false;
            int size = childFile.length;
            if (size > 0) {
                for (int i = 0; i < size; i++) {
                    if (childFile[i].isFile()) {
                        confirm = childFile[i].delete();
                        System.out.println(childFile[i]+":"+confirm + " is deleted");
                    }
                }
            }
        	Log.d(TAG, "deleteStorageDirectory().External= images delete result = " + filedir.delete());
        	filedir.delete();
        }
        
        // video will be deleted
        path = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        filedir = new File(path, "TJ_VID");
        
        if (filedir.exists()) {
        	childFile = filedir.listFiles();
            boolean confirm = false;
            int size = childFile.length;
            if (size > 0) {
                for (int i = 0; i < size; i++) {
                    if (childFile[i].isFile()) {
                        confirm = childFile[i].delete();
                        System.out.println(childFile[i]+":"+confirm + " is deleted");
                    }
                }
            }
        	Log.d(TAG, "deleteStorageDirectory().External= vedio delete result = " + filedir.delete());
        	filedir.delete();
        }
        
        // Check Internal Storage
        filedir = new File("/data/data/" + getApplicationContext().getPackageName() + "/files/");
        
        if (filedir.exists()) {
        	childFile = filedir.listFiles();
            boolean confirm = false;
            int size = childFile.length;
            if (size > 0) {
                for (int i = 0; i < size; i++) {
                    if (childFile[i].isFile()) {
                        confirm = childFile[i].delete();
                        System.out.println(childFile[i]+":"+confirm + " is deleted");
                    }
                }
            }
        	Log.d(TAG, "deleteStorageDirectory().Internal.delete result=" + filedir.delete());
        	filedir.delete();
        }
	}
	
	/*
	 ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *   
	 * DEMO modules 
	 * 
	 ** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *   
	 */
//	private class AsyUpdateImage extends AsyncTask<String, Void, Void> {   
//    	private ProgressDialog Dialog = new ProgressDialog(CameraAct.this);
//    	TJListItem item = null;
//        		   	       
//    	protected void onPreExecute() {   
//			Dialog.setMessage("Loading...");   
//    		Dialog.show();
//    	}   
//
//
//    	protected Void doInBackground(String... arg0) {  
//    		item = getThelastImageUriInfoFromMediaStore();
//    		try {
//    			Thread.sleep(5000);
//    		} catch (InterruptedException ie) {
//    			ie.printStackTrace();
//    		}
//	    	return null;    				
//		}  
//    	
//    	protected void onPostExecute(Void unused) {
//    		Dialog.dismiss();	
//    		updateViewImage(item);
//    	
//	    }   
//	 }  
	
}
	
	

