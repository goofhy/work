package com.tjmedia.android.tjdebugger.battery;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : Jimmy
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class BatteryAct extends Activity {   
   
	private static final String TAG = "BatteryAct"; 	
	String sBatteryInfo = "";
	
	Button mTitleExit;
	SoundPoolManager mPoolManger;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.battery_main);    
 
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
		registerBatteryInfo();
		mLoopHandler.start(getApplicationContext());
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		unregisterBatteryInfo();
		mLoopHandler.stop();
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
	}
	
	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		for(int i=0; i<InnerBattery.mComponents.length; i++) {
			InnerBattery.mComponents[i] = (TextView)  findViewById(Const.I_BATTERY_INDEX[i]);
		}
//		InnerBattery.mComponet11 = (Button)  findViewById(R.id.Battery_Main_Index11);
//		InnerBattery.mComponet11.setOnClickListener(mClickListener);
		
		for(int i=0; i<InnerBattery.mComponents.length; i++) {
			InnerBattery.mComponents[i].setText(mInnerBatteryResult[i]);
		}
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
		
		InnerBattery.mListView = (ListView) findViewById(R.id.Battery_main_ListView);
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		InnerBattery.mListView.setAdapter(mAdapter);
		
	}
	
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
				case R.id.top_exit:
					finish();
					break;
				case R.id.Battery_Main_Index11:
					setInnerBatteryEvent();
					break;
				default:
					break;
				
			}
		}
	};

	private void registerBatteryInfo() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_BATTERY_CHANGED);
		filter.addAction(Intent.ACTION_BATTERY_LOW);
		filter.addAction(Intent.ACTION_BATTERY_OKAY);
		filter.addAction(Intent.ACTION_POWER_CONNECTED);
		filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
		registerReceiver(mBatteryReciver, filter);
	}
	
	private void unregisterBatteryInfo() {
		unregisterReceiver(mBatteryReciver);
	}
	
	
	private void setInnerBatteryEvent() {
		new I_AsynTask().execute(10);
	}
	
	private int mCount = 0;
	ProgressDialog mProgress;
	String[] mInnerBatteryResult = new String[8];
	class I_AsynTask extends AsyncTask<Integer, Integer, Integer> {
		protected void onPreExecute() {
			mCount = 0;
			mProgress = new ProgressDialog(BatteryAct.this);
			mProgress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mProgress.setMessage("Updating...");
//				mProgress.setCancelable(false);
			mProgress.setProgress(0);
//				mProgress.setButton("Cancel", new DialogInterface.OnClickListener() {
//					@Override
//					public void onClick(DialogInterface dialog, int which) {
//					// TODO Auto-generated method stub
//						cancel(true);
//					}
//				});
			mProgress.show();
		}
			
		protected Integer doInBackground(Integer... arg0) {
//			TDMKMisc_Service.Initalize();
			while (isCancelled() == false) { 
				if (mCount <= 8) {
					publishProgress(mCount);
				} else {
					break;
				}
				try { 
					Thread.sleep(100); 
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				mCount++;
			}
			return mCount;
		}
		protected void onProgressUpdate(Integer... progress) {
			int index = progress[0];
			switch (index) {
			case 0:
//				mInnerBatteryResult[0] = TDMKMisc_Service.VERSION_Info_t.szBootloader.toString();
				break;
			default:
				break;
			}
			mProgress.setProgress(progress[0]);     
		}
		    
		protected void onPostExecute(Integer result) { 
			mProgress.dismiss();
			for(int i=0; i<InnerBattery.mComponents.length; i++) {
				InnerBattery.mComponents[i].setText(mInnerBatteryResult[i]);
			}
		}
	}
	
	public final int FREQUENCY = 1000;
	public LoopHandler mLoopHandler = new LoopHandler();
	private boolean FLAG_COLOR = false;
	public void loop() {
		Log.d(TAG, "loop()");
		updateView();
		mLoopHandler.sleep(FREQUENCY);
	}
	
	public class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start(Context context) {
			bStop = false;
			loop();
		}
	};
	
	private 	int mPlug, mStatus, mScale, mLevel, mRatio, mVolt;
	private boolean mPresent;
	private void updateView() {
		String sPlug = "";
		String sStatus = "";
		sBatteryInfo = (mPresent)?"OK ,BATTERY": "NG, BATTERY";
		switch (mPlug) {
			case BatteryManager.BATTERY_PLUGGED_AC:				
				sPlug = (mPresent)?"BATTERY&AC":"AC ONLY";
				break;
			case BatteryManager.BATTERY_PLUGGED_USB:
				sPlug = (mPresent)?"BATTERY & USB":"AC & USB";
				break;
			default:
				sPlug = (BatteryManager.BATTERY_STATUS_CHARGING== mStatus)?"BATTERY&AC":"BATTERY";
				break;
		}

		switch (mStatus) {
			case BatteryManager.BATTERY_STATUS_CHARGING:
				sStatus = "CHARGING";
				break;
			case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
				sStatus = "NOT CHARGING";
				break;
			case BatteryManager.BATTERY_STATUS_DISCHARGING:
				sStatus = "DISCHARGING";
				break;
			case BatteryManager.BATTERY_STATUS_FULL:
				sStatus = "FULL";
				break;
			default:
			case BatteryManager.BATTERY_STATUS_UNKNOWN:
				sStatus = "UNKNOWN";
				break;
		}

		FLAG_COLOR = FLAG_COLOR == true ? false : true;
		int color = 0;
		if (FLAG_COLOR) {
			color = getApplicationContext().getResources().getColor(R.color.red);
		} else {
			color = getApplicationContext().getResources().getColor(R.color.skyblue);
		}
		
		//mInnerBatteryResult[0] = String.format("Count Info - %d", Count);
		//Spannable span = new SpannableString(mInnerBatteryResult[0]);
		//span.setSpan(new ForegroundColorSpan(color), 0, mInnerBatteryResult[0].length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		//InnerBattery.mComponents[0].setText(span);
				
		mInnerBatteryResult[0] = sBatteryInfo;
		Spannable span = new SpannableString(mInnerBatteryResult[0]);
		span.setSpan(new ForegroundColorSpan(color), 0, mInnerBatteryResult[0].length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		InnerBattery.mComponents[0].setText(span);
		
		mInnerBatteryResult[1] = sPlug;
		span = new SpannableString(mInnerBatteryResult[1]);
		span.setSpan(new ForegroundColorSpan(color), 0, mInnerBatteryResult[1].length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		InnerBattery.mComponents[1].setText(span);
		
		mInnerBatteryResult[2] = sStatus;
		span = new SpannableString(mInnerBatteryResult[2]);
		span.setSpan(new ForegroundColorSpan(color), 0, mInnerBatteryResult[2].length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		InnerBattery.mComponents[2].setText(span);
		
		//mInnerBatteryResult[3] = String.valueOf(mLevel) +"[level] , "+ String.valueOf(mRatio) + "[%] , "+ (mVolt / 1000) + "." + (mVolt % 1000) +"[Volt]";
		float fVolt = mVolt;	
		mInnerBatteryResult[3] = String.valueOf(mLevel) +"[level] , "+ String.valueOf(mRatio) + "[%] ,"+ String.format("%.3f", fVolt/1000) +"[Volt]";
		Log.d(TAG,mInnerBatteryResult[3]);
		span = new SpannableString(mInnerBatteryResult[3]);
		span.setSpan(new ForegroundColorSpan(color), 0, mInnerBatteryResult[3].length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		InnerBattery.mComponents[3].setText(span);
	}
	
	
	int Count = 0;
	int mListIndex = 0;
	BroadcastReceiver mBatteryReciver = new BroadcastReceiver() {
		
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			Log.d(TAG, "mBatteryReciver.action=" + action);
			Count++;
			if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
				onBatteryChanged(intent);
			}
			if (action.equals(Intent.ACTION_BATTERY_LOW)) {
				Toast.makeText(context, "BATTERY LOW", Toast.LENGTH_LONG).show();
				mItem.add(0, "Status[" +mListIndex +"] : " + "BATTERY LOW");
				mAdapter.notifyDataSetChanged();
				mListIndex++;
			}
			if (action.equals(Intent.ACTION_BATTERY_OKAY)) {
				Toast.makeText(context, "BATTERY OK", Toast.LENGTH_LONG).show();
				mItem.add(0, "Status[" +mListIndex +"] : " + "BATTERY OK");
				mAdapter.notifyDataSetChanged();
				mListIndex++;
			}
			if (action.equals(Intent.ACTION_POWER_CONNECTED)) {
				Toast.makeText(context, "POWER(AC) CONNECTED", Toast.LENGTH_LONG).show();
				mItem.add(0, "Status[" +mListIndex +"] : " + "POWER CONNECTED");
				mAdapter.notifyDataSetChanged();
				mListIndex++;
			}
			if (action.equals(Intent.ACTION_POWER_DISCONNECTED)) {
				Toast.makeText(context, "POWER(AC) DISCONNECTED", Toast.LENGTH_LONG).show();
				mItem.add(0, "Status[" +mListIndex +"] : " + "POWER DISCONNECTED");
				mAdapter.notifyDataSetChanged();
				mListIndex++;
			}
		}
		
		public void onBatteryChanged(Intent intent) {
			Log.d(TAG, "mBatteryReciver.onBatteryChanged()");
			
			mPresent = intent.getBooleanExtra(BatteryManager.EXTRA_PRESENT, false);			
			mPlug = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
			mStatus = intent.getIntExtra(BatteryManager.EXTRA_STATUS, 
					BatteryManager.BATTERY_STATUS_UNKNOWN);
			mLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
			mScale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
			mVolt = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
			mRatio = mLevel * 100 / mScale;
			
			updateView();
		}
	};
	
	static class InnerBattery {
		/*
		 * mComponents
		 * Battery info
		 * 
		 */
		private static ListView 		mListView;
		private static TextView[]		mComponents = new TextView[4];		// Button display Viewer
		
		private static Button 			mComponet11;		// Update Battery info
		
	}
}
	
	

