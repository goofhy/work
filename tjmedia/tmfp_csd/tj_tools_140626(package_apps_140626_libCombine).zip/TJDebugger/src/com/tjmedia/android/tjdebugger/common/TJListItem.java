/**
 * Copyright (C) 2010 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Mobile Communication Division,
 * Digital Media & Communications Business, Samsung Electronics Co., Ltd.
 *
 * This software and its documentation are confidential and proprietary
 * information of Samsung Electronics Co., Ltd.  No part of the software and
 * documents may be copied, reproduced, transmitted, translated, or reduced to
 * any electronic medium or machine-readable form without the prior written
 * consent of Samsung Electronics.
 *
 * Samsung Electronics makes no representations with respect to the contents,
 * and assumes no responsibility for any errors that might appear in the
 * software and documents. This publication and the contents hereof are subject
 * to change without notice.
 */
package com.tjmedia.android.tjdebugger.common;

import android.os.Parcel;
import android.os.Parcelable;

public class TJListItem implements Parcelable {
	private String[] 	mColumns = new String[10];			// _id
	
	private boolean isChecked;
	private boolean checkBox;
	
	public TJListItem() {
		this(null);
	}

	public TJListItem(String first) {
		this(first, null, null, null, null, null);
	}
	
	public TJListItem(String first, String second) {
		this(first, second, null, null, null, null);
	}
	
	public TJListItem(String first, String second, String third) {
		this(first, second, third, null, null, null);
	}
	
	public TJListItem(String first, String second, String third, String four) {
		this(first, second, third, four, null, null);
	}
	
	public TJListItem(String first, String second, String third, String four, String five) {
		this(first, second, third, four, five, null, null, null, null, null);
	}
	
	public TJListItem(String first, String second, String third, String four, String five,
			String six) {
		this(first, second, third, four, five, six, null, null, null, null);
	}
	
	public TJListItem(String first, String second, String third, String four, String five,
			String six, String seven) {
		this(first, second, third, four, five, six, seven, null, null, null);
	}

	public TJListItem(String first, String second, String third, String four, String five,
			String six, String seven, String eight) {
		this(first, second, third, four, five, six, seven, eight, null, null);
	}

	public TJListItem(String first, String second, String third, String four, String five,
			String six, String seven, String eight, String nine) {
		this(first, second, third, four, five, six, seven, eight, nine, null);
	}

	public TJListItem(String first, String second, String third, String four, String five,
			String six, String seven, String eight, String nine, String ten) {
		this.mColumns[0] = first;
		this.mColumns[1] = second;
		this.mColumns[2] = third;
		this.mColumns[3] = four;
		this.mColumns[4] = five;
		this.mColumns[5] = six;
		this.mColumns[6] = seven;
		this.mColumns[7] = eight;
		this.mColumns[8] = nine;
		this.mColumns[9] = ten;
	}

	public void setColumn(int index, String data) {
		mColumns[index] = data;
	}

	public String[] getAllColumns() {
		return mColumns;
	}
	
	/*
	 * mColumns[0]
	 */
	public String getColumns(int index) {
		return mColumns[index];
	}
	
	public boolean isItemChecked() {
		return this.isChecked;
	}
	
	public void setItemChecked(boolean state) {
		this.isChecked = state;
	}
	
	public boolean getCheckBox() {
		return this.checkBox;
	}
	
	public void setCheckBox(boolean state) {
		this.checkBox = state;
	}
	
	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		for(int i=0; i<mColumns.length; i++) {
			dest.writeString(mColumns[i]);
		}
	}

	public static final Parcelable.Creator<TJListItem> CREATOR = new Parcelable.Creator<TJListItem>() {
		public TJListItem createFromParcel(Parcel source) {
			TJListItem item = new TJListItem();
			for(int i=0; i<item.mColumns.length; i++) {
				item.mColumns[i] = source.readString();
			}
			return item;
		}

		public TJListItem[] newArray(int size) {
			return new TJListItem[size];
		}
	};
}
