/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.tjmedia.android.tjdebugger.bluetooth;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

import android.R.array;
import android.R.integer;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;


/**
 * This class does all the work for setting up and managing Bluetooth
 * connections with other devices. It has a thread that listens for
 * incoming connections, a thread for connecting with a device, and a
 * thread for performing data transmissions when connected.
 */
public class BluetoothFileTransRecv{
		    
//    BluetoothTestActivity mParent;
    Context mParent;    
    
    byte		STX	= (byte) 0xAA;
    byte		ETX	= (byte) 0x55;    
    byte		BT_CMD_OK_SN			= (byte) 0x11;
    
    byte		BT_CMD_NONE				= (byte) 0x40;
    byte		BT_REQ_CMD_FILE_NAME	= (byte) 0x42;
    byte		BT_REQ_CMD_FILE_SIZE	= (byte) 0x43;
    byte		BT_REQ_CMD_FILE_WRITE	= (byte) 0x44;    
    byte		BT_REQ_CMD_FILE_END		= (byte) 0x45;
    byte		BT_REQ_CMD_MESSGAE		= (byte) 0x46;
    byte		BT_REQ_CMD_DEVID		= (byte) 0x47;
    byte		BT_REQ_CMD_SN			= (byte) 0x48;

    
    
    byte		BT_ACK_CMD_FILE_NAME	= (byte) 0x82;
    byte		BT_ACK_CMD_FILE_SIZE	= (byte) 0x83;
    byte		BT_ACK_CMD_FILE_WRITE	= (byte) 0x84;    
    byte		BT_ACK_CMD_FILE_END		= (byte) 0x85;
    byte		BT_ACK_CMD_MESSGAE		= (byte) 0x86;
    byte		BT_ACK_CMD_DEVID		= (byte) 0x87;
    byte		BT_ACK_CMD_SN			= (byte) 0x88;
    
    //static int 	nRecvOffset = 0;
    //static int 	nSendfileOffset = 0;
    //static int 	nSendfileTotalSize = 0;    
    FileTransRecvThread	mFileTransRecvThread = null;
    FileInputStream mTranFile = null;
    FileOutputStream mRecvfile = null;    
    
    int 	mTransEVENT = BluetoothAct.MESSAGE_NONE;		//Read : 0 , Write : 1
    int 	mRecvEVENT = BluetoothAct.MESSAGE_NONE;		//Read : 0 , Write : 1
    byte 	mTransCMD = BT_CMD_NONE;
    int 	mCMDRetry = 0;
    int 	mSaveCMDRetry = 0;
    int		mCount = 0;    
    
    //TDMK & GalaxySII
//    static int 	mTranspacketsize = 117;
//    static int	mBtBuffLen = 100*1024;
//    static int	mMaxCMDRetry = 12000;    
//    static int 	nTickmSec = 10;
//    static int 	mRetryTick = 500;	//nTickmSec * mRetryTime

    //TDMK & TDMK
    static int 	mTranspacketsize = 2*1024;
    static int	mBtBuffLen = 100*1024;
    static int	mMaxCMDRetry = 12000; //   mMaxCMDRetry * nTickmSec  
    static int 	nTickmSec = 10;
    static int 	mRetryTick = 200;	//nTickmSec * mRetryTime

    
    //STX LEN CMD DATA~DAT SUM ETX
    
    public class BtBuff
    {    	
    	int		mACKOffset = 0;				//
    	byte	mACKCmd = BT_CMD_NONE;		//���� �Ǿ�� �� cmd
    	byte	mBeforeCmd = BT_CMD_NONE;	//���� ���ŵ� cmd
    	int		nHead = 0;
    	int 	nTail = 0;
    	int		beforewsize = 0;			//���� ��� data ������ 
    	byte [] beforewbuffer = new byte[mTranspacketsize*2];	//���� ��� data 
    	byte [] mTempBuff = new byte[mBtBuffLen];
    }
    String mtmpstr;
    public class TmpBtBuff
    {    	
    	int		nHead = 0;	//stx
    	int 	nTail = 0;	//etx
    	byte [] mTempBuff = new byte[mBtBuffLen];    	    	
    }    
    TmpBtBuff mTmpBuf;    
    BtBuff mBuf;
    Handler mHandler;
    
    
    public BluetoothFileTransRecv(Context context, Handler handler) {                
        mParent = context;    
        mBuf = new BtBuff();    
        mHandler = handler;
        mtmpstr = new String("                                                 ");
    }   
    
    void SetFileRecvStart(String str,int filesize)
    {
    	mtmpstr = str;
    	mHandler.obtainMessage(BluetoothAct.MESSAGE_RECV_FILE_NAME, str.length(), filesize, mtmpstr.getBytes()).sendToTarget();
    }   
    
    void SetFileRecvEnd(String str,int filesize)
    {
    	mtmpstr = str;
    	mHandler.obtainMessage(BluetoothAct.MESSAGE_RECV_END, str.length(), filesize, mtmpstr.getBytes()).sendToTarget();
    }
    
    void SetFileRecvStatus(String str,int offset)
    {          
    	mtmpstr = str;
        mHandler.obtainMessage(BluetoothAct.MESSAGE_RECV_STATUS, str.length(), offset, mtmpstr.getBytes()).sendToTarget();        
    }	    

    void SetMessageRecvStatus(String str)
    {            	
    	mtmpstr = str;
        mHandler.obtainMessage(BluetoothAct.MESSAGE_READ, str.length(), -1, mtmpstr.getBytes()).sendToTarget();        
    }	    

    void SetMessageRecvSN(String str)
    {            	
    	mtmpstr = str;
        mHandler.obtainMessage(BluetoothAct.MESSAGE_SNREAD, str.length(), -1, mtmpstr.getBytes()).sendToTarget();        
    }	  
    
    void SetMessageSaveSN()
    {            	    	
        mHandler.obtainMessage(BluetoothAct.MESSAGE_SNSAVE, 0, -1, null).sendToTarget();        
    }	    
    
    void SetMessageTransSN(String str)
    {            	
    	mtmpstr = str;
        mHandler.obtainMessage(BluetoothAct.MESSAGE_SNWRITE, str.length(), -1, mtmpstr.getBytes()).sendToTarget();        
    }	    
    
    void SetFileTransStart(String str,int filesize)
    {
    	mtmpstr = str;
    	mHandler.obtainMessage(BluetoothAct.MESSAGE_TRANS_FILE_NAME, str.length(), filesize, mtmpstr.getBytes()).sendToTarget();
    }   
    
    void SetFileTransEnd(String str,int filesize)
    {
    	mtmpstr = str;
    	mHandler.obtainMessage(BluetoothAct.MESSAGE_TRANS_END, str.length(), filesize, mtmpstr.getBytes()).sendToTarget();
    }
    
    void SetFileTransStatus(String str,int offset)
    {            	
    	mtmpstr = str;
        mHandler.obtainMessage(BluetoothAct.MESSAGE_TRANS_STATUS, str.length(), offset, mtmpstr.getBytes()).sendToTarget();        
    }	        
    
    public boolean SetTransFile(String file)
    {
    	File oFile = new File(file.toString());
    	if (null == oFile)	
    		return false;
    	mFileTransRecvThread.setTransFile(file);
    	return true;
    }

    public boolean SetMessage(String msg)
    {    	
    	mFileTransRecvThread.setTransMessage(msg);
    	return true;
    }
        
    
    public void SetTransEvent(int event, byte cmd)
    {
    	if (null != mFileTransRecvThread)
    	mFileTransRecvThread.setTransEvent(event, cmd);
    }
    
        
    public void SetBeforeCMD(byte cmd)
    {
    	if (null != mBuf)	mBuf.mBeforeCmd = cmd;
    }
    
    public byte GetBeforeCMD()
    {
    	if (null != mBuf)
    	{
    		//Log.d("CURRENT ACK CMD" , "CMD:" + mBuf.mACKCmd);
    		return mBuf.mBeforeCmd;
    	}
    	else
    	{
    		return BT_CMD_NONE;
    	}
    }    

    
    public void SetWaitAckCMD(byte cmd)
    {
    	if (null != mBuf)	mBuf.mACKCmd = cmd;
    }
    
    public byte GetWaitAckCMD()
    {
    	if (null != mBuf)
    	{
    		//Log.d("CURRENT ACK CMD" , "CMD:" + mBuf.mACKCmd);
    		return mBuf.mACKCmd;
    	}
    	else
    	{
    		return BT_CMD_NONE;
    	}
    }    
    
    public boolean StartTranRecv() throws IOException
    {    	
    	StopTranRecv();	
    	    	
    	mFileTransRecvThread = new FileTransRecvThread(true); 
    	if (null != mFileTransRecvThread)
    	{
    		mFileTransRecvThread.start();
    		return true;
    	}
    	
		return false;    
    }
    
    public int StopTranRecv() throws IOException
    {
    	if (null != mTranFile)    	
    	{
    		mTranFile.close();
    		mTranFile = null;    		
    	}
    	if (null != mRecvfile)    	
    	{    		
    		mRecvfile.close();
    		mRecvfile = null;
    	}    	    	
        mCount = 0;        
    	
    	SetBeforeCMD(BT_CMD_NONE);
    	SetTransEvent(BluetoothAct.MESSAGE_NONE,BT_CMD_NONE);
		SetWaitAckCMD(BT_CMD_NONE);
		
		if (null != mFileTransRecvThread)	mFileTransRecvThread.stopThread();
		mFileTransRecvThread = null;   	
		return 0;    
    }    
    
    static int nstatic = 0;
    public FileOutputStream CreateRecvFile(String name) throws IOException
    {
    	if (null != mRecvfile)
    	{
    		mRecvfile.close();
    	}
    	else
    	{
    		
    		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
    		String recvfilename = ( "/data/data/" + mParent.getPackageName() + "/recv_" + nstatic + ".jpg");
    		//String recvfilename = ( "/sdcard/recv_" + timeStamp + ".jpg");
    		
    		mRecvfile = new FileOutputStream(recvfilename);        	
    		mFileTransRecvThread.setRecvFileSize(0);
    		mFileTransRecvThread.setTotalRecvFileSize(0);
    		mFileTransRecvThread.setRecvFile(recvfilename);
    		Log.d("CREATE FILE",recvfilename );
    		nstatic++;
    	}
    	return mRecvfile;
    }
    
    public FileOutputStream WriteRecvFile(byte[] readBuf,int nsize,int offset) throws IOException
    {
    	if (null != mRecvfile)
    	{    		
    		byte wData[] = new byte[nsize];
    		System.arraycopy(readBuf,0,wData,0,nsize);
    		mRecvfile.write(wData);//,offset,nsize);    		    		
    		mFileTransRecvThread.setRecvFileSize(offset + nsize);
    		
    		Log.d("WRITE FILE", " OFFSET: " + offset + " ~ " + mFileTransRecvThread.getRecvFileSize());
    	}    		
    	return mRecvfile;
    }    
    
    public boolean CloseRecvFile() throws IOException
    {
    	if (null != mRecvfile)
    	{
    		mRecvfile.close();
    		mRecvfile = null;
    		mFileTransRecvThread.setTotalRecvFileSize(0); 
    		mFileTransRecvThread.setRecvFileSize(0);   	    
    	    return true;
    	}   
    	return false;
    }    
    
    public byte[] intToByteArray(int value)
    {
    	return new byte[]
    			{
    			(byte)(value>>24),
    			(byte)(value>>16),
    			(byte)(value>>8),
    			(byte)(value)    			
    			};
    }
        
    public int ByteTointArray(byte []b)
    {
    	return (b[0] << 24) 
    			+ ((b[1] & 0xFF) << 16)
    			+ ((b[2] & 0xFF) << 8)
    			+ (b[3] & 0xFF);
    			
    }    
    
    public void writedata(byte []wbuffer, int size)
    {
    	if (size  > 0 && BluetoothAct.GetBlueToothConnection())
    	{
	    	mBuf.beforewsize = size;
	    	System.arraycopy(wbuffer,0,mBuf.beforewbuffer,0,size);
	    	BluetoothAct.mFileService.write(wbuffer);
    	}
    	else
    	{
    		mBuf.beforewsize = 0;
    	}
    	
    }
    
    public void beforwritedata()
    {
    	if (mBuf.beforewsize  > 0 && BluetoothAct.GetBlueToothConnection())
    	{
	    	byte []wbuffer =  new byte[mBuf.beforewsize];    	
	    	Log.d("RETRY=====>>", "CMD:" +  mBuf.beforewbuffer[5] + " size:" + mBuf.beforewsize);
	    	System.arraycopy(mBuf.beforewbuffer,0,wbuffer,0,mBuf.beforewsize);
	    	BluetoothAct.mFileService.write(wbuffer);
    	}
    }
    	
    
    public void RunTransFile(byte nCmd, String filename) throws IOException
    {
    	if (true == BluetoothAct.GetBlueToothConnection())
    	{
			if (nCmd == BT_REQ_CMD_FILE_NAME)
			{
    	    	//File oFile = new File("/sdcard/1325235227204.jpg");    				    				
    	    		    	    	
    	    	//STX + LEN(4) + CMD + DATA + ETX
    	    	byte[] send = new byte[filename.length() + 7];
    	    	send[0] = STX;
    	    	
    	    	//LEN
    	    	int leng = filename.length() + 1;    	    	
    	    	System.arraycopy(intToByteArray(leng),0,send,1,4);
	    		
    	    	//CMD 
    	    	send[5] = BT_REQ_CMD_FILE_NAME;
    	    	//DATA
    	    	System.arraycopy(filename.getBytes(),0,send,6,filename.length());
    	    	//ETX
    	    	send[6 + filename.length()] = ETX;
    	    	
    	    	SetWaitAckCMD(BT_ACK_CMD_FILE_NAME);
    	    	mFileTransRecvThread.setTransFile(filename);
    	    	writedata(send,send.length);
    	    	Log.d("SEND","REQ FILENAME!!!");
    	    	
			}
			else if (nCmd == BT_REQ_CMD_FILE_SIZE)
			{
				//mTranFile = new FileInputStream(filename.toString());    				
				File oFile = new File(filename.toString());    				
				String filesize = new String(""+oFile.length());
				
    	    	//STX + LEN(4) + CMD + DATA + ETX
    	    	byte[] send = new byte[filesize.length() + 7];
    	    	//STX
    	    	send[0] = STX;
    	    	
    	    	//LEN    	    	    	    	
    	    	int leng = filesize.length() + 1;    	    	
    	    	System.arraycopy(intToByteArray(leng),0,send,1,4);    	    	
    	    	//CMD
    	    	send[5] = BT_REQ_CMD_FILE_SIZE;	  
    	    	//DATA
    	    	System.arraycopy(filesize.getBytes(),0,send,6,filesize.length());
    	    	//ETX
    	    	send[6 + filesize.length()] = ETX;
    	    	
    	    	SetWaitAckCMD(BT_ACK_CMD_FILE_SIZE); 

    	    	mFileTransRecvThread.setTotalTransFileSize((int)oFile.length());
    	    	mFileTransRecvThread.setTransFileSize(0);    	    	
    	    	SetFileTransStart(mFileTransRecvThread.getTransFile(), (int)mFileTransRecvThread.getTotalTransFileSize());
    	    	writedata(send,send.length);
    	    	Log.d("SEND","REQ FILESIZE!!!");
			}
			else if (nCmd == BT_REQ_CMD_FILE_WRITE)
			{
				if (null == mTranFile)
					mTranFile = new FileInputStream(filename.toString());    				
				byte[] rbuffer = new byte[mTranspacketsize];		
				int nRead = mTranFile.read(rbuffer);//,nSendfileOffset,rbuffer.length);				
				String fileoffset = new String(""+mFileTransRecvThread.getTransFileSize());								
				
				if (0 < nRead)
				{    					
					int nSize = nRead + 7 + 4;
					//STX + LEN(4) + CMD + DATA + OFFSET(4) + ETX
					byte[] send = new byte[nSize];
					
					send[0] = STX;
					
						    	    	
	    	    	//LEN(offset ����)
	    	    	int leng = nRead + 1;    	    	
	    	    	System.arraycopy(intToByteArray(leng),0,send,1,4);
	    	    	
					//CMD
	    	    	send[5] = BT_REQ_CMD_FILE_WRITE;
					//DATA
					System.arraycopy(rbuffer,0,send,6,nRead);					
					//OFFSET
					byte[] off = intToByteArray(mFileTransRecvThread.getTransFileSize());
					System.arraycopy(intToByteArray(mFileTransRecvThread.getTransFileSize()),0,send,6+nRead,4);
										
					
					//ETX
					send[6+nRead+4] = ETX;

					SetWaitAckCMD(BT_ACK_CMD_FILE_WRITE);  																							
					mFileTransRecvThread.setTransFileSize(mFileTransRecvThread.getTransFileSize() + nRead);
					mBuf.mACKOffset = mFileTransRecvThread.getTransFileSize();		
					if (0 == (mCount++ % 10))
					{
						SetFileTransStatus(mFileTransRecvThread.getTransFile(), mFileTransRecvThread.getTransFileSize());
					}					
					writedata(send,send.length);
					//Log.d("SEND","REQ FILE WRITE!!!" + mFileTransRecvThread.getTransFileSize());
				}
				else
				{
					byte[] send = new byte[7];
					send[0] = STX;
	    	    	//DATA + CMD

					//LEN(offset ����)
	    	    	int leng = 1;    	    	
	    	    	System.arraycopy(intToByteArray(leng),0,send,1,4);					
					
	    	    	send[5] = BT_REQ_CMD_FILE_END;        					
	    	    	send[6] = ETX;
					SetWaitAckCMD(BT_ACK_CMD_FILE_END); 					
					writedata(send,send.length);	
					Log.d("SEND","REQ FILE WRITE END!!!");
					//end 					
				}    				
			}
			else if (nCmd == BT_REQ_CMD_MESSGAE)
			{				
				//stx
				byte[] send = new byte[mFileTransRecvThread.getTransMessage().length() + 7];
    	    	send[0] = STX;
    	    	    	    	    	        	    
    	    	//LEN(offset ����)
    	    	int leng = mFileTransRecvThread.getTransMessage().length() + 1;    	    	
    	    	System.arraycopy(intToByteArray(leng),0,send,1,4);    	    	
    	    	    	    	
    	    	
    	    	send[5] = BT_REQ_CMD_MESSGAE;	    	    	
    	    	System.arraycopy(mFileTransRecvThread.getTransMessage().getBytes(),0,
    	    			send,6,mFileTransRecvThread.getTransMessage().length());
    	    	send[6 + mFileTransRecvThread.getTransMessage().length()] = ETX;
    	    	
    	    	SetWaitAckCMD(BT_ACK_CMD_MESSGAE);  	    	    	    	
    	    	writedata(send,send.length);	
    	    	Log.d("SEND","REQ MESSAGE!!!");
			}					
			else if (nCmd == BT_REQ_CMD_DEVID || nCmd == BT_ACK_CMD_DEVID)
			{				
				//stx
				byte[] send = new byte[mFileTransRecvThread.getTransMessage().length() + 7];
    	    	send[0] = STX;
    	    	    	    	    	        	    
    	    	//LEN(offset ����)
    	    	int leng = mFileTransRecvThread.getTransMessage().length() + 1;    	    	
    	    	System.arraycopy(intToByteArray(leng),0,send,1,4);    	    	
    	    	    	    	
    	    	
    	    	send[5] = nCmd;	    	    	
    	    	System.arraycopy(mFileTransRecvThread.getTransMessage().getBytes(),0,
    	    			send,6,mFileTransRecvThread.getTransMessage().length());
    	    	send[6 + mFileTransRecvThread.getTransMessage().length()] = ETX;
    	    	
    	    	SetWaitAckCMD(BT_CMD_NONE);  	    	    	    	
    	    	writedata(send,send.length);	
    	    	Log.d("SEND","REQ DEVID or ACK DEVID!!!");
			}					
			
			else if (nCmd == BT_REQ_CMD_SN || nCmd == BT_ACK_CMD_SN)
			{				
				//stx
				byte[] send = new byte[mFileTransRecvThread.getTransMessage().length() + 7];
    	    	send[0] = STX;
    	    	    	    	    	        	    
    	    	//LEN(offset ����)
    	    	int leng = mFileTransRecvThread.getTransMessage().length() + 1;    	    	
    	    	System.arraycopy(intToByteArray(leng),0,send,1,4);    	    	
    	    	    	    	
    	    	
    	    	send[5] = nCmd;	    	    	
    	    	System.arraycopy(mFileTransRecvThread.getTransMessage().getBytes(),0,
    	    			send,6,mFileTransRecvThread.getTransMessage().length());
    	    	send[6 + mFileTransRecvThread.getTransMessage().length()] = ETX;
    	    	
    	    	SetWaitAckCMD(BT_CMD_NONE);  	   
    	    	
//    	    	for(int i = 0; i < send.length; i++)
//				{
//					Log.d("dd","send data ===>" + send[i]);
//				}    	    	
    	    	writedata(send,send.length);	
    	    	Log.d("SEND","REQ SN or ACK SN!!!");
			}	
			else if (nCmd == BT_CMD_OK_SN)
			{
				SetWaitAckCMD(BT_CMD_NONE);  
				SendAck(BT_CMD_OK_SN);
			}
    	}
    
//    	{
//			Intent i = new Intent(Intent.ACTION_SEND);
//			File file = new File("/sdcard/1325235227204.jpg");
//			
//			Uri uri =Uri.fromFile(file);
//			i.setType("image/jpeg");    
//			i.putExtra(Intent.EXTRA_STREAM, uri); 
//			startActivity(Intent.createChooser(i, "Send Image"));			
//    	}
    }    
    
    //long mRecvWriteFileSize = 0;
    
    public void SendAck(byte cmd)
    {
		byte[] wbuffer = new byte[7];
		wbuffer[0] = STX;
		
		int leng = 1;    	    	
    	System.arraycopy(intToByteArray(leng),0,wbuffer,1,4);	
		
		wbuffer[5] = cmd;        					
		wbuffer[6] = ETX;
		BluetoothAct.mFileService.write(wbuffer);	
    }
        
    public void SendFileSyncAck(byte cmd,int nOffset)
    {
		byte[] wbuffer = new byte[11];
		wbuffer[0] = STX;
		
		int leng = 5;    	    			
    	System.arraycopy(intToByteArray(leng),0,wbuffer,1,4);
    	wbuffer[5] = cmd;    	
    	System.arraycopy(intToByteArray(nOffset),0,wbuffer,6,4);			
		        			
		wbuffer[10] = ETX;
		BluetoothAct.mFileService.write(wbuffer);	
    }
            
    
    public void RunRecvFile() throws IOException, InterruptedException
    {    	
    	if (null == mTmpBuf)
    	{
    		mTmpBuf = new TmpBtBuff(); 
    	}
    	mTmpBuf.nHead = -1;
    	mTmpBuf.nTail = -1;
    	
    	//BluetoothTestActivity.mFileService.readsysnc(false);
    	ReadBuff(mTmpBuf);
    	//BluetoothTestActivity.mFileService.readsysnc(true);
    	byte cmd = 0;
    	if (true == BluetoothAct.GetBlueToothConnection() 
    			&& 0 <= mTmpBuf.nHead && 0 <= mTmpBuf.nTail)
    	{    		
    	    	
    		byte []datacmdlen = new byte[4];
    		datacmdlen[0] = mTmpBuf.mTempBuff[1];
    		datacmdlen[1] = mTmpBuf.mTempBuff[2];
    		datacmdlen[2] = mTmpBuf.mTempBuff[3];
    		datacmdlen[3] = mTmpBuf.mTempBuff[4];
    		int datalen = ByteTointArray(datacmdlen) -1;
    		cmd = mTmpBuf.mTempBuff[5];
    		    		
    		//DATA
    		byte []data = new byte[datalen];
    		int noffsetlen = 0;    		
    		
    		if (cmd == BT_REQ_CMD_FILE_WRITE)
    		{
    		
	    		//STX+LEN+ETX = 3 - data	    		
	    		byte []offsetlen = new byte[4];
	    		offsetlen[0] = mTmpBuf.mTempBuff[6 + datalen + 0];
	    		offsetlen[1] = mTmpBuf.mTempBuff[6 + datalen + 1];
	    		offsetlen[2] = mTmpBuf.mTempBuff[6 + datalen + 2];
	    		offsetlen[3] = mTmpBuf.mTempBuff[6 + datalen + 3];
	    		noffsetlen = ByteTointArray(offsetlen);	   
	    		
	    		if (GetBeforeCMD() == cmd && 
	    				mFileTransRecvThread.getBeforeRecvFileSize() > 0 &&
	    				noffsetlen == mFileTransRecvThread.getBeforeRecvFileSize())
	    		{
	    			mBuf.nHead  = 0;
					mBuf.nTail  = 0;
					TmpBtBuff TmpBuf = new TmpBtBuff(); 
					System.arraycopy(TmpBuf.mTempBuff,0,mBuf.mTempBuff,0,mBtBuffLen);
	    			SendFileSyncAck(BT_ACK_CMD_FILE_WRITE,mFileTransRecvThread.getRecvFileSize());
					Log.d("SEND","RETRY ----> ACK FILE WRITE!!! offset:" + mFileTransRecvThread.getRecvFileSize());			    	
					return;
	    		}
    			
    		}
    		
    		System.arraycopy(mTmpBuf.mTempBuff,6,data,0,datalen);
    		    		    		
			if (cmd == BT_REQ_CMD_FILE_NAME )
			{
				//Log.d("TDMK","BT_REQ_CMD_FILE_NAME");				
				String readMessage = new String(data, 0, datalen);
				Log.d("RECV","BT_REQ_CMD_FILE_NAME=======>" + readMessage);						
				CreateRecvFile(readMessage);							
				SendAck(BT_ACK_CMD_FILE_NAME);										

    	    	//Log.d("SEND","ACK FILE NAME!!!");
				
			}
			else if (cmd == BT_REQ_CMD_FILE_SIZE)
			{
				//Log.d("TDMK","BT_REQ_CMD_FILE_SIZE");				
				String readMessage = new String(data, 0, datalen);				
				mFileTransRecvThread.setTotalRecvFileSize((int)Long.parseLong(readMessage));
				mFileTransRecvThread.setRecvFileSize(0);
				Log.d("RECV","BT_REQ_CMD_FILE_SIZE=======>" + readMessage + ":" + mFileTransRecvThread.getTotalRecvFileSize());								
				SetFileRecvStart(mFileTransRecvThread.getRecvFile(), (int)mFileTransRecvThread.getTotalRecvFileSize());				
				SendAck(BT_ACK_CMD_FILE_SIZE);				
			}
			else if (cmd == BT_REQ_CMD_FILE_WRITE)
			{				
				//Log.d("RECV","BT_REQ_CMD_FILE_WRITE OFFSET :" + noffsetlen + " size:" + datalen);
				if (mFileTransRecvThread.getRecvFileSize()+datalen == noffsetlen + datalen)
				{
					WriteRecvFile(data,datalen,noffsetlen);		
					if (0 == (mCount++ % 10))
					{
						SetFileRecvStatus("Recv Status :"+ mFileTransRecvThread.getRecvFileSize() + "/"+ 
								(int)mFileTransRecvThread.getTotalRecvFileSize(), mFileTransRecvThread.getRecvFileSize());
					}
					SendFileSyncAck(BT_ACK_CMD_FILE_WRITE,mFileTransRecvThread.getRecvFileSize());					
				}
				else
				{
					Log.d("ERROR","sync error a:" + (mFileTransRecvThread.getRecvFileSize()+datalen) + " b:" + (noffsetlen + datalen));
	    			mBuf.nHead  = 0;
					mBuf.nTail  = 0;
					TmpBtBuff TmpBuf = new TmpBtBuff(); 
					System.arraycopy(TmpBuf.mTempBuff,0,mBuf.mTempBuff,0,mBtBuffLen);					
				}
				//Log.d("SEND","ACK FILE WRITE!!!");
			}
						
			else if (cmd == BT_REQ_CMD_DEVID)	
			{															
				String readMessage = new String(data, 0, datalen);
				Log.d("RECV","BT_REQ_CMD_DEVID=======>" + readMessage);	
				SendAck(BT_CMD_NONE);	
				SetMessageRecvStatus("conneted id:"+ readMessage);
				SetMessage(BluetoothAct.getAdaptername());
				SetTransEvent(BluetoothAct.MESSAGE_WRITE, BT_ACK_CMD_DEVID);					
			}

			else if (cmd == BT_REQ_CMD_SN)	
			{								
				String readMessage = new String(data, 0, datalen);
				Log.d("RECV","BT_REQ_CMD_SN=======>" + readMessage);	
				SendAck(BT_CMD_NONE);
				
//				for(int i = 0; i < datalen; i++)
//				{
//					Log.d("dd","recv data ===>" + data[i]);
//				}								
				SetMessage(readMessage);
				SetMessageRecvSN(readMessage);				
				
//				Log.d("getmsg:==============",mFileTransRecvThread.getTransMessage());
//				
//				byte []a = mFileTransRecvThread.getTransMessage().getBytes();
//				for(int i = 0; i < datalen; i++)
//				{
//					Log.d("dd","trans data ===>" + a[i]);
//				}			
				SetTransEvent(BluetoothAct.MESSAGE_WRITE, BT_ACK_CMD_SN);					
			}
			else if (cmd == BT_CMD_OK_SN)
			{
				String readMessage = new String(data, 0, datalen);
				Log.d("RECV","BT_CMD_OK_SN=======>" + readMessage);					
				SendAck(BT_CMD_NONE);
				SetMessageSaveSN();
			}
			
			else if (cmd == BT_REQ_CMD_MESSGAE)	
			{															
				String readMessage = new String(data, 0, datalen);				
				Log.d("RECV","BT_REQ_CMD_MESSGAE=======>" + readMessage);											
				SetMessageRecvStatus("Recv message:" + readMessage);
				SendAck(BT_ACK_CMD_MESSGAE);					
			}
			else if (cmd == BT_REQ_CMD_FILE_END)
			{
				Log.d("RECV","FILE WRITE END!!!!!!!!!!!!!!!!!! realsize:" + 
						(int)mFileTransRecvThread.getTotalRecvFileSize() + 
						" destsize:" + mFileTransRecvThread.getRecvFileSize());
				SetFileRecvEnd("SUCCESS:" + mFileTransRecvThread.getRecvFile(),(int)mFileTransRecvThread.getRecvFileSize());				
				CloseRecvFile();			
				cmd = BT_CMD_NONE;
				SetBeforeCMD(cmd);
				SendAck(BT_ACK_CMD_FILE_END);
				//Log.d("SEND","ACK FILE WRITE END!!!");
			}
			//ACK
			else if (cmd == BT_ACK_CMD_FILE_NAME)
			{
				if (GetWaitAckCMD() == BT_ACK_CMD_FILE_NAME)
				{
					Log.d("RECV","ACK FILE NAME!!!");
					SetWaitAckCMD(BT_CMD_NONE);		
					SetTransEvent(BluetoothAct.MESSAGE_WRITE,BT_REQ_CMD_FILE_SIZE);										
				}
			}
			else if (cmd == BT_ACK_CMD_FILE_SIZE)
			{
				if (GetWaitAckCMD() == BT_ACK_CMD_FILE_SIZE)
				{
					Log.d("RECV","ACK FILE SIZE!!!");
					SetWaitAckCMD(BT_CMD_NONE);
					SetTransEvent(BluetoothAct.MESSAGE_WRITE,BT_REQ_CMD_FILE_WRITE);															
				}				
			}
			else if (cmd == BT_ACK_CMD_FILE_WRITE)
			{
				if (GetWaitAckCMD() == BT_ACK_CMD_FILE_WRITE)
				{
					byte []offsetlen = new byte[4];
					offsetlen[0] = data[0];
		    		offsetlen[1] = data[1];
		    		offsetlen[2] = data[2];
		    		offsetlen[3] = data[3];
		    		noffsetlen = ByteTointArray(offsetlen);	
		    		
		    		if (mFileTransRecvThread.getTransFileSize() == noffsetlen)
		    		{						
						SetWaitAckCMD(BT_CMD_NONE);					
						SetTransEvent(BluetoothAct.MESSAGE_WRITE,BT_REQ_CMD_FILE_WRITE);
		    		}
		    		Log.d("RECV","ACK FILE WRITE!!!" + mFileTransRecvThread.getTransFileSize() + ":" + noffsetlen);
				}				
			}
			else if (cmd == BT_ACK_CMD_DEVID)	
			{															
				String readMessage = new String(data, 0, datalen);
				Log.d("RECV","BT_ACK_CMD_DEVID=======>" + readMessage);	
				SetWaitAckCMD(BT_CMD_NONE);	
				SetMessageRecvStatus("conneted id:"+ readMessage);
			}	
			
			else if (cmd == BT_ACK_CMD_SN)	
			{															
				String readMessage = new String(data, 0, datalen);
				Log.d("RECV","BT_ACK_CMD_SN=======>" + readMessage);	
				SetWaitAckCMD(BT_CMD_NONE);	
				SetMessageTransSN(readMessage);
//				SetMessageTransSN("Recv SN:"+ readMessage);
			}			
			else if (cmd == BT_ACK_CMD_MESSGAE)
			{								
				if (GetWaitAckCMD() == BT_ACK_CMD_MESSGAE)
				{
					Log.d("RECV","ACK MESSAGE!!!");					
					SetMessageRecvStatus("Send Message:"+ mFileTransRecvThread.getTransMessage());
					SetWaitAckCMD(BT_CMD_NONE);
					SetTransEvent(BluetoothAct.MESSAGE_NONE,BT_CMD_NONE);
				}			
			}
			else if (cmd == BT_ACK_CMD_FILE_END)
			{
				if (GetWaitAckCMD() == BT_ACK_CMD_FILE_END)
				{
					Log.d("RECV","ACK FILE WRITE END!!!");		
					
					SetFileTransEnd("SUCCESS:" + mFileTransRecvThread.getTransFile(),(int)mFileTransRecvThread.getTransFileSize());
					
					SetWaitAckCMD(BT_CMD_NONE);
					SetTransEvent(BluetoothAct.MESSAGE_NONE,BT_CMD_NONE);
					
					if (null != mTranFile)
					mTranFile.close();					
				}				
			}
			mCMDRetry = 0;
			mSaveCMDRetry = 0;
								
    	}
    	//수신 상태 time out 
    	else if (GetBeforeCMD() == BT_REQ_CMD_FILE_WRITE)
    	{
    		mCMDRetry++;			
			mSaveCMDRetry++;	
			if (nTickmSec > 0)
			{
				if ((mCMDRetry*nTickmSec) > (mMaxCMDRetry * nTickmSec))
				{
					mCMDRetry = 0;
					
					writedata(new byte[1],0);
					Log.d("ERROR>>", "TIMEOUT, NO REQ");
					SetWaitAckCMD(BT_CMD_NONE);									
					mBuf.nHead  = 0;
					mBuf.nTail  = 0;
					TmpBtBuff TmpBuf = new TmpBtBuff(); 
					System.arraycopy(TmpBuf.mTempBuff,0,mBuf.mTempBuff,0,mBtBuffLen);
					SetBeforeCMD(BT_CMD_NONE);
					SetTransEvent(BluetoothAct.MESSAGE_NONE,BT_CMD_NONE);
					SetFileRecvEnd("RECV ERROR>> Time Out, No req Recv name:"+ mFileTransRecvThread.getRecvFile(),mFileTransRecvThread.getRecvFileSize());
				}
				else if (mSaveCMDRetry*nTickmSec >  mRetryTick * nTickmSec)
				{				
					Log.d("RECV WARRING>>", "mSaveCMDRetry:" + mSaveCMDRetry + " mCMDRetry:" + mCMDRetry);
					mBuf.nHead  = 0;
					mBuf.nTail  = 0;
					TmpBtBuff TmpBuf = new TmpBtBuff(); 
					System.arraycopy(TmpBuf.mTempBuff,0,mBuf.mTempBuff,0,mBtBuffLen);
					mSaveCMDRetry = 0;
				}			
			}
			else	//galaxy sII
			{
				if ((mCMDRetry) > (mMaxCMDRetry))
				{
					mCMDRetry = 0;					
					writedata(new byte[1],0);
					Log.d("ERROR>>", "TIMEOUT, NO REQ");
					SetWaitAckCMD(BT_CMD_NONE);									
					mBuf.nHead  = 0;
					mBuf.nTail  = 0;
					TmpBtBuff TmpBuf = new TmpBtBuff(); 
					System.arraycopy(TmpBuf.mTempBuff,0,mBuf.mTempBuff,0,mBtBuffLen);
					
					SetTransEvent(BluetoothAct.MESSAGE_NONE,BT_CMD_NONE);
					SetFileTransEnd("RECV ERROR>> Time Out, No req Recv name:"+ mFileTransRecvThread.getRecvFile(),mFileTransRecvThread.getRecvFileSize());
					CloseRecvFile();
				}
				else if (mSaveCMDRetry >  mRetryTick)
				{				
					Log.d("RECV WARRING>>", "mSaveCMDRetry:" + mSaveCMDRetry + " mCMDRetry:" + mCMDRetry);
					mBuf.nHead  = 0;
					mBuf.nTail  = 0;
					TmpBtBuff TmpBuf = new TmpBtBuff(); 
					System.arraycopy(TmpBuf.mTempBuff,0,mBuf.mTempBuff,0,mBtBuffLen);
					mSaveCMDRetry = 0;
				}							
			}
			return;    		
    	}
    	//전송 상태 time out 또는 Retry 
    	else if (GetWaitAckCMD() != BT_CMD_NONE)
		{    		
			mCMDRetry++;			
			mSaveCMDRetry++;	
			if (nTickmSec > 0)
			{
				if ((mCMDRetry*nTickmSec) > (mMaxCMDRetry * nTickmSec))
				{
					mCMDRetry = 0;
					
					writedata(new byte[1],0);
					Log.d("ERROR>>", "TIMEOUT, NO ACK(" +  mBuf.mACKCmd + ")");
					SetWaitAckCMD(BT_CMD_NONE);				
					
					mBuf.nHead  = 0;
					mBuf.nTail  = 0;
					TmpBtBuff TmpBuf = new TmpBtBuff(); 
					System.arraycopy(TmpBuf.mTempBuff,0,mBuf.mTempBuff,0,mBtBuffLen);
					
					SetTransEvent(BluetoothAct.MESSAGE_NONE,BT_CMD_NONE);
					SetFileTransStatus("ERROR>> Time Out, No ack transfile name:"+ mFileTransRecvThread.getTransFile(),mFileTransRecvThread.getTransFileSize());
					if (null != mTranFile)	mTranFile.close();
				}
				else if (mSaveCMDRetry*nTickmSec >  mRetryTick * nTickmSec)
				{				
					Log.d("ERROR>>", "mSaveCMDRetry:" + mSaveCMDRetry + " mCMDRetry:" + mCMDRetry);
					beforwritedata();
					mSaveCMDRetry = 0;
				}			
			}
			else	//galaxy sII
			{
				if ((mCMDRetry) > (mMaxCMDRetry))
				{
					mCMDRetry = 0;
					
					writedata(new byte[1],0);
					Log.d("ERROR>>", "TIMEOUT, NO ACK(" +  mBuf.mACKCmd + ")");
					SetWaitAckCMD(BT_CMD_NONE);				
					SetTransEvent(BluetoothAct.MESSAGE_NONE,BT_CMD_NONE);						
				}
				else if (mSaveCMDRetry >  mRetryTick)
				{				
					Log.d("ERROR>>", "mSaveCMDRetry:" + mSaveCMDRetry + " mCMDRetry:" + mCMDRetry);
					beforwritedata();
					mSaveCMDRetry = 0;
				}							
			}
			return;
		}
    	
    	if (cmd != 0)
    	{
    		SetBeforeCMD(cmd);
    	}

    }       

	synchronized public void WriteBuff(int nEvent,byte [] data, int nSize)
    {
		if (BluetoothAct.MESSAGE_READ == nEvent)
		{			

			if (mBuf.nTail + nSize >= mBtBuffLen)
			{
				System.arraycopy(data, 0, mBuf.mTempBuff, mBuf.nTail, mBtBuffLen - mBuf.nTail);
				if ((nSize - (mBtBuffLen - mBuf.nTail)) >= 1)
				{
					System.arraycopy(data, mBtBuffLen - mBuf.nTail,
							mBuf.mTempBuff, 0, nSize - (mBtBuffLen - mBuf.nTail));
				}
				mBuf.nTail = nSize - (mBtBuffLen - mBuf.nTail);				
			}
			else
			{
				System.arraycopy(data, 0, mBuf.mTempBuff, mBuf.nTail, nSize);
				mBuf.nTail += nSize;
			}
//			String readMessage = new String(data, 0, nSize);
//			Log.d("TDMK","BT_REQ_CMD_FILE_NAME=======>" + readMessage);		
			//Log.d("TDMK_AJK","WRITE=======>Head:" + mBuf.nHead + "TAIL:" + mBuf.nTail);
			
		}
    }

	int nCount = 0;
	synchronized public void ReadBuff(TmpBtBuff cBuf)
    {
    	if (null == cBuf)
    	{
    		Log.d("ERROR","ReadBuff=======>TmpBtBuff cBuf is null!!!!!!!!!!!");
    		return;
    	}
		if (mBuf.nHead == mBuf.nTail && BT_CMD_NONE == GetWaitAckCMD())
		{
			cBuf.nHead = -1;
			cBuf.nTail = -1;	
			//Log.d("TDMK_AJK","READ=======>Head:" + mBuf.nHead + "TAIL:" + mBuf.nTail);
			return;
		}		
		else if (mBuf.nHead < mBuf.nTail)
		{
			int stxpos = -1;		
			int etxpos = -1;
			int realextpos = -1;
			
			//�ּ� 5�� �̻� Read �����Ͱ� ���� ��� ó�� �ؾ� ��.
			if (mBuf.nHead + 5 > mBuf.nTail)
			{
				cBuf.nHead = -1;
				cBuf.nTail = -1;
				//Log.d("TDMK_AJK","READ=======>Head:" + mBuf.nHead + "TAIL:" + mBuf.nTail);
				return;
			}
			
			for(int i = 0; i < (mBuf.nTail-mBuf.nHead); i++)
			{
				//Buffer ����� over ��  �ܿ� �Ǵ� Tail ���� Ŭ���.
				if (mBuf.nHead + i >= mBtBuffLen || mBuf.nHead + i >= mBuf.nTail)
				{
					cBuf.nHead = -1;
					cBuf.nTail = -1;
					//Log.d("TDMK_AJK","READ=======>Head:" + mBuf.nHead + "TAIL:" + mBuf.nTail);
					return;
				}
				
				if (-1 == stxpos && STX == mBuf.mTempBuff[mBuf.nHead+i])
				{
					cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
					stxpos = mBuf.nHead+i;
					
					byte []len = new byte[4];
					
					//STX + LEN(4) + len(CMD + DATA) + ETX 
					int lenpos = mBuf.nHead+i+1;
					int cmdpos = 0;
					int datapos = 0;
					
					for (int k = 0; k < 4; k++)
					{
												
						if (lenpos + k >= mBtBuffLen)
						{
							len[k] = mBuf.mTempBuff[(lenpos + k) - mBtBuffLen];
							if (k == 3)
							{
								cmdpos = (lenpos + k) - mBtBuffLen + 1;
								datapos = cmdpos + 1;								
							}
						}
						else
						{
							len[k] = mBuf.mTempBuff[lenpos+k];
							if (k == 3)
							{
								cmdpos = (lenpos + k) + 1;
								datapos = cmdpos + 1;
							}
							
						}						
					}		
								
					realextpos = datapos + 	ByteTointArray(len);

					if (realextpos > mBuf.nTail)	
					{						
						cBuf.nHead = -1;
						cBuf.nTail = -1;
						return;
					}
					
					//write ��ü ��Ŷ����  offset(4�ڸ�)�߰�
					else if (mBuf.mTempBuff[cmdpos] == BT_REQ_CMD_FILE_WRITE)
					{
						realextpos += 4;
						
						if (realextpos >= mBtBuffLen)
						{
							//120307 error ����
							cBuf.nHead = -1;
							cBuf.nTail = -1;
							return;						
						}						

						if (realextpos > mBuf.nTail)	
						{						
							cBuf.nHead = -1;
							cBuf.nTail = -1;
							return;
						}
						
					}				
				}
				else if (-1 == etxpos && -1 < stxpos && ETX == mBuf.mTempBuff[mBuf.nHead+i])
				{
					if (realextpos-1 <= mBuf.nHead+i)
					{
						cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
						etxpos = mBuf.nHead+i;						
					}
					else
					{
						cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
						//Log.d("ETX SKIP : ReadBuff","read etx =" + realextpos + ",find etx=" + (mBuf.nTail - mBuf.nHead+i));
					}
						
				}				
				else if (-1 == etxpos && -1 < stxpos)
				{
					cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
				}
			}
			
			if (-1 < stxpos && -1 < etxpos)
			{
				mBuf.nHead = etxpos + 1;
				if (mBuf.nHead >= mBtBuffLen)
				{
					mBuf.nHead = 0;
				}

				cBuf.nHead = stxpos;
				cBuf.nTail = etxpos;	
			}
			else
			{
				cBuf.nHead = -1;
				cBuf.nTail = -1;
			}
		}
		else //if (mBuf.nHead >= mBuf.nTail)
		{
			int stxpos = -1;		
			int etxpos = -1;
			int realextpos = -1;
			int j = 0;
			int i = 0;
			
			//�ּ� 5�� �̻� Read �����Ͱ� ���� ��� ó�� �ؾ� ��.
			//if ((5 - mBtBuffLen - mBuf.nHead) > mBuf.nTail)
			if ( (mBtBuffLen - mBuf.nHead) + mBuf.nTail < 5)
			{
				cBuf.nHead = -1;
				cBuf.nTail = -1;
				//Log.d("TDMK_AJK","READ=======>Head:" + mBuf.nHead + "TAIL:" + mBuf.nTail);
				return;
			}			
			
			for(i = 0; i < mBtBuffLen - mBuf.nHead; i++)
			{
				
				if (-1 == stxpos && STX == mBuf.mTempBuff[mBuf.nHead+i])
				{
					cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
					stxpos = mBuf.nHead+i;
					
					byte []len = new byte[4];
					int lenpos = mBuf.nHead+ i + 1;
					int datapos = 0;
					int cmdpos = 0;
					int checkpos = 0;
					
					for (int k = 0; k < 4; k++)
					{
												
						if (lenpos + k >= mBtBuffLen)
						{
							len[k] = mBuf.mTempBuff[(lenpos + k) - mBtBuffLen];
							if (k == 3)
							{
								int offsetlen = 0;
								cmdpos = (lenpos + k) - mBtBuffLen + 1;
								datapos = cmdpos + 1;									
								
								if (mBuf.mTempBuff[cmdpos] == BT_REQ_CMD_FILE_WRITE)
									offsetlen = 4;
								
								realextpos = datapos + 	ByteTointArray(len) + offsetlen;
								
								
								if (realextpos >= mBtBuffLen)
								{
									realextpos -= mBtBuffLen;
								}
																
							}
						}
						else
						{
							len[k] = mBuf.mTempBuff[lenpos+k];
							if (k == 3)
							{
								int offsetlen = 0;
								cmdpos = (lenpos + k) + 1;
								
								if (cmdpos >= mBtBuffLen)
								{
									//120307 error ����
									cmdpos = mBtBuffLen - cmdpos;
								}
								
								datapos = cmdpos + 1;
								
								if (datapos >= mBtBuffLen)
								{
									//120307 error ����
									datapos = mBtBuffLen - datapos;
								}								
								
								if (mBuf.mTempBuff[cmdpos] == BT_REQ_CMD_FILE_WRITE);
									offsetlen = 4;
									
								realextpos = datapos + 	ByteTointArray(len) + offsetlen;
																
								if(realextpos >= mBtBuffLen)
								{
									realextpos -= mBtBuffLen;
								}								
								
							}
							
						}						
					}									
					
				}
				else if (-1 == etxpos && -1 < stxpos && ETX == mBuf.mTempBuff[mBuf.nHead+i])
				{					
					if (0 <=realextpos  &&  realextpos-1 == mBuf.nHead+i)
					{
						cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
						etxpos = mBuf.nHead+i;
					}
					else
					{
						cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
						//Log.d("ETX SKIP1 : ReadBuff","read etx =" + realextpos + ",find etx=" + mBuf.nHead+i);
					}					
				}				
				else if (-1 == etxpos && -1 < stxpos)
				{
					cBuf.mTempBuff[i] = mBuf.mTempBuff[mBuf.nHead+i];
				}
			}
			
			for(j = 0; j < mBuf.nTail && -1 < stxpos; j++)
			{
				if (i+j >= mBtBuffLen)
				{
					cBuf.nHead = -1;
					cBuf.nTail = -1;
					//Log.d("TDMK_AJK","READ=======>Head:" + mBuf.nHead + "TAIL:" + mBuf.nTail);
					return;
				}
				
				if (-1 == etxpos && ETX == mBuf.mTempBuff[j])
				{
					if (0 <=realextpos  && realextpos-1 == j)
					{
						cBuf.mTempBuff[i+j] = mBuf.mTempBuff[j];
						etxpos = j;
					}				
					else
					{
						cBuf.mTempBuff[i+j] = mBuf.mTempBuff[j];
						//Log.d("ETX SKIP2 : ReadBuff","read etx =" + realextpos + ",find etx=" + j);
					}
				}				
				else if (-1 == etxpos)
				{
					cBuf.mTempBuff[i+j] = mBuf.mTempBuff[j];
				}
			}			
			
			if (-1 < stxpos && -1 < etxpos)
			{
				if (etxpos >= mBtBuffLen)
				{
					etxpos -= mBtBuffLen;
				}
				
				mBuf.nHead = etxpos + 1;
				if (mBuf.nHead >= mBtBuffLen)
				{
					mBuf.nHead = 0;
				}
				cBuf.nHead = stxpos;
				cBuf.nTail = etxpos;					
				
			}	
			else
			{
				cBuf.nHead = -1;
				cBuf.nTail = -1;
			}
		}	
		//Log.d("TDMK_AJK","READ=======>Head:" + mBuf.nHead + "TAIL:" + mBuf.nTail);
    }
        
	
	String gTransMessage = new String("                                                ");
    class FileTransRecvThread extends Thread {
    	 
        private boolean isRun = false;
        private String Message = null;
        private String Transfilename;
        private String Recvfilename;
        private int TransfileSize = 0;
        private int RecvfileSize = 0;
        private int TransTotalfileSize = 0;
        private int RecvTotalfileSize = 0;
        private int BeforeRecvfileSize = 0;
  
        public FileTransRecvThread(boolean b) {
			// TODO Auto-generated constructor stub
        	synchronized (this)
        	{
        		this.isRun = b;
        	}
		}

		public void stopThread(){
			synchronized (this)
			{
		        Transfilename = null;
		        Recvfilename = null;
		        TransfileSize = 0;
		        RecvfileSize = 0;
		        TransTotalfileSize = 0;
		        RecvTotalfileSize = 0;	
		        BeforeRecvfileSize = 0;
		        
				isRun = !isRun;
			}
        }
		
		public void setTransFile(String file){
			synchronized (this)
			{
				Transfilename = file;
			}
        }

		public String getTransFile(){
			synchronized (this)
			{
				return Transfilename;
			}
        }

		public void setTransMessage(String msg){
			synchronized (this)
			{
				if (null != Message)
				{
					Message = null;
				}
				Message = new String(msg); 					
			}
        }

		public String getTransMessage(){
			synchronized (this)
			{
				if (null != Message)
					return Message;
				else 
					return null;
			}
        }
		
		public void setRecvFile(String file){
			synchronized (this)
			{
				Recvfilename = file;
			}
        }

		public String getRecvFile(){
			synchronized (this)
			{
				return Recvfilename;
			}
        }				
		
		public String setTransFileSize(){
			synchronized (this)
			{
				return Recvfilename;
			}
        }		
		
		public void setTransFileSize(int size){
			synchronized (this)
			{
				TransfileSize = size;
			}
        }				
		
		public void setRecvFileSize(int size){
			synchronized (this)
			{
				BeforeRecvfileSize = RecvfileSize;
				RecvfileSize = size;
			}
        }	
		
		public int getBeforeRecvFileSize(){
			synchronized (this)
			{
				return BeforeRecvfileSize;
			}
        }				
		
		
		public int getTransFileSize(){
			synchronized (this)
			{
				return TransfileSize;
			}
        }				
		
		public int getRecvFileSize(){
			synchronized (this)
			{
				return RecvfileSize;
			}
        }				
		//
		public void setTotalTransFileSize(int size){
			synchronized (this)
			{
				TransTotalfileSize = size;
			}
        }				
		
		public void setTotalRecvFileSize(int size){
			synchronized (this)
			{
				RecvTotalfileSize = size;
			}
        }	
		
		public int getTotalTransFileSize(){
			synchronized (this)
			{
				return TransTotalfileSize;
			}
        }				
		
		public int getTotalRecvFileSize(){
			synchronized (this)
			{
				return RecvTotalfileSize;
			}
        }				
				
		
		public void setTransEvent(int event,byte cmd){
			synchronized (this)
			{
				mTransEVENT = event;
				mTransCMD = cmd;				
			}
        }			
		
		
        @Override
        public void run() {
            while (isRun) 
            {
            	try {
					sleep(nTickmSec);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
            	try {
            		synchronized (this)
            		{
	            		if (BluetoothAct.MESSAGE_WRITE == mTransEVENT)
	            		{
	            			RunTransFile(mTransCMD,Transfilename);
	        				mTransCMD = BT_CMD_NONE;
	        				mTransEVENT = BluetoothAct.MESSAGE_NONE;
	            		}
	            		else 
	            		{
	            			RunRecvFile();
	            		}
            		}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }        
               
    }

                                 
}
