package com.tjmedia.android.tjdebugger.common;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;



public class TJPackageManager {
	private static final String TAG = "PackageManager";
	
	
	private static String getAppVersionName(Context context) {
		String version;
		try {
		   PackageInfo i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
		   version = i.versionName;
		} catch(NameNotFoundException e) { 
			version = null;
		}
		return version;
	}
	
	private static int getAppVersionCode(Context context) {
		int version;
		try {
			PackageInfo i = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
			version = i.versionCode;
		} catch(NameNotFoundException e) { 
			version = -1;
		}
		return version;
	}
	
	public static String updateVersionInfo(Context context) {
		String vName = getAppVersionName(context);
		int vCode = getAppVersionCode(context);
		int sCode = SharedManager.getVersionCode(context);
		Log.d(TAG, "vName="+vName + ", vCode=" + vCode);
		int var = Integer.valueOf(vCode);
		int var2 = Integer.valueOf(sCode);
		
		if (var > var2) {
			Log.d(TAG, "var > var2 true, vName="+vName);
			SharedManager.setVersionCode(context, var);
			SharedManager.setVersionName(context, vName);
		}
		return vName;
	}
	
}
