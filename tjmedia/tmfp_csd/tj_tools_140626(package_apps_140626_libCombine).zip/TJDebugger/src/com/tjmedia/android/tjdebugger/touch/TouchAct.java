package com.tjmedia.android.tjdebugger.touch;

import android.app.Activity;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.activity.TJDebugger.LoopHandler;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.RegexManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : Jimmy
 * @Date    :  12.04.20
 * @History : 
 * @MenuTree
 * 
 *
 */

public class TouchAct extends Activity {   
   
	private static final String TAG = "TouchAct"; 	

	SoundPoolManager mPoolManger;	
	Button mTitleExit;
	String strManufacturer = android.os.Build.MANUFACTURER;	
	
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.touch_main);    
 
        initObjInfo();
        initViewID();
        initTouchView();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		mTspCal = false;
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent ev) {		
		
        final int action = ev.getAction();
        
        switch (action & MotionEvent.ACTION_MASK) {
	        case MotionEvent.ACTION_UP:
	            Log.d(TAG, "onTouchEvent()========" + ev.getX() + "," + ev.getY());
	            float x = ev.getX();
	            float y = ev.getY();
	            if (10 <= x && 150 >= x && 5 <= y && 60 >= y)
	            {
	            	mPoolManger.playTouchSe();
	            	finish();
	            	super.onTouchEvent(ev); 
	        		return true;
	            }
//	            if (10 <= x && 150 >= x && 100 <= y && 150 >= y)
//	            {
//	            	
//	            	if (!mTspCal)
//					{
//						mTspCal = true;
//						
////						if (strManufacturer.equalsIgnoreCase("tjmedia"))
//						if (Log.getTJ())
//						{							
//							TDMKMisc_Service.TouchScreenCalibration();
//							mPoolManger.playTouchSe();
//							SystemClock.sleep(1000);
//							ToastManager.showToast(this, "Calibration Event, waitting ..", Toast.LENGTH_LONG);
//						}
//					}	            	
//	            	super.onTouchEvent(ev); 
//	        		return true;
//	            }
//	            if (10 <= x && 150 >= x && 195 <= y && 240 >= y)
//	            {
//	    			mPoolManger.playTouchSe();
//	    			SystemClock.sleep(1000);
//	            	
//	            	Intent i = new Intent();
//					i.setAction("tjmedia.intent.ACTION_EXPLORER");			
//					startActivityForResult(i,RESULT_FIRST_USER);	            	
//	            }	            
	            break;
        }
        
		super.onTouchEvent(ev); 
		return false;		
	}
	String mUri = null;	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
         
		if (resultCode == RESULT_FIRST_USER) {
			String uri = data.getStringExtra("flag");			
			
			if (!RegexManager.isTspFWFormatInfo(uri)) {
				ToastManager.showToast(getApplicationContext(), "The Tsp FWUdpate File is not supported", Toast.LENGTH_SHORT);
        		return;
			}			
			mUri = uri;
			ToastManager.showToast(this, "TSP F/W Update, waitting ..", Toast.LENGTH_LONG);		
			LoopHandler a = new LoopHandler();
			mTspOK = false;	
			mReboot = 0;
			a.sleep(1000);
			a.start();			
			mThread = new TspThread();
			mThread.start();				
		}
	}
	boolean mTspOK = false;
	TspThread mThread = null;
	Toast mToast;
	class TspThread extends Thread {
    	public boolean FLAG_WifiUpdate = true;
		@Override
		public void run() {
			// TODO Auto-generated method stub
			synchronized (this) {
				mTspOK = false;				
			}
			//TDMKMisc_Service.SYSTEM_Run("/vendor/data/tdmk_touchtool "+mUri);	
			Log.d(TAG,"TSP F/W Update, Start!!!!");
			//TDMKMisc_Service.SYSTEM_TSP_FirmwareUpgrade(mUri);		
			//TDMKMisc_Service.SYSTEM_Run("/vendor/data/tdmk_touchtool "+mUri);
			//TDMKMisc_Service.TouchScreenCalibration();
			Log.d(TAG,"TSP F/W Update, Stop!!!!");
			synchronized (this) {
				mTspOK = true;				
			}
		}
	};
	
	int mReboot = 0;

	private boolean loop()
	{
		if (mTspOK)
		{						
			mPoolManger.playTouchSe();							
			if (mReboot++ < 3) 
			{				
				if (false == ToastManager.ToastState)
				{
					ToastManager.showToast(this, "TSP F/W Update, Complete ,Wait Power Reboot!!!!!", Toast.LENGTH_LONG);					
					Log.d(TAG,"TSP F/W Update, Complete ,Wait Power Reboot!!!!!");
				}
				return true;
			}			
			//Log.d(TAG,"TSP F/W Update, Complete ,Reboot!!!!");
			//TDMKMisc_Service.POWER_Reboot(TDMKMisc_Service.POWER__REBOOT_WITHOUT_VIEW);
			return false;
		}
		else
		{
			if (false == ToastManager.ToastState)
				ToastManager.showToast(this, "wait ..(Don't Turn Off the power)", Toast.LENGTH_SHORT);				
			mPoolManger.playTouchSe();
			return true;
		}
	}
		
	
	public class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				synchronized (this) {					
					if(loop())
					{
						sleep(1000);
					}
					else
					{
						stop();
						mThread.stop();
					}
				}
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		public void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;						
			loop();	
		}
	};
	
	public boolean onKeyDown(int KeyCode, KeyEvent event) {
		Log.d(TAG, "onKeyDown()");
		Log.d(TAG, "KeyCode = " + KeyCode);
		if (event.getAction() == KeyEvent.ACTION_DOWN) {
			switch (KeyCode) {
			case KeyEvent.KEYCODE_CLEAR:
				ToastManager.showToast(this, "KEYCODE_CLEAR(MENU) Event", Toast.LENGTH_SHORT);
				if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TOUCH);
				return true;
			case KeyEvent.KEYCODE_SOFT_LEFT:								
				if (!mTspCal)
				{
					mTspCal = true;
//					if (strManufacturer.equalsIgnoreCase("tjmedia"))
					if (Log.getTJ())
					{
//						TDMKMisc_Service.TouchScreenCalibration();
						if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TOUCH);
						SystemClock.sleep(1000);
						ToastManager.showToast(this, "KEYCODE_SOFT_LEFT(HOME) & Calibration Event, waitting ..", Toast.LENGTH_LONG);
					}
				}
				return true;
			case KeyEvent.KEYCODE_BACK:
				ToastManager.showToast(this, "KEYCODE_BACK(BACK) Event", Toast.LENGTH_SHORT);
				if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TOUCH);
				finish();
				return true;
			case KeyEvent.KEYCODE_SOFT_RIGHT:
				ToastManager.showToast(this, "KEYCODE_SOFT_RIGHT(COMPOSE) Event", Toast.LENGTH_SHORT);
				if(mPoolManger != null) mPoolManger.play(SoundPoolManager.SE_TOUCH);
				return true;
			}
		}
		super.onKeyDown(KeyCode, event);
		return false;
	}
	
	private void initObjInfo() {
	}
	
	void initViewID() {
		RelativeLayout rl = (RelativeLayout)findViewById(R.id.TAP_RL_Index01);
		rl.setVisibility(View.GONE);
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		if(mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}			
	}
	
	FrameLayout mSurfaceLL;
	TouchExampleView view;
	public static boolean mTspCal = false;
	void initTouchView() {
		mSurfaceLL = (FrameLayout) findViewById(R.id.Touch_FL_Index01);
		TouchExampleView view = new TouchExampleView(this);
        view.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
//        setContentView(view);
		mSurfaceLL.addView(view);
	}
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			default:
				break;
				
			}
		}
	};
    
}
	
	

