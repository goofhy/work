package com.tjmedia.android.tjdebugger.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

public class TJJni {
	public static final String TAG = "TJJni";
//    static 
//    {
//		try
//		{
//			System.loadLibrary("tm10");			
//		}
//		catch (UnsatisfiedLinkError e)
//		{
//			System.err.println("libtm10.so : library load failed.");
//		}   	    	
//    }         
//    public static native int TJJNI_SYSTEM_Run(String strTime);
//    public static native int TJJNI_Test(int x,int y);	 
//    public static native String TJJNI_GetProperty(String strcmd);        
//    
    public static String TJJNI_GetProperty(String string) throws IOException
	{
		String a =System.getProperty(string);
		Log.d(TAG,"System.getProperty : " + string + " =>" + a);
		TDMKMisc_Service.SYSTEM_Run("getprop " + string + " > /dev/tempprop");
		
		File filename = new File("/dev/tempprop");
		FileReader fr;
		String temp = null;
		
		if (!filename.canRead())
		{
			return temp == null?"unknow":temp;			
		}
		try {
			fr = new FileReader(filename);
			BufferedReader br = new BufferedReader(fr);
			StringBuffer sb = new StringBuffer();				
            while ((temp=br.readLine()) != null) {
            	sb.append(temp);   
            	break;
            }
            br.close();
            fr.close();		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return temp == null?"unknow":temp;
	}	    
}
