package com.tjmedia.android.tjdebugger.common;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;


public class ToastManager {
	
	public static boolean ToastState;
	public static final int TOAST_DELAYTIME = 3000;
	
	public static void showToast(Context context, CharSequence msg, int time) {
		if (ToastManager.ToastState == true) {
			return;
		}
		ToastState = true;
		//
		if(Toast.LENGTH_LONG == time) {
			Toast.makeText(context, msg, Toast.LENGTH_LONG).show();
		} else {
			Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
		}
		mReleaseToast.sendEmptyMessageDelayed(0,
				ToastManager.TOAST_DELAYTIME);
	}
	
	static Handler mReleaseToast = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			ToastState = false;
		}
	};
}
