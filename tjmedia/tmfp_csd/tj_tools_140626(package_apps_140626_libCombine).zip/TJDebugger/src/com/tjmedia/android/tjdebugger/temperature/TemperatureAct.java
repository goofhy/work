package com.tjmedia.android.tjdebugger.temperature;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc :
 * 
 * @Company : TJMedia. Inc
 * @Author : Jimmy
 * @Date :
 * @History :
 * @MenuTree
 * 
 * 
 */

public class TemperatureAct extends Activity {

	private static final String TAG = "TemperatureAct";
	String strManufacturer = android.os.Build.MANUFACTURER;	

	Button mTitleExit;
	SoundPoolManager mPoolManger;
	
	public TemperatureAct() {
	}
	
	public TemperatureAct(Context context) {
		mSensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
		mSensorList = mSensorManager.getSensorList(Sensor.TYPE_TEMPERATURE);

		if (mSensorList.size() > 0) {
			mSensorTemp = mSensorList.get(0);
			Log.d(TAG, "mSensorTemp:" + mSensorTemp.getName() + ", "
					+ mSensorTemp.getVersion() + ", " + mSensorTemp.getVendor()
					+ ", " + mSensorList.get(0) + ", obj:" + mSensorTemp);
		}
	}
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.temperature_main);

		// initObjInfo();
		initViewID();

	}

	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
		registerSensor();
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
		unRegisterSensor();
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
		mLoopHandler.stop();
	}
	
	@Override
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if (Const.DEBUG)
			finish();
	}

	void initObjInfo() {
//		if (strManufacturer.equalsIgnoreCase("tjmedia"))
		if (Log.getCSD())
		{
//			TDMKMisc_Service.Initalize();
//			TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__HOME_KEY, 1);
//			TDMKMisc_Service.Finalize();
		}
	}

	SensorManager mSensorManager;
	private List<Sensor> mSensorList;
	private Sensor mSensorTemp;
	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button) findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);

		mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		mSensorList = mSensorManager.getSensorList(Sensor.TYPE_TEMPERATURE);

		if (mSensorList.size() > 0) {
			mSensorTemp = mSensorList.get(0);
			Log.e(TAG, "mSensorTemp:" + mSensorTemp.getName() + ", "
					+ mSensorTemp.getVersion() + ", " + mSensorTemp.getVendor()
					+ ", " + mSensorList.get(0) + ", obj:" + mSensorTemp);
		}
		Temperature.mComponet01 = (ListView) findViewById(R.id.Temperature_main_temp_ListView);
		Temperature.mComponet02 = (Button) findViewById(R.id.Temperature_main_temp_index02);
//		Temperature.mComponet03 = (EditText) findViewById(R.id.Temperature_main_temp_index03);
		Temperature.mComponet10 = (RadioButton) findViewById(R.id.Camera_main_dialog_Index_RG01);
		Temperature.mComponet11 = (RadioButton) findViewById(R.id.Camera_main_dialog_Index_RG02);
		Temperature.mComponet10.setChecked(true);
		
		Temperature.mComponet04 = (Button) findViewById(R.id.Temperature_main_temp_index04);
		Temperature.mComponet05 = (Button) findViewById(R.id.Temperature_main_temp_index05);
		Temperature.mComponet02.setOnClickListener(mClickListener);
		Temperature.mComponet04.setOnClickListener(mClickListener);
		Temperature.mComponet05.setOnClickListener(mClickListener);
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		Temperature.mComponet01.setAdapter(mAdapter);
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}		
	}

	private View.OnClickListener mClickListener = new View.OnClickListener() {
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			case R.id.Temperature_main_temp_index02:
				if (mTemperature != null) {
					mItem.add(0, "TemperatureSensor[" + mTempIndex + "] : "
							+ String.format("%.1f", mTemperature[0]) + " ℃");
//					mItem.add(0, "TemperatureSensor[" + mTempIndex + "] : "
//							+ String.format("%.1f", mTemperature[0]) + ", "
//							+ String.format("%.1f", mTemperature[1]) + ", "
//							+ String.format("%.1f", mTemperature[2]) + "\n");
					mAdapter.notifyDataSetChanged();
					mTempIndex++;
				}
				break;
			case R.id.Temperature_main_temp_index04:
				if(Temperature.mComponet10.isChecked()) {
					Frequency = 500;
				} else {
					Frequency = 1000;
				}
				ToastManager.showToast(getApplicationContext(), "Aging Start", Toast.LENGTH_SHORT);
				mLoopHandler.start();				
				break;
			case R.id.Temperature_main_temp_index05:
				ToastManager.showToast(getApplicationContext(), "Aging Stop", Toast.LENGTH_SHORT);
				mLoopHandler.stop();
				break;
			default:
				break;

			}
		}
	};
	
	public int Frequency = 1000;
	private LoopHandler mLoopHandler = new LoopHandler();
	public void loop() {
		mItem.add(0, "TemperatureSensor[" + mTempIndex + "] : "
				+ String.format("%.1f", mTemperature[0]) + " ℃");
		mAdapter.notifyDataSetChanged();
		mTempIndex++;
		mLoopHandler.sleep(Frequency);
	}
	
	class LoopHandler extends Handler {
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			loop();
		}
	};
	

	public void registerSensor() {
		if (mSensorManager != null) {
			mSensorManager.registerListener(mTemperatureListener, mSensorTemp,
					SensorManager.SENSOR_DELAY_GAME);
		}
	}

	public void unRegisterSensor() {
		if (mSensorManager != null) {
			mSensorManager.unregisterListener(mTemperatureListener);
			mSensorManager = null;
		}
	}
	
	public String readTemperature() {
		String str = "";
		str = String.format("%.0f", mTemperature[0]) + " ℃";
//		str = "TemperatureSensor[" + mTempIndex + "] : "
//				+ String.format("%.2f", mTemperature[0]) + " ℃";
		Log.d(TAG,"temperature : " + str);
		mTempIndex++;		
		return str;
	}

	public static float[] mTemperature = new float[3];
	long mTempIndex = 0L;
	SensorEventListener mTemperatureListener = new SensorEventListener() {
		public void onSensorChanged(SensorEvent event) {
			// TODO Auto-generated method stub
			switch (event.sensor.getType()) {
			case Sensor.TYPE_TEMPERATURE:
				mTemperature = event.values;
				if (mTemperature != null) {
//					Log.i(TAG,
//							"TemperatureSensor: "
//									+ String.format("%.1f", mTemperature[0])
//									+ ", "
//									+ String.format("%.1f", mTemperature[1])
//									+ ", "
//									+ String.format("%.1f", mTemperature[2]));
				}
				break;
			}

		}

		public void onAccuracyChanged(Sensor sensor, int accuracy) {
			// TODO Auto-generated method stub

		}
	};
	
	static class Temperature {
		// private static LogTextBox mComponet01;
		private static ListView mComponet01;
		private static Button mComponet02;
//		private static EditText mComponet03;
		private static Button mComponet04;
		private static Button mComponet05;
		
		
		private static RadioButton mComponet10;
		private static RadioButton mComponet11;
		
		
	}

}
