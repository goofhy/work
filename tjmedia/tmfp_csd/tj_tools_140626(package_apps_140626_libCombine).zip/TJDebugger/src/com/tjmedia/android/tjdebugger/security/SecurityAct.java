package com.tjmedia.android.tjdebugger.security;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class SecurityAct extends Activity {   
   
	private static final String TAG = "SecurityAct"; 	

	SoundPoolManager mPoolManger;
	Button mTitleExit;
	byte[]	pOldSecureCoreBuffer = new byte[nSecureCoreTest];
	
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.security_main);    
 
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		Log.d(TAG, "recovery security()");
//		TDMKMisc_Service.SECURECORE_WriteData(16, nSecureCoreTest, pOldSecureCoreBuffer);
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {		
//		TDMKMisc_Service.SECURECORE_ReadData(16, nSecureCoreTest, pOldSecureCoreBuffer);
	}
	
	
	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		Security.mComponetListView = (ListView) findViewById(R.id.Security_main_ListView);
		Security.mComponet01 = (TextView) findViewById(R.id.Security_main_index01);
		
		Security.mComponet02 = (Button)  findViewById(R.id.Security_main_index02);
		Security.mComponet03 = (Button)  findViewById(R.id.Security_main_index03);
		Security.mComponet04 = (Button)  findViewById(R.id.Security_main_index04);
		Security.mComponet02.setOnClickListener(mClickListener);
		Security.mComponet03.setOnClickListener(mClickListener);
		Security.mComponet04.setOnClickListener(mClickListener);
		
		Security.mComponet90 = (RadioButton) findViewById(R.id.Security_main_dialog_Index_RG01);
		Security.mComponet91 = (RadioButton) findViewById(R.id.Security_main_dialog_Index_RG02);
		Security.mComponet98 = (Button)  findViewById(R.id.Security_main_index98);
		Security.mComponet99 = (Button)  findViewById(R.id.Security_main_index99);
		Security.mComponet98.setOnClickListener(mClickListener);
		Security.mComponet99.setOnClickListener(mClickListener);
		
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		Security.mComponetListView.setAdapter(mAdapter);
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}		
				
	}
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			case R.id.Security_main_index02:
				setSecurityEvent(0);
				break;
			case R.id.Security_main_index03:
				setSecurityEvent(1);
				break;
			case R.id.Security_main_index04:
				setSecurityEvent(2);
				break;
			default:
				break;
				
			}
		}
	};
	
	private static final int		nSecureCoreTest=4;	
	byte[]	pSecureCoreBufferW = new byte[nSecureCoreTest];
	byte[]	pSecureCoreBufferR = new byte[nSecureCoreTest];
	byte data = 0;
	
	private void setSecurityEvent(int key) {
		switch (key) {
			case 0:
				// read
//				TDMKMisc_Service.SECURECORE_ReadData(16, nSecureCoreTest, pSecureCoreBufferR);
				updateList(key, String.format("%02Xh %02Xh %02Xh %02Xh", 
						pSecureCoreBufferR[0], pSecureCoreBufferR[1], pSecureCoreBufferR[2], pSecureCoreBufferR[3]));
				break;
			case 1:
				// read, and then write
				
				pSecureCoreBufferW[0]=data;
				pSecureCoreBufferW[1]=data;
				pSecureCoreBufferW[2]=data;
				pSecureCoreBufferW[3]=data;
				data++;
				int j = 0;
				boolean ok = true;
				for (j = 0; j < 5; j++)
				{
//					TDMKMisc_Service.SECURECORE_WriteData(16, nSecureCoreTest, pSecureCoreBufferW);
//					SystemClock.sleep(500);
//					TDMKMisc_Service.SECURECORE_ReadData(16, nSecureCoreTest, pSecureCoreBufferR);
					
					for (int i = 0 ; i < nSecureCoreTest; i++)
					{
						if (pSecureCoreBufferW[i] != pSecureCoreBufferR[i])
						{
//							updateList(key, String.format("NG :%02Xh %02Xh %02Xh %02Xh", 
//									pSecureCoreBufferW[0], pSecureCoreBufferW[1], pSecureCoreBufferW[2], pSecureCoreBufferW[3]));
//							
							ok = false;
						}
												
					}
					if (ok)
					{
						updateList(key, String.format("OK :%02Xh %02Xh %02Xh %02Xh", 
								pSecureCoreBufferR[0], pSecureCoreBufferR[1], pSecureCoreBufferR[2], pSecureCoreBufferR[3]));
						return;
					}
					else
					{
						ok = true;
					}
				}
				updateList(key, String.format("NG :%02Xh %02Xh %02Xh %02Xh", 
						pSecureCoreBufferW[0], pSecureCoreBufferW[1], pSecureCoreBufferW[2], pSecureCoreBufferW[3]));						
				
				
				break;
			case 2:
//				int result = TDMKMisc_Service.SECURECORE_GetTotalSize();
//				updateList(key, result);
				break;
		}
	};
	
	private long mListIndex = 0;
	private void updateList(int index) {
		mItem.add(0, "INDEX[" + mListIndex + "] : "
				+ Const.I_BACKLIGHT_PERCENT[index]  + "\n");
		mAdapter.notifyDataSetChanged();
		mListIndex++;
	}
	
	private void updateList(int index, String str) {
		mItem.add(0, "INDEX[" + mListIndex + "] : "
				+ Const.I_SECURITY_INDEX[index] + " : " + str  + "\n");
		mAdapter.notifyDataSetChanged();
		mListIndex++;
	}
	
	private void updateList(int index, int var) {
		mItem.add(0, "INDEX[" + mListIndex + "] : "
				+ Const.I_SECURITY_INDEX[index] + " : " + var   + " Kbyte"+ "\n");
		mAdapter.notifyDataSetChanged();
		mListIndex++;
	}
	
	static class Security {
		private static ListView 		mComponetListView;
		private static TextView		mComponet01;		// Button display Viewer
//		private static Button[] 		mComponets = new Button[11];		// start 0 btn
		
		private static Button 			mComponet02;		// Data Read
		private static Button 			mComponet03;		// Data Write
		private static Button 			mComponet04;		// Security Version Read
		
		private static RadioButton 	mComponet90;
		private static RadioButton 	mComponet91;
		private static Button 			mComponet98;		// Aging Start
		private static Button 			mComponet99;		// Aging Stop
	}
}
	
	

