package com.tjmedia.android.tjdebugger.activity;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJPackageManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : jimmy
 * @Date    : 2012. 2. 27. 
 * @History : TJMedia Menu Tree
 * 
 * com.tjmedia.android.tjdebugger.package
 *  1)		WIFI : scan, proxy, 속도측정, 인터넷, parsing, Setting,
 *  2)		Camera : 
 *  3)		Sensor : G-Sensor
 *  4)		Temperature : 
 * 	 5)		Remocon : Remote Control 
 *  6)		LED : 
 *  7)		Backlight : 
 *  8)		AudioNMic : 
 *  9)		TOUCH : 
 *  10)	Media : 
 *  11)	Security :  Security Chip
 *  12)	Power : 
 *  13)	Reboot : Reboot, sleep
 *  14)	IO : I/O Performance
 *  15)	Bluetooth : 
 *  16)	NFC
 *  17)	Battery
 *  18)	Inand : Inand info
 *  19)	Version : version info
 *  20)	Storage : Storage Test
 *  
 *
 */
//import android.os.AsyncTask;
//import android.os.AsyncTask;
//import android.os.SystemProperties;

public class TJDevelopMode extends Activity {
	private final String TAG = "TJDevelopMode";
    /** Called when the activity is first created. */
	ListView mTJMainListView;
	ArrayAdapter<String> mAdapter;
	SoundPoolManager mPoolManger;
	
	String strManufacturer = android.os.Build.MANUFACTURER;	
	String strProduct = android.os.Build.HARDWARE;
	String lastaction = "";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate()!!!");
        setContentView(R.layout.tj_developmode);
        initObjInfo();
        initViewInfo();
  
        
//        if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
        if (Log.getTJ())
        {
//			TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__STOP_KEY, 1);
//			TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__REMOTE_KEY, 1);
        }
    }
    
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();		
		lastaction = "";
//		initViewInfo();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {		
		Log.d(TAG, "onPause()");
		super.onPause();
	}

	protected void onStop() {		
		if (!lastaction.equals(""))
		{
//			callActivity(lastaction);
		}
		Log.d(TAG, "onStop()");
		super.onStop();
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}
	
	private void initObjInfo() {
	}
	
	Button mTitleExit;
	private void initViewInfo() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		DevelopMode.mComponent00 = (TextView) findViewById(R.id.TJ_DevelopMode_Index00);
		DevelopMode.mComponents[0] = (Button) findViewById(R.id.TJ_DevelopMode_Index01);
		DevelopMode.mComponents[1] = (Button) findViewById(R.id.TJ_DevelopMode_Index02);
		DevelopMode.mComponents[2] = (Button) findViewById(R.id.TJ_DevelopMode_Index03);
		DevelopMode.mComponents[3] = (Button) findViewById(R.id.TJ_DevelopMode_Index04);
		DevelopMode.mComponents[4] = (Button) findViewById(R.id.TJ_DevelopMode_Index05);
		DevelopMode.mComponents[5] = (Button) findViewById(R.id.TJ_DevelopMode_Index06);
		DevelopMode.mComponents[6] = (Button) findViewById(R.id.TJ_DevelopMode_Index07);
		DevelopMode.mComponents[7] = (Button) findViewById(R.id.TJ_DevelopMode_Index08);
		DevelopMode.mComponents[8] = (Button) findViewById(R.id.TJ_DevelopMode_Index09);
		DevelopMode.mComponents[9] = (Button) findViewById(R.id.TJ_DevelopMode_Index10);
		
		DevelopMode.mComponents[10]= (Button) findViewById(R.id.TJ_DevelopMode_Index11);
		DevelopMode.mComponents[11] = (Button) findViewById(R.id.TJ_DevelopMode_Index12);
		DevelopMode.mComponents[12] = (Button) findViewById(R.id.TJ_DevelopMode_Index13);
		DevelopMode.mComponents[13] = (Button) findViewById(R.id.TJ_DevelopMode_Index14);
		DevelopMode.mComponents[14] = (Button) findViewById(R.id.TJ_DevelopMode_Index15);
		DevelopMode.mComponents[15] = (Button) findViewById(R.id.TJ_DevelopMode_Index16);
		DevelopMode.mComponents[16] = (Button) findViewById(R.id.TJ_DevelopMode_Index17);
		DevelopMode.mComponents[17] = (Button) findViewById(R.id.TJ_DevelopMode_Index18);
		DevelopMode.mComponents[18] = (Button) findViewById(R.id.TJ_DevelopMode_Index19);
		DevelopMode.mComponents[19] = (Button) findViewById(R.id.TJ_DevelopMode_Index20);		
		
		for(int i=0; i<DevelopMode.mComponents.length; i++) {
			DevelopMode.mComponents[i].setOnClickListener(mClickListener);
		}
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}
		
		DevelopMode.mComponent00.setText(getResources().getString(R.string.tj_shipmentmode_index31) 
				+ TJPackageManager.updateVersionInfo(getApplicationContext()) + ")");
	}
	
	private boolean GetUSBWifi() {		
		return false;
	}	
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			case R.id.TJ_DevelopMode_Index01:
				callActivity(Const.ACTION_AUDIO);
				break;
			case R.id.TJ_DevelopMode_Index02:
				callActivity(Const.ACTION_BACKLIGHT);
				break;
			case R.id.TJ_DevelopMode_Index03:
				callActivity(Const.ACTION_BATTERY);
				break;
			case R.id.TJ_DevelopMode_Index04:
				if (Log.getCSD() || !Log.getTJ())
				{
					if (!Log.getTmpCSD())					
					callActivity(Const.ACTION_BLUETOOTH);
				}
				break;
			case R.id.TJ_DevelopMode_Index05:
				if (Log.getTMFP() || !Log.getTJ())
				callActivity(Const.ACTION_CAMERA);
				break;
			case R.id.TJ_DevelopMode_Index06:
				if (!Log.getTJ())
				callActivity(Const.ACTION_GSENSOR);
				break;
			case R.id.TJ_DevelopMode_Index07:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
				if (Log.getTJ())
				{					
					callActivity(Const.ACTION_CONSOLE);
				}
				break;
			case R.id.TJ_DevelopMode_Index08:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
				if (Log.getTJ())
				{
//					if (!Log.getTmpCSD())
					callActivity(Const.ACTION_LED);
				}
				break;
			case R.id.TJ_DevelopMode_Index09:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
				if (Log.getTMFP())
				{
					//callActivity(Const.ACTION_NFC);
				}
				break;
			case R.id.TJ_DevelopMode_Index10:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
//				if (Log.getTJ())
//				callActivity(Const.ACTION_POWER);
				break;
			case R.id.TJ_DevelopMode_Index11:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
				if (Log.getTJ())
				callActivity(Const.ACTION_REMOCON);
				break;
			case R.id.TJ_DevelopMode_Index12:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
//				if (Log.getTJ())
//				callActivity(Const.ACTION_SECURITY);
				break;
			case R.id.TJ_DevelopMode_Index13:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
				if (Log.getTJ())
				{
//					if (false || !Log.getTmpCSD())
					callActivity(Const.ACTION_SERIAL);
				}
				break;
			case R.id.TJ_DevelopMode_Index14:
//				if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")))
				if (Log.getTJ())
				{
//					if(!Log.getTmpCSD())
//					callActivity(Const.ACTION_STORAGE);
				}
				break;
			case R.id.TJ_DevelopMode_Index15:
				callActivity(Const.ACTION_TEMPERATURE);
				break;
			case R.id.TJ_DevelopMode_Index16:
				callActivity(Const.ACTION_TOUCH);
				break;
			case R.id.TJ_DevelopMode_Index17:
				if (false)
				callActivity(Const.ACTION_VERSION);
				break;
			case R.id.TJ_DevelopMode_Index18:
				callActivity(Const.ACTION_VIDEO);
				break;
			case R.id.TJ_DevelopMode_Index19:
				if(Log.getTmpCSD() && GetUSBWifi())
				callActivity(Const.ACTION_WIFI);
				break;
			case R.id.TJ_DevelopMode_Index20:
//				callActivity(Const.ACTION_PACKAGE);
				break;
				
			default:
				ToastManager.showToast(getApplicationContext(), 
						getResources().getString(R.string.tj_main_index04), Toast.LENGTH_SHORT);
				break;
			}
		}
	};
	
	private void callActivity(String action) {
		try {
			Intent intent = new Intent(action);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			startActivity(intent);
			lastaction = action;
			
//			startActivity(new Intent(action));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	static class DevelopMode {
		
		private static TextView		mComponent00;	// version
		private static Button[]		 	mComponents = new Button[20]; 
		
	}
	
}