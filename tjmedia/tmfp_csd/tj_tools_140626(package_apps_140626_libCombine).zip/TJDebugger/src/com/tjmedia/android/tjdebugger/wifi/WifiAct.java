package com.tjmedia.android.tjdebugger.wifi;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiConfiguration.AuthAlgorithm;
import android.net.wifi.WifiConfiguration.KeyMgmt;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.provider.Settings.SettingNotFoundException;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.R.color;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJJni;
import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * WIFI Scanner
 *  
 * 
 */
public class WifiAct extends Activity implements OnClickListener {

    static final int SECURITY_NONE = 0;
    static final int SECURITY_WEP = 1;
    static final int SECURITY_PSK = 2;
    static final int SECURITY_EAP = 3;
    static PowerManager pm = null;
    static PowerManager.WakeLock wl = null;
	private static final String TAG = "WIFIScanner";
	private EditText mPassword = null;
	private EditText mStaticIP = null;
	private EditText mStaticSubnet = null;
	
	private EditText mProxy1 = null;
	private EditText mProxy2 = null;
	private EditText mProxy3 = null;
	
	private EditText mStaticGateway = null;	
	private EditText mStaticDNS1 = null;
	private EditText mStaticDNS2 = null;	
	private int	nProxyMode=0;
	private WebView  mWebView = null;
	private	AlertDialog ad = null;
	String proxycmd = null; 
	// WifiManager variable
	public WifiManager wifimanager;	
	public NotificationManager mNotiMgr;
	public ScanResult mSelecResult;
	SoundPoolManager mPoolManger;
	Button mTitleExit;

	// UI variable
	//TextView textStatus;
	TextView textWifiMac;
	ListView listAplist;
	Button btnScanStart;
	Button btnScanStop;
	Button btnWifiOn;
	Button btnWifiOff;
	Button btnWifiInternet;
	Button btnAndriodSettings;		
	Button btnShowConfig;
	Button btnSetPorxy;
	Button btnSetStaticIP;
	Button btnAgingStart;
	Button btnAgingStop;
	Button btnDbg;
	Toast mToast;
	private int scanCount = 0;
	int gLastIP = 0;
	
	
	String text = "";
	String result = "";

	private List<ScanResult> mScanResult; // ScanResult List
	
	long gnStartTime = 0;
	long gnStopTime = 0;
	int gnStartFlag = -1;
	boolean gnScanFlag = false;
	boolean gnWifiPowerFlag = false;
	String strManufacturer = android.os.Build.MANUFACTURER;	

	public void StarTime()
	{
		if (-1 == gnStartFlag)
			gnStartTime = System.currentTimeMillis();
	}
	
	public void StopTime()
	{
		if (-1 != gnStartFlag)
		{
			gnStopTime = System.currentTimeMillis();
			gnStartFlag = -1;
		}
	}

	public long GetTime(String strTitle)
	{
		if (-1 == gnStartFlag)
		{			
			gnStopTime = System.currentTimeMillis();
			Log.d("======TIME=====",strTitle + ":["+ (gnStopTime - gnStartTime) + "]msec");
		}
		return gnStopTime - gnStartTime;
	}
	
	public void initWIFIScan() {
		// init WIFISCAN
		scanCount = 0;
		text = "";
		final IntentFilter filter = new IntentFilter(
				WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
		filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
		registerReceiver(mReceiver, filter);
		printToast("WIFI SCAN Start");
		StarTime();
		wifimanager.startScan();
		gnScanFlag = true;
		Log.d(TAG, "initWIFIScan()");
	}

	private BroadcastReceiver mReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			final String action = intent.getAction();
			if (action.equals(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)) {
				StopTime();				
				long time = GetTime("WIFI SCAN");		
				printToast("WIFI SCAN TIME: [" + time + "]msec");
				getWIFIScanResult(); // get WIFISCanResult		
				//wifimanager.startScan(); // for refresh
				if (gnScanFlag)	
				{					
					unregisterReceiver(mReceiver); // stop WIFISCan
					Log.d("SCAN", " STOP");
					gnScanFlag = false;
				}
			} else if (action.equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
				sendBroadcast(new Intent("wifi.ON_NETWORK_STATE_CHANGED"));
			}
		}
	};
	
	public void getWIFIScanResult() {

		mScanResult = wifimanager.getScanResults(); // ScanResult
		// Scan count
		
		/*
		textStatus.setText("Scan count is \t" +scanCount + " times \n");
		textStatus.append("=======================================\n");
		
		for (int i = 0; i < mScanResult.size(); i++) {
			ScanResult result = mScanResult.get(i);
			textStatus.append("\n"  + (i + 1) + ". SSID : " + result.SSID.toString()
					+ "\t\t\t\t RSSI : " + result.level + " dBm" + "\t\t\t\t frequency:" + result.frequency);
			Log.d("RSSI",". SSID : " + result.SSID.toString()
					+ "\t\t\t\t RSSI : " + result.level + " dBm"+ "\t\t frequency:" + result.frequency );

			
		}
		textStatus.append("\n=======================================\n");
		*/
		ArrayList<String> result = new ArrayList<String>();
		for (int i = 0; i < mScanResult.size(); i++) 
		{
			String szTmp;
			ScanResult tmpresult = mScanResult.get(i);		
			result.add((i + 1) + ". SSID : [" + tmpresult.SSID.toString()
					+ "] RSSI : [" + tmpresult.level 
					+ "dBm] " + " frequency: [" 
					+ tmpresult.frequency + "] certification: [" + getStrSecurity(tmpresult) + "]");			
		}
		listAplist.setAdapter
        ((ListAdapter) new ArrayAdapter<String> (this, android.R.layout.simple_list_item_1, result));
		
	}	
		
	@Override
	public void onDestroy()
	{
		super.onDestroy();		
		Log.d(TAG,"onDestory()");
		mLoopHandler.stop();
		if (null != wl)
		{
			wl.release();
		}
		if (gnScanFlag && null != mReceiver)
		{
			unregisterReceiver(mReceiver); // stop WIFISCan
		}
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.wifi_main);
		
		//Early Suspend(not used) : WakeupLock
		pm = (PowerManager)getSystemService(Context.POWER_SERVICE);
		
		wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "WIFI Test");
		wl.acquire();
		//wl.release();
				
		
		// Setup UI
		//textStatus = (TextView) findViewById(R.id.textStatus);
		btnScanStart = (Button) findViewById(R.id.wifi_main_btnScanStart);
		btnScanStop = (Button) findViewById(R.id.wifi_main_btnScanStop);
		btnWifiOn = (Button) findViewById(R.id.wifi_main_btnWifiOn);
		btnWifiOff = (Button) findViewById(R.id.wifi_main_btnWifiOff);
		btnShowConfig = (Button) findViewById(R.id.wifi_main_btnShowConfig);		
		btnWifiInternet = (Button) findViewById(R.id.wifi_main_btnWifiInternet);
		btnAndriodSettings = (Button) findViewById(R.id.wifi_main_btnAndroidSettings);		
		btnSetPorxy = (Button) findViewById(R.id.wifi_main_btnSetProxyServer);
		btnSetStaticIP = (Button) findViewById(R.id.wifi_main_btnSetStaticIP);
		textWifiMac = (TextView) findViewById(R.id.wifi_main_textMacAddress);
		listAplist = (ListView) findViewById(R.id.wifi_main_listView1);		
		
		btnAgingStart = (Button) findViewById(R.id.wifi_main_btnAgingStart);
		btnAgingStop = (Button) findViewById(R.id.wifi_main_btnAgingStop);
		
		btnDbg = (Button) findViewById(R.id.wifi_main_btnDebug);
		
		
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		// Setup OnClickListener
		btnScanStart.setOnClickListener(this);
		btnScanStop.setOnClickListener(this);
		btnWifiOn.setOnClickListener(this);
		btnWifiOff.setOnClickListener(this);
		btnShowConfig.setOnClickListener(this);
		btnWifiInternet.setOnClickListener(this);
		btnAndriodSettings.setOnClickListener(this);		
		btnSetPorxy.setOnClickListener(this);
		btnSetStaticIP.setOnClickListener(this);
		
		btnAgingStart.setOnClickListener(this);
		btnAgingStop.setOnClickListener(this);
		btnDbg.setOnClickListener(this);
		
		// Setup WIFI
		wifimanager = (WifiManager) getSystemService(WIFI_SERVICE);
		mNotiMgr = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		Log.d(TAG, "Setup WIfiManager getSystemService");
		
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}			
		ShowConnectionInfo();
		
		// if WIFIEnabled
		if (wifimanager.isWifiEnabled() == false)
		{
			//wifimanager.setWifiEnabled(true);
		}
				

		listAplist.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View view, int pos,long id) {
				// TODO Auto-generated method stub		
				//								
        		//Get Mac Address
				mPoolManger.playTouchSe();

				if (gnScanFlag)	
				{					
					unregisterReceiver(mReceiver); // stop WIFISCan
					Log.d("SCAN", " STOP");
					gnScanFlag = false;
				}
				mSelecResult = mScanResult.get(pos);															

				ShowInputPasswdMessageBox("input passwd","Select AP:[" 
						+ mSelecResult.SSID + "] Certification:["
						+ getStrSecurity(mSelecResult) + "]", pos);
				ShowConnectionInfo();
			}
			
		});			
	}
	    
	private static String getStrSecurity(ScanResult result) {
        if (result.capabilities.contains("WEP")) {
            return "WEP";
        } else if (result.capabilities.contains("PSK")) {
            return "PSK";
        } else if (result.capabilities.contains("EAP")) {
            return "EAP";
        }
        return "NONE";
    }
	
	private static int getIntSecurity(ScanResult result) {
        if (result.capabilities.contains("WEP")) {
            return SECURITY_WEP;
        } else if (result.capabilities.contains("PSK")) {
            return SECURITY_PSK;
        } else if (result.capabilities.contains("EAP")) {
            return SECURITY_EAP;
        }
        return SECURITY_NONE;
    }
	
    static String convertToQuotedString(String string) {
        return "\"" + string + "\"";
    }
    
	public void printToast(String messageToast) {
		if (null != mToast)
			mToast.cancel();
		mToast = Toast.makeText(this, messageToast, Toast.LENGTH_LONG);
		mToast.setGravity(Gravity.CENTER,0, 0);
		mToast.show();
		
	}

	public boolean SetWIFIPower(boolean on) {
		boolean ret = false;
		gnWifiPowerFlag = true;
		long time = 0;
				
		Log.d(TAG, "=====SetWIFIPower():" + wifimanager.isWifiEnabled() + strManufacturer);		
		//printToast("WIFI Power " + (on?"ON":"OFF") + " Start...");
		StarTime();
		ret = wifimanager.setWifiEnabled(on);
		StopTime();
		time = GetTime("WIFI" + (on?"POWER ON":"POWER OFF"));
		
		if (on && 0 != gLastIP /*&& !strManufacturer.equalsIgnoreCase("tjmedia")*/)
		{	
			Log.d(TAG, "Obtain IP ...");
			
				
			while(true)
			{				
				if (wifimanager.WIFI_STATE_ENABLED  == wifimanager.getWifiState())
				{
					WifiInfo wfinfo = wifimanager.getConnectionInfo();
					int ipAddress = wfinfo.getIpAddress();
					
					String sIp = String.format("%d.%d.%d.%d",
						       (ipAddress & 0xff),
						       (ipAddress >> 8 & 0xff),
						       (ipAddress >> 16 & 0xff),
						       (ipAddress >> 24 & 0xff));				
				
					if (!sIp.equalsIgnoreCase("0.0.0.0") && null != wfinfo.getSSID())
					{
						StopTime();
						time = GetTime("WIFI POWER ON + " + "Obtain Ip");
						printToast("Wireless power is turn on + " + "Obtain IP : Time[" + time + "]msec");
						ShowConnectionInfo();
						gnWifiPowerFlag = false;
						return true;
					}
				}
			}
		}	
		else	if (on)
		{
			while(true)
			{
				if (wifimanager.WIFI_STATE_ENABLED  == wifimanager.getWifiState())
				{
					StopTime();
					time = GetTime("WIFI POWER ON!!!"); 					
					printToast("Wireless power is turn " + (on?"ON":"OFF") + "Time[" + time + "]msec");
					gnWifiPowerFlag = false;		
					return ret;

				}
			}			
		}		
		else	if (!on)
		{
			while(true)
			{
				if (wifimanager.WIFI_STATE_DISABLED  == wifimanager.getWifiState())
				{
					StopTime();
					time = GetTime("WIFI POWER OFF!!!"); 					
					printToast("Wireless power is turn " + (on?"ON":"OFF") + "Time[" + time + "]msec");
					gnWifiPowerFlag = false;		
					return ret;

				}
			}			
		}
		printToast("Wireless power is turn " + (on?"ON":"OFF") + "Time[" + time + "]msec");
		gnWifiPowerFlag = false;		
		return ret;
	}	
	
	public void ShowConnectionInfo()
	{
		if (wifimanager.WIFI_STATE_ENABLED  == wifimanager.getWifiState())
		{
			WifiInfo wfinfo = wifimanager.getConnectionInfo();
			int ipAddress = wfinfo.getIpAddress();
			String sIp = String.format("%d.%d.%d.%d",
				       (ipAddress & 0xff),
				       (ipAddress >> 8 & 0xff),
				       (ipAddress >> 16 & 0xff),
				       (ipAddress >> 24 & 0xff));
			
			textWifiMac.setText("MAC:" + wfinfo.getMacAddress() + 
					" IP:" +  sIp + " SSID:" + wfinfo.getSSID());
		}
		else
		{
			textWifiMac.setText("MAC: " + 
					" IP: " + " SSID: ");			
		}		
	}
	

	
	public void ShowMessageBox(String Title,String Message, String ButtonStr)
	{
		AlertDialog alertDlg = new AlertDialog.Builder(this)
				.setIcon(R.drawable.ic_launcher)
				.setTitle(Title)
				.setMessage(Message)
				.setPositiveButton(ButtonStr,new DialogInterface.OnClickListener() 
				{
					
					@Override
					public void onClick(DialogInterface dialog, int which) 
					{
						// TODO Auto-generated method stub
						mPoolManger.playTouchSe();
						
					}
				})
				.show();				
	}
	
	public void ShowInternet()
	{
		Context mContext = WifiAct.this;	
		
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.wifi_custom_dialog2,(ViewGroup) findViewById(R.id.wifi_custom_dialog2_layout_root2));
        //setContentView(R.layout.custom_dialog);        
        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle("Internet Test http://www.naver.com");
        aDialog.setView(layout);
        //aDialog.setMessage("http://www.naver.com");     
                
        mWebView = (WebView)layout.findViewById(R.id.wifi_custom_dialog2_webView1);
        mWebView.getSettings().setPluginState(PluginState.ON);
        mWebView.getSettings().setPluginsEnabled(true);
        mWebView.getSettings().setJavaScriptEnabled(true); // JavaScript ���
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.getSettings().setSupportZoom(true);
        mWebView.getSettings().setBuiltInZoomControls(true);    
        
        mWebView.setWebViewClient(new WebViewClient());
        mWebView.setWebChromeClient(new ProgressBarWebChromeClient()); 
        
        mWebView.loadUrl("http://www.naver.com");
        aDialog.setPositiveButton("Close", new DialogInterface.OnClickListener() 
        {
        	@Override		
            public void onClick(DialogInterface dialog, int which) 
            {      
        		mPoolManger.playTouchSe();
            }
        });
                
        ad = aDialog.create();        
        ad.show();        
	}
	
  public class ProgressBarWebChromeClient extends WebChromeClient
  {
    	public void onRequestFocus(WebView view){}
    	
    	public boolean onJsAlert(WebView view, String url, String message, JsResult result)
    	{
			return true;
    	}
    	
    	public boolean onJsBeforeUnload(WebView view, String url, String message, JsResult result)
    	{
			return true;
    	}
    	
    	public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result)
    	{
    		return true;
    	}
    	
    	public void onReceivedIcon(WebView view, Bitmap icon)
    	{    	
    	}
    	
    	public void onShowCustomView(View view, int requestedOrientation, WebChromeClient.CustomViewCallback callback)
    	{
    	
    	}

    	public void onShowCustomView(View view, WebChromeClient.CustomViewCallback callback)
    	{
    	
    	}
    	
    	public void onProgressChanged(WebView view, int newProgress)
    	{
    	}
    	
    	public void onReceivedTouchIconUrl (WebView view, String url, boolean precomposed)
    	{
    		
    		/*if (!precomposed)
		{
			mVideoView.setVideoURI(Uri.parse(url));
			mVideoView.requestFocus();
			mVideoView.start();
			
			//mWebview1.loadUrl(url);
		}*/
    	}    
    		    			 	
    	    	
  }
		
	
	public void ShowInputPasswdMessageBox(String Title,String Message,final int pos)
	{
		Context mContext = WifiAct.this;	
		
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.wifi_custom_dialog,(ViewGroup) findViewById(R.id.wifi_custom_dialog_layout_root));
        //setContentView(R.layout.custom_dialog);        
        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle(Title);
        aDialog.setView(layout);
        aDialog.setMessage(Message);        
        mPassword = (EditText)layout.findViewById(R.id.wifi_custom_dialog_Passwd);
        
        aDialog.setPositiveButton("Connection", new DialogInterface.OnClickListener() 
        {
        	@Override		
            public void onClick(DialogInterface dialog, int which) 
            {            		
            	if (SetConnectionWifi(pos, mPassword.getText().toString()))
            	{            	
            		mPoolManger.playTouchSe();
            		ShowConnectionInfo();
            	}
            }
        });
        
        aDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which) 
            {   
        		mPoolManger.playTouchSe();
        		ShowConnectionInfo();
            }
        });        
        
        aDialog.setNeutralButton("Disconnect or Forget", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which) 
            {           		
        		ScanResult result = mScanResult.get(pos);
        		WifiConfiguration wc = new WifiConfiguration();        		
        		if (null != (wc = GetConfig(convertToQuotedString(result.SSID))))
        		{
        			//WifiInfo wfinfo = wifimanager.getConnectionInfo();  	         		
	         		mPoolManger.playTouchSe();
        			if (SetDisConnectionWifi(wc))
        			{
        				ShowConnectionInfo();       				
        			}
        		}
        		else
        		{
        			printToast("unknow ssid:" + result.SSID);
        		}
            }
        });  
        
        ad = aDialog.create();        
        ad.show();        
	}	
	
	
	public void ShowInputProxyMessageBox(String Title,String Message,final int pos)
	{
		
//		Context mContext = WifiAct.this;	
//		
//		LayoutInflater inflater = 
//				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
//        View layout = inflater.inflate
//        		(R.layout.wifi_custom_dialog4,(ViewGroup) findViewById(R.id.wifi_custom_dialog4_layout_root4));
//        //setContentView(R.layout.custom_dialog);        
//                        
//        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
//        aDialog.setTitle(Title);
//        aDialog.setView(layout);                
//        mProxy1 = (EditText)layout.findViewById(R.id.wifi_custom_dialog4_editProxyIP1);
//        mProxy1.setTextSize(15);
//        mProxy1.setText("210.120.87.116,3128,3128");
//
//        mProxy2 = (EditText)layout.findViewById(R.id.wifi_custom_dialog4_editProxyIP2);
//        mProxy2.setTextSize(15);
//        mProxy2.setText("httpport,8888");
//        
//        mProxy3 = (EditText)layout.findViewById(R.id.wifi_custom_dialog4_editProxyIP3);
//        mProxy3.setTextSize(15);
//        mProxy3.setText("httpsport,7777");        
//        
//        aDialog.setPositiveButton("Enable", new DialogInterface.OnClickListener() 
//        {
//        	@Override		
//            public void onClick(DialogInterface dialog, int which) 
//            {            	
//        		mPoolManger.playTouchSe();
//				proxycmd = String.format("Enable Proxy : %s, %s, %s\n", 
//						mProxy1.getText().toString(), mProxy2.getText().toString(), mProxy3.getText().toString());
//				String[]	szaProxyInfo=new String[3];        
//				szaProxyInfo[0]=new String(mProxy1.getText().toString());
//				szaProxyInfo[1]=new String(mProxy2.getText().toString());
//				szaProxyInfo[2]=new String(mProxy3.getText().toString());
//				TDMKMisc_Service.PROXY_Stop();
//				TDMKMisc_Service.PROXY_Start(szaProxyInfo);				
//				
//				nProxyMode = 1;
//				printToast(proxycmd);
//            }
//        });
//        
//        aDialog.setNegativeButton("Disable", new DialogInterface.OnClickListener() 
//        {
//        	@Override
//            public void onClick(DialogInterface dialog, int which) 
//            {
//        		mPoolManger.playTouchSe();
//        		proxycmd = String.format("Disable Proxy");
//        		TDMKMisc_Service.PROXY_Stop();	
//				nProxyMode = 0;
//				printToast(proxycmd);
//            }
//        });        
//                        
//        ad = aDialog.create();        
//        ad.show();  
            
	}		
	
	public void ShowInputStaticIPMessageBox(String Title,String Message,final int pos)
	{
		Context mContext = WifiAct.this;	
		
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.wifi_custom_dialog3,(ViewGroup) findViewById(R.id.wifi_custom_dialog3_layout_root3));
        //setContentView(R.layout.custom_dialog);        
                        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle(Title);
        aDialog.setView(layout);                
        mStaticIP = (EditText)layout.findViewById(R.id.wifi_custom_dialog3_editStaticIP);
        mStaticIP.setTextSize(15);
        mStaticIP.setText(null);
        mStaticSubnet = (EditText)layout.findViewById(R.id.wifi_custom_dialog3_editStaticSubnet);
        mStaticSubnet.setTextSize(15);
        mStaticSubnet.setText(null);
        mStaticGateway = (EditText)layout.findViewById(R.id.wifi_custom_dialog3_editStaticGateway);
        mStaticGateway.setTextSize(15);
        mStaticGateway.setText(null);
        mStaticDNS1 = (EditText)layout.findViewById(R.id.wifi_custom_dialog3_editStaticDNS1);
        mStaticDNS1.setTextSize(15);
        mStaticDNS1.setText(null);
        mStaticDNS2 = (EditText)layout.findViewById(R.id.wifi_custom_dialog3_editStaticDNS2);
        mStaticDNS2.setTextSize(15);
        mStaticDNS2.setText(null);

        try {
			if (1 == Settings.System.getInt(getContentResolver(), Settings.System.WIFI_USE_STATIC_IP))
			{
				mStaticIP.setText(Settings.System.getString(getContentResolver(), Settings.System.WIFI_STATIC_IP));
				mStaticSubnet.setText(Settings.System.getString(getContentResolver(), Settings.System.WIFI_STATIC_NETMASK));
				mStaticGateway.setText(Settings.System.getString(getContentResolver(), Settings.System.WIFI_STATIC_GATEWAY));
				mStaticDNS1.setText(Settings.System.getString(getContentResolver(), Settings.System.WIFI_STATIC_DNS1));
				mStaticDNS2.setText(Settings.System.getString(getContentResolver(), Settings.System.WIFI_STATIC_DNS2));
				
			}
			else
			{
		        int value = Settings.System.getInt(getContentResolver(),
		                Settings.System.WIFI_SLEEP_POLICY);	
		        mStaticDNS2.setText("WIFI_SLEEP_POLICY is " + value);
			}
		} catch (SettingNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        aDialog.setPositiveButton("SAVE", new DialogInterface.OnClickListener() 
        {
        	@Override		
            public void onClick(DialogInterface dialog, int which) 
            {            		
        		if (7 <= mStaticIP.getText().toString().length()
        			&& 7 <= mStaticSubnet.getText().toString().length()
        			&& 7 <= mStaticGateway.getText().toString().length())
        		{
        			mPoolManger.playTouchSe();
	            	Settings.System.putString(getContentResolver(), Settings.System.WIFI_STATIC_IP, mStaticIP.getText().toString());
	            	Settings.System.putString(getContentResolver(), Settings.System.WIFI_STATIC_NETMASK, mStaticSubnet.getText().toString());
	            	Settings.System.putString(getContentResolver(), Settings.System.WIFI_STATIC_GATEWAY, mStaticGateway.getText().toString());
	            	Settings.System.putString(getContentResolver(), Settings.System.WIFI_STATIC_DNS1, mStaticDNS1.getText().toString());
	            	Settings.System.putString(getContentResolver(), Settings.System.WIFI_STATIC_DNS2, mStaticDNS2.getText().toString());            	
	            	Settings.System.putInt(getContentResolver(), Settings.System.WIFI_USE_STATIC_IP, 1);
        		}
        		else
        		{
        			printToast("FAIL: IP,Subnet,Gateway is NULL!!");
            		ShowConnectionInfo();
            		Settings.System.putInt(getContentResolver(), Settings.System.WIFI_USE_STATIC_IP, 0);        			
        		}
            }
        });
        
        aDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which) 
            {   
        		mPoolManger.playTouchSe();
        		ShowConnectionInfo();
        		Settings.System.putInt(getContentResolver(), Settings.System.WIFI_USE_STATIC_IP, 0);
            }
        });        
                        
        ad = aDialog.create();        
        ad.show();        
	}	
		
	
	public void OnPaintWifiStatus(int nStatus)
	{
		String szMessage = null;				
		switch(nStatus)
		{
		case WifiManager.WIFI_STATE_DISABLED:
			szMessage = "Wireless power is turend off";
			break;
		case WifiManager.WIFI_STATE_DISABLING:
			szMessage = "Wireless power is turning off";
			break;
		case WifiManager.WIFI_STATE_ENABLING:
			szMessage = "Wireless power is turning on";
			break;
			
		case WifiManager.WIFI_STATE_ENABLED:
			szMessage = "Wireless power is turned on";
			break;
			
		case WifiManager.WIFI_STATE_UNKNOWN:
			szMessage = "Wireless is unknown";
			break;
		}
		ShowMessageBox("WIFI STATUS",szMessage,"OK");	
	}
	
	public boolean SetDisConnectionWifi(WifiConfiguration wc)
	{
		boolean ret; 
		Log.d("WIFI TEST", "Set Disconnect !!!! =============SSID:" + wc.SSID);
		StarTime();
		
		WifiInfo wfinfo = wifimanager.getConnectionInfo();
		if (convertToQuotedString(wfinfo.getSSID()).equals(wc.SSID))
		{
			ret = wifimanager.disableNetwork(wc.networkId);
		}
		else
		{
			ret = false;
		}
		
		while(ret)
		{				
			WifiInfo wfinfo2 = wifimanager.getConnectionInfo();
			int ipAddress = wfinfo2.getIpAddress();
			String sIp = String.format("%d.%d.%d.%d",
				       (ipAddress & 0xff),
				       (ipAddress >> 8 & 0xff),
				       (ipAddress >> 16 & 0xff),
				       (ipAddress >> 24 & 0xff));				
		
			if (sIp.equalsIgnoreCase("0.0.0.0"))					
			{
				StopTime();
				break;
			}
		}
				
		long time = GetTime("WIFI" + " Set Disconnect !!!! =============SSID:" + wc.SSID);
		wifimanager.removeNetwork(wc.networkId);
		wifimanager.saveConfiguration();
		if (ret) printToast("DisConnect SSID:" + wfinfo.getSSID() + " Time[" + time + "]msec");
		else printToast("Forget SSID:" + wc.SSID + " Time[" + time + "]msec");
		return ret;
	}
	
	public boolean SetConnectionWifi(int pos, String strPassword)
	{
		long time = 0;
		Log.d("WIFI TEST","ConnectionWifi pos:" + pos);
		WifiConfiguration configs = new WifiConfiguration();
		ScanResult result = mScanResult.get(pos);	   
		configs.SSID = convertToQuotedString(result.SSID); 
		configs.status = WifiConfiguration.Status.ENABLED;
				
    	Log.d("WIFI TEST","SSID : " + configs.SSID);
		int capabilities = getIntSecurity(result);   
		Log.d("WIFI TEST","capabilities : " + capabilities);
		switch(capabilities)
		{
			case SECURITY_NONE:
				configs.allowedKeyManagement.set(KeyMgmt.NONE);
				break;
		
			case SECURITY_WEP:
				configs.allowedKeyManagement.set(KeyMgmt.NONE);
                configs.allowedAuthAlgorithms.set(AuthAlgorithm.OPEN);
                configs.allowedAuthAlgorithms.set(AuthAlgorithm.SHARED);
                if (strPassword.length() != 0) {
                    int length = strPassword.length();
                    String password = strPassword;
                    // WEP-40, WEP-104, and 256-bit WEP (WEP-232?)
                    if ((length == 10 || length == 26 || length == 58) &&
                            password.matches("[0-9A-Fa-f]*")) {
                        configs.wepKeys[0] = password;
                    } else {
                        configs.wepKeys[0] = '"' + password + '"';
                    }
                }
                		                
				break;
			case SECURITY_PSK:
                configs.allowedKeyManagement.set(KeyMgmt.WPA_PSK);
                if (strPassword.length() != 0) {
                	String password = strPassword;
                    if (password.matches("[0-9A-Fa-f]{64}")) {
                        configs.preSharedKey = password;
                    } else {
                        configs.preSharedKey = '"' + password + '"';
                    }
                }
				break;
			case SECURITY_EAP:
				break;
				
		}
		//1.before config check.
		int beforenetid = 0;
		if (-1 != (beforenetid = existSSID(configs.SSID)))
		{
			wifimanager.removeNetwork(beforenetid);
		}
		//2.add config		
		int netid = wifimanager.addNetwork(configs);
		configs.networkId = netid;
		
		//3.update config
		wifimanager.updateNetwork(configs);
		
		//4.connection
		boolean retstat = wifimanager.enableNetwork(netid, false);
		
		//5.save config
		wifimanager.saveConfiguration(); //*Warring!!!!!!! Retry Connection 
				
		StarTime();						
		
		
		Log.d(TAG, "Set Connect  Obtain IP ...");	
		
		int nTimeout = 0;
		
		while(true && nTimeout++ < 15)
		{				
			WifiInfo wfinfo = wifimanager.getConnectionInfo();
			int ipAddress = wfinfo.getIpAddress();
			String ssid = wfinfo.getSSID();
			String sIp = String.format("%d.%d.%d.%d",
				       (ipAddress & 0xff),
				       (ipAddress >> 8 & 0xff),
				       (ipAddress >> 16 & 0xff),
				       (ipAddress >> 24 & 0xff));	
			//Log.d("check ip", "ip : " + sIp + " SSDI:" + ssid);
			if (!sIp.equalsIgnoreCase("0.0.0.0") && null != ssid)
			{
				StopTime();				
				time = GetTime("SUCCESS:WIFI" + " Set Connect !!!! =============SSID:" + wfinfo.getSSID());
				retstat = true;
				break;
			}
			SystemClock.sleep(1000);
		}
									
		if (retstat) printToast("Connect SSID:" + configs.SSID+ " Time[" + time + "]msec");		
		return retstat;
	}
	
	private int existSSID(String ssid) {
        for (final WifiConfiguration w : wifimanager.getConfiguredNetworks()) {
            if (w.SSID.equals(ssid))
            {             	
                return w.networkId;
            }
        }
        return -1;
    }	
	
	private WifiConfiguration GetConfig(String ssid) {
        for (final WifiConfiguration w : wifimanager.getConfiguredNetworks()) {
            if (w.SSID.equals(ssid))
            {             	
                return w;
            }
        }
        return null;
    }		
	
	public boolean GetBusyStatus()
	{
		//boolean gnWifiPowerFlag = false;gnStartFlag
		return gnScanFlag||gnWifiPowerFlag;
	}
		
	@Override
	public void onClick(View v) {
		mPoolManger.playTouchSe();
		if (v.getId() == R.id.wifi_main_btnShowConfig) 
		{			
			ShowConnectionInfo();
		}	
		
		if (v.getId() == R.id.wifi_main_btnSetProxyServer) 
		{			
			//Settings.System.putString(getContentResolver(), Settings.System.HTTP_PROXY, "myproxy:8080");			
			//Settings.System.putInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, a);
			Intent intent = new Intent(Intent.ACTION_MAIN);
			intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.ProxySelector"));
			startActivity(intent);				

		}	
		
		if (v.getId() == R.id.wifi_main_btnSetStaticIP)
		{
			ShowInputStaticIPMessageBox("Static IP Settings","Test", 0);	
		}
		
		
		if (v.getId() == R.id.wifi_main_btnAndroidSettings)
		{
		    	startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));    		    	
//		    	Intent intent = new Intent(Intent.ACTION_MAIN);
//				intent.setComponent(new ComponentName("com.android.settings", "com.android.settings.ProxySelector"));
//				startActivity(intent);			    	    
		}
		
		if (v.getId() == R.id.wifi_main_btnScanStop) 
		{			
			int nStatus = wifimanager.getWifiState();
			Log.d(TAG, "OnClick() btnScanStop()  status:" + nStatus);			
			if (wifimanager.WIFI_STATE_ENABLED == nStatus)
			{
				if (gnScanFlag)
				{
					unregisterReceiver(mReceiver); // stop WIFISCan
					GetTime("WIFI SCAN Force Stop!!!");
					printToast("WIFI Scan Force Stop !!!");
					gnScanFlag = false;
				}
				//printToast("WIFI SCAN Stop");
			}
			else
			{	
				OnPaintWifiStatus(nStatus);
			}
			
		}					
	
		if (v.getId() == R.id.wifi_main_btnScanStart) 
		{			
			if (GetBusyStatus())
			{
				printToast("Before Work has not been completed!!!!");
				return;
			}
			int nStatus = wifimanager.getWifiState();
			Log.d(TAG, "OnClick() btnScanStart() status:" + nStatus);				
			if (wifimanager.WIFI_STATE_ENABLED == nStatus)
			{				
				initWIFIScan(); // start WIFIScan
				//printToast("WIFI SCAN Start");
			}
			else
			{	
				OnPaintWifiStatus(nStatus);
			}
		}

		if (v.getId() == R.id.wifi_main_btnWifiOn) 
		{	
			if (GetBusyStatus())
			{
				printToast("Before Work has not been completed!!!!");
				return;
			}
			
			
			int nStatus = wifimanager.getWifiState();
			Log.d(TAG, "OnClick() btnWifiOn()  status:" + nStatus);	
			if (wifimanager.WIFI_STATE_DISABLED == nStatus
					|| wifimanager.WIFI_STATE_UNKNOWN == nStatus)
			{				
				if (SetWIFIPower(true))
				{
					//printToast("Wireless power is turn on");
					//���¹� ȣ��	
					Notification noti = 
							new Notification(R.drawable.ic_launcher,"Wifi Power On",System.currentTimeMillis());
					Intent it = new Intent(Intent.ACTION_WEB_SEARCH);
					PendingIntent pendingIntent =PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT);
					noti.setLatestEventInfo(getApplicationContext(), "WIFI", "ON",pendingIntent);
					noti.flags = Notification.FLAG_AUTO_CANCEL;
					mNotiMgr.notify(0,noti);
				}
				else
				{
					ShowMessageBox("WIFI STATUS","Fail. Wireless power is turn on.","OK");
				}				
			}
			
		}
		
		if (v.getId() == R.id.wifi_main_btnWifiOff) 
		{	
			if (GetBusyStatus())
			{
				printToast("Before Work has not been completed!!!!");
				return;
			}
			
			
			int nStatus = wifimanager.getWifiState();
			Log.d(TAG, "OnClick() btnWifiOff()  status:" + nStatus);
			
			WifiInfo wfinfo = wifimanager.getConnectionInfo();
			
			// Enable �� ip �� �����ϴ��� Ȯ���Ѵ�.
			if (wifimanager.WIFI_STATE_ENABLED == nStatus)
			{
				gLastIP = wfinfo.getIpAddress();	
				
				if (SetWIFIPower(false))
				{
					Notification noti = 
							new Notification(R.drawable.ic_launcher,"Wifi Power Off",System.currentTimeMillis());
					Intent it = new Intent(Intent.ACTION_WEB_SEARCH);
					PendingIntent pendingIntent =PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT);
					noti.setLatestEventInfo(getApplicationContext(), "WIFI", "OFF",pendingIntent);
					noti.flags = Notification.FLAG_AUTO_CANCEL;
					mNotiMgr.notify(0,noti);
					
					ArrayList<String> result = new ArrayList<String>();
					
					listAplist.setAdapter
			        ((ListAdapter) new ArrayAdapter<String> (this, android.R.layout.simple_list_item_1, result));
					
				}
				else
				{
					ShowMessageBox("WIFI STATUS","Fail. Wireless power is turn off.","OK");
				}
				ShowConnectionInfo();
			}		
			
		}
		if (v.getId() == R.id.wifi_main_btnWifiInternet) 
		{			
			if (GetBusyStatus())
			{
				printToast("Before Work has not been completed!!!!");
				return;
			}
			
			ShowInternet();
		}
		
		if (v.getId() == R.id.wifi_main_btnAgingStart)
		{
			if (GetBusyStatus())
			{
				printToast("Before Work has not been completed!!!!");
				return;
			}
			
			
			btnScanStart.setEnabled(false);
			btnScanStop.setEnabled(false);
			btnWifiOn.setEnabled(false);
			btnWifiOff.setEnabled(false);
			btnShowConfig.setEnabled(false);		
			btnWifiInternet.setEnabled(false);
			btnAndriodSettings.setEnabled(false);		
			btnSetPorxy.setEnabled(false);
			btnSetStaticIP.setEnabled(false);		
			btnAgingStart.setEnabled(false);
			btnDbg.setEnabled(false);
			mLoopHandler.stop();
			mLoopHandler.start();
		}
		
		if (v.getId() == R.id.wifi_main_btnAgingStop)
		{
			if (GetBusyStatus())
			{
				printToast("Before Work has not been completed!!!!");
				return;
			}
			
			btnScanStart.setEnabled(true);
			btnScanStop.setEnabled(true);
			btnWifiOn.setEnabled(true);
			btnWifiOff.setEnabled(true);
			btnShowConfig.setEnabled(true);		
			btnWifiInternet.setEnabled(true);
			btnAndriodSettings.setEnabled(true);		
			btnSetPorxy.setEnabled(true);
			btnSetStaticIP.setEnabled(true);		
			btnAgingStart.setEnabled(true);			
			btnDbg.setEnabled(true);
			mLoopHandler.stop();
		}
		
		if (v.getId() == R.id.wifi_main_btnDebug)
		{
			if (GetBusyStatus())
			{
				printToast("Before Work has not been completed!!!!");
				return;
			}
			int status = wifimanager.getWifiState();	
			if (status == WifiManager.WIFI_STATE_ENABLED)
			{
				
				WifiInfo wfinfo = wifimanager.getConnectionInfo();
				
				
				int ipaddr = wfinfo.getIpAddress();
				
				String sIp = String.format("%d.%d.%d.%d",
					       (ipaddr & 0xff),
					       (ipaddr >> 8 & 0xff),
					       (ipaddr >> 16 & 0xff),
					       (ipaddr >> 24 & 0xff));				
			
				if (!sIp.equalsIgnoreCase("0.0.0.0") && null != wfinfo.getSSID())
				{
					if (strManufacturer.equals("tjmedia") || strManufacturer.equals("TJMedia"))
//					if (Log.getTJ())
					{
						printToast("adb connect " + sIp + ":5555");
						
						TDMKMisc_Service.SYSTEM_Run("./system/bin/tdmk_enable_wifi_adb.sh");
					}
					return;
				}
				
				
			}
			printToast("Unknow, IP!!!!!, Please, Wifi Connection");
			
		}
	}		
	
	private int nRetryCount = 0;
	private int nNGCount2 = 0;
	private int nTotalNGCount2 = 0;
	private int nDisableLastCmd = 0;
	private int updateWifiInfo() {
		
		int status = wifimanager.getWifiState();		
		String szInfo = "";
		
		if (10 < mLoopHandler.count)
		{
			if (0 == nDisableLastCmd && status == WifiManager.WIFI_STATE_DISABLED)
			{
				
				nRetryCount++;
				
				if (nRetryCount > 5)
				{
					nRetryCount = 0;
					wifimanager.setWifiEnabled(true);
					Log.e(TAG,"Last Cmd (Wifi is enable) current status(Wifi disable) : Retry");
					return 0;
				}
				Log.e(TAG,"Last Cmd (Wifi is enable) current status(Wifi disable) : SKIP");
				
				return 0;
			}
			if (1 == nDisableLastCmd && status == WifiManager.WIFI_STATE_ENABLED)
			{			
				
				nRetryCount++;
				
				if (nRetryCount > 5)
				{
					nRetryCount = 0;
					wifimanager.setWifiEnabled(false);
					Log.e(TAG,"Last Cmd (Wifi is disable) current status(Wifi enable) : Retry");
					return 0;
				}		
				Log.e(TAG,"Last Cmd (Wifi is disable) current status(Wifi enable) : SKIP");			
				return 0;
			}
		}
		if (status == WifiManager.WIFI_STATE_ENABLED) {						
			//Log.d(TAG,"Wifi is pingSupplicant ==> OK");	
			Log.d(TAG,"Wifi is enable ==> Wifi disable++");
			if (!wifimanager.setWifiEnabled(false))
			{
				nTotalNGCount2++;
				Log.e(TAG,"Wifi is enable ==> Wifi disable : NG");
			}
			else
			{
				nDisableLastCmd = 1;
			}
			nNGCount2 = 0;						
			szInfo = "Wifi is enable ==> Wifi disable";
		} else if (status == WifiManager.WIFI_STATE_DISABLED) {
			Log.d(TAG,"Wifi is disable ==> Wifi Enable++");
			if (!wifimanager.setWifiEnabled(true))
			{
				nTotalNGCount2++;
				Log.e(TAG,"Wifi is disable ==> Wifi Enable : NG");
			}
			else
			{
				nDisableLastCmd = 0;
			}
			nNGCount2 = 0;
			Log.d(TAG,"Wifi is disable ==> Wifi Enable++");
			szInfo = "Wifi is disable ==> Wifi Enable";
		} else if (status == WifiManager.WIFI_STATE_UNKNOWN){
			Log.d(TAG,"Wifi is unknown ==> Wifi Enable++");
			nNGCount2++;
			
			if (nNGCount2 > 5)	nTotalNGCount2++;
			if (!wifimanager.setWifiEnabled(true))
			{							
				Log.e(TAG,"Wifi is unknown ==> Wifi Enable : NG");
			}
			Log.d(TAG,"Wifi is unknown ==> Wifi Enable--");
			szInfo = "Wifi is unknown ==> Wifi Enable";
		}		
		else
		{
			return 0;
		}
		textWifiMac.setText("Aging Count: " + mLoopHandler.count + " Status:" + szInfo + " ,  NG Count:" + nTotalNGCount2);		
		//mPoolManger.playTouchSe();
		return 1;
	}
	
	public int Frequency = 5000;
	private LoopHandler mLoopHandler = new LoopHandler();
	public void loop() {		
		if (1 == updateWifiInfo())			
			mLoopHandler.count++;		
//		if (mLoopHandler.count > 200)
//		{
//			mLoopHandler.removeMessages(0);
//			btnScanStart.setEnabled(true);
//			btnScanStop.setEnabled(true);
//			btnWifiOn.setEnabled(true);
//			btnWifiOff.setEnabled(true);
//			btnShowConfig.setEnabled(true);		
//			btnWifiInternet.setEnabled(true);
//			btnAndriodSettings.setEnabled(true);		
//			btnSetPorxy.setEnabled(true);
//			btnSetStaticIP.setEnabled(true);		
//			btnAgingStart.setEnabled(true);			
//			btnDbg.setEnabled(true);			
//			mLoopHandler.stop();
//			return;
//		}
		mLoopHandler.sleep(Frequency);
	}
	
	class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			nRetryCount = 0;
			nNGCount2 = 0;
			nTotalNGCount2 =0;
			mLoopHandler.count = 0;
			loop();
		}
	};	
	
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			default:
				break;
				
			}
		}
	};
	
	public boolean I_WifiON() {
		if (GetBusyStatus())
		{
			printToast("Before Work has not been completed!!!!");
			return false;
		}
		
		int nStatus = wifimanager.getWifiState();
		Log.d(TAG, "wifiStatus = :" + nStatus);	
		if (wifimanager.WIFI_STATE_DISABLED == nStatus)
		{				
			if (SetWIFIPower(true))
			{
//				Notification noti = 
//						new Notification(R.drawable.ic_launcher,"Wifi Power On",System.currentTimeMillis());
//				Intent it = new Intent(Intent.ACTION_WEB_SEARCH);
//				PendingIntent pendingIntent =PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT);
//				noti.setLatestEventInfo(getApplicationContext(), "WIFI", "ON",pendingIntent);
//				noti.flags = Notification.FLAG_AUTO_CANCEL;
//				mNotiMgr.notify(0,noti);
				return true;
			} else {
				ShowMessageBox("WIFI STATUS","Fail : Wireless power is turn on.", "NG");
				return false;
				
			}				
		}
		return false;
	}
	
	public boolean I_WifiOFF() {
		if (GetBusyStatus())
		{
			printToast("Before Work has not been completed!!!!");
			return false;
		}
		
		int nStatus = wifimanager.getWifiState();
		Log.d(TAG, "OnClick() btnWifiOff()  status:" + nStatus);
		
		WifiInfo wfinfo = wifimanager.getConnectionInfo();
		
		if (wifimanager.WIFI_STATE_ENABLED == nStatus)
		{
			gLastIP = wfinfo.getIpAddress();	
			
			if (SetWIFIPower(false))
			{
				Notification noti = 
						new Notification(R.drawable.ic_launcher,"Wifi Power Off",System.currentTimeMillis());
				Intent it = new Intent(Intent.ACTION_WEB_SEARCH);
				PendingIntent pendingIntent =PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT);
				noti.setLatestEventInfo(getApplicationContext(), "WIFI", "OFF",pendingIntent);
				noti.flags = Notification.FLAG_AUTO_CANCEL;
				mNotiMgr.notify(0,noti);
				return true;
			}
			else
			{
				ShowMessageBox("WIFI STATUS","Fail. Wireless power is turn off.","OK");
				return false;
			}
		}	
		return false;
	}
}