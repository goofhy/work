package com.tjmedia.android.tjdebugger.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import com.tjmedia.android.tjdebugger.common.Log;

public class DBSQL {

	private static final String TAG = "DBSQL"; 
	
	private static final String DATABASE_NAME = "TJDebugger.db";
	private static final int DATABASE_VERSION = 1;
	
	private SQLiteDatabase mDB;
	private DatabaseHelper mDBHelper;
	private Context mCtx;
	
	private class DatabaseHelper extends SQLiteOpenHelper{

		public DatabaseHelper(Context context, String name,	CursorFactory factory, int version) {
			super(context, name, factory, version);
		}

	    /** Called when it is time to create the database */
		public void onCreate(SQLiteDatabase db) {			
	    	String[] sql = {DBConst._CREATE1};
//	    	String[] sql = {DBConst._CREATE1, DBConst._CREATE2};    	
	    	db.beginTransaction();
			try {
				// Create tables & test data		
				execMultipleSQL(db, sql);
				db.setTransactionSuccessful();
			} catch (SQLException e) {
	            Log.e("Error creating tables and debug data", e.toString());
	        } finally {
	        	db.endTransaction();
	        }
		}
		
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.d(TAG, "Upgrading database from version " + oldVersion 
	                 + " to "
	                 + newVersion + ", which will destroy all old data");	 
		}		
		
		/**
		 * Execute all of the SQL statements in the String[] array
		 * @param db The database on which to execute the statements
		 * @param sql An array of SQL statements to execute
		 */
		private void execMultipleSQL(SQLiteDatabase db, String[] sql){  
			for( String s : sql )
				if (s.trim().length() > 0) {
					db.execSQL(s);
					Log.d(TAG, "=============> execMultipleSQL =" + s);
				}
		}
	}

	public DBSQL(Context context){
		this.mCtx = context;
		mDBHelper = new DatabaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	
	
	private DBSQL openRead() throws SQLException{
		try {
			mDB = mDBHelper.getReadableDatabase();
		} catch (SQLiteException ex) {
			ex.printStackTrace();
		}
		return this;
	}
	
	private DBSQL openWrite() throws SQLException{
		try {
			mDB = mDBHelper.getWritableDatabase();
		} catch (SQLiteException ex) {
			ex.printStackTrace();
		}
		return this;
	}
	
	private void close(){
		mDB.close();
	}
	
	
	public long insertDB(String mTable, ContentValues values){
		openWrite();
		long id = 0;
		mDB.beginTransaction();
		try {
			id = mDB.insert(mTable, null, values);
			mDB.setTransactionSuccessful();
		}catch (SQLiteException e) {
			e.fillInStackTrace();
		} finally {
			mDB.endTransaction();
		}
		close();
		return id;
	}
	
	
	public boolean updateDBByID(String mTable, long id, ContentValues values){
		openWrite();
		boolean result = mDB.update(mTable, values, "_ID = " + id, null) > 0;
		close();
		return result;
	}
	
	public boolean updateDBByKey(String mTable, String mKey,  String mValue, ContentValues values){	
		openWrite();
		boolean result = mDB.update(mTable, values, mKey + " = " + mValue, null) > 0;
		close();
		return result;
	}
	
	public boolean updateDBALL(String mTable, ContentValues values, String whereClause, String[] whereArgs){	
		openWrite();
		boolean result = mDB.update(mTable, values, whereClause, whereArgs) > 0;
		close();
		return result;
	}
	
	public boolean deleteDBByID(String mTable, long id){
		openWrite();
		boolean result = mDB.delete(mTable, "_ID = " + id, null) > 0;
		close();
		return result;
	}
		
	public boolean deleteDBByKey(String mTable, String mKey,  String mValue) {
		openWrite();
		String[] mSelectionArgs = new String[1];
		mSelectionArgs[0] = mValue;
		boolean result = mDB.delete(mTable, mKey + " = ?", mSelectionArgs) > 0;
		close();
		return result;
	}
	
	public Cursor getFullTableScan(String mTable, String[] returnColumns, String selection, 
			String[] selectionArgs, String groupBy, String having, String orderBy){
		openRead();
		Cursor cursor = mDB.query(mTable, returnColumns, selection, selectionArgs, groupBy, having, orderBy);
		
		if(cursor!=null && cursor.getCount() != 0) {
			cursor.moveToFirst();
		}
		close();
		return cursor; 
	}
	
	public Cursor getRawQuery(String sql) {
		openRead();
//		String sql ="SELECT distinct iseg_matnr FROM MTB_MM_H001 " +
//				"WHERE ISEG_WERKS = " +
//				 plantkey +" AND iseg_lgort = " + lockey;
		Cursor mCursor = mDB.rawQuery(sql, null);
		if(mCursor!=null && mCursor.getCount() != 0) {
			mCursor.moveToFirst();
		}
		close();
		return mCursor;
	}
	
	/*
	 * *********************************************************************************************************
	 * reference methods
	 * *********************************************************************************************************
	 */
	/***
	 * <pre>
	* @Author Jimmy  
	* @Date 2011. 7. 11. / 오후 2:10:14
	* @param mTable TABLE 이름
	* @param name	조건 필드 배열
	* @param value	조건 필드 해당 값 배열
	* @return
	* </pre>
	 */
//	public boolean deleteBTCDB3KEY(String mTable, String[] name, String[] value) {
//		openWrite();
//		String deleteSql = "";
//		for(int i = 0; i< name.length; i++){
//			if(i != (name.length - 1)){
//				deleteSql = deleteSql + name[i] + " like '%" + value[i] + "%'" + " AND "; 
//			}else{
//				deleteSql = deleteSql + name[i] + " like '%" + value[i] + "%'";
//			}
//		}
//		Log.d(TAG, "deleteSql"+deleteSql);
//		boolean result = mDB.delete(mTable, deleteSql, null) > 0;
//		close();
//		return result;
//	}
//	
//	public boolean deleteTableInfo(String mTable) {
//		openWrite();
//		boolean result = mDB.delete(mTable, null, null) > 0;
//		close();
//		return result;
//	}
//	
//	public boolean deleteTableInfo(String mTable, String whereClause, String[] whereArgs) {
//		openWrite();
//		boolean result = mDB.delete(mTable, whereClause, whereArgs) > 0;
//		close();
//		return result;
//	}
//	
//	
//	public Cursor getDBInfoGroupBy(String mTable, String[] returnColumns, 
//			String selection, String[] selectionArgs, String groupBy){
//		openRead();
//		Cursor cursor = mDB.query(mTable, returnColumns, selection, selectionArgs, groupBy, null, null);
//		if(cursor!=null && cursor.getCount() != 0) {
//			cursor.moveToFirst();
//		}
//		close();
//		return cursor;
//	}
//	
//	public Cursor getDBInfo2Cond(String mTable, String[] columns, String mKey, String mValue){
//		openRead();
//		Cursor cursor = mDB.query(mTable, columns, mKey + "= "+ mValue, null, null, null, null);
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		close();
//		return cursor;
//	}
//	
//	public Cursor getCDInfoAll(String mTable, String[] returnColumns, String selection, 
//			String[] selectionArgs, String groupBy, String having, String orderBy){
//		openRead();
//		Cursor cursor = mDB.query(mTable, returnColumns, selection, selectionArgs, groupBy, having, orderBy);
//		
//		if(cursor!=null && cursor.getCount() != 0) {
//			cursor.moveToFirst();
//		}
//		close();
//		return cursor; 
//	}
//	
//	public Cursor getCDInfoGroupBy(String mTable, String[] columns, String name, String value, String groupBy) {
//		String selection = name + " like '%" + value + "%'";
//		mDB = mDBHelper.getReadableDatabase();
//		Cursor cursor = mDB.query(mTable, columns, selection, null, groupBy, null, null);
//		
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		close();
//		return cursor;
//	}
//	
//	public Cursor getCDInfo3KEY(String mTable, String[] columns, String[] name, String[] value, String orderby) {
//		openRead();
//		String selection = " ";
//		for(int i = 0; i< name.length; i++){
//			if(i != (name.length - 1)){
//				selection = selection + name[i] + " like '%" + value[i] + "%'" + " AND "; 
//			}else{
//				selection = selection + name[i] + " like '%" + value[i] + "%'";
//			}
//		}
//		Log.d(TAG, "selection"+selection);
//		mDB = mDBHelper.getReadableDatabase();
//		
//		Cursor cursor = mDB.query(mTable, columns, selection, null, null, null, orderby);
//		
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		close();
//		return cursor;
//	}	
//	
//	/*내역 플랜트 수*/
//	public Cursor getCDInfo2KEYdistinct() {
//		openRead();
//		String sql ="SELECT distinct  ISEG_WERKS, iseg_lgort FROM MTB_MM_H001";
//		
//		mDB = mDBHelper.getReadableDatabase();
//		Cursor cursor = mDB.rawQuery(sql, null);
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		close();
//		return cursor;
//	}
//	
//	
//	public Cursor getCDInfo2KEYN(String plantkey, String lockey) {
//		openRead();
//		String sql ="SELECT distinct iseg_matnr FROM MTB_MM_H001 " +
//				"WHERE INSP_STAT IN ('N') and ISEG_WERKS = " +
//				plantkey +" AND iseg_lgort = " + lockey;
//		
//		mDB = mDBHelper.getReadableDatabase();
//		Cursor cursor = mDB.rawQuery(sql, null);
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		
//		Log.d(TAG, "getCDInfo2KEYN" + cursor.getCount());
//		close();
//		return cursor;
//	}
//	
//	public Cursor getCDInfo2KEYALL(String plantkey, String lockey) {
//		openRead();
//		String sql ="SELECT distinct iseg_matnr FROM MTB_MM_H001 " +
//				"WHERE ISEG_WERKS = " +
//				 plantkey +" AND iseg_lgort = " + lockey;
//		
//		mDB = mDBHelper.getReadableDatabase();
//		Cursor cursor = mDB.rawQuery(sql, null);
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		Log.d(TAG, "getCDInfo2KEYALL" + cursor.getCount());
//		close();
//		return cursor;
//	}
//	
//	public Cursor getCDInfoLawQuery(String clause) {
//		openRead();
//		String sql = clause;
//		mDB = mDBHelper.getReadableDatabase();
//		Cursor cursor = mDB.rawQuery(sql, null);
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		Log.d(TAG, "getCDInfo2PMOrderList" + cursor.getCount());
//		close();
//		return cursor;
//	}
//	
//	public Cursor getDBInfoID(String mTable, long id){
//		openRead();
//		Cursor cursor = mDB.query(mTable, null, "_ID = "+ id, null, null, null, null);
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		close();
//		return cursor;
//	}
//	
//	public Cursor getCheckUpWeekBeing(long time, String action) {
//		openRead();
//		String sql = null;
//		
//		if("Left".equalsIgnoreCase(action)) {
//			
//			sql ="SELECT * FROM "+ DBConst._TABLENAME1 +
//			" WHERE ( "+ DBConst.P_S01_SDATE +"<"+ time +" )";
//		
//			
//		} else {
//			sql ="SELECT * FROM "+ DBConst._TABLENAME1 +
//			" WHERE ( "+ DBConst.P_S01_REPEAT + " = 0 AND "+ DBConst.P_S01_EDATE +">"+ time +" ) OR ( "+
//			DBConst.P_S01_REPEAT + " != 0 AND "+ DBConst.P_S01_REPEAT_EDATE +">"+ time +" )";
//			
//		}
//		Log.d(TAG, sql);
//		
//		mDB = mDBHelper.getReadableDatabase();
//		Cursor mCursor = mDB.rawQuery(sql, null);
//		if(mCursor!=null && mCursor.getCount() != 0)
//			mCursor.moveToFirst();
//		
//		Log.d(TAG, "getCheckUpWeekBeing" + mCursor.getCount());
//		close();
//		return mCursor;
//	}
//	
//	public Cursor beingBTCDB(String mTable){	
//		openRead();
//		Cursor cursor = mDB.query(mTable, null, null, null, null, null, null);
//		if(cursor!=null && cursor.getCount() != 0)
//			cursor.moveToFirst();
//		close();
//		return cursor;
//	}
}
