package com.tjmedia.android.tjdebugger.activity;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ActionBar.LayoutParams;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.IntentFilter.MalformedMimeTypeException;
import android.graphics.Canvas;
import android.hardware.Camera;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.nfc.NfcAdapter;
import android.nfc.tech.NfcF;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.os.RemoteException;
import android.os.SystemClock;
import android.preference.Preference;
import android.text.Layout;
import android.text.method.ScrollingMovementMethod;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TextView.OnEditorActionListener;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.backlight.BacklightAct;
import com.tjmedia.android.tjdebugger.camera.TJCameraView;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SharedManager;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.TJJni;
import com.tjmedia.android.tjdebugger.common.TJPackageManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
import com.tjmedia.android.tjdebugger.led.LedAct;
import com.tjmedia.android.tjdebugger.remocon.RemoconAct;
import com.tjmedia.android.tjdebugger.temperature.TemperatureAct;


import android.provider.Settings;

/**
 * 
 * Desc :
 * 
 * @Company : TJMedia. Inc
 * @Author : jimmy
 * @Date : 2012. 2. 27.
 * @History : TJMedia Menu Tree
 * 
 * 
 */

public class TJDebugger extends Activity implements OnEditorActionListener {
	private final String TAG = "TJDebugger";
	SoundPoolManager mPoolManger;
	/** Called when the activity is first created. */
	String strManufacturer = android.os.Build.MANUFACTURER;
	String strProduct = android.os.Build.HARDWARE;	
	String strSN = "";
	String strServiceVer = "";
	com.tjmedia.service.ITJMedia_ServiceInterface TJService;
	
	private boolean wifitext = !(Log.getTmpCSD() || Log.getTMFP());	
	
	public static final int TJDBG_START = 0;
	public static final int TJDBG_STOPPING = 1;
	public static final int TJDBG_STOP = 2;
	public static final int TJUSBWIFI_VID = 5263;
	
	private int TJDBG_Status = TJDBG_STOP; 
	
	private boolean mUsbwifi = false;
	DrawLoopHandler mDrawhandler;
	WifiOffLoopHandler mWifiOffhandler;
	WifiOnLoopHandler mWifiOnhandler;
	WifiOnOffLoopHandler mWifiOnOffLoopHandler;
	UsbManager mUsbManager;
	private boolean wifiscan = true;
	private boolean wifiloop = false;
	private boolean mWifiCon = false;

	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.d(TAG, "onCreate()!!!");
		setContentView(R.layout.tj_debugger);
		initViewInfo();
		initObjInfo();

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm");
		Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT+09:00"),
				Locale.KOREA);
		Date date = new Date();
		TimeZone tz = TimeZone.getTimeZone("Asia/Seoul");
		formatter.setTimeZone(tz);
		Log.d(TAG, formatter.format(date));

	}

	
	private ServiceConnection con = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {

			TJService = com.tjmedia.service.ITJMedia_ServiceInterface.Stub.asInterface(service);
			if (TJService == null)
			{
				Log.d(TAG, "onServiceConnected>------------ TJService is NULL ------------");
			}
			else
			{
				Log.d(TAG, "onServiceConnected>------------ TJService = " + TJService);
				try {
					strSN = TJService.SYSTEM_GetSerialNumber();
					strServiceVer = TJService.GetVersionInfo(3);
//					TJService.SYSTEM_SetSerialNumber("AK12345");
//					Log.d(TAG,"after sn:" + TJService.SYSTEM_GetSerialNumber());
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			Log.d(TAG, "onServiceDisconnected> TJService = " + TJService);		
			TJService = null;
		}		
	};
	
	private boolean updateUSBWifi() {
		
		if (Log.getTMFP())
		{			
			try {
				if (null != TJService && 0 == TJService.GetUsbWifiStatus()) return true;
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			return false;
		}						
		else 
		{
			return true;
		}

	}		
		
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");
	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");			
		
		initModulesInfo();
		// mLoopHandler.start();
		// zsani2: wait for flushing broadcast receiver.
	}

	protected void onPause() {		
		synchronized (this) {
			removeModulesInfo();	
		}				
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();		
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
	}

	private void initObjInfo() {
		mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
		mWakeLock = mPowerManager.newWakeLock(
				PowerManager.SCREEN_BRIGHT_WAKE_LOCK, getClass().getName());

		setAirplaneMode(getApplicationContext(), false);
		mUsbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
		//1. audio(tmfp,csd)
		mAudioMgr = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		//2. temp(tmfp????,csd)		
		mTempObj = new TemperatureAct(getApplicationContext());
		//3. backlight(tmfp,csd)		
		mBLightObj = new BacklightAct();
		//4. remocon tx(csd)
//		if (Log.getCSD()){
//			mRemoconObj = new RemoconAct(getApplicationContext());
//		}
		//5. led(csd)		
//		if (Log.getCSD()){
//			if (!Log.getTmpCSD())
//			mLedObj = new LedAct();
//		}		
		//6. audio(tmfp,csd)
//		initMediaTest();

		int volume = mAudioMgr.getStreamVolume(AudioManager.STREAM_MUSIC);
		SharedManager.setAudioVolume(getApplicationContext(), volume);
		

		//7. gsensor(?)		
//		if (!Log.getTJ()){
//			mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
//			mSensor = mSensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
//			if (mSensor.size() > 0) {
//				sensorGrav = mSensor.get(0);
//			}
//		}

		//8. wifi(tmfp,csd(usb))		
		mWifiMgr = (WifiManager) getSystemService(WIFI_SERVICE);
		mConnManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
		
		int wifi = mWifiMgr.getWifiState();

		if (wifi == WifiManager.WIFI_STATE_ENABLED
				|| wifi == WifiManager.WIFI_STATE_ENABLING) 
		{
			
			if (Log.getTmpCSD())
			{
//				SharedManager.setWifiStatus(getApplicationContext(), true);
				SharedManager.setWifiStatus(getApplicationContext(), false);							
			} 
			else 
			{			
				SharedManager.setWifiStatus(getApplicationContext(), false);
			}
		} 
		else 
		{			
				SharedManager.setWifiStatus(getApplicationContext(), false);
		}

		//9. bluetooth(csd)		
		if (Log.getCSD()||!Log.getTJ()){
			if(!Log.getTmpCSD())
			mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		}
		
		if (null != mBluetoothAdapter) {
			if (Log.getCSD()|| !Log.getTJ()){
				int status = mBluetoothAdapter.getState();
				if (status == BluetoothAdapter.STATE_ON
						|| status == BluetoothAdapter.STATE_TURNING_ON) {
					if(!Log.getTmpCSD())
					SharedManager.setBluetoothStatus(getApplicationContext(),
							true);
				} else {
					if(!Log.getTmpCSD())
					SharedManager.setBluetoothStatus(getApplicationContext(),
							false);
				}
			}
			else	//tmfp
			{
				SharedManager.setBluetoothStatus(getApplicationContext(),false);				
			}
		}
		

	}
	
	private void initModulesInfo() {
		int i = 0;
		int wifi_state;
		Intent intent = new Intent("com.tjmedia.service.TJMedia_ServiceInterface");
		bindService(intent, con, Context.BIND_AUTO_CREATE);
		mStopCount = 0;
		TJDBG_Status = TJDBG_START;
		mWifiUnknownCount = 0;
		mWifiCon = false;
		
		mUsbwifi = updateUSBWifi();	

		//BTWIFI--		

		if (null != mBluetoothAdapter) {
//			if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& strProduct.equals("csd")) {
			if (Log.getCSD()|| !Log.getTJ()){
				
				int status;
				
				if (Log.getTmpCSD())  i = 100;
				
						for (i = 0; i < 3; i++) // wait for 500ms
						{
					status = mBluetoothAdapter.getState();
					switch(status)
					{
						case BluetoothAdapter.STATE_TURNING_OFF:
						{
								Log.d(TAG, "Wait for disabling BT... [" + i + "]");
								SystemClock.sleep(5000);
							}
						break;
						
						case BluetoothAdapter.STATE_OFF:
						{
							mBluetoothAdapter.enable();
							i = 100;
						}
						break;
						
						default:	i = 100;	break;
					}
				}
				//BTWIFI--					
			}
		}

		// This wakeLock ensures that screen is always on this Activity.
		mWakeLock.acquire();

		if (mTempObj == null) {
			mTempObj = new TemperatureAct(getApplicationContext());
		}
		mTempObj.registerSensor();

//		if (strManufacturer.equalsIgnoreCase("TJMedia")) {
//		if (!Log.getTJ()){
//			registerSensor();
//		}
		
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& (strProduct.equals("fptm") || strProduct.equals("tmfp"))) {
		if (Log.getTMFP())
			registerIRReceiverInfo();
		
		if(Log.getTMFP() || !Log.getTJ())
		{
			initCameraViewer();
		}
		
		if (Log.getCSD() || !Log.getTJ())
		{
			registerBatteryInfo();
//			if(!Log.getTmpCSD())
//			registerBTInfo();			
		}

		// zsani2
		registerWifiInfo();
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& strProduct.equals("csd")) {


//		mAudioMgr
//				.setStreamVolume(
//						AudioManager.STREAM_MUSIC,
//						mAudioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * 2 / 3,
//						0);
		mWifiOffhandler = new WifiOffLoopHandler();
		mWifiOnhandler = new WifiOnLoopHandler();
		
		mLoopHandler.bStop = false;
		mLoopHandler.sleep(FREQUENCY);
		mLoopHandler.start();
		mDrawhandler = new DrawLoopHandler();
		mDrawhandler.sleep(500);
		mDrawhandler.start();				
		
//		mWifiOnOffLoopHandler = new WifiOnOffLoopHandler();
//		mWifiOnOffLoopHandler.sleep(3000);
//		mWifiOnOffLoopHandler.start();		
		
	}

	private void removeModulesInfo() {
		
		mUsbwifi = false;
		TJDBG_Status = TJDBG_STOP;
		
		boolean wifi = SharedManager.getWifiStatus(getApplicationContext());
		if (!wifi && mWifiMgr.getWifiState() == WifiManager.WIFI_STATE_ENABLED)
		{							
			setWifiControl(false);
		}
		else if (wifi && mWifiMgr.getWifiState() == WifiManager.WIFI_STATE_DISABLED)
		{
			setWifiControl(true);
		}			
		unregisterWifiInfo();
		
		wifiscan = true;

		if (TJService != null)
			unbindService(con);
		
		if (!mDrawhandler.isStoped()) {
			mDrawhandler.stop();
		}

		
		if (!mLoopHandler.isStoped()) {
			mLoopHandler.stop();
			SystemClock.sleep(200);
		}

		if (!mWifiOffhandler.isStoped()) {
			mWifiOffhandler.stop();
		}

		if (!mWifiOnhandler.isStoped()) {
			mWifiOnhandler.stop();
		}

		for (int i = 0; i < 5; i++) {
			if (mloopstart == false) {
				break;
			}
			SystemClock.sleep(200);
		}

		// This wakeLock performs that screen is off this Activity.
		mWakeLock.release();

		mTempObj.unRegisterSensor();

//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&&  (strProduct.equals("fptm") || strProduct.equals("tmfp"))) {
		if (Log.getTMFP()){			
			unregisterIRReceiverInfo();
			if (mCamera != null) {
				mCamera.release();
				mCamera = null;
			}			
		}
		
		if (!Log.getTJ()){
			// Rollback camera flash info
			if (mCamera != null) {
				int flash = SharedManager
						.getSettingCameraFlash(getApplicationContext());
				Camera.Parameters p;
				p = mCamera.getParameters();
				p.setFlashMode(flash != 1 ? Camera.Parameters.FLASH_MODE_ON
						: Camera.Parameters.FLASH_MODE_OFF);
				mCamera.setParameters(p);
				mCamera.release();
				mCamera = null;
			}
		} 		


//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& strProduct.equals("csd")) {
		if (Log.getCSD() || !Log.getTJ()){
			unregisterBatteryInfo();
			if(!Log.getTmpCSD())
			{
//				unregisterBTInfo();
				boolean blue = SharedManager
						.getBluetoothStatus(getApplicationContext());
				if (null != mBluetoothAdapter) {
					int btstatus = mBluetoothAdapter.getState();
					if (true == blue
							&& (btstatus == BluetoothAdapter.STATE_TURNING_OFF || btstatus == BluetoothAdapter.STATE_OFF)) {
						int i = 0;
						for (i = 0; i < 10; i++) {
							SystemClock.sleep(200);
							if (BluetoothAdapter.STATE_OFF == mBluetoothAdapter
									.getState()) {
								break;
							}
						}
						mBluetoothAdapter.enable();
					} else if (false == blue
							&& (btstatus == BluetoothAdapter.STATE_TURNING_ON || btstatus == BluetoothAdapter.STATE_ON)) {
						int i = 0;
						for (i = 0; i < 10; i++) {
							SystemClock.sleep(200);
							if (BluetoothAdapter.STATE_ON == mBluetoothAdapter
									.getState()) {
								break;
							}
						}
						mBluetoothAdapter.disable();
					}
					SystemClock.sleep(500);
				}
			}
		}

		int volume = SharedManager.getAudioVolume(getApplicationContext());
		mAudioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, volume, 0);
		mLoopHandler.count = 0;

		InnerFactory.mComponent15.removeAllViews();
	}

	private WifiManager mWifiMgr;
	private ConnectivityManager mConnManager;
	private TemperatureAct mTempObj;
	private BluetoothAdapter mBluetoothAdapter;
//	private RemoconAct mRemoconObj;
//	private LedAct mLedObj;
	private BacklightAct mBLightObj;
	AudioManager mAudioMgr;

	public static boolean isAirplaneModeOn(Context context) {
		return Settings.System.getInt(context.getContentResolver(),
				Settings.System.AIRPLANE_MODE_ON, 0) != 0;
	}

	public static void setAirplaneMode(Context context, boolean status) {
		boolean isAirplaneModeOn = isAirplaneModeOn(context);
		if (isAirplaneModeOn && status) {
			return;
		}
		if (!isAirplaneModeOn && !status) {
			return;
		}
		if (isAirplaneModeOn && !status) {

			Settings.System.putInt(context.getContentResolver(),
					Settings.System.AIRPLANE_MODE_ON, 0);
			Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
			intent.putExtra("state", 0);
			context.sendBroadcast(intent);
			return;
		}
	}

	Button mTitleExit, mDevMode;
	private PowerManager mPowerManager;
	private WakeLock mWakeLock;

	private void initViewInfo() {
		mTitleExit = (Button) findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		mDevMode = (Button) findViewById(R.id.TJ_Debugger_Index01);
		mDevMode.setOnClickListener(mClickListener);
		if (mPoolManger == null) {
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}

		InnerFactory.mComponent00 = (TextView) findViewById(R.id.Shipment_Main_Index00);
		InnerFactory.mComponent16 = (TextView) findViewById(R.id.Shipment_Main_IndexCount);

		InnerFactory.mComponent01 = (TextView) findViewById(R.id.Shipment_Main_Index01);
		InnerFactory.mComponent02 = (TextView) findViewById(R.id.Shipment_Main_Index02);
//		InnerFactory.mComponent03 = (TextView) findViewById(R.id.Shipment_Main_Index03);
//		InnerFactory.mComponent04 = (TextView) findViewById(R.id.Shipment_Main_Index04);
		InnerFactory.mComponent05 = (TextView) findViewById(R.id.Shipment_Main_Index05);

		InnerFactory.mComponent06 = (TextView) findViewById(R.id.Shipment_Main_Index06);
		InnerFactory.mComponent07 = (TextView) findViewById(R.id.Shipment_Main_Index07);
		InnerFactory.mComponent08 = (TextView) findViewById(R.id.Shipment_Main_Index08);
		InnerFactory.mComponent09 = (TextView) findViewById(R.id.Shipment_Main_Index09);
		InnerFactory.mComponent10 = (TextView) findViewById(R.id.Shipment_Main_Index10);

		InnerFactory.mComponent11 = (TextView) findViewById(R.id.Shipment_Main_Index11);
		InnerFactory.mComponent12 = (TextView) findViewById(R.id.Shipment_Main_Index12);
//		InnerFactory.mComponent13 = (TextView) findViewById(R.id.Shipment_Main_Index13);
//		InnerFactory.mComponent14 = (TextView) findViewById(R.id.Shipment_Main_Index14);

		InnerFactory.mComponent15 = (FrameLayout) findViewById(R.id.Shipment_Main_Index15);

		InnerFactory.mComponent17 = (TextView) findViewById(R.id.Shipment_Main_Index17);

		InnerFactory.mComponent00.setText(getResources().getString(
				R.string.tj_shipmentmode_index31)
				+ TJPackageManager.updateVersionInfo(getApplicationContext())
				+ ")");
		if (wifitext)
		InnerFactory.mComponent08.setText("Waiting..");
			
		if (Log.getTMFP())
		{
			InnerFactory.mCSD_LayOut = findViewById(R.id.CSD_LayOut);
			InnerFactory.mCSD_LayOut.setVisibility(View.INVISIBLE);			
			
			LinearLayout.LayoutParams p = (android.widget.LinearLayout.LayoutParams)InnerFactory.mCSD_LayOut.getLayoutParams();
			p.height=0;
			InnerFactory.mCSD_LayOut.setLayoutParams(p);
		}
		else
		{
			InnerFactory.mTMFP_LayOut = findViewById(R.id.TMFP_LayOut);
			InnerFactory.mTMFP_LayOut.setVisibility(View.INVISIBLE);			
			
			LinearLayout.LayoutParams p = (android.widget.LinearLayout.LayoutParams)InnerFactory.mTMFP_LayOut.getLayoutParams();
			p.height=0;
			InnerFactory.mTMFP_LayOut.setLayoutParams(p);		
		}
		InnerFactory.mConsole = (Button) findViewById(R.id.Shipment_Console);
		InnerFactory.mConsole.setOnClickListener(mClickListener);
		
		InnerFactory.mWifi = (Button) findViewById(R.id.Shipment_Wifi);
		InnerFactory.mWifi.setText((wifiloop)?"Wifi Loop : Off":"Wifi Loop :On");
		InnerFactory.mWifi.setOnClickListener(mClickListener);
		
//		InnerFactory.mConsoleInput = (EditText) findViewById(R.id.EditTextConsoleInput);
//		InnerFactory.mConsoleOutput = (TextView)findViewById(R.id.TextViewConsoleOutput);
//		
//		InnerFactory.mConsoleOutput.setMovementMethod(new ScrollingMovementMethod());
//		
//		InnerFactory.mConsoleInput.setOnEditorActionListener(this);
	}
	
	public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		int i;
		if (actionId == EditorInfo.IME_ACTION_DONE)
		{
			CharSequence t = v.getText();
//			char[] text = new char[t.length()];
			String szText = "";
			for (i=0; i<t.length(); i++) {
//				text[i] = t.charAt(i);
				szText += t.charAt(i);
			}
			if (2 <= i)			
			SystemCall(szText);
		}
		return false;

	}
	
	public void SystemCall(String str)
	{
		String ret = null;
		Log.d(TAG, "systemcall:" + str);
		try {
			ret = TJService.SystemCall(str,true);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		InnerFactory.mConsoleOutput.setText(ret);					
	}
	//////
	private	AlertDialog ad = null;
	public void ShowConsoleMessageBox(String Title,String Message)
	{
		Context mContext = this;	
		EditText mPassword = null;
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.console_dialog,(ViewGroup) findViewById(R.id.console_dialog_layout_root));
        //setContentView(R.layout.custom_dialog);        
        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle(Title);
        aDialog.setView(layout);
        aDialog.setMessage(Message);                
        
		InnerFactory.mConsoleInput = (EditText) layout.findViewById(R.id.EditTextConsoleInput);
		InnerFactory.mConsoleOutput = (TextView)layout.findViewById(R.id.TextViewConsoleOutput);
        
		InnerFactory.mConsoleOutput.setMovementMethod(new ScrollingMovementMethod());
		InnerFactory.mConsoleInput.setOnEditorActionListener(this);		
        
//        aDialog.setPositiveButton("Logcat Save(usb)", new DialogInterface.OnClickListener() 
//        {
//        	@Override		
//            public void onClick(DialogInterface dialog, int which) 
//            {            		
//        		Date date = new Date();
//        		int m = date.getMinutes();
//        		int s = date.getSeconds();
//        		int h = date.getHours();
//        		
//        		String uriString = "/storage/usb/";
//        		File file = new File(uriString);
//        		File[] files = file.listFiles();
//        		long leng = file.length();
//        		// Lost.dir directory check
//        		if (leng > 0) {        		
//	        		try {
//						TJService.SystemCall("logcat -t 1000 -v time",true);
//		        		TJService.SystemCall("sync",false);
//		        		TJService.SystemCall("cp /data/data/com.tjmedia.service/files/ret.txt /storage/usb/logcat_" + h + "_" + m + "_" + s,false);
//		        		TJService.SystemCall("sync",false);		        		
//					} catch (RemoteException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//	        		ShowConsoleMessageBox2("Result logcat", 1);
//        		}
//        		else
//        		{
//        			ShowConsoleMessageBox2("Result logcat", 0);
//        		}        		
//            }
//        });
		
        aDialog.setNegativeButton("exit", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which)
            {           					
            }
        });        
        
//        aDialog.setNeutralButton("Dmesg Save(usb)", new DialogInterface.OnClickListener() 
//        {
//        	@Override
//            public void onClick(DialogInterface dialog, int which) 
//            {   
//        		Date date = new Date();
//        		int m = date.getMinutes();
//        		int s = date.getSeconds();
//        		int h = date.getHours();
//        		
//        		String uriString = "/storage/usb/";
//        		File file = new File(uriString);
//        		long leng = file.length();
//        		File[] files = file.listFiles();
//        		// Lost.dir directory check
//        		if (leng > 0) {        		
//	        		try {
//						TJService.SystemCall("dmesg",true);
//		        		TJService.SystemCall("sync",false);
//		        		TJService.SystemCall("cp /data/data/com.tjmedia.service/files/ret.txt /storage/usb/dmesg_" + h + "_" + m + "_" + s,false);
//		        		TJService.SystemCall("sync",false);
//					} catch (RemoteException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}	  
//	        		ShowConsoleMessageBox2("Result dmesg", 1);
//        		}  
//        		else
//        		{
//        			ShowConsoleMessageBox2("Result dmesg", 0);
//        		}
//            }
//        });    
        
        ad = aDialog.create();        
        ad.show();        
	}		
	
	private	AlertDialog ad2 = null;
	public void ShowConsoleMessageBox2(String Title, int nMode)
	{
		Context mContext = this;	
		EditText mPassword = null;
		LayoutInflater inflater = 
				(LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate
        		(R.layout.console_dialog2,(ViewGroup) findViewById(R.id.console_dialog_layout_root2));
        //setContentView(R.layout.custom_dialog);        
        
        AlertDialog.Builder aDialog = new AlertDialog.Builder(mContext);
        aDialog.setTitle(Title);
        aDialog.setView(layout);        
        
		InnerFactory.mConsoleOutput2 = (TextView)layout.findViewById(R.id.TextViewConsoleOutput);
        
		InnerFactory.mConsoleOutput2.setMovementMethod(new ScrollingMovementMethod());	
		
		String szResult = "";
		
		switch(nMode)
		{
			case 0:
				try {
					szResult = "<<USB ERROR>>\n" + TJService.SystemCall("ls -l /storage/usb",true);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 1: 
				try {
					szResult =TJService.SystemCall("ls -l /storage/usb",true);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
		}
		
		InnerFactory.mConsoleOutput2.setText(szResult);
             		
        aDialog.setNegativeButton("exit", new DialogInterface.OnClickListener() 
        {
        	@Override
            public void onClick(DialogInterface dialog, int which)
            {           					
            }
        });        
                
        ad2 = aDialog.create();        
        ad2.show();        
	}			
	//////
 
	
	private View.OnClickListener mClickListener = new View.OnClickListener() {
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				// finish();
				synchronized (this) {
					if (mLoopHandler.count < 1) {
						ToastManager.showToast(getApplicationContext(),
								"SKIP,Test is not Ready", Toast.LENGTH_SHORT);
						return;
					}
					wifiloop = true;
					wifiscan = true;
					TJDBG_Status = TJDBG_STOPPING;
					
						mTitleExit.setEnabled(false);
					mTitleExit.setText("waiting exit");
						Log.d(TAG,
								"set TJDBG_STOPPING========================>");						
						ToastManager.showToast(getApplicationContext(),
								"waiting exit", Toast.LENGTH_SHORT);
				}
				// mLoopHandler.stop();
				break;
			case R.id.TJ_Debugger_Index01:
				mTitleExit.setEnabled(true);
				if (mLoopHandler.count < 1) {
					ToastManager.showToast(getApplicationContext(),
							"SKIP,Test is not Ready", Toast.LENGTH_SHORT);
					return;
				}
				callActivity(0);				
				break;
				
			case R.id.Shipment_Console:
				ShowConsoleMessageBox("Command","test");
				break;
				
			case R.id.Shipment_Wifi:
				synchronized (this) {
					wifiloop = (wifiloop)?false:true;
					InnerFactory.mWifi.setText((wifiloop)?"Wifi Loop : Off":"Wifi Loop : On");
					wifiscan = true;
				}						
				break;
				
			default:
				break;

			}
		}
	};
	
	private void callActivity(int index) {
		Intent i;
		switch (index) {
		case 0:
			Intent intent = new Intent(this, TJDevelopMode.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			startActivity(intent);			
			break;
		default:
			ToastManager.showToast(this,
					getResources().getString(R.string.tj_main_index04),
					Toast.LENGTH_SHORT);
			break;
		}
	}

	public final int FREQUENCY = 3000;
	public final String log_tag = "++++++++++++++++++++++++++++++++++++++++++++++++";
	public final String log_tag2 = "-----------------------------------------------";
	public LoopHandler mLoopHandler = new LoopHandler();
	Date startdate = new Date();
	public boolean mloopstart = false;
	public int mStopCount = 0;

	public void loop() {

//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//		Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT+09:00"),
//				Locale.KOREA);
//		Date date = new Date();
//		TimeZone tz = TimeZone.getTimeZone("Asia/Seoul");
//		formatter.setTimeZone(tz);
//		if (mLoopHandler.count == 0) {
//			startdate = date;
//		}
//		InnerFactory.mComponent16.setText("test " + "Aging count["
//				+ mLoopHandler.count + "] " + '\n' + "Aging Time :"
//				+ formatter.format(startdate) + "~" + formatter.format(date));				

		mLoopHandler.mFLAG = mLoopHandler.mFLAG == false ? true : false;
		Log.d(TAG, log_tag + "start loop() count[" + mLoopHandler.count + "]"
				+ "this turn is [" + mLoopHandler.mFLAG + "]");

		updateViewInfo();		
		
		if (TJDBG_Status == TJDBG_STOP)
		{
			mLoopHandler.stop();
			finish();
		}
		
		if (TJDBG_Status == TJDBG_STOPPING)
		{
			mStopCount++;
			if (mStopCount > 2)
			{
				Log.d(TAG,log_tag + "force stop!!!!");
				mLoopHandler.stop();
				finish();
			}
		}
		
		mLoopHandler.sleep(FREQUENCY);

		mLoopHandler.count++;
	}
	
	public class LoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "LoopHandler handleMessage" + msg);
			if (msg.what != 0)
				return;
			synchronized (this) {
				mloopstart = true;

				if (this.bStop == false) {
					loop();
				}
				super.handleMessage(msg);

				mloopstart = false;
			}

//			if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")) && strProduct.equals("csd")) {
//			if (!Log.getTJ()){
//				if (bStop == false && !mLoopHandler.mFLAG) {
//					SystemClock.sleep(200);
//					updateFlash();
//				}
//			}
		}
		
		public boolean isStoped() {
			return this.bStop;
		}

		private void sleep(long delayMillis) {
			Log.d(TAG, log_tag + "LoopHandler Sleep++");
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
			Log.d(TAG, log_tag + "LoopHandler Sleep--");
		}

		public void stop() {
			this.removeMessages(0);
			this.bStop = true;
		}

		void start() {
			this.bStop = false;
			loop();
		}
	};
	
	public class DrawLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			if (this.bStop == false) {
								
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT+09:00"),Locale.KOREA);
					Date date = new Date();
					InnerFactory.mComponent16.setText(" SN:" + strSN + " ServiceVer:" + strServiceVer + "      count["
							+ mLoopHandler.count + "] " + '\n' + "Aging Time :"
							+ formatter.format(startdate) + "~" + formatter.format(date));				
									
					InnerFactory.mComponent16.invalidate();
					sleep(1);
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}
		
		public boolean isStoped() {
			return this.bStop;
		}
		
		public void stop() {
			this.bStop = true;
		}

		private void start() {
			this.bStop = false;							
		}
	};

	private void updateViewInfo() {
		Log.d(TAG, "updateViewInfo ++");

		Log.d(TAG, "updateBacklight ++");
		updateBacklight();		
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& strProduct.equals("csd")) {
		if (Log.getCSD()){
			if (!(mWifiMgr.getWifiState() == WifiManager.WIFI_STATE_ENABLING 
					|| !mWifiOnhandler.isStoped() || !mWifiOffhandler.isStoped()) || !wifiloop)
			{			
				Log.d(TAG, "updateRemocon ++");
				updateRemocon();				
			}
			else
			{
				Log.d(TAG, log_tag2 + "skip : updateRemocon ++");
				if (mLoopHandler.mFLAG) {
					InnerFactory.mComponent11.setTextColor(getApplicationContext()
							.getResources().getColor(R.color.skyblue));
				} else {
					InnerFactory.mComponent11.setTextColor(getApplicationContext()
							.getResources().getColor(R.color.red));
				}				
			}
			Log.d(TAG, "updateBattery ++");
			updateBattery();
			Log.d(TAG, "updateNFC ++");
			updateUSBNfc();
		}

		if (Log.getTJ()) {
			Log.d(TAG, "updateLed ++");
			updateLed();

		Log.d(TAG, "updateUSB ++");
		updateUSB();

		Log.d(TAG, "updateSDCARD ++");
		updateSDCARD();

		Log.d(TAG, "updateTemperature ++");
		updateTemperature();

		}


		// Log.d(TAG,"updateAudio ++");
		// updateAudio();

			updateWifiInfo();
				Log.d(TAG, "updateBluetoothInfo ++");
			
					if (null != mBluetoothAdapter)
						updateBluetoothInfo();
		
	}
	
	/*
	 * ***********************************************************
	 * volume
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event) 
	{
		Log.d(TAG, "onKeyDown()");
		Log.d(TAG, "KeyCode = " + keyCode);
		InnerFactory.mComponent17.setTextColor(getApplicationContext()
				.getResources().getColor(R.color.yellowgren));
				
		switch(keyCode)
		{			
			case Const.KEYCODE_TMFP_BGM_VOL_DOWN:
				InnerFactory.mComponent17.setText("BGM VOL-");
				break;
			case Const.KEYCODE_TMFP_BGM_VOL_UP:
				InnerFactory.mComponent17.setText("BGM VOL+");
				break;
			case Const.KEYCODE_TMFP_MIC_VOL_DOWN:
				InnerFactory.mComponent17.setText("MIC VOL-");
				break;
			case Const.KEYCODE_TMFP_MIC_VOL_UP:
				InnerFactory.mComponent17.setText("MIC VOL+");
				break;
			case Const.KEYCODE_TMFP_ECO_VOL_DOWN:
				InnerFactory.mComponent17.setText("ECO VOL-");
				break;
			case Const.KEYCODE_TMFP_ECO_VOL_UP:
				InnerFactory.mComponent17.setText("ECO VOL+");
				break;
			case Const.KEYCODE_TMFP_MUSIC_VOL_DOWN:
				InnerFactory.mComponent17.setText("MUSIC VOL-");
				break;
			case Const.KEYCODE_TMFP_MUSIC_VOL_UP:
				InnerFactory.mComponent17.setText("MUSIC VOL+");
				break;			
		}
		InnerFactory.mComponent17.invalidate();
		return false;		
	};
	/*
	 * ***********************************************************
	 * m/b key
	 */
	public boolean onKeyUp(int keyCode, KeyEvent event)
	{
		int nKeyNum = 0;
		Log.d(TAG, "onKeyUp()");
		InnerFactory.mComponent17.setTextColor(getApplicationContext()
				.getResources().getColor(R.color.yellowgren));
				
		if (Log.getCSD())
		{
			keyCode = event.getScanCode();
			Log.d(TAG, "CSD KeyCode = " + keyCode);
			
			switch(keyCode)
			{			
				case Const.KEYCODE_CSD_MBKEY1:
				case Const.KEYCODE_CSD_MBKEY2:
				case Const.KEYCODE_CSD_MBKEY3:
				case Const.KEYCODE_CSD_MBKEY4:
				case Const.KEYCODE_CSD_MBKEY5:
				case Const.KEYCODE_CSD_MBKEY6:
				case Const.KEYCODE_CSD_MBKEY7:
				case Const.KEYCODE_CSD_MBKEY8:
				case Const.KEYCODE_CSD_MBKEY9:
				case Const.KEYCODE_CSD_MBKEY10:				
				case Const.KEYCODE_CSD_MBKEY11:
				case Const.KEYCODE_CSD_MBKEY12:				
				case Const.KEYCODE_CSD_MBKEY13:				
				case Const.KEYCODE_CSD_MBKEY14:
				case Const.KEYCODE_CSD_MBKEY15:
				case Const.KEYCODE_CSD_MBKEY16:
				case Const.KEYCODE_CSD_MBKEY17:
				case Const.KEYCODE_CSD_MBKEY18:					
					nKeyNum = keyCode - Const.KEYCODE_CSD_MBKEY1 + 1;
					InnerFactory.mComponent17.setText("M/B KEY[" + nKeyNum + "] UP");
					break;
			}
		}
		else if(Log.getTMFP())
		{
			keyCode = event.getScanCode();
			Log.d(TAG, "TMFP KeyCode = " + keyCode);
					
			switch(keyCode)
			{
				case Const.KEYCODE_TMFP_STANDBY:									
					InnerFactory.mComponent17.setText("STANDBY KEY UP");
					break;
				case Const.KEYCODE_TMFP_LIVESOUND:								
					InnerFactory.mComponent17.setText("LIVESOUND KEY UP");
					break;			
					
			}
		}
		InnerFactory.mComponent17.invalidate();
		return false;		
	};
	
	/*
	 * ***********************************************************
	 * RMC(RX)
	 */	
	private void registerIRReceiverInfo() {
		IntentFilter filter = new IntentFilter();		
		filter.addAction("TMFP.RMC");
		filter.addAction("TMFP.VOL");
		registerReceiver(mIRReceiver, filter);
	}

	private void unregisterIRReceiverInfo() {		
		unregisterReceiver(mIRReceiver);
	}	
	
	BroadcastReceiver mIRReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {	
				if (intent.getAction().equals("TMFP.RMC"))
				{
					byte [] data = new byte [100];
					byte nSize = 1;
					byte i = 0;
					//byte data = intent.getByteExtra("data", (byte)0);					
					data = intent.getByteArrayExtra("data");					
					nSize = intent.getByteExtra("leng", (byte)0);
					
					String str;					
					str = "Recv:";					 
//					 str += String.format("[0x%02X]", data);
					for (i = 0; i < nSize; i++)
					{					
						str += "[" + String.format("0x%02X", data[i]) + "]";	
					}					 
					str += "\n";					
					Log.d(TAG, str);
					InnerFactory.mComponent11.setText(str);
					InnerFactory.mComponent11.setTextColor(getApplicationContext().getResources().getColor(R.color.yellowgren));		
					InnerFactory.mComponent11.invalidate();
				}
				else if (intent.getAction().equals("TMFP.VOL"))
				{
					//byte data = intent.getByteExtra("data", (byte)0);										
					int key = intent.getIntExtra("key", 0);
					int nSize = intent.getIntExtra("leng", 0);
					String str = "";
					switch(key)
					{			
						case Const.KEYCODE_TMFP_BGM_VOL_DOWN:
							str = "BGM VOL-" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("BGM VOL-" + "[" + nSize +"]");
							break;
						case Const.KEYCODE_TMFP_BGM_VOL_UP:
							str = "BGM VOL+" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("BGM VOL+" + "[" + nSize +"]");
							break;
						case Const.KEYCODE_TMFP_MIC_VOL_DOWN:
							str = "MIC VOL-" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("MIC VOL-" + "[" + nSize +"]");
							break;
						case Const.KEYCODE_TMFP_MIC_VOL_UP:
							str = "MIC VOL+" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("MIC VOL+" + "[" + nSize +"]");
							break;
						case Const.KEYCODE_TMFP_ECO_VOL_DOWN:
							str = "ECO VOL-" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("ECO VOL-" + "[" + nSize +"]");
							break;
						case Const.KEYCODE_TMFP_ECO_VOL_UP:
							str = "ECO VOL+" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("ECO VOL+" + "[" + nSize +"]");
							break;
						case Const.KEYCODE_TMFP_MUSIC_VOL_DOWN:
							str = "MUSIC VOL-" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("MUSIC VOL-" + "[" + nSize +"]");
							break;
						case Const.KEYCODE_TMFP_MUSIC_VOL_UP:
							str = "MUSIC VOL+" + "[" + nSize +"]";
							InnerFactory.mComponent17.setText("MUSIC VOL+" + "[" + nSize +"]");
							break;			
					}
					Log.d(TAG,str);
				}				
		}	
	};
	
//	BroadcastReceiver IRReceiver = new BroadcastReceiver() {
//		@Override
//		public void onReceive(Context context, Intent intent) {
//			if (intent.getAction().equals("TMFP.RMC")) {
//				byte data = intent.getByteExtra("data", (byte)0);
//				
//				String str;					
//				str = "recv:[";
//					str += String.format("[0x%02X]", data);						 						
//				str += "\n";					
//				Log.d(TAG, str);
//				
//				int i = 0;
//				str = "?�신:";
//				str += String.format("[0x%02X]", data);
//				str += "\n";
//
//				if (mLoopHandler.mFLAG) {
//					InnerFactory.mComponent11
//							.setTextColor(getApplicationContext()
//									.getResources()
//									.getColor(R.color.yellowgren));
//				} else {
//					InnerFactory.mComponent11
//							.setTextColor(getApplicationContext()
//									.getResources()
//									.getColor(R.color.yellowgren));
//				}
//
//				InnerFactory.mComponent11.setText(str);
//			}
//		}
//	};
	/*
	 * ***********************************************************
	 * Led
	 */
	public void senddata(byte cmd, byte led, byte bright) {

		byte[] buffer = new byte[100];		
		buffer[0] = led;	//MODE
		buffer[1] = bright;		
		Intent intent = new Intent();
		intent.setAction("TMFP.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", buffer);		
		intent.putExtra("leng",(byte)2);		
		sendBroadcast(intent);				
	}
	
	private void updateLed() {
		boolean result = false;
		if (mLoopHandler.mFLAG) {			
			if (Log.getCSD()) {
//				result = mLedObj.isAllLedStatus(1);
			}
			else if (Log.getTMFP()){
				senddata(Const.BOTTOM_PCB_LED_ALL_CMD, Const.ON_LED, (byte)0x5);
				senddata(Const.LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, Const.ON_LED, (byte)0x5);
				senddata(Const.LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, Const.RGB_LED, (byte)0x5);				
				result = true;
				InnerFactory.mComponent01.setText(result == true ? "ON" : "ON(NG)");
				InnerFactory.mComponent01.invalidate();	
			}						
			InnerFactory.mComponent01.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.skyblue));

		} else {
			if (Log.getCSD()) {
//				result = mLedObj.isAllLedStatus(0);
			}
			else if (Log.getTMFP()){
			senddata(Const.BOTTOM_PCB_LED_ALL_CMD, Const.OFF_LED, (byte)0x0);
			senddata(Const.LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD, Const.OFF_LED, (byte)0x0);
			senddata(Const.LEFT_RIGHT_BACK_PCB_LED_ALL_CMD, Const.OFF_LED, (byte)0x0);
			result = true;
			InnerFactory.mComponent01.setText(result == true ? "OFF"
					: "OFF(NG)");			
			InnerFactory.mComponent01.invalidate();	
			}			
			InnerFactory.mComponent01.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.red));

		}
	}

	/*
	 * ***********************************************************
	 * BackLight
	 */
	private void updateBacklight() {
		if (mLoopHandler.mFLAG) {
//			updateFlash();
//			SystemClock.sleep(200);
			mBLightObj.setBackLight(this, 100);
			InnerFactory.mComponent02.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.skyblue));
			InnerFactory.mComponent02.setText("ON");
		} else {
			mBLightObj.setBackLight(this, 20);
			InnerFactory.mComponent02.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.red));
			InnerFactory.mComponent02.setText("OFF");
		}
		InnerFactory.mComponent02.invalidate();
	}

	/*
	 * ***********************************************************
	 * Flash
	 */
//	boolean FLAG_COLOR_FLASH = false;
//	boolean FLAG_FLASH_STATUS = false;
//
//	private void updateFlash() {
//		if (!Log.getTJ()){
//
//			if (!mLoopHandler.mFLAG) {
//				InnerFactory.mComponent03.setTextColor(getApplicationContext()
//						.getResources().getColor(R.color.skyblue));
//			} else {
//				InnerFactory.mComponent03.setTextColor(getApplicationContext()
//						.getResources().getColor(R.color.red));
//			}
//			if (!mLoopHandler.mFLAG) {
//				setFlashOnOff(true);
//				InnerFactory.mComponent03.setText("ON");
//			} else {
//				setFlashOnOff(false);
//				InnerFactory.mComponent03.setText("OFF");
//			}
//		}
//	}
//
//	private void setFlashOnOff(boolean flag) {
//		if (!Log.getTJ()){
//			Camera.Parameters p;
//			if (mCamera == null)
//				return;
//			p = mCamera.getParameters();
//			if (flag) {
//				p.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
//			} else {
//				p.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
//			}
//			mCamera.setParameters(p);
//		}
//	}

	/*
	 * ***********************************************************
	 * USB
	 */
	boolean FLAG_COLOR_USB = true;

	private void updateUSB() {
		int result = 0;

		String uriString = "/storage/usb/";
		File file = new File(uriString);
		File[] files = file.listFiles();
		// Lost.dir directory check
		if (files != null) {
			InnerFactory.mComponent05.setText("OK");
		} else {
			InnerFactory.mComponent05.setText("NG");
		}

		if (mLoopHandler.mFLAG) {
			InnerFactory.mComponent05.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.skyblue));
		} else {
			InnerFactory.mComponent05.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.red));
		}

		InnerFactory.mComponent05.invalidate();	
		Log.d(TAG, "USB Disk : check ret = " + result);
	}

	/*
	 * ***********************************************************
	 * SDCard
	 */
	boolean FLAG_COLOR_SDCARD = true;

	private void updateSDCARD() {
		String ext = null;

		String uriString = "/storage/sdcard1/";
		File file = new File(uriString);
		File[] files = file.listFiles();
		// Lost.dir directory check
		if (files != null) {
			InnerFactory.mComponent06.setText("OK");
		} else {
			InnerFactory.mComponent06.setText("NG");
		}
		if (mLoopHandler.mFLAG) {
			InnerFactory.mComponent06.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.skyblue));
		} else {
			InnerFactory.mComponent06.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.red));
		}
		InnerFactory.mComponent06.invalidate();
	}

	/*
	 * ***********************************************************
	 * Wifi
	 */
	int mWifiUnknownCount = 0;
	private void updateWifiInfo() {
		Log.d(TAG, "updateWifiInfo ++");
		int status = mWifiMgr.getWifiState();
		
		if (wifiscan && status == WifiManager.WIFI_STATE_ENABLED)
		{
			mWifiUnknownCount = 0;
			if (mWifiOffhandler.isStoped())
			{
				WifiInfo winfo = mWifiMgr.getConnectionInfo();
				
				if (-1 != winfo.getNetworkId())
				{
					Log.d(TAG,log_tag2 + "mWifiMgr.disconnect()");
					mWifiMgr.disconnect();
				}				
			}
			}

		if (status == WifiManager.WIFI_STATE_UNKNOWN)
		{	
			mWifiUnknownCount++;
			if (0 == mWifiUnknownCount%10)
			{
				if (mWifiOnhandler.isStoped())
				{
					Log.d(TAG,log_tag2+"mWifiOnhandler Start(wifi unknown)");
					mWifiOnhandler.sleep(5000);
					mWifiOnhandler.start();
				}				
			}
			else
			{
				if (mWifiOffhandler.isStoped())
				{
					Log.d(TAG,log_tag2+"mWifiOffhandler Start(wifi unknown)");
					mWifiOffhandler.sleep(5000);
					mWifiOffhandler.start();
				}				
			}
		}

		if (status == WifiManager.WIFI_STATE_DISABLED && TJDBG_Status != TJDBG_STOPPING)
		{
			mWifiUnknownCount = 0;
			if (mWifiOnhandler.isStoped())
			{
				Log.d(TAG,log_tag2+"mWifiOnhandler Start");				
				mWifiOnhandler.sleep(5000);
				mWifiOnhandler.start();
			}
		}

	}

	boolean lastwificmd = false;
	int lastwificmdcount = 0;
	int beforelastwificmdcount = 0;

	public void setWifiControl(boolean status) {
		Log.e(TAG, log_tag + "SetWIFIEnabled : " + status);
		if (!wifiloop && !status)
			return;
		
//		try {
//			String str = TJService.SystemCall("lsmod", true);
//			Log.d(TAG,"-----------------------------------------");
//			Log.e(TAG,str);
//			Log.d(TAG,"-----------------------------------------");
//			str = TJService.SystemCall("getprop wlan.driver.status", true);
//			Log.d(TAG,"-----------------------------------------");
//			Log.e(TAG,str);
//			Log.d(TAG,"-----------------------------------------");
//			str = TJService.SystemCall("getprop wifi.interface", true);
//			Log.d(TAG,"-----------------------------------------");
//			Log.e(TAG,str);
//			Log.d(TAG,"-----------------------------------------");		
//			str = TJService.SystemCall("getprop init.svc.wpa_supplicant", true);
//			Log.d(TAG,"-----------------------------------------");
//			Log.e(TAG,str);
//			Log.d(TAG,"-----------------------------------------");
//			
//			if (status && str.lastIndexOf("stopped") == -1)
//			{
//				Log.e(TAG,"skip, supplicat is not stopped!!!!");
//				return;
//			}
//			else if (!status && str.lastIndexOf("running") == -1)
//			{
//				Log.e(TAG,"skip, supplicat is not running!!!!");
//				return;				
//			}

//		} catch (RemoteException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
			mWifiMgr.setWifiEnabled(status);
	}

	public String getWifiStatus(int nStatus) {
		String szMessage = "UNKNOWN";
		switch (nStatus) {
		case WifiManager.WIFI_STATE_DISABLED:
			return szMessage = "OK(OFF)";
		case WifiManager.WIFI_STATE_DISABLING:
			return szMessage = "Waiting OFF";
		case WifiManager.WIFI_STATE_ENABLING:
			return szMessage = "Waiting ON";
		case WifiManager.WIFI_STATE_ENABLED:
			return szMessage = "OK(ON)";
		default:
			return szMessage;
		}
	}

	// add zsani2 method
	private void registerWifiInfo() {
		IntentFilter mIntentFilter;
		mIntentFilter = new IntentFilter();
		mIntentFilter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
		mIntentFilter.addAction(WifiManager.SUPPLICANT_STATE_CHANGED_ACTION);
		mIntentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
		// mWifiFilter.addAction(WifiManager.RSSI_CHANGED_ACTION);
		mIntentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
		registerReceiver(mWifiReceiver, mIntentFilter);
	}

	private void unregisterWifiInfo() {
		unregisterReceiver(mWifiReceiver);
		}

	BroadcastReceiver mWifiReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			// Log.d(TAG, "intent.getAction=" + intent.getAction());

			String action = intent.getAction();

					
			if (WifiManager.WIFI_STATE_CHANGED_ACTION.equals(action)) 
					{
				int wifi_status = intent.getIntExtra(
						WifiManager.EXTRA_WIFI_STATE,
						WifiManager.WIFI_STATE_UNKNOWN);

				String wifi_state = getWifiStatus(mWifiMgr.getWifiState());		
						
				switch(wifi_status)
				{
					case WifiManager.WIFI_STATE_DISABLED:
					{
						mWifiCon = false;
						Log.d(TAG,log_tag+"WifiManager.WIFI_STATE_DISABLED");
						InnerFactory.mComponent08.setText(wifi_state);
						InnerFactory.mComponent08.invalidate();																
						InnerFactory.mComponent08.setTextColor(getApplicationContext().getResources().getColor(R.color.red));
						
						synchronized (this) {
							if (!mWifiOnhandler.isStoped())
							{
								Log.d(TAG,log_tag2+"mWifiOnhandler Force Stop");
								wifiscan = false; 
								mWifiOnhandler.stop();
						}
						}

						if (TJDBG_Status == TJDBG_STOPPING)
						{
							TJDBG_Status = TJDBG_STOP;
							break;
				}
			}
					break;
					
					case WifiManager.WIFI_STATE_DISABLING:	break;
					case WifiManager.WIFI_STATE_ENABLED:	
					{
						Log.d(TAG,log_tag+"WifiManager.WIFI_STATE_ENABLED");
						InnerFactory.mComponent08.setText(wifi_state);
						InnerFactory.mComponent08.invalidate();			
						InnerFactory.mComponent08.setTextColor(getApplicationContext().getResources().getColor(R.color.skyblue));
						wifiscan = true;     							
		}
					break;

					case WifiManager.WIFI_STATE_ENABLING:	break;
					case WifiManager.WIFI_STATE_UNKNOWN:	
					{
						Log.d(TAG,log_tag+"WifiManager.WIFI_STATE_UNKNOWN");
						if (true == updateUSBWifi())
							InnerFactory.mComponent08.setText(wifi_state);
						else
							InnerFactory.mComponent08.setText("");
						InnerFactory.mComponent08.invalidate();															
						InnerFactory.mComponent08.setTextColor(getApplicationContext().getResources().getColor(R.color.red));
		}
					break;					
				}
			} 
			else if (WifiManager.SUPPLICANT_STATE_CHANGED_ACTION.equals(action)) 
			{
				SupplicantState mSupplicantState = (SupplicantState) intent.getParcelableExtra(WifiManager.EXTRA_NEW_STATE);

				if (mSupplicantState.equals(SupplicantState.ASSOCIATED))
				{
					Log.d(TAG,log_tag+"SupplicantState.ASSOCIATED");
					synchronized (this) {
						if (!mWifiOffhandler.isStoped())
						{
							Log.d(TAG,log_tag2+"mWifiOffhandler Force Stop");
							wifiscan = true; 
							mWifiOffhandler.stop();
						}						
					}										
		}

				if (mSupplicantState.equals(SupplicantState.ASSOCIATING))
				{
					Log.d(TAG,log_tag+"SupplicantState.ASSOCIATING");					
					synchronized (this) {
						if (!mWifiOffhandler.isStoped())
						{
							Log.d(TAG,log_tag2+"mWifiOffhandler Force Stop");
							wifiscan = true; 
							mWifiOffhandler.stop();
						}						
					}
		}

				if (mSupplicantState.equals(SupplicantState.AUTHENTICATING))
				{
					Log.d(TAG,log_tag+"SupplicantState.AUTHENTICATING");	
					synchronized (this) {
						if (!mWifiOffhandler.isStoped())
						{
							Log.d(TAG,log_tag2+"mWifiOffhandler Force Stop");
							wifiscan = true; 
							mWifiOffhandler.stop();
						}						
					}					
				}

				if (mSupplicantState.equals(SupplicantState.COMPLETED))
				{
					Log.d(TAG,log_tag+"SupplicantState.COMPLETED");
				}

				if (mSupplicantState.equals(SupplicantState.DISCONNECTED ))
				{
					Log.d(TAG,log_tag+"SupplicantState.DISCONNECTED ");
		}

				if (mSupplicantState.equals(SupplicantState.DORMANT  ))
				{
					Log.d(TAG,log_tag+"SupplicantState.DORMANT  ");
				}
				
				if (mSupplicantState.equals(SupplicantState.FOUR_WAY_HANDSHAKE)) 
				{
					Log.d(TAG,log_tag+"SupplicantState.FOUR_WAY_HANDSHAKE");
			}
				if (mSupplicantState.equals(SupplicantState.GROUP_HANDSHAKE)) 
				{
					Log.d(TAG,log_tag+"SupplicantState.GROUP_HANDSHAKE");
		}

				if (mSupplicantState.equals(SupplicantState.INACTIVE))
				{
					Log.d(TAG,log_tag+"SupplicantState.INACTIVE");				
				}																
				if (mSupplicantState.equals(SupplicantState.INTERFACE_DISABLED ))
				{
					Log.d(TAG,log_tag+"SupplicantState.INTERFACE_DISABLED ");
		}
				if (mSupplicantState.equals(SupplicantState.INVALID ))
				{
					Log.d(TAG,log_tag+"SupplicantState.INVALID ");
				}																
				if (mSupplicantState.equals(SupplicantState.SCANNING))
				{
					Log.d(TAG,log_tag+"SupplicantState.SCANNING");	

					synchronized (this) {
						if (!mWifiOffhandler.isStoped())
						{
							Log.d(TAG,log_tag2+"mWifiOffhandler Force Stop");
							wifiscan = true; 
							mWifiOffhandler.stop();
						}						
					}					
		}

				if (mSupplicantState.equals(SupplicantState.UNINITIALIZED ))
				{
					Log.d(TAG,log_tag+"SupplicantState.UNINITIALIZED ");
		}

			}
			else if (WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(action))
			{
				Log.d(TAG,log_tag+"WifiManager.NETWORK_STATE_CHANGED_ACTION ");

				NetworkInfo networkInfo = mConnManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
				if ( (networkInfo != null) && (networkInfo.isAvailable() == true) )
				{
					if (networkInfo.getState() == NetworkInfo.State.CONNECTED)
					{
						Log.e("@@@@@","join NETWORK_STATE_CONNECTED");
		}
					else if (networkInfo.getState() == NetworkInfo.State.CONNECTING)
					{
						Log.e("@@@@@","POPUP NETWORK_STATE_CONNECTING");
	}
					else if (networkInfo.getState() == NetworkInfo.State.DISCONNECTED)
					{
						Log.e("@@@@@","POPUP NETWORK_STATE_DISCONNECTED");				      
					}
					else if (networkInfo.getState() == NetworkInfo.State.DISCONNECTING)
					{
						Log.e("@@@@@","POPUP NETWORK_STATE_DISCONNECTING");
					}
					else if (networkInfo.getState() == NetworkInfo.State.SUSPENDED)
					{
						Log.e("@@@@@","POPUP NETWORK_STATE_SUSPENDED");
					}
					else if (networkInfo.getState() == NetworkInfo.State.UNKNOWN)
					{
						Log.e("@@@@@","POPUP NETWORK_STATE_UNKNOWN");
					}		
				}
			}
			else if (WifiManager.SCAN_RESULTS_AVAILABLE_ACTION.equals(action)) 
			{
				Log.d(TAG,log_tag+"WifiManager.SCAN_RESULTS_AVAILABLE_ACTION ");	
				Log.d(TAG,log_tag2+"mWifiOffhandler start ");					
				mWifiOffhandler.sleep(5000);
				mWifiOffhandler.start();
	}

	}
	};

	public class WifiOnOffLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop = true;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			String wifi_state;
			if (this.bStop == false) {
				switch(mWifiMgr.getWifiState())
				{
					case WifiManager.WIFI_STATE_ENABLED:
					case WifiManager.WIFI_STATE_ENABLING:
						wifi_state = getWifiStatus(WifiManager.WIFI_STATE_ENABLED);	
						InnerFactory.mComponent08.setText(wifi_state);
						InnerFactory.mComponent08.invalidate();															
						InnerFactory.mComponent08.setTextColor(getApplicationContext().getResources().getColor(R.color.red));
						setWifiControl(false);
						break;
					default:
						wifi_state = getWifiStatus(WifiManager.WIFI_STATE_DISABLED);
						InnerFactory.mComponent08.setText(wifi_state);
						InnerFactory.mComponent08.invalidate();															
						InnerFactory.mComponent08.setTextColor(getApplicationContext().getResources().getColor(R.color.red));
						setWifiControl(true);
						break;

			}
						}
			sendMessageDelayed(obtainMessage(2), 3000);
			this.bStop = false;			
		}

		public void sleep(long delayMillis) {
			synchronized (this) {
			this.removeMessages(2);
			sendMessageDelayed(obtainMessage(2), delayMillis);
					}
						}

		public boolean isStoped() {
			synchronized (this) {
			return this.bStop;
			}
					}

		public void stop() {
			synchronized (this) {
			this.bStop = true;
			this.removeMessages(2);
			}
				}

		private void start() {
			synchronized (this) {
			this.bStop = false;	
			}
				}
	};

	public class WifiOffLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop = true;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
//			Log.d(TAG, "handleMessage");
			synchronized (this) {
			if (this.bStop == false) {							
				setWifiControl(false);				
				wifiscan = false; 													
			}
			super.handleMessage(msg);
			this.bStop = true;
			}
		}

		public void sleep(long delayMillis) {
			synchronized (this) {
			this.removeMessages(11);
			sendMessageDelayed(obtainMessage(11), delayMillis);
			}
			}

		public boolean isStoped() {
			synchronized (this) {
			return this.bStop;
			}
		}

		public void stop() {
			synchronized (this) {
			this.bStop = true;
			this.removeMessages(11);
			}
		}
					
		private void start() {
			synchronized (this) {
			this.bStop = false;	
			}
		}
	};

	public class WifiOnLoopHandler extends Handler {
		private int count = 0;
		private boolean bStop = true;
		private boolean mFLAG = false;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handleMessage" + msg.what);
			synchronized (this) {
			if (this.bStop == false) {				
				setWifiControl(true);				
				wifiscan = true; 					
			}
			super.handleMessage(msg);
			this.bStop = true;
			}
					}

		public void sleep(long delayMillis) {
			synchronized (this) {
			this.removeMessages(12);
			sendMessageDelayed(obtainMessage(12), delayMillis);
					}
				}

		public boolean isStoped() {
			synchronized (this) {
			return this.bStop;
			}
		}

		public void stop() {
			synchronized (this) {
			this.bStop = true;
			this.removeMessages(12);
					}	
				}

		private void start() {
			synchronized (this) {
			this.bStop = false;
			}
		}
	};

	/*
	 * ***********************************************************
	 * Bluetooth
	 */

	// add zsani2 method
	private void registerBTInfo() {

			IntentFilter mIntentFilter;
			mIntentFilter = new IntentFilter();
			mIntentFilter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
			registerReceiver(mBTReceiver, mIntentFilter);
	}

	private void unregisterBTInfo() {
			unregisterReceiver(mBTReceiver);
	}

	public String getBluetoothStatus(int nStatus) {
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& strProduct.equals("csd")) {
		if (Log.getTmpCSD()) return "";
		if (Log.getCSD() || !Log.getTJ()){				
			
			String szMessage = "OTHER STATE";
			switch (nStatus) {
			case BluetoothAdapter.STATE_ON:
				return szMessage = "OK(ON)";
			case BluetoothAdapter.STATE_OFF:
				return szMessage = "OK(OFF)";
			case BluetoothAdapter.STATE_TURNING_ON:
				return szMessage = "Waiting ON";
			case BluetoothAdapter.STATE_TURNING_OFF:
				return szMessage = "Waiting OFF";
			case BluetoothAdapter.ERROR:
				return szMessage = "NG(Error)";
			default:
				return szMessage;
			}
		}
		return "";
	}

	private void updateBluetoothInfo() {
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& strProduct.equals("csd")) {
		if (Log.getTmpCSD()) return;
		
		if (Log.getCSD() || !Log.getTJ()){					
			
			int status;
			Log.d(TAG, "updateBTInfo ++");

			if (null != mBluetoothAdapter)
				status = mBluetoothAdapter.getState();
			else
				status = BluetoothAdapter.ERROR;
			
			//BTWIIF++
			InnerFactory.mComponent09.setText(getBluetoothStatus(status)); 
			if (status == BluetoothAdapter.ERROR && mWifiMgr.getWifiState() == WifiManager.WIFI_STATE_ENABLED)
			{
				Log.d(TAG,"BTWIIF: WIFI : OK , BT : NG => BT Turning On...");
				mBluetoothAdapter.enable();
			}
			//BTWIFI--
			
			if (mLoopHandler.mFLAG) {
				InnerFactory.mComponent09.setTextColor(getApplicationContext()
						.getResources().getColor(R.color.skyblue));
				//BTWIFI mBluetoothAdapter.enable();
			} else {
				InnerFactory.mComponent09.setTextColor(getApplicationContext()
						.getResources().getColor(R.color.red));
				//BTWIFI mBluetoothAdapter.disable();
			}
		}
	}

	public boolean mBTLoopCond = false;
	public boolean mOnGoingBTTest = false;

	BroadcastReceiver mBTReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			// Log.d(TAG, "intent.getAction=" + intent.getAction());
//BTWIFI++			
//			if (mOnGoingBTTest == true) {
//				String action = intent.getAction();
//
//				if (BluetoothAdapter.ACTION_STATE_CHANGED.equals(action)) {
//					int bt_status = intent.getIntExtra(
//							BluetoothAdapter.EXTRA_STATE,
//							BluetoothAdapter.ERROR);
//					// if(bt_status == BluetoothAdapter.STATE_TURNING_ON ||
//					// bt_status == BluetoothAdapter.STATE_ON)
//					if (bt_status == BluetoothAdapter.STATE_ON) {
//						Log.d(TAG,
//								log_tag
//										+ "starting to change BLUETOOTH ON ---> OFF operation");
//						mBTLoopCond = true;
//					}
//					// else if(bt_status == BluetoothAdapter.STATE_TURNING_OFF
//					// || bt_status == BluetoothAdapter.STATE_OFF)
//					else if (bt_status == BluetoothAdapter.STATE_OFF) {
//						Log.d(TAG,
//								log_tag
//										+ "starting to change BLUETOOTH OFF ---> ON operation");
//						mBTLoopCond = true;
//					}
//					InnerFactory.mComponent09
//							.setText(getBluetoothStatus(bt_status));
//
//					Log.d(TAG,
//							log_tag
//									+ "Current BLUETOOTH State = "
//									+ getBluetoothStatus(intent.getIntExtra(
//											BluetoothAdapter.EXTRA_STATE,
//											BluetoothAdapter.ERROR)));
//				}
//
//				Log.d(TAG,
//						log_tag
//								+ "check loop cycle reliability ---> BLUETOOTH ON/OFF ["
//								+ mBTLoopCond + "]");
//
//				if (mBTLoopCond == true) {
//					mBTLoopCond = false;
//					Log.d(TAG, log_tag + "mBTLoop done.");
//					mLoopHandler.sleep(FREQUENCY);
//					mOnGoingBTTest = false;
//					Log.d(TAG, log_tag + "end loop() count["
//							+ mLoopHandler.count + "]"
//							+ " entering loop after 5sec.");
//				}
//			}
//BTWIFI--			
		}
	};

	/*
	 * ***********************************************************
	 * Temperature
	 */
	private void updateTemperature() {
		if (mLoopHandler.mFLAG) {
			InnerFactory.mComponent10.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.skyblue));
			InnerFactory.mComponent10.setText(mTempObj.readTemperature());
		} else {
			InnerFactory.mComponent10.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.red));
			InnerFactory.mComponent10.setText(mTempObj.readTemperature());
		}
		InnerFactory.mComponent10.invalidate();
	}

	/*
	 * ***********************************************************
	 * Remocon
	 */
	boolean FLAG_COLOR_REMOCON = true;
	
	public void Senddata_DAMRMC(byte cmd ,byte[] buffer,byte len) {

		Intent intent = new Intent();
		intent.setAction("CSD.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", buffer);		
		intent.putExtra("leng",len);
		sendBroadcast(intent);
				
	}	

	private void updateRemocon() {
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))&& strProduct.equals("csd")) {
		int result = 0;
		// InnerFactory.mComponent11.setText(mRemoconObj.reserveASongNumberThroughRMC());
		byte[] pBufferIR = new byte[1];

		pBufferIR[0] = (byte) (0x31 + (mLoopHandler.count % 4));
		int ir = pBufferIR[0];
		//int result = TDMKMisc_Service.IR_Send(ir);
		Senddata_DAMRMC((byte)1, pBufferIR,(byte)1);

			if (mLoopHandler.mFLAG) {
				InnerFactory.mComponent11.setTextColor(getApplicationContext()
						.getResources().getColor(R.color.skyblue));
			} else {
				InnerFactory.mComponent11.setTextColor(getApplicationContext()
						.getResources().getColor(R.color.red));
			}
			
			// int result = 0;
			InnerFactory.mComponent11.setText("Send Code - "
					+ String.format("0x%x", pBufferIR[0])
					+ (result == 0 ? "(OK)" : "(NG)"));
			InnerFactory.mComponent11.invalidate();		
		}

	/*
	 * ***********************************************************
	 * Battery
	 */
	private int mBattery_LEVEL = 0;
	private int mBattery_SCALE = 0;
	private int mBattery_RATIO = 0;
	private int mBattery_VOLT = 0;

	private void updateBattery() {

		float fVolt = mBattery_VOLT;

		InnerFactory.mComponent12.setText("LEVEL : " + mBattery_LEVEL + " ("
				+ mBattery_RATIO + "%) " + String.format("%.3f", fVolt / 1000)
				+ "Volt");

		if (mLoopHandler.mFLAG) {
			InnerFactory.mComponent12.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.skyblue));
		} else {
			InnerFactory.mComponent12.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.red));
		}

		InnerFactory.mComponent12.invalidate();
		Log.d(TAG, "LEVEL : " + mBattery_LEVEL + " (" + mBattery_RATIO + "%) "
				+ String.format("%.3f", fVolt / 1000) + "v");
	}

	private void registerBatteryInfo() {
		IntentFilter filter = new IntentFilter();
		filter.addAction(Intent.ACTION_BATTERY_CHANGED);
		registerReceiver(mBatteryReciver, filter);
	}

	private void unregisterBatteryInfo() {
		unregisterReceiver(mBatteryReciver);
	}

	BroadcastReceiver mBatteryReciver = new BroadcastReceiver() {
		public void onReceive(Context context, Intent intent) {
			String action = intent.getAction();
			Log.d(TAG, "mBatteryReciver.action=" + action);
			if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
				onBatteryChanged(intent);
			}
		}

		public void onBatteryChanged(Intent intent) {
			Log.d(TAG, "mBatteryReciver.onBatteryChanged()");
			if (intent.getBooleanExtra(BatteryManager.EXTRA_PRESENT, false) == false) {
				// InnerBattery.mComponents[0].setText("배터�??�음");
				return;
			}
			mBattery_SCALE = intent
					.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
			mBattery_LEVEL = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
			mBattery_RATIO = mBattery_LEVEL * 100 / mBattery_SCALE;
			mBattery_VOLT = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);
		}
	};

	/*
	 * ***********************************************************
	 * NFC
	 */
	private void updateUSBNfc() {
		
		if (mLoopHandler.mFLAG) {
			InnerFactory.mComponent07.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.skyblue));
		} else {
			InnerFactory.mComponent07.setTextColor(getApplicationContext()
					.getResources().getColor(R.color.red));
		}
		
		// int result = 0;
		
		if (Log.getTmpCSD())
		{			
			try {
				if (null != TJService && 0 == TJService.GetUsbNfcStatus())
				{
					InnerFactory.mComponent07.setText("NFC(OK)");
					InnerFactory.mComponent07.invalidate();		
					
					return;
				}
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	    	
		}
		InnerFactory.mComponent07.setText("NFC(NG)");
		InnerFactory.mComponent07.invalidate();		
		
	}		

	/*
	 * ***********************************************************
	 * G-Sensor
	 */
//	private void updateGSensor() {
////		if (strManufacturer.equalsIgnoreCase("TJMedia")) {
//		if (!Log.getTJ()){
//			if (mLoopHandler.mFLAG) {
//				InnerFactory.mComponent13.setTextColor(getApplicationContext()
//						.getResources().getColor(R.color.skyblue));
//			} else {
//				InnerFactory.mComponent13.setTextColor(getApplicationContext()
//						.getResources().getColor(R.color.red));
//			}
//		}
//	}

//	private Sensor sensorGrav;
//	private SensorManager mSensorManager;
//	private List<Sensor> mSensor;

//	private void registerSensor() {
////		if (strManufacturer.equalsIgnoreCase("TJMedia")) {
//		if (!Log.getTJ()){
//			mSensorManager.registerListener(AccelatorSensor, sensorGrav,
//					SensorManager.SENSOR_DELAY_UI);
//		}
//	}

//	private void unRegisterSensor() {
////		if (strManufacturer.equalsIgnoreCase("TJMedia")) {
//		if (!Log.getTJ()){
//			mSensorManager.unregisterListener(AccelatorSensor);
//		}
//	}

//	public float[] mGravity = new float[3];
//	final float GRAVITY_EARTH = 9.80665f;
//	final float LSG = 64.0f;
//	final float SENSOR_DIVIDER = GRAVITY_EARTH / LSG;
//
//	SensorEventListener AccelatorSensor = new SensorEventListener() {
//		public void onSensorChanged(SensorEvent event) {
//			// TODO Auto-generated method stub
//			switch (event.sensor.getType()) {
//			case Sensor.TYPE_ACCELEROMETER:
//				mGravity = event.values;
//				if (mGravity != null) {
//					InnerFactory.mComponent13.setText(""
//							+ String.format("%.1f", mGravity[0])
//							+ ", "
//							+ String.format("%.1f", mGravity[1])
//							+ ", "
//							+ String.format("%.1f", mGravity[2])
//							+ " ("
//							+ String.format("%.1f",
//									(mGravity[0] / SENSOR_DIVIDER))
//							+ ","
//							+ String.format("%.1f",
//									(mGravity[1] / SENSOR_DIVIDER))
//							+ ","
//							+ String.format("%.1f",
//									(mGravity[2] / SENSOR_DIVIDER)) + ")");
//				}
//				break;
//			}
//		}
//
//		public void onAccuracyChanged(Sensor sensor, int accuracy) {
//			// TODO Auto-generated method stub
//		}
//	};

	/*
	 * ***********************************************************
	 * Camera
	 */
	private void updateCamera() {
	}

	android.hardware.Camera mCamera;
	private TJCameraView mPreview;

	private void initCameraViewer() {
		mCamera = TJCameraView.getCameraInstance();
		SystemClock.sleep(100);
		if (mCamera != null) {
			mPreview = new TJCameraView(this, mCamera);
			InnerFactory.mComponent15.addView(mPreview, 480, 320);
		} else {
			ToastManager.showToast(getApplicationContext(),
					"[ERROR] Camera Open fail!!!", Toast.LENGTH_LONG);
		}
	}

	/*
	 * ***********************************************************
	 * Audio -
	 */
//	private void updateAudio() {
//		if (mLoopHandler.count < 0)
//			return;
//
//		// if (mLoopHandler.mFLAG) {
//		// InnerFactory.mComponent06.setTextColor(getApplicationContext().getResources().getColor(R.color.skyblue));
//		// } else {
//		// InnerFactory.mComponent06.setTextColor(getApplicationContext().getResources().getColor(R.color.red));
//		// }
//		// if (FLAG_AUDIO_DELAY) {
//		// return;
//		// }
//		mPoolManger.play(SoundPoolManager.SE_TOUCH);
//		/*
//		 * if (!mPlayer.isPlaying()) { mPlayer.start();
//		 * 
//		 * // InnerFactory.mComponent06.setTextColor(getApplicationContext().
//		 * getResources().getColor(R.color.skyblue)); //
//		 * InnerFactory.mComponent06.setText("PLAY"); }
//		 */
//	}
//
//	private MediaPlayer mPlayer = new MediaPlayer();
//	boolean FLAG_AUDIO_DELAY = false;
//
//	private void initMediaTest() {
//		// mPlayer = MediaPlayer.create(getApplicationContext(), R.raw.all);
//		mPlayer = MediaPlayer.create(getApplicationContext(),
//				SoundPoolManager.URI_TOUCH);
//		mPlayer.setOnCompletionListener(mOnCompleteListener);
//	}
//
//	MediaPlayer.OnCompletionListener mOnCompleteListener = new MediaPlayer.OnCompletionListener() {
//		@Override
//		public void onCompletion(MediaPlayer mp) {
//			// TODO Auto-generated method stub
//			Log.d(TAG, "mOnCompleteListener");
//			// FLAG_AUDIO_DELAY = true;
//			mPlayer.stop();
//			// InnerFactory.mComponent06.setText("STOP");
//			try {
//				mPlayer.prepare();
//			} catch (IllegalStateException e) {
//				Log.e(TAG, e.toString());
//			} catch (Exception e) {
//				Log.e(TAG, e.toString());
//			}
//			// mPlayerHandler.postDelayed(mPlayerRunnable, 2000);
//		}
//	};
//
//	Handler mPlayerHandler = new Handler();
//	Runnable mPlayerRunnable = new Runnable() {
//		@Override
//		public void run() {
//			// TODO Auto-generated method stub
//			FLAG_AUDIO_DELAY = false;
//		}
//	};

	static class InnerFactory {

		private static TextView mComponent00; // Device Tool Version

		private static TextView mComponent01; // LED
		private static TextView mComponent02; // Backlight
		private static TextView mComponent03; // Camera Flash
		private static TextView mComponent04; // Security
		private static TextView mComponent05; // USB

		private static TextView mComponent06; // SDCard
		private static TextView mComponent07; // NFC
		private static TextView mComponent08; // Wifi
		private static TextView mComponent09; // Bluetooth
		private static TextView mComponent10; // Temperature

		private static TextView mComponent11; // Remocon
		private static TextView mComponent12; // Battery
		private static TextView mComponent13; // G-Sensor
		private static TextView mComponent14; // Camera
		private static TextView mComponent16; // Counter

		private static TextView mComponent17; // Volume
		// private static TextView mComponent99; // None

		private static FrameLayout mComponent15; // CameraViewer
		private static View mCSD_LayOut;
		private static View mTMFP_LayOut;
		private static View mCSDTMFP_LayOut;		
		
		private static Button mConsole;	//input
		private static Button mWifi;	//input
		
		private static EditText mConsoleInput;	//input
		private static TextView mConsoleOutput;	//output
		private static TextView mConsoleOutput2;	//output
	}

}
