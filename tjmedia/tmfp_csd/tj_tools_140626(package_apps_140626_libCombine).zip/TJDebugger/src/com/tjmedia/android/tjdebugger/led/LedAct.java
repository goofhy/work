package com.tjmedia.android.tjdebugger.led;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Toast;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;
import com.tjmedia.android.tjdebugger.common.SoundPoolManager;
import com.tjmedia.android.tjdebugger.common.ToastManager;
//import com.tjmedia.tdmk.java_client.TDMKMisc_Service;

/**
 * 
 * Desc : 
 * @Company : TJMedia. Inc
 * @Author  : 
 * @Date    :  
 * @History : 
 * @MenuTree
 * 
 *
 */

public class LedAct extends Activity {   
   
	private static final String TAG = "LedAct"; 	

	Button mTitleExit;
	SoundPoolManager mPoolManger;
	String strManufacturer = android.os.Build.MANUFACTURER;
	String strProduct = android.os.Build.HARDWARE;
	byte gBright = 5;
	byte  glastledcmd = -1;
	byte  glastledled = -1;
	byte  glastledbright = -1;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.led_main);    
        initObjInfo();
        initViewID();
    }
	
	protected void onStart() {
		super.onStart();
		Log.d(TAG, "onStart()");

	}

	protected void onResume() {
		super.onResume();
		Log.d(TAG, "onResume()");
	}

	protected void onPause() {
		super.onPause();
		Log.d(TAG, "onPause()");
	}

	protected void onStop() {
		super.onStop();
		Log.d(TAG, "onStop()");
	}

	protected void onDestroy() {
		super.onDestroy();
		Log.d(TAG, "onDestroy()");
		mLoopHandler.stop();
		releaseAllLeds();
	}
	
	public void onBackPressed() {
		Log.d(TAG, "onBackPressed()");
		if(Const.DEBUG) finish();
	}
	
	private void initObjInfo() {
	}
    
	public ArrayAdapter<String> mAdapter;
	ArrayList<String> mItem;
	void initViewID() {
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		LED.mComponet01 = (ListView) findViewById(R.id.Led_main_ListView);
		
		LED.mComponetBar = (SeekBar) findViewById(R.id.Led_main_dialog_seekBar1);
		LED.mComponetBar.setMax(32);
		
		LED.mComponet02 = (Button) findViewById(R.id.Led_main_index02);
		LED.mComponet03 = (Button) findViewById(R.id.Led_main_index03);
		LED.mComponet04 = (Button) findViewById(R.id.Led_main_index04);
//		LED.mComponet05 = (Button) findViewById(R.id.Led_main_index05);
		LED.mComponet06 = (Button) findViewById(R.id.Led_main_index06);
		LED.mComponet07 = (Button) findViewById(R.id.Led_main_index07);
		LED.mComponet08 = (Button) findViewById(R.id.Led_main_index08);
		LED.mComponet09 = (Button) findViewById(R.id.Led_main_index09);
		
		LED.mComponet010 = (Button) findViewById(R.id.Led_main_index010);
		LED.mComponet011 = (Button) findViewById(R.id.Led_main_index011);		
		LED.mComponet012 = (Button) findViewById(R.id.Led_main_index012);
		LED.mComponet013 = (Button) findViewById(R.id.Led_main_index013);
		
		LED.mComponet020 = (Button) findViewById(R.id.Led_main_index020);
		LED.mComponet021 = (Button) findViewById(R.id.Led_main_index021);
		LED.mComponet022 = (Button) findViewById(R.id.Led_main_index022);
		LED.mComponet023 = (Button) findViewById(R.id.Led_main_index023);		
		LED.mComponet024 = (Button) findViewById(R.id.Led_main_index024);
		LED.mComponet025 = (Button) findViewById(R.id.Led_main_index025);
		LED.mComponet026 = (Button) findViewById(R.id.Led_main_index026);
		LED.mComponet027 = (Button) findViewById(R.id.Led_main_index027);
		LED.mComponet028 = (Button) findViewById(R.id.Led_main_index028);
		
		LED.mComponet030 = (Button) findViewById(R.id.Led_main_index030);
		LED.mComponet031 = (Button) findViewById(R.id.Led_main_index031);
		LED.mComponet032 = (Button) findViewById(R.id.Led_main_index032);
		LED.mComponet033 = (Button) findViewById(R.id.Led_main_index033);		
		LED.mComponet034 = (Button) findViewById(R.id.Led_main_index034);
		LED.mComponet035 = (Button) findViewById(R.id.Led_main_index035);
		LED.mComponet036 = (Button) findViewById(R.id.Led_main_index036);
		LED.mComponet037 = (Button) findViewById(R.id.Led_main_index037);
		LED.mComponet038 = (Button) findViewById(R.id.Led_main_index038);
		
		LED.mComponet040 = (Button) findViewById(R.id.Led_main_index040);
		LED.mComponet048 = (Button) findViewById(R.id.Led_main_index048);

		
		
//		LED.mComponet11 = (EditText) findViewById(R.id.Led_main_index11);
		LED.mComponet10 = (RadioButton) findViewById(R.id.Led_main_dialog_Index_RG01);
		LED.mComponet11 = (RadioButton) findViewById(R.id.Led_main_dialog_Index_RG02);
		LED.mComponet10.setChecked(true);
		
		LED.mComponet12 = (Button) findViewById(R.id.Led_main_index12);
		LED.mComponet13 = (Button) findViewById(R.id.Led_main_index13);
		LED.mComponet02.setOnClickListener(mClickListener);
		LED.mComponet03.setOnClickListener(mClickListener);
		LED.mComponet04.setOnClickListener(mClickListener);
//		LED.mComponet05.setOnClickListener(mClickListener);
		LED.mComponet06.setOnClickListener(mClickListener);
		LED.mComponet07.setOnClickListener(mClickListener);
		LED.mComponet08.setOnClickListener(mClickListener);
		LED.mComponet09.setOnClickListener(mClickListener);

		LED.mComponet12.setOnClickListener(mClickListener);
		LED.mComponet13.setOnClickListener(mClickListener);
		
		LED.mComponet010.setOnClickListener(mClickListener);
		LED.mComponet011.setOnClickListener(mClickListener);
		LED.mComponet012.setOnClickListener(mClickListener);
		LED.mComponet013.setOnClickListener(mClickListener);
		
		LED.mComponet020.setOnClickListener(mClickListener);
		LED.mComponet021.setOnClickListener(mClickListener);
		LED.mComponet022.setOnClickListener(mClickListener);
		LED.mComponet023.setOnClickListener(mClickListener);		
		LED.mComponet024.setOnClickListener(mClickListener);
		LED.mComponet025.setOnClickListener(mClickListener);
		LED.mComponet026.setOnClickListener(mClickListener);
		LED.mComponet027.setOnClickListener(mClickListener);
		LED.mComponet028.setOnClickListener(mClickListener);
		
		LED.mComponet030.setOnClickListener(mClickListener);
		LED.mComponet031.setOnClickListener(mClickListener);
		LED.mComponet032.setOnClickListener(mClickListener);
		LED.mComponet033.setOnClickListener(mClickListener);		
		LED.mComponet034.setOnClickListener(mClickListener);
		LED.mComponet035.setOnClickListener(mClickListener);
		LED.mComponet036.setOnClickListener(mClickListener);
		LED.mComponet037.setOnClickListener(mClickListener);
		LED.mComponet038.setOnClickListener(mClickListener);
		
		LED.mComponet040.setOnClickListener(mClickListener);
		LED.mComponet048.setOnClickListener(mClickListener);	
				
		LED.mComponetBar.setProgress(gBright);
		
		

		if (Log.getTMFP())
		{
			LED.mCSD_LayOut = findViewById(R.id.linearLayout02);
			LED.mCSD_LayOut.setVisibility(View.INVISIBLE);			
		}
		else
		{
			LED.mTMFP_LayOut1 = findViewById(R.id.LinearLayout01);
			LED.mTMFP_LayOut2 = findViewById(R.id.linearLayout2);
			LED.mTMFP_LayOut3 = findViewById(R.id.linearLayout3);
			LED.mTMFP_LayOut1.setVisibility(View.INVISIBLE);
			LED.mTMFP_LayOut2.setVisibility(View.INVISIBLE);
			LED.mTMFP_LayOut3.setVisibility(View.INVISIBLE);
		}
		
		LED.mComponetBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				// TODO Auto-generated method stub
				gBright = (byte) seekBar.getProgress();
				if (gBright <= 0) gBright = 1;
				seekBar.setProgress(gBright);
				
				mItem.add(0, "LED 밝기:" + gBright);
				mAdapter.notifyDataSetChanged();				
				mListIndex++;
				synchronized (this) {
					if (glastledbright > 0)
					{
						senddata(glastledcmd, glastledled, gBright);
					}						
					
				}
				
			}
		});
		
		mItem = new ArrayList<String>();
		mAdapter = new ArrayAdapter<String>(getApplicationContext(),
				android.R.layout.simple_list_item_1, mItem);

		LED.mComponet01.setAdapter(mAdapter);
		if(mPoolManger == null) {
//			mPoolManger = new SoundPoolManager(getApplicationContext());
			mPoolManger = new SoundPoolManager(getApplicationContext());
		}		
	}
	
	private void setUpLETInfo(int index, int flag) {
		if (Log.getTMFP() || !Log.getTJ())
		{
			return;
		}
		switch (index) {
//			case TDMKMisc_Service.LED__WLAN:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__WLAN, flag);
////				TDMKMisc_Service.Finalize();
//				break;
//			case TDMKMisc_Service.LED__IR:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__IR, flag);
////				TDMKMisc_Service.Finalize();
//				break;
//			case TDMKMisc_Service.LED__BACK_KEY:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__BACK_KEY, flag);
////				TDMKMisc_Service.Finalize();
//				break;
//			case TDMKMisc_Service.LED__FLASH:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__FLASH, flag);
////				TDMKMisc_Service.Finalize();
//				break;
//			case TDMKMisc_Service.LED__HOME_KEY:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__HOME_KEY, flag);
////				TDMKMisc_Service.Finalize();
//				break;
//			case TDMKMisc_Service.LED__NFC:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__NFC, flag);
////				TDMKMisc_Service.Finalize();
//				break;
//			case TDMKMisc_Service.LED__REMOTE_KEY:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__REMOTE_KEY, flag);
////				TDMKMisc_Service.Finalize();
//				break;
//			case TDMKMisc_Service.LED__STOP_KEY:
////				TDMKMisc_Service.Initalize();
////				TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__STOP_KEY, flag);
////				TDMKMisc_Service.Finalize();
//				break;
			default:
				break;
		}
	}
	
	private void releaseAllLeds() {
		int flag = 0;
		if (Log.getTMFP() || !Log.getTJ())
		{
			return;
		}		
//		TDMKMisc_Service.Initalize();
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__WLAN, flag);
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__IR, flag);
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__BACK_KEY, flag);
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__FLASH, flag);
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__HOME_KEY, flag);
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__NFC, flag);
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__REMOTE_KEY, flag);
//		TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__STOP_KEY, flag);
//		TDMKMisc_Service.Finalize();
	}
	
	
	
	private long mListIndex = 0L;
	private int mWLAN = 0;
	private int mIR = 0;
	private int mBACK = 0;
	private int mFLASH = 0;
	private int mHOME = 0;
	private int mNFC = 0;
	private int mREMOTE= 0;
	private int mSTOP= 0;
	private byte[] mTMFP_LED= new byte[100];
	private View.OnClickListener mClickListener = new View.OnClickListener() {		
		public void onClick(View v) {
			mPoolManger.playTouchSe();
			switch (v.getId()) {
			case R.id.top_exit:
				finish();
				break;
			case R.id.Led_main_index02:
				setLedEvent(0);
				break;
			case R.id.Led_main_index03:
				setLedEvent(1);
				break;
			case R.id.Led_main_index04:
				setLedEvent(2);
				break;
//			case R.id.Led_main_index05:
//				setLedEvent(3);
//				break;
			case R.id.Led_main_index06:
				setLedEvent(3);
				break;
			case R.id.Led_main_index07:
				setLedEvent(4);
				break;
			case R.id.Led_main_index08:
				setLedEvent(5);
				break;
			case R.id.Led_main_index09:
				setLedEvent(6);
				break;
			
			case R.id.Led_main_index010:	setLedEvent(10);	break;
			case R.id.Led_main_index011:	setLedEvent(14);	break;
			case R.id.Led_main_index012:	setLedEvent(15);	break;
			case R.id.Led_main_index013:	setLedEvent(14); setLedEvent(15);	break;
			case R.id.Led_main_index020:	setLedEvent(20);	break;
			case R.id.Led_main_index021:	setLedEvent(21);	break;
			case R.id.Led_main_index022:	setLedEvent(22);	break;
			case R.id.Led_main_index023:	setLedEvent(23);	break;
			case R.id.Led_main_index024:	setLedEvent(24);	break;
			case R.id.Led_main_index025:	setLedEvent(25);	break;
			case R.id.Led_main_index026:	setLedEvent(26);	break;
			case R.id.Led_main_index027:	setLedEvent(27);	break;
			case R.id.Led_main_index028:	setLedEvent(28);	break;
			case R.id.Led_main_index030:	setLedEvent(30);	break;
			case R.id.Led_main_index031:	setLedEvent(31);	break;
			case R.id.Led_main_index032:	setLedEvent(32);	break;
			case R.id.Led_main_index033:	setLedEvent(33);	break;
			case R.id.Led_main_index034:	setLedEvent(34);	break;
			case R.id.Led_main_index035:	setLedEvent(35);	break;
			case R.id.Led_main_index036:	setLedEvent(36);	break;
			case R.id.Led_main_index037:	setLedEvent(37);	break;
			case R.id.Led_main_index038:	setLedEvent(38);	break;
			case R.id.Led_main_index040:	setLedEvent(40);	break;
			case R.id.Led_main_index048:	setLedEvent(48);	break;
				
			case R.id.Led_main_index12:
				if(LED.mComponet10.isChecked()) {
					Frequency = 500;
				} else {
					Frequency = 1000;
				}
				ToastManager.showToast(getApplicationContext(), "Aging Start", Toast.LENGTH_SHORT);
				mLoopHandler.start();
				break;
			case R.id.Led_main_index13:
				ToastManager.showToast(getApplicationContext(), "Aging Stop", Toast.LENGTH_SHORT);
				mLoopHandler.stop();
				break;
			default:
				break;
				
			}
		}
	};
	
	private byte[] nLedCount = new byte[3];
	
	public void setLedEvent(int key) {
		byte led = 0;
		byte bright = 0;
		String str = "";
		String colorstr = "";
				
		Log.d(TAG,"key "  + key);
//		if (!(strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia"))) {
		if (!Log.getTJ()){
			return;
		}
		
		if (key >= 10)
		{
			led = (byte) (mTMFP_LED[key] = mTMFP_LED[key] != 0 ? Const.OFF_LED : Const.ON_LED);
			if (led != Const.OFF_LED)
			{
				if (key == 28)
				{
					led = (byte)(nLedCount[0]%7 + 1);	
					nLedCount[0]++;
				}
				if (key == 38)
				{
					led = (byte)(nLedCount[1]%7 + 1);
					nLedCount[1]++;
				}
				if (key == 48)
				{
					led = (byte)(nLedCount[2]%7 + 1);
					nLedCount[2]++;
				}
			}
			bright = (byte) (led != Const.OFF_LED ? gBright : 0);
		}		
		switch (key) {
			case 0:
//				setUpLETInfo(TDMKMisc_Service.LED__WLAN, (mWLAN = mWLAN != 0 ? 0 : 1));
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mWLAN != 0 ? "WLAN ON" : "WLAN OFF") + "\n");
				mAdapter.notifyDataSetChanged();
				LED.mComponet02.setText(mWLAN != 0 ? getResources().getString(R.string.led_main_index22):
						getResources().getString(R.string.led_main_index02));
				mListIndex++;
				break;
			case 1:
//				setUpLETInfo(TDMKMisc_Service.LED__IR, (mIR = mIR != 0 ? 0 : 1));
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mIR != 0 ? "IR ON" : "IR OFF") + "\n");
				mAdapter.notifyDataSetChanged();
				LED.mComponet03.setText(mIR != 0 ? getResources().getString(R.string.led_main_index23):
					getResources().getString(R.string.led_main_index03));
				mListIndex++;
				break;
			case 2:
//				setUpLETInfo(TDMKMisc_Service.LED__BACK_KEY, (mBACK = mBACK != 0 ? 0 : 1));
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mBACK != 0 ? "BACK_K ON" : "BACK_K OFF") + "\n");
				mAdapter.notifyDataSetChanged();
				LED.mComponet04.setText(mBACK != 0 ? getResources().getString(R.string.led_main_index24):
					getResources().getString(R.string.led_main_index04));
				mListIndex++;
				break;
//			case 3:
//				setUpLETInfo(TDMKMisc_Service.LED__FLASH, (mFLASH = mFLASH != 0 ? 0 : 1));
//				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
//						+ (mFLASH != 0 ? "FLASH ON" : "FLASH OFF") + "\n");
//				mAdapter.notifyDataSetChanged();
//				LED.mComponet05.setText(mFLASH != 0 ? getResources().getString(R.string.led_main_index25):
//					getResources().getString(R.string.led_main_index05));
//				mListIndex++;
//				break;
			case 3:
//				setUpLETInfo(TDMKMisc_Service.LED__HOME_KEY, (mHOME = mHOME != 0 ? 0 : 1));
//				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
//						+ (mHOME != 0 ? "HOME ON" : "HOME OFF") + "\n");
//				mAdapter.notifyDataSetChanged();
//				LED.mComponet06.setText(mHOME != 0 ? getResources().getString(R.string.led_main_index26):
//					getResources().getString(R.string.led_main_index06));
//				mListIndex++;
				break;
			case 4:
//				setUpLETInfo(TDMKMisc_Service.LED__NFC, (mNFC = mNFC != 0 ? 0 : 1));
//				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
//						+ (mNFC != 0 ? "NFC ON" : "NFC OFF") + "\n");
//				mAdapter.notifyDataSetChanged();
//				LED.mComponet07.setText(mNFC != 0 ? getResources().getString(R.string.led_main_index27):
//					getResources().getString(R.string.led_main_index07));
//				mListIndex++;
				break;
			case 5:
//				setUpLETInfo(TDMKMisc_Service.LED__REMOTE_KEY, (mREMOTE = mREMOTE != 0 ? 0 : 1));
//				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
//						+ (mREMOTE != 0 ? "REMOTE ON" : "REMOTE OFF") + "\n");
//				mAdapter.notifyDataSetChanged();
//				LED.mComponet08.setText(mREMOTE != 0 ? getResources().getString(R.string.led_main_index28):
//					getResources().getString(R.string.led_main_index08));
//				mListIndex++;
				break;
			case 6:
//				setUpLETInfo(TDMKMisc_Service.LED__STOP_KEY, (mSTOP = mSTOP != 0 ? 0 : 1));
//				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
//						+ (mSTOP != 0 ? "STOP ON" : "STOP OFF") + "\n");
//				mAdapter.notifyDataSetChanged();
//				LED.mComponet09.setText(mSTOP != 0 ? getResources().getString(R.string.led_main_index29):
//					getResources().getString(R.string.led_main_index09));
//				mListIndex++;
				break;
				
			case 10:
				str = getResources().getString(R.string.led_main_index010);
				senddata(Const.BOTTOM_PCB_LED_ALL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;								
				break;		
				
			case 14:
				str = getResources().getString(R.string.led_main_index011);
				senddata(Const.BOTTOM_PCB_LED_LIVE_1_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;								
				break;	
				
			case 15:
				str = getResources().getString(R.string.led_main_index012);
				senddata(Const.BOTTOM_PCB_LED_LIVE_2_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;								
				break;					
				
			case 20:
				str = getResources().getString(R.string.led_main_index020);
				senddata(Const.LEFT_FRONT_PCB_LED_ALL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;								
				break;
			
			case 21:
				str = getResources().getString(R.string.led_main_index021);
				senddata(Const.LEFT_FRONT_PCB_LED_TEMPO_CTRL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();
				mListIndex++;								
				break;
			case 22:
				str = getResources().getString(R.string.led_main_index022);
				senddata(Const.LEFT_FRONT_PCB_LED_TEMPO_UP_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();
				mListIndex++;												
				break;
			case 23:
				str = getResources().getString(R.string.led_main_index023);
				senddata(Const.LEFT_FRONT_PCB_LED_TEMPO_CTRL_STAND_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();
				mListIndex++;																
				break;
			case 24:
				str = getResources().getString(R.string.led_main_index024);
				senddata(Const.LEFT_FRONT_PCB_LED_TEMPO_CTRL_DOWN_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;																
				
				break;
			case 25:
				str = getResources().getString(R.string.led_main_index025);
				senddata(Const.LEFT_FRONT_PCB_LED_RESERVED_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;																
				
				break;
			case 26:
				str = getResources().getString(R.string.led_main_index026);
				senddata(Const.LEFT_FRONT_PCB_LED_SCORE_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;				
				break;
			case 27:
				str = getResources().getString(R.string.led_main_index027);
				senddata(Const.LEFT_FRONT_PCB_LED_DAM_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;				
				break;
			case 28:
				str = getResources().getString(R.string.led_main_index028);
				senddata(Const.LEFT_BACK_PCB_LED_ALL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;								
				break;
			case 30:
				str = getResources().getString(R.string.led_main_index030);
				senddata(Const.RIGHT_FRONT_PCB_LED_ALL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				break;				
			case 31:
				str = getResources().getString(R.string.led_main_index031);
				senddata(Const.RIGHT_FRONT_PCB_LED_KEY_CTRL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
			case 32:
				str = getResources().getString(R.string.led_main_index032);
				senddata(Const.RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
			case 33:
				str = getResources().getString(R.string.led_main_index033);
				senddata(Const.RIGHT_FRONT_PCB_LED_KEY_BASE_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
			case 34:
				str = getResources().getString(R.string.led_main_index034);
				senddata(Const.RIGHT_FRONT_PCB_LED_KEY_B_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
			case 35:
				str = getResources().getString(R.string.led_main_index035);
				senddata(Const.RIGHT_FRONT_PCB_LED_START_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
			case 36:
				str = getResources().getString(R.string.led_main_index036);
				senddata(Const.RIGHT_FRONT_PCB_LED_STOP_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
			case 37:
				str = getResources().getString(R.string.led_main_index037);
				senddata(Const.RIGHT_FRONT_PCB_LED_MENU_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				break;
			case 38:
				str = getResources().getString(R.string.led_main_index038);
				senddata(Const.RIGHT_BACK_PCB_LED_ALL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;																
				break;				
			case 40:
				str = getResources().getString(R.string.led_main_index040);
				senddata(Const.LEFT_RIGHT_FRONT_PCB_LED_ALL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
			case 48:
				str = getResources().getString(R.string.led_main_index048);
				senddata(Const.LEFT_RIGHT_BACK_PCB_LED_ALL_CMD,led,bright);
				mItem.add(0, "LED TEST INFO[" + mListIndex + "] : "
						+ (mTMFP_LED[key] != 0 ? str + " ON" : str + " OFF") + "\n");
				mAdapter.notifyDataSetChanged();				
				mListIndex++;												
				
				break;
				
			default:
				break;
		}
	}
	
	public int Frequency = 1000;
	private LoopHandler_led mLoopHandler = new LoopHandler_led();
	
	public void loop() {
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")) && strProduct.equals("csd"))
		if (Log.getCSD())
			setLedEvent(mLoopHandler.count % 7);
//		if ((strManufacturer.equals("TJMedia") || strManufacturer.equals("tjmedia")) && strProduct.equals("fptm"))
		if (Log.getTMFP())
			setLedEvent(mLoopHandler.tmfpcount[mLoopHandler.count%mLoopHandler.tmfpcount.length]);
		mLoopHandler.count++;
		mLoopHandler.sleep(Frequency);
	}
	
	class LoopHandler_led extends Handler {
		private int count = 0;
		private byte [] tmfpcount = {10,21,22,23,24,25,26,27,28,31,32,33,34,35,36,37,38,48,20,30,40};
		private boolean bStop;

		@Override
		public void handleMessage(Message msg) {
			Log.d(TAG, "handleMessage");
			if (bStop == false) {
				loop();
			}
			super.handleMessage(msg);
		}

		private void sleep(long delayMillis) {
			this.removeMessages(0);
			sendMessageDelayed(obtainMessage(0), delayMillis);
		}

		private void stop() {
			bStop = true;
		}

		private void start() {
			bStop = false;
			loop();
		}
	};
	
	public void senddata(byte cmd, byte led, byte bright) {
		
		if (Log.getCSD()|| !Log.getTJ()) return;
		byte[] buffer = new byte[100];		
		buffer[0] = led;	//MODE
		buffer[1] = bright;
		
		if (glastledcmd == cmd && glastledbright == bright && glastledled == led)
		{			
			Log.d(TAG,"SKIP >> Equals, BeforCMD and AfterCMD");
			return;
		}
		glastledcmd = cmd;
		glastledbright = bright;
		glastledled = led;
		
		Intent intent = new Intent();
		intent.setAction("TMFP.DATA");
		intent.putExtra("cmd", cmd);
		intent.putExtra("data", buffer);		
		intent.putExtra("leng",(byte)2);		
		sendBroadcast(intent);
				
	}
	
	@Override
	public boolean onKeyDown(int KeyCode, KeyEvent event) {
		Log.d(TAG, "onKeyDown()");
		Log.d(TAG, "KeyCode = " + KeyCode);
		switch (KeyCode)
		{
			case 1: KeyCode = Const.KEYCODE_TMFP_TSPKEY6;	break;
			case 2: KeyCode = Const.KEYCODE_TMFP_TSPKEY4;	break;			
			case 4: KeyCode = Const.KEYCODE_TMFP_TSPKEY10;	break;
			case 28: KeyCode = Const.KEYCODE_TMFP_TSPKEY11;	break;
			case 82: KeyCode = Const.KEYCODE_TMFP_TSPKEY12;	break;
		}
		
		switch(KeyCode)
		{
			case Const.KEYCODE_TMFP_TSPKEY1:
			case Const.KEYCODE_TMFP_TSPKEY2:
			case Const.KEYCODE_TMFP_TSPKEY3:
			case Const.KEYCODE_TMFP_TSPKEY4:
			case Const.KEYCODE_TMFP_TSPKEY5:
			case Const.KEYCODE_TMFP_TSPKEY6:		
				KeyCode -= Const.KEYCODE_TMFP_TSPKEY2;
//				senddata((byte)(Const.LEFT_FRONT_PCB_LED_TEMPO_UP_CMD + KeyCode),Const.ON_LED,(byte)32);
				senddata((byte)(Const.LEFT_FRONT_PCB_LED_TEMPO_UP_CMD + KeyCode),Const.OFF_LED,(byte)0);
				break;
				
			case Const.KEYCODE_TMFP_TSPKEY7:
			case Const.KEYCODE_TMFP_TSPKEY8:
			case Const.KEYCODE_TMFP_TSPKEY9:
			case Const.KEYCODE_TMFP_TSPKEY10:
			case Const.KEYCODE_TMFP_TSPKEY11:
			case Const.KEYCODE_TMFP_TSPKEY12:		
				KeyCode -= Const.KEYCODE_TMFP_TSPKEY7;
//				senddata((byte)(Const.RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD + KeyCode),Const.ON_LED,(byte)32);
				senddata((byte)(Const.RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD + KeyCode),Const.OFF_LED,(byte)0);
				break;
				
		}
		return false;
	}
	
	@Override
	public boolean onKeyUp(int KeyCode, KeyEvent event) {
		Log.d(TAG, "onKeyUp()");
		Log.d(TAG, "KeyCode = " + KeyCode);
		
		switch (KeyCode)
		{
			case 1: KeyCode = Const.KEYCODE_TMFP_TSPKEY6;	break;
			case 2: KeyCode = Const.KEYCODE_TMFP_TSPKEY4;	break;			
			case 4: KeyCode = Const.KEYCODE_TMFP_TSPKEY10;	break;
			case 28: KeyCode = Const.KEYCODE_TMFP_TSPKEY11;	break;
			case 82: KeyCode = Const.KEYCODE_TMFP_TSPKEY12;	break;
		}
	    
		switch(KeyCode)
		{

			case Const.KEYCODE_TMFP_TSPKEY1:
			case Const.KEYCODE_TMFP_TSPKEY2:
			case Const.KEYCODE_TMFP_TSPKEY3:
			case Const.KEYCODE_TMFP_TSPKEY4:
			case Const.KEYCODE_TMFP_TSPKEY5:
			case Const.KEYCODE_TMFP_TSPKEY6:		
				KeyCode -= Const.KEYCODE_TMFP_TSPKEY2;
//				senddata((byte)(Const.LEFT_FRONT_PCB_LED_TEMPO_UP_CMD + KeyCode),Const.OFF_LED,(byte)0);
				senddata((byte)(Const.LEFT_FRONT_PCB_LED_TEMPO_UP_CMD + KeyCode),Const.ON_LED,(byte)32);
				break;
				
			case Const.KEYCODE_TMFP_TSPKEY7:
			case Const.KEYCODE_TMFP_TSPKEY8:
			case Const.KEYCODE_TMFP_TSPKEY9:
			case Const.KEYCODE_TMFP_TSPKEY10:
			case Const.KEYCODE_TMFP_TSPKEY11:
			case Const.KEYCODE_TMFP_TSPKEY12:		
				KeyCode -= Const.KEYCODE_TMFP_TSPKEY7;
//				senddata((byte)(Const.RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD + KeyCode),Const.OFF_LED,(byte)0);	
				senddata((byte)(Const.RIGHT_FRONT_PCB_LED_KEY_SHAP_CMD + KeyCode),Const.ON_LED,(byte)32);
				break;				
		}
		return false;
	}
	
	static class LED {
		// private static LogTextBox mComponet01;
		private static ListView 	mComponet01;
		private static SeekBar 		mComponetBar;
		
		private static Button 		mComponet02;
		private static Button 		mComponet03;
		private static Button 		mComponet04;
//		private static Button 		mComponet05;
		private static Button 		mComponet06;
		private static Button 		mComponet07;
		private static Button 		mComponet08;
		private static Button 		mComponet09;
		
		
		
		private static Button 		mComponet010;
		private static Button 		mComponet020;
		private static Button 		mComponet021;
		private static Button 		mComponet022;
		private static Button 		mComponet023;
		private static Button 		mComponet024;
		private static Button 		mComponet025;
		private static Button 		mComponet026;
		private static Button 		mComponet027;
		private static Button 		mComponet028;
				
		private static Button 		mComponet030;
		private static Button 		mComponet031;
		private static Button 		mComponet032;
		private static Button 		mComponet033;
		private static Button 		mComponet034;
		private static Button 		mComponet035;
		private static Button 		mComponet036;
		private static Button 		mComponet037;
		private static Button 		mComponet038;
		
		private static Button 		mComponet040;
		private static Button 		mComponet048;
		
		
		private static Button 		mComponet011;
		private static Button 		mComponet012;
		private static Button 		mComponet013;
		
		
		
//		private static EditText 	mComponet11;
		private static RadioButton 		mComponet10;
		private static RadioButton 		mComponet11;
		
		private static Button 		mComponet12;
		private static Button 		mComponet13;
		
		private static View 		mCSD_LayOut;
		private static View 		mTMFP_LayOut1;
		private static View 		mTMFP_LayOut2;
		private static View 		mTMFP_LayOut3;
	}
	
	
	/*
	 * ************************************************************
	 * Interface below methods
	 */
	public boolean isAllLedStatus(int var) {
		boolean result = true;
		int count = 0;
		if (Log.getTMFP() || !Log.getTJ())
		{
			return false;
		}
//		TDMKMisc_Service.Initalize();
		// return 0 == off, 1 == on, error is negative numbers.
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__WLAN, 			var) < 0)	count++;
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__IR, 					var) < 0)	count++;
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__BACK_KEY, 		var) < 0)	count++;
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__FLASH, 			var) < 0)	count++;
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__HOME_KEY, 		var) < 0)	count++;
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__NFC, 				var) < 0)	count++;
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__REMOTE_KEY, 	var) < 0)	count++;
//		if (TDMKMisc_Service.LED_SetOnOff(TDMKMisc_Service.LED__STOP_KEY, 		var) < 0)	count++;
		
//		TDMKMisc_Service.Finalize();
		if (count > 0) {
			result = false;
		}
		return result;
	}
	
}
	
	

