package com.tjmedia.android.tjdebugger.database;

import static android.provider.BaseColumns._ID;

public interface DBConst {

	/**
	 * Tabel List
	 * =======================================================================================================================================
	 * 		Table ID				Table 명						비고(ERP 모듈명)								개요
	 * =======================================================================================================================================
	 * 		TJ_S01  				카메라정보  					공통										카메라 옵션 설정값.
	 * 		
	 * =======================================================================================================================================
	 */
	
	//공통	
	public static final String _TABLENAME1 		= "TJ_S01";
	public static final String _TABLENAME2 		= "TJ_S02";

	public static final String TJ_S01_ID	 				= _ID;				
	public static final String TJ_S01_MODE 				= "_title";		// 일정명
	public static final String TJ_S01_FLASH 				= "_sdate";		// 시작일	ex) 1323522000000 2011-12-10
	public static final String TJ_S01_BALANCE			= "_edate";		// 종료일  ex) 	1323529200000 2011-12-11
	
	public static final String _CREATE1 = 
			"create table "			+ _TABLENAME1 +"("
			+ TJ_S01_ID				+ " integer primary key autoincrement not null, "
			+ TJ_S01_MODE			+ " text , "
			+ TJ_S01_FLASH			+ " text , "
			
//			+ TJ_S01_STIME			+ " text ,"
//			+ TJ_S01_ETIME			+ " text ,"
//			+ TJ_S01_COLOR			+ " text default '0', "
//			+ TJ_S01_FLAG			+ " text default 'N', "
			+ TJ_S01_BALANCE				+ " text default 'N');";
	
	//공통	
//	public static final String _TABLENAME1 		= "KPlan_S01";
//	public static final String _TABLENAME2 		= "KPlan_S02";
	public static final String _TRIGGER01 		= "FK_INSERT_DATE";

	public static final String P_S01_ID	 				= _ID;				
	public static final String P_S01_TITLE 				= "s_title";		// 일정명
	public static final String P_S01_SDATE 				= "s_sdate";		// 시작일	ex) 1323522000000 2011-12-10
	public static final String P_S01_EDATE 				= "s_edate";		// 종료일  ex) 	1323529200000 2011-12-11
	
	public static final String P_S01_STIME 				= "s_stime";		// 시작일	StringFormatter 18:20	
	public static final String P_S01_ETIME 				= "s_etime";		// 종료일  StringFormatter 04:20
	
	public static final String P_S01_COLOR				= "s_color";		// 색상
	
	public static final String P_S01_FLAG					= "s_flag";			// Flag(default N or Y)
	public static final String P_S01_REPEAT_EDATE 		= "s_repeat_edate";	// 종료일
	public static final String P_S01_REPEAT				= "s_repeat";		// 반복횟수
	
	public static final String P_S01_NM					= "s_nm";			// 이름 
	public static final String P_S01_CONTACT			= "s_contact";		// 연락처
	public static final String P_S01_MEMO				= "s_memo";			// 메모
	
	public static final String P_S01_PATTERN_DATES		= "s_pattern_dates";// 반복일자들	ex) 2011-11-03~04/2011-11-10~11/2011-11-17~18/
//	public static final String P_S01_FIRST_PATTERN_DATES= "s_first_pattern_dates";// 반복일자들	ex) 2011-11-03/2011-11-10/2011-11-17/
	public static final String P_S01_ALARM_MILLIS		= "s_alarm_millis";	// 알람 millis
	public static final String P_S01_ETC				= "s_etc";			// ETC(default N or Y)
	
	
	
	public static final String P_S02_ID					= _ID;				// "KPlan_S01" 테이블 _ID의 참조키
	public static final String P_S02_DATE				= "s_sdate";		// 저장된 반복 일자
	
	
	public static final String _CREATE1_B = 
			"create table "			+ _TABLENAME1 +"("
					+ P_S01_ID				+ " integer primary key autoincrement not null, "
					+ P_S01_TITLE			+ " text , "
					+ P_S01_SDATE			+ " text , "
					+ P_S01_EDATE			+ " text , "
					
		+ P_S01_STIME			+ " text ,"
		+ P_S01_ETIME			+ " text ,"
		
		+ P_S01_COLOR			+ " text default '0', "
		
		+ P_S01_FLAG			+ " text default 'N', "
		+ P_S01_REPEAT_EDATE	+ " text , "
		+ P_S01_REPEAT			+ " text , "
		
		+ P_S01_NM				+ " text ,"
		+ P_S01_CONTACT			+ " text ,"
		+ P_S01_MEMO			+ " text ,"
		
		+ P_S01_PATTERN_DATES	+ " text ,"
//		+ P_S01_FIRST_PATTERN_DATES	 " text ,"
+ P_S01_ALARM_MILLIS	+ " text ,"
+ P_S01_ETC				+ " text default 'N');";
	
	public static final String _CREATE2 = 
		"create table "			+ _TABLENAME2 +"("
		+ P_S02_ID				+ " integer primary key not null, "
		+ P_S02_DATE			+ " text );";
		
	
	public static final String _TriggerADD = 
		"CREATE TRIGGER "			+ _TRIGGER01 +" BEFORE INSERT ON " + _TABLENAME1 +" "
		+ " FOR EACH ROW "
		+ " BEGIN "
		+ " UPDATE metadata SET man_count = man_count - 1 WHERE old.gender = 1 "     
		+ " END ";
	/**************************************************************************************/
	
}
