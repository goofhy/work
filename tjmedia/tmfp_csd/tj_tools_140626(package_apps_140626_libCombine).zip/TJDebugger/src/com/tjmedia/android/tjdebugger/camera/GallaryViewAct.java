package com.tjmedia.android.tjdebugger.camera;

import java.io.FileNotFoundException;
import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore.Images;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.tjmedia.android.tjdebugger.R;
import com.tjmedia.android.tjdebugger.common.Const;
import com.tjmedia.android.tjdebugger.common.Log;

public class GallaryViewAct extends Activity {

	private static final String TAG = "GallaryViewAct";
	
	ImageView mImagview;
	TextView mText;
	Button mTitleExit;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gallary_view);
		Intent intent = getIntent();
		String str = intent.getStringExtra("uri");
		Log.d(TAG, "Uri = " + str);
		mImagview = (ImageView) findViewById(R.id.Gallary_View_Index01);
//		Bitmap bm;
//		try {
//			bm = Images.Media.getBitmap(getContentResolver(), Uri.parse(str));
//			mImagview.setImageBitmap(bm);
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
		Uri uri = Uri.parse(str);
		Log.d(TAG, "" + uri);
		
		mTitleExit = (Button)findViewById(R.id.top_exit);
		mTitleExit.setOnClickListener(mClickListener);
		
		mImagview.setImageURI(uri);
	}

	private View.OnClickListener mClickListener = new View.OnClickListener() 
	{		
		public void onClick(View v) 
		{
			switch (v.getId()) 
			{
				case R.id.top_exit:
					finish();
					break;
			}
		}
	};
	
}
